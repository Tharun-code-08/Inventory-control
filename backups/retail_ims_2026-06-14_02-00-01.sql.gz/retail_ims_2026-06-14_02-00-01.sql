--
-- PostgreSQL database dump
--

\restrict gitdrVZmdcmCbZ63QNmeNefNU3TtpIfpv9N2K9ljn797Zpg4qBtDobUlvAQBlmQ

-- Dumped from database version 15.18
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AlertType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AlertType" AS ENUM (
    'GOODS_RECEIPT_CREATED',
    'GOODS_RECEIPT_APPROVED',
    'GOODS_RECEIPT_REJECTED',
    'PURCHASE_ORDER_CREATED',
    'PURCHASE_ORDER_APPROVED',
    'PURCHASE_ORDER_REJECTED',
    'RFQ_CREATED',
    'RFQ_RESPONSE_RECEIVED',
    'RFQ_APPROVED',
    'RFQ_REJECTED',
    'SALES_QUOTATION_CREATED',
    'SALES_QUOTATION_APPROVED',
    'SALES_QUOTATION_REJECTED',
    'WAREHOUSE_TRANSFER_COMPLETED',
    'LOW_STOCK',
    'CRITICAL_STOCK',
    'NEGATIVE_STOCK_PREVENTION',
    'INVENTORY_ADJUSTMENT_COMPLETED',
    'WAREHOUSE_CAPACITY_ALERT',
    'NEW_DEVICE_LOGIN',
    'PASSWORD_CHANGED',
    'SESSION_REVOKED',
    'BIOMETRIC_LOGIN_ENABLED',
    'LOGIN_ATTEMPT_LOCKOUT',
    'SYSTEM_MAINTENANCE',
    'VERSION_UPDATE',
    'COMPANY_ANNOUNCEMENT',
    'FEATURE_RELEASE',
    'CONTRACT_EXPIRY',
    'RFQ_DEADLINE',
    'PO_OVERDUE'
);


ALTER TYPE public."AlertType" OWNER TO retail;

--
-- Name: ApprovalStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ApprovalStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."ApprovalStatus" OWNER TO retail;

--
-- Name: ApprovalType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ApprovalType" AS ENUM (
    'GOODS_RECEIPT',
    'PURCHASE_ORDER',
    'RFQ',
    'SALES_QUOTATION',
    'WAREHOUSE_TRANSFER',
    'INVENTORY_ADJUSTMENT'
);


ALTER TYPE public."ApprovalType" OWNER TO retail;

--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AuditAction" AS ENUM (
    'LOGIN',
    'LOGOUT',
    'LOGIN_FAILED',
    'MFA_ENABLED',
    'MFA_DISABLED',
    'PASSWORD_CHANGED',
    'CREATE_PRODUCT',
    'UPDATE_PRODUCT',
    'DELETE_PRODUCT',
    'CREATE_GR',
    'UPDATE_GR',
    'RECEIVE_GOODS',
    'TRANSFER_STOCK',
    'STOCK_ADJUSTMENT',
    'CREATE_ISSUE',
    'CREATE_PO',
    'UPDATE_PO',
    'CONFIRM_PO',
    'CANCEL_PO',
    'APPROVE_PO',
    'REJECT_PO',
    'APPROVE',
    'REJECT',
    'ESCALATE',
    'CREATE_USER',
    'UPDATE_USER',
    'DELETE_USER',
    'UPDATE_ROLE',
    'REVOKE_SESSION',
    'EXPORT_REPORT',
    'EXPORT_AUDIT',
    'VIEW_DASHBOARD',
    'DASHBOARD_CARD_CLICKED',
    'DASHBOARD_ACTION_TAKEN',
    'DELETE_DATA',
    'BULK_UPDATE',
    'CREATE',
    'UPDATE',
    'DELETE',
    'POST'
);


ALTER TYPE public."AuditAction" OWNER TO retail;

--
-- Name: AuditReason; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AuditReason" AS ENUM (
    'USER_NOT_FOUND',
    'INVALID_PASSWORD',
    'ACCOUNT_LOCKED',
    'DEVICE_BLOCKED',
    'ACCESS_DENIED',
    'MFA_FAILED',
    'SESSION_EXPIRED'
);


ALTER TYPE public."AuditReason" OWNER TO retail;

--
-- Name: AuditSeverity; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AuditSeverity" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."AuditSeverity" OWNER TO retail;

--
-- Name: AuthChallengePurpose; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AuthChallengePurpose" AS ENUM (
    'SIGNUP_MFA_ENROLL',
    'LOGIN_MFA_VERIFY'
);


ALTER TYPE public."AuthChallengePurpose" OWNER TO retail;

--
-- Name: BackupJobStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BackupJobStatus" AS ENUM (
    'PENDING',
    'RUNNING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."BackupJobStatus" OWNER TO retail;

--
-- Name: BackupProvider; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BackupProvider" AS ENUM (
    'MANUAL',
    'GOOGLE_DRIVE',
    'EMAIL'
);


ALTER TYPE public."BackupProvider" OWNER TO retail;

--
-- Name: BarcodeType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BarcodeType" AS ENUM (
    'EAN13',
    'UPC_A',
    'CODE128',
    'CODE39',
    'QR',
    'INTERNAL'
);


ALTER TYPE public."BarcodeType" OWNER TO retail;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO retail;

--
-- Name: BrandingMode; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BrandingMode" AS ENUM (
    'LIVE',
    'SNAPSHOT'
);


ALTER TYPE public."BrandingMode" OWNER TO retail;

--
-- Name: CostingMethod; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."CostingMethod" AS ENUM (
    'AVERAGE',
    'FIFO'
);


ALTER TYPE public."CostingMethod" OWNER TO retail;

--
-- Name: CreditNoteStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."CreditNoteStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'APPLIED',
    'VOID'
);


ALTER TYPE public."CreditNoteStatus" OWNER TO retail;

--
-- Name: DevicePlatform; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DevicePlatform" AS ENUM (
    'ANDROID',
    'IOS',
    'WEB'
);


ALTER TYPE public."DevicePlatform" OWNER TO retail;

--
-- Name: DocumentEmailStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentEmailStatus" AS ENUM (
    'PENDING_PDF',
    'PENDING_SEND',
    'SENT',
    'DELIVERED',
    'FAILED'
);


ALTER TYPE public."DocumentEmailStatus" OWNER TO retail;

--
-- Name: DocumentEmailTrigger; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentEmailTrigger" AS ENUM (
    'AUTO',
    'MANUAL',
    'RESEND'
);


ALTER TYPE public."DocumentEmailTrigger" OWNER TO retail;

--
-- Name: DocumentSeriesRestart; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentSeriesRestart" AS ENUM (
    'NONE',
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."DocumentSeriesRestart" OWNER TO retail;

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'DRAFT',
    'POSTED'
);


ALTER TYPE public."DocumentStatus" OWNER TO retail;

--
-- Name: EmailSenderStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."EmailSenderStatus" AS ENUM (
    'PENDING',
    'VERIFIED',
    'FAILED'
);


ALTER TYPE public."EmailSenderStatus" OWNER TO retail;

--
-- Name: EmailSenderType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."EmailSenderType" AS ENUM (
    'CUSTOM_DOMAIN',
    'PUBLIC_DOMAIN'
);


ALTER TYPE public."EmailSenderType" OWNER TO retail;

--
-- Name: FulfillmentStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."FulfillmentStatus" AS ENUM (
    'NONE',
    'PARTIAL',
    'FULL'
);


ALTER TYPE public."FulfillmentStatus" OWNER TO retail;

--
-- Name: GstSupplyType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."GstSupplyType" AS ENUM (
    'INTRA_STATE',
    'INTER_STATE'
);


ALTER TYPE public."GstSupplyType" OWNER TO retail;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'PARTIALLY_PAID',
    'PAID',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO retail;

--
-- Name: InwardShift; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."InwardShift" AS ENUM (
    'DAY_SHIFT',
    'NIGHT_SHIFT'
);


ALTER TYPE public."InwardShift" OWNER TO retail;

--
-- Name: LifecycleCampaignStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."LifecycleCampaignStatus" AS ENUM (
    'SCHEDULED',
    'SENT',
    'SKIPPED',
    'FAILED'
);


ALTER TYPE public."LifecycleCampaignStatus" OWNER TO retail;

--
-- Name: LifecycleStage; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."LifecycleStage" AS ENUM (
    'NEW',
    'ACTIVE',
    'ENGAGED',
    'AT_RISK',
    'RENEWAL_DUE',
    'EXPIRED',
    'TRIAL',
    'TRIAL_EXPIRED'
);


ALTER TYPE public."LifecycleStage" OWNER TO retail;

--
-- Name: LifecycleStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."LifecycleStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'OBSOLETE',
    'REPLACED'
);


ALTER TYPE public."LifecycleStatus" OWNER TO retail;

--
-- Name: MediaAssetType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."MediaAssetType" AS ENUM (
    'LOGO',
    'STAMP',
    'SIGNATURE',
    'LETTERHEAD',
    'WATERMARK'
);


ALTER TYPE public."MediaAssetType" OWNER TO retail;

--
-- Name: MfaMethod; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."MfaMethod" AS ENUM (
    'TOTP'
);


ALTER TYPE public."MfaMethod" OWNER TO retail;

--
-- Name: NotificationModule; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."NotificationModule" AS ENUM (
    'GOODS_RECEIPT',
    'PURCHASE_ORDER',
    'RFQ',
    'SALES_QUOTATION',
    'WAREHOUSE_TRANSFER',
    'INVENTORY',
    'SECURITY',
    'SYSTEM',
    'APPROVAL'
);


ALTER TYPE public."NotificationModule" OWNER TO retail;

--
-- Name: NotificationPriority; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."NotificationPriority" AS ENUM (
    'CRITICAL',
    'HIGH',
    'NORMAL',
    'LOW'
);


ALTER TYPE public."NotificationPriority" OWNER TO retail;

--
-- Name: NotificationStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."NotificationStatus" AS ENUM (
    'UNREAD',
    'READ',
    'DELETED'
);


ALTER TYPE public."NotificationStatus" OWNER TO retail;

--
-- Name: PasswordResetMethod; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PasswordResetMethod" AS ENUM (
    'OTP',
    'MAGIC_LINK'
);


ALTER TYPE public."PasswordResetMethod" OWNER TO retail;

--
-- Name: PlatformNotificationCategory; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PlatformNotificationCategory" AS ENUM (
    'REVENUE',
    'HEALTH',
    'SYSTEM'
);


ALTER TYPE public."PlatformNotificationCategory" OWNER TO retail;

--
-- Name: PlatformNotificationSeverity; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PlatformNotificationSeverity" AS ENUM (
    'CRITICAL',
    'HIGH',
    'WARNING',
    'INFO'
);


ALTER TYPE public."PlatformNotificationSeverity" OWNER TO retail;

--
-- Name: PurchaseOrderStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PurchaseOrderStatus" AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'CANCELLED'
);


ALTER TYPE public."PurchaseOrderStatus" OWNER TO retail;

--
-- Name: ReceiptSource; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ReceiptSource" AS ENUM (
    'PURCHASE_ORDER',
    'OUTSIDE'
);


ALTER TYPE public."ReceiptSource" OWNER TO retail;

--
-- Name: ReceiptType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ReceiptType" AS ENUM (
    'FULL',
    'PARTIAL'
);


ALTER TYPE public."ReceiptType" OWNER TO retail;

--
-- Name: RestoreJobStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."RestoreJobStatus" AS ENUM (
    'PENDING',
    'DRY_RUN_COMPLETED',
    'RUNNING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."RestoreJobStatus" OWNER TO retail;

--
-- Name: RestoreMode; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."RestoreMode" AS ENUM (
    'TENANT_REPLACE',
    'FULL_DB'
);


ALTER TYPE public."RestoreMode" OWNER TO retail;

--
-- Name: ReturnStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ReturnStatus" AS ENUM (
    'DRAFT',
    'POSTED',
    'SUBMITTED',
    'ACKNOWLEDGED',
    'DONE',
    'CANCELLED'
);


ALTER TYPE public."ReturnStatus" OWNER TO retail;

--
-- Name: RoleName; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."RoleName" AS ENUM (
    'OWNER',
    'ADMIN',
    'INVENTORY_MANAGER',
    'PURCHASE_MANAGER',
    'SALES',
    'EMPLOYEE',
    'WAREHOUSE_STAFF',
    'VIEWER',
    'VENDOR',
    'SHOP_USER'
);


ALTER TYPE public."RoleName" OWNER TO retail;

--
-- Name: SalesOrderStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SalesOrderStatus" AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'FULFILLED',
    'CLOSED',
    'CANCELLED'
);


ALTER TYPE public."SalesOrderStatus" OWNER TO retail;

--
-- Name: SalesQuotationStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SalesQuotationStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'ACCEPTED',
    'USER_REQUESTED',
    'CANCELLED',
    'CONVERTED'
);


ALTER TYPE public."SalesQuotationStatus" OWNER TO retail;

--
-- Name: ScanAction; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ScanAction" AS ENUM (
    'LOOKUP',
    'GOODS_RECEIPT',
    'GOODS_ISSUE',
    'STOCK_COUNT',
    'SALES_ORDER',
    'PURCHASE_ORDER',
    'STOCK_TRANSFER'
);


ALTER TYPE public."ScanAction" OWNER TO retail;

--
-- Name: ScanResult; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ScanResult" AS ENUM (
    'FOUND',
    'NOT_FOUND',
    'INVALID'
);


ALTER TYPE public."ScanResult" OWNER TO retail;

--
-- Name: ScanSource; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ScanSource" AS ENUM (
    'WEB',
    'MOBILE',
    'USB_SCANNER',
    'CAMERA',
    'API'
);


ALTER TYPE public."ScanSource" OWNER TO retail;

--
-- Name: StockCountStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."StockCountStatus" AS ENUM (
    'OPEN',
    'REVIEW',
    'APPROVED',
    'CANCELLED'
);


ALTER TYPE public."StockCountStatus" OWNER TO retail;

--
-- Name: SubscriptionPlan; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SubscriptionPlan" AS ENUM (
    'TRIAL',
    'PRO',
    'PLUS'
);


ALTER TYPE public."SubscriptionPlan" OWNER TO retail;

--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'CANCELLED',
    'SUSPENDED'
);


ALTER TYPE public."SubscriptionStatus" OWNER TO retail;

--
-- Name: SupplierBillStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SupplierBillStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'PARTIALLY_PAID',
    'PAID',
    'VOID'
);


ALTER TYPE public."SupplierBillStatus" OWNER TO retail;

--
-- Name: SupplierReturnReasonCode; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SupplierReturnReasonCode" AS ENUM (
    'DAMAGED',
    'WRONG_ITEM',
    'EXPIRED',
    'EXCESS'
);


ALTER TYPE public."SupplierReturnReasonCode" OWNER TO retail;

--
-- Name: TaxPreference; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."TaxPreference" AS ENUM (
    'TAXABLE',
    'NON_TAXABLE'
);


ALTER TYPE public."TaxPreference" OWNER TO retail;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."TransactionType" AS ENUM (
    'OPENING',
    'GOODS_RECEIPT',
    'GOODS_ISSUE',
    'DAMAGE',
    'ADJUSTMENT',
    'STOCK_TRANSFER_OUT',
    'STOCK_TRANSFER_IN'
);


ALTER TYPE public."TransactionType" OWNER TO retail;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO retail;

--
-- Name: alert_events; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.alert_events (
    id uuid NOT NULL,
    alert_type public."AlertType" NOT NULL,
    severity text DEFAULT 'MEDIUM'::text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    shop_id uuid,
    reference_type text,
    reference_id text,
    is_read boolean DEFAULT false NOT NULL,
    triggered_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp(6) with time zone
);


ALTER TABLE public.alert_events OWNER TO retail;

--
-- Name: approval_comments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.approval_comments (
    id uuid NOT NULL,
    approval_id uuid NOT NULL,
    user_id uuid NOT NULL,
    comment text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.approval_comments OWNER TO retail;

--
-- Name: approval_escalations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.approval_escalations (
    id uuid NOT NULL,
    approval_id uuid NOT NULL,
    escalated_to uuid NOT NULL,
    escalated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    reason text,
    resolved_at timestamp(6) with time zone
);


ALTER TABLE public.approval_escalations OWNER TO retail;

--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    requested_by uuid NOT NULL,
    assigned_to uuid NOT NULL,
    approval_type public."ApprovalType" NOT NULL,
    reference_id text NOT NULL,
    status public."ApprovalStatus" DEFAULT 'PENDING'::public."ApprovalStatus" NOT NULL,
    document_number text,
    amount numeric(14,2),
    description text,
    rejection_reason text,
    approved_at timestamp(6) with time zone,
    rejected_at timestamp(6) with time zone,
    required_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.approval_requests OWNER TO retail;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action public."AuditAction" NOT NULL,
    entity_type text,
    entity_id text,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    device_id text,
    metadata jsonb,
    reason public."AuditReason",
    severity public."AuditSeverity",
    request_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO retail;

--
-- Name: auth_challenges; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.auth_challenges (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    purpose public."AuthChallengePurpose" NOT NULL,
    token_hash text NOT NULL,
    totp_secret_encrypted text,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    requested_ip text,
    requested_user_agent text
);


ALTER TABLE public.auth_challenges OWNER TO retail;

--
-- Name: backup_artifacts; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.backup_artifacts (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    backup_job_id uuid,
    file_name text NOT NULL,
    storage_path text NOT NULL,
    file_size bigint NOT NULL,
    sha256 text NOT NULL,
    provider public."BackupProvider" NOT NULL,
    drive_file_id text,
    schema_version integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.backup_artifacts OWNER TO retail;

--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.backup_jobs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    status public."BackupJobStatus" DEFAULT 'PENDING'::public."BackupJobStatus" NOT NULL,
    provider public."BackupProvider" NOT NULL,
    error_message text,
    started_at timestamp(6) with time zone,
    completed_at timestamp(6) with time zone,
    created_by uuid,
    lifecycle_status public."LifecycleStatus" DEFAULT 'ACTIVE'::public."LifecycleStatus" NOT NULL,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.backup_jobs OWNER TO retail;

--
-- Name: backup_provider_credentials; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.backup_provider_credentials (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    provider public."BackupProvider" DEFAULT 'GOOGLE_DRIVE'::public."BackupProvider" NOT NULL,
    encrypted_tokens text NOT NULL,
    account_email text,
    drive_folder_id text,
    connected_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.backup_provider_credentials OWNER TO retail;

--
-- Name: barcode_audit_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_audit_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    barcode_id uuid,
    barcode text NOT NULL,
    product_id uuid,
    action text NOT NULL,
    detail jsonb,
    user_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.barcode_audit_logs OWNER TO retail;

--
-- Name: barcode_history; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_history (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    barcode text NOT NULL,
    old_product_id uuid,
    new_product_id uuid,
    user_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.barcode_history OWNER TO retail;

--
-- Name: barcode_print_jobs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_print_jobs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    template_id uuid NOT NULL,
    pdf_url text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    quantities jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    label_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.barcode_print_jobs OWNER TO retail;

--
-- Name: barcode_template_versions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_template_versions (
    id uuid NOT NULL,
    template_name text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    json_content jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid
);


ALTER TABLE public.barcode_template_versions OWNER TO retail;

--
-- Name: branding_profiles; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.branding_profiles (
    id uuid NOT NULL,
    branding_version integer DEFAULT 1 NOT NULL,
    logo_asset_id uuid,
    watermark_asset_id uuid,
    seal_asset_id uuid,
    signature_asset_id uuid,
    letterhead_asset_id uuid,
    footer_text text,
    email text,
    phone text,
    website text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.branding_profiles OWNER TO retail;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.companies (
    id uuid NOT NULL,
    company_code text NOT NULL,
    company_name text NOT NULL,
    address text,
    branding_profile_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    subscription_plan public."SubscriptionPlan" DEFAULT 'TRIAL'::public."SubscriptionPlan" NOT NULL,
    billing_cycle public."BillingCycle",
    subscription_status public."SubscriptionStatus" DEFAULT 'ACTIVE'::public."SubscriptionStatus" NOT NULL,
    trial_starts_at timestamp(6) with time zone,
    trial_ends_at timestamp(6) with time zone,
    subscription_ends_at timestamp(6) with time zone,
    platform_marketing_opt_out boolean DEFAULT false NOT NULL,
    razorpay_subscription_id text,
    paid_activated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.companies OWNER TO retail;

--
-- Name: company_engagement_snapshots; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.company_engagement_snapshots (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    lifecycle_stage public."LifecycleStage" NOT NULL,
    last_login_at timestamp(6) with time zone,
    login_count_30d integer DEFAULT 0 NOT NULL,
    features_used jsonb DEFAULT '{}'::jsonb NOT NULL,
    products_count integer DEFAULT 0 NOT NULL,
    inventory_txn_count integer DEFAULT 0 NOT NULL,
    team_members_count integer DEFAULT 0 NOT NULL,
    reports_generated integer DEFAULT 0 NOT NULL,
    trial_progress_pct integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.company_engagement_snapshots OWNER TO retail;

--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.company_settings (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.company_settings OWNER TO retail;

--
-- Name: contract_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.contract_header (
    id uuid NOT NULL,
    contract_number text NOT NULL,
    shop_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    rfq_id uuid,
    quotation_id uuid,
    title text NOT NULL,
    payment_terms text,
    start_date date NOT NULL,
    end_date date,
    notes text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.contract_header OWNER TO retail;

--
-- Name: contract_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.contract_items (
    id uuid NOT NULL,
    contract_id uuid NOT NULL,
    product_id uuid,
    description text,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.contract_items OWNER TO retail;

--
-- Name: cost_layers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.cost_layers (
    id uuid NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    gr_id uuid,
    ledger_id uuid,
    qty_remaining numeric(12,3) NOT NULL,
    qty_original numeric(12,3) NOT NULL,
    unit_cost numeric(14,4) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.cost_layers OWNER TO retail;

--
-- Name: credit_notes; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.credit_notes (
    id uuid NOT NULL,
    credit_number text NOT NULL,
    credit_date date NOT NULL,
    shop_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    invoice_id uuid,
    return_id uuid,
    status public."CreditNoteStatus" DEFAULT 'DRAFT'::public."CreditNoteStatus" NOT NULL,
    amount numeric(14,2) NOT NULL,
    applied_amount numeric(14,2) DEFAULT 0 NOT NULL,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.credit_notes OWNER TO retail;

--
-- Name: currencies; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.currencies (
    code text NOT NULL,
    name text NOT NULL,
    decimals integer DEFAULT 2 NOT NULL
);


ALTER TABLE public.currencies OWNER TO retail;

--
-- Name: customer_return_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.customer_return_items (
    id uuid NOT NULL,
    return_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL
);


ALTER TABLE public.customer_return_items OWNER TO retail;

--
-- Name: customer_returns; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.customer_returns (
    id uuid NOT NULL,
    return_number text NOT NULL,
    return_date date NOT NULL,
    shop_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    invoice_id uuid,
    sales_order_id uuid,
    reason text,
    remarks text,
    status public."ReturnStatus" DEFAULT 'DRAFT'::public."ReturnStatus" NOT NULL,
    total_value numeric(14,2) DEFAULT 0 NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.customer_returns OWNER TO retail;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.customers (
    id uuid NOT NULL,
    customer_code text NOT NULL,
    customer_name text NOT NULL,
    email text,
    phone text,
    tax_id text,
    pan text,
    street text,
    city text,
    state text,
    postal_code text,
    country text,
    shop_id uuid NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.customers OWNER TO retail;

--
-- Name: damaged_stock; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.damaged_stock (
    id uuid NOT NULL,
    damage_number text NOT NULL,
    damage_date date NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    damaged_quantity numeric(12,3) NOT NULL,
    reason text NOT NULL,
    remarks text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.damaged_stock OWNER TO retail;

--
-- Name: data_retention_config; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.data_retention_config (
    id uuid NOT NULL,
    entity text NOT NULL,
    retain_days integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.data_retention_config OWNER TO retail;

--
-- Name: device_registrations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.device_registrations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    device_id text NOT NULL,
    device_name text,
    platform public."DevicePlatform" NOT NULL,
    push_token text,
    app_version text,
    os_version text,
    is_active boolean DEFAULT true NOT NULL,
    last_active_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.device_registrations OWNER TO retail;

--
-- Name: document_email_outbox; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.document_email_outbox (
    id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    document_number text NOT NULL,
    template_id text NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid,
    recipient text NOT NULL,
    attachment_filename text,
    status public."DocumentEmailStatus" DEFAULT 'PENDING_PDF'::public."DocumentEmailStatus" NOT NULL,
    trigger public."DocumentEmailTrigger" DEFAULT 'MANUAL'::public."DocumentEmailTrigger" NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    last_error text,
    next_retry_at timestamp(6) with time zone,
    payload_json jsonb NOT NULL,
    sent_at timestamp(6) with time zone,
    sent_by_id uuid,
    message_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.document_email_outbox OWNER TO retail;

--
-- Name: document_sequences; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.document_sequences (
    id uuid NOT NULL,
    doc_type text NOT NULL,
    shop_id uuid NOT NULL,
    year_month text NOT NULL,
    last_seq integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.document_sequences OWNER TO retail;

--
-- Name: document_series_config; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.document_series_config (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid,
    doc_type text NOT NULL,
    module_label text NOT NULL,
    prefix text NOT NULL,
    starting_number integer DEFAULT 1 NOT NULL,
    pad_width integer DEFAULT 5 NOT NULL,
    restart_period public."DocumentSeriesRestart" DEFAULT 'NONE'::public."DocumentSeriesRestart" NOT NULL,
    shop_scoped boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    use_category_prefix boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.document_series_config OWNER TO retail;

--
-- Name: email_delivery_log; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_delivery_log (
    id uuid NOT NULL,
    template_id text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    recipient text NOT NULL,
    sent_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    click_count integer DEFAULT 0 NOT NULL,
    open_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.email_delivery_log OWNER TO retail;

--
-- Name: email_sender_domains; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_sender_domains (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    domain text NOT NULL,
    dkim_selector text NOT NULL,
    dkim_host text NOT NULL,
    dkim_value text NOT NULL,
    status public."EmailSenderStatus" DEFAULT 'PENDING'::public."EmailSenderStatus" NOT NULL,
    verified_at timestamp(6) with time zone,
    last_checked_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.email_sender_domains OWNER TO retail;

--
-- Name: email_sender_identities; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_sender_identities (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    domain_id uuid,
    display_name text NOT NULL,
    email text NOT NULL,
    sender_type public."EmailSenderType" NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    status public."EmailSenderStatus" DEFAULT 'PENDING'::public."EmailSenderStatus" NOT NULL,
    verified_at timestamp(6) with time zone,
    smtp_host text,
    smtp_port integer,
    smtp_secure boolean,
    smtp_user text,
    smtp_password_enc text,
    smtp_configured_at timestamp(6) with time zone,
    smtp_last_verified_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.email_sender_identities OWNER TO retail;

--
-- Name: email_sender_verifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_sender_verifications (
    id uuid NOT NULL,
    sender_id uuid NOT NULL,
    otp_hash text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.email_sender_verifications OWNER TO retail;

--
-- Name: fx_rates; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.fx_rates (
    id uuid NOT NULL,
    base text NOT NULL,
    quote text NOT NULL,
    rate numeric(18,8) NOT NULL,
    as_of timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.fx_rates OWNER TO retail;

--
-- Name: goods_issue_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_issue_header (
    id uuid NOT NULL,
    gi_number text NOT NULL,
    gi_date date NOT NULL,
    shop_id uuid NOT NULL,
    issue_reason text NOT NULL,
    issue_type text NOT NULL,
    other_reason text,
    remarks text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.goods_issue_header OWNER TO retail;

--
-- Name: goods_issue_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_issue_items (
    id uuid NOT NULL,
    gi_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    available_stock_snapshot numeric(12,3) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.goods_issue_items OWNER TO retail;

--
-- Name: goods_receipt_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_receipt_header (
    id uuid NOT NULL,
    gr_number text NOT NULL,
    gr_date date NOT NULL,
    shop_id uuid NOT NULL,
    supplier_name text NOT NULL,
    purchase_order_id uuid,
    receipt_type public."ReceiptType" DEFAULT 'FULL'::public."ReceiptType" NOT NULL,
    receipt_source public."ReceiptSource" DEFAULT 'PURCHASE_ORDER'::public."ReceiptSource" NOT NULL,
    inward_shift public."InwardShift",
    supplier_ref text,
    remarks text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.goods_receipt_header OWNER TO retail;

--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_receipt_items (
    id uuid NOT NULL,
    gr_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    purchase_rate numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    batch_number text,
    serial_number text,
    expiry_date date,
    storage_location_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.goods_receipt_items OWNER TO retail;

--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.idempotency_keys (
    id uuid NOT NULL,
    key text NOT NULL,
    scope text,
    result jsonb NOT NULL,
    user_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone
);


ALTER TABLE public.idempotency_keys OWNER TO retail;

--
-- Name: invoice_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.invoice_header (
    id uuid NOT NULL,
    invoice_number text NOT NULL,
    invoice_date date NOT NULL,
    sales_order_id uuid,
    customer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_value numeric(14,2) NOT NULL,
    paid_value numeric(14,2) DEFAULT 0 NOT NULL,
    due_date date,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.invoice_header OWNER TO retail;

--
-- Name: job_failures; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.job_failures (
    id uuid NOT NULL,
    queue text NOT NULL,
    job_name text NOT NULL,
    job_id text,
    data jsonb,
    error_name text,
    error_message text,
    stack text,
    attempts integer DEFAULT 0 NOT NULL,
    failed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.job_failures OWNER TO retail;

--
-- Name: lifecycle_campaign_enrollments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.lifecycle_campaign_enrollments (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    campaign_key text NOT NULL,
    scheduled_for timestamp(6) with time zone,
    sent_at timestamp(6) with time zone,
    status public."LifecycleCampaignStatus" DEFAULT 'SCHEDULED'::public."LifecycleCampaignStatus" NOT NULL,
    email_delivery_log_id uuid,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.lifecycle_campaign_enrollments OWNER TO retail;

--
-- Name: low_stock_alerts; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.low_stock_alerts (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    product_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    current_stock integer NOT NULL,
    min_stock integer NOT NULL,
    reorder_point integer NOT NULL,
    "alertLevel" text NOT NULL,
    notified boolean DEFAULT false NOT NULL,
    notified_at timestamp(6) with time zone,
    resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.low_stock_alerts OWNER TO retail;

--
-- Name: media_assets; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.media_assets (
    id uuid NOT NULL,
    company_id uuid,
    shop_id uuid,
    branding_profile_id uuid,
    type public."MediaAssetType" NOT NULL,
    asset_key text NOT NULL,
    file_name text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    uploaded_by uuid,
    uploaded_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.media_assets OWNER TO retail;

--
-- Name: notification_audit_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notification_audit_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action text NOT NULL,
    notification_id uuid,
    approval_id uuid,
    details jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notification_audit_logs OWNER TO retail;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notification_preferences (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    gr_created boolean DEFAULT true NOT NULL,
    gr_approved boolean DEFAULT true NOT NULL,
    gr_rejected boolean DEFAULT true NOT NULL,
    po_approval_required boolean DEFAULT true NOT NULL,
    po_approved boolean DEFAULT true NOT NULL,
    po_rejected boolean DEFAULT true NOT NULL,
    low_stock_alert boolean DEFAULT true NOT NULL,
    transfer_completed boolean DEFAULT true NOT NULL,
    inventory_adjustment boolean DEFAULT true NOT NULL,
    login_alert boolean DEFAULT true NOT NULL,
    device_alert boolean DEFAULT true NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    email_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO retail;

--
-- Name: notification_subscriptions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notification_subscriptions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    push_token text NOT NULL,
    platform text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.notification_subscriptions OWNER TO retail;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type public."AlertType" NOT NULL,
    priority public."NotificationPriority" DEFAULT 'NORMAL'::public."NotificationPriority" NOT NULL,
    module public."NotificationModule" NOT NULL,
    status public."NotificationStatus" DEFAULT 'UNREAD'::public."NotificationStatus" NOT NULL,
    reference_type text,
    reference_id text,
    deep_link text,
    action_url text,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone,
    created_by uuid
);


ALTER TABLE public.notifications OWNER TO retail;

--
-- Name: password_reset_requests; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.password_reset_requests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    email text NOT NULL,
    method public."PasswordResetMethod" NOT NULL,
    otp_hash text,
    link_token_hash text,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_sent_at timestamp(6) with time zone,
    requested_ip text,
    requested_user_agent text
);


ALTER TABLE public.password_reset_requests OWNER TO retail;

--
-- Name: payment_receipts; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.payment_receipts (
    id uuid NOT NULL,
    receipt_number text NOT NULL,
    receipt_date date NOT NULL,
    invoice_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    method text,
    reference text,
    remarks text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.payment_receipts OWNER TO retail;

--
-- Name: platform_notification_reads; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.platform_notification_reads (
    id uuid NOT NULL,
    notification_id uuid NOT NULL,
    admin_email text NOT NULL,
    read_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.platform_notification_reads OWNER TO retail;

--
-- Name: platform_notifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.platform_notifications (
    id uuid NOT NULL,
    category public."PlatformNotificationCategory" NOT NULL,
    severity public."PlatformNotificationSeverity" DEFAULT 'INFO'::public."PlatformNotificationSeverity" NOT NULL,
    notification_key text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    action_url text,
    reference_type text,
    reference_id uuid,
    company_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone
);


ALTER TABLE public.platform_notifications OWNER TO retail;

--
-- Name: po_cancel_verifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.po_cancel_verifications (
    id uuid NOT NULL,
    po_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reason text NOT NULL,
    otp_hash text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.po_cancel_verifications OWNER TO retail;

--
-- Name: product_barcodes; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.product_barcodes (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    barcode text NOT NULL,
    company_id uuid,
    supplier_id uuid,
    barcode_type public."BarcodeType" DEFAULT 'INTERNAL'::public."BarcodeType" NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.product_barcodes OWNER TO retail;

--
-- Name: product_plants; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.product_plants (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    storage_location_id uuid,
    opening_stock numeric(12,3) DEFAULT 0 NOT NULL,
    batch_number text,
    expiry_date date,
    min_stock_level numeric(12,3) DEFAULT 0 NOT NULL,
    max_stock_level numeric(12,3),
    reorder_qty numeric(12,3),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.product_plants OWNER TO retail;

--
-- Name: product_specifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.product_specifications (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    label text NOT NULL,
    value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.product_specifications OWNER TO retail;

--
-- Name: products; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    product_code text NOT NULL,
    description text NOT NULL,
    uom text NOT NULL,
    category text NOT NULL,
    hsn_code text,
    material_group text,
    drawing_reference text,
    brand text,
    tax_preference public."TaxPreference" DEFAULT 'TAXABLE'::public."TaxPreference" NOT NULL,
    gst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    purchase_price numeric(12,2) NOT NULL,
    selling_price numeric(12,2) NOT NULL,
    image_url text,
    thumbnail_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.products OWNER TO retail;

--
-- Name: purchase_order_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.purchase_order_header (
    id uuid NOT NULL,
    po_number text NOT NULL,
    po_date date NOT NULL,
    shop_id uuid NOT NULL,
    rfq_id uuid,
    contract_id uuid,
    supplier text NOT NULL,
    status public."PurchaseOrderStatus" DEFAULT 'DRAFT'::public."PurchaseOrderStatus" NOT NULL,
    remarks text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.purchase_order_header OWNER TO retail;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.purchase_order_items (
    id uuid NOT NULL,
    po_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    rfq_item_id uuid,
    line_description text,
    line_category text,
    current_stock numeric(12,3) NOT NULL,
    min_stock numeric(12,3) NOT NULL,
    suggested_qty numeric(12,3) NOT NULL,
    order_qty numeric(12,3) NOT NULL,
    rate numeric(12,2) NOT NULL,
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_rate numeric(7,4) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.purchase_order_items OWNER TO retail;

--
-- Name: report_saved_filters; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.report_saved_filters (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    report_type text NOT NULL,
    name text NOT NULL,
    filter_json jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.report_saved_filters OWNER TO retail;

--
-- Name: restore_jobs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.restore_jobs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    mode public."RestoreMode" DEFAULT 'TENANT_REPLACE'::public."RestoreMode" NOT NULL,
    status public."RestoreJobStatus" DEFAULT 'PENDING'::public."RestoreJobStatus" NOT NULL,
    dry_run_report jsonb,
    confirmation_token text,
    error_message text,
    started_at timestamp(6) with time zone,
    completed_at timestamp(6) with time zone,
    created_by uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.restore_jobs OWNER TO retail;

--
-- Name: rfq_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.rfq_header (
    id uuid NOT NULL,
    rfq_number text NOT NULL,
    rfq_date date NOT NULL,
    deadline date,
    title text NOT NULL,
    notes text,
    shop_id uuid NOT NULL,
    branding_mode public."BrandingMode" DEFAULT 'LIVE'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.rfq_header OWNER TO retail;

--
-- Name: rfq_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.rfq_items (
    id uuid NOT NULL,
    rfq_header_id uuid NOT NULL,
    product_id uuid,
    description text,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    specifications text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.rfq_items OWNER TO retail;

--
-- Name: rfq_suppliers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.rfq_suppliers (
    id uuid NOT NULL,
    rfq_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.rfq_suppliers OWNER TO retail;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name public."RoleName" NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.roles OWNER TO retail;

--
-- Name: sales_order_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_order_header (
    id uuid NOT NULL,
    so_number text NOT NULL,
    order_date date NOT NULL,
    expected_date date,
    customer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."SalesOrderStatus" DEFAULT 'DRAFT'::public."SalesOrderStatus" NOT NULL,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    fulfillment_status public."FulfillmentStatus" DEFAULT 'NONE'::public."FulfillmentStatus" NOT NULL,
    remarks text,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_value numeric(14,2),
    gst_supply_type public."GstSupplyType" DEFAULT 'INTRA_STATE'::public."GstSupplyType" NOT NULL,
    subtotal_before_tax numeric(14,2) DEFAULT 0 NOT NULL,
    total_cgst numeric(14,2) DEFAULT 0 NOT NULL,
    total_sgst numeric(14,2) DEFAULT 0 NOT NULL,
    total_igst numeric(14,2) DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.sales_order_header OWNER TO retail;

--
-- Name: sales_order_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_order_items (
    id uuid NOT NULL,
    so_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    shipped_qty numeric(12,3) DEFAULT 0 NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    cgst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    sgst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    igst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    tax_rate numeric(7,4) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.sales_order_items OWNER TO retail;

--
-- Name: sales_quote_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_quote_header (
    id uuid NOT NULL,
    quote_number text NOT NULL,
    quote_date date NOT NULL,
    valid_until date,
    customer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."SalesQuotationStatus" DEFAULT 'DRAFT'::public."SalesQuotationStatus" NOT NULL,
    branding_mode public."BrandingMode" DEFAULT 'LIVE'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    sales_order_id uuid,
    portal_token text,
    remarks text,
    total_value numeric(14,2),
    customer_requested_total numeric(14,2),
    customer_request_note text,
    customer_responded_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.sales_quote_header OWNER TO retail;

--
-- Name: sales_quote_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_quote_items (
    id uuid NOT NULL,
    quote_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.sales_quote_items OWNER TO retail;

--
-- Name: scan_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.scan_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid,
    barcode text NOT NULL,
    product_id uuid,
    user_id uuid NOT NULL,
    action public."ScanAction" DEFAULT 'LOOKUP'::public."ScanAction" NOT NULL,
    result public."ScanResult" DEFAULT 'FOUND'::public."ScanResult" NOT NULL,
    source public."ScanSource" DEFAULT 'API'::public."ScanSource" NOT NULL,
    session_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.scan_logs OWNER TO retail;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_hash text NOT NULL,
    ip text,
    user_agent text,
    device_name text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_seen_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_at timestamp(6) with time zone,
    expires_at timestamp(6) with time zone
);


ALTER TABLE public.sessions OWNER TO retail;

--
-- Name: shops; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.shops (
    id uuid NOT NULL,
    shop_number text NOT NULL,
    shop_name text NOT NULL,
    tax_id text,
    address text NOT NULL,
    contact_person text NOT NULL,
    mobile text NOT NULL,
    email text NOT NULL,
    company_id uuid,
    branding_profile_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    costing_method public."CostingMethod" DEFAULT 'AVERAGE'::public."CostingMethod" NOT NULL,
    functional_currency text DEFAULT 'USD'::text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.shops OWNER TO retail;

--
-- Name: signup_verifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.signup_verifications (
    id uuid NOT NULL,
    email text NOT NULL,
    payload jsonb NOT NULL,
    otp_hash text NOT NULL,
    session_token_hash text,
    totp_secret_encrypted text,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.signup_verifications OWNER TO retail;

--
-- Name: stock_count_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_count_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    product_id uuid NOT NULL,
    counted_qty numeric(12,3) DEFAULT 0 NOT NULL,
    expected_qty numeric(12,3),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.stock_count_items OWNER TO retail;

--
-- Name: stock_count_sessions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_count_sessions (
    id uuid NOT NULL,
    session_number text NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."StockCountStatus" DEFAULT 'OPEN'::public."StockCountStatus" NOT NULL,
    remarks text,
    started_by uuid NOT NULL,
    approved_by uuid,
    approved_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.stock_count_sessions OWNER TO retail;

--
-- Name: stock_ledger; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_ledger (
    id uuid NOT NULL,
    transaction_type public."TransactionType" NOT NULL,
    transaction_ref text NOT NULL,
    transaction_date date NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    in_qty numeric(12,3) DEFAULT 0 NOT NULL,
    out_qty numeric(12,3) DEFAULT 0 NOT NULL,
    balance_qty numeric(12,3) NOT NULL,
    unit_rate numeric(12,2),
    value numeric(14,2),
    remarks text,
    idempotency_key text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.stock_ledger OWNER TO retail;

--
-- Name: stock_summary; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_summary (
    id uuid NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    current_stock numeric(12,3) NOT NULL,
    avg_cost numeric(14,4) DEFAULT 0 NOT NULL,
    last_movement_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.stock_summary OWNER TO retail;

--
-- Name: stock_transfer_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_transfer_header (
    id uuid NOT NULL,
    transfer_number text NOT NULL,
    transfer_date date NOT NULL,
    from_shop_id uuid NOT NULL,
    to_shop_id uuid NOT NULL,
    from_storage_location_id uuid,
    to_storage_location_id uuid,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    notes text,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.stock_transfer_header OWNER TO retail;

--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_transfer_items (
    id uuid NOT NULL,
    transfer_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL
);


ALTER TABLE public.stock_transfer_items OWNER TO retail;

--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    shop_id uuid NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.storage_locations OWNER TO retail;

--
-- Name: subscription_invoices; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.subscription_invoices (
    id uuid NOT NULL,
    invoice_number text NOT NULL,
    company_id uuid NOT NULL,
    plan public."SubscriptionPlan" NOT NULL,
    billing_cycle public."BillingCycle" NOT NULL,
    amount_paise integer NOT NULL,
    tax_paise integer DEFAULT 0 NOT NULL,
    total_paise integer NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    gst_number text,
    billing_address_snapshot jsonb,
    issued_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    pdf_storage_key text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.subscription_invoices OWNER TO retail;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.subscription_payments (
    id uuid NOT NULL,
    company_id uuid,
    plan public."SubscriptionPlan" NOT NULL,
    billing_cycle public."BillingCycle" NOT NULL,
    amount_paise integer NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    razorpay_order_id text NOT NULL,
    razorpay_payment_id text,
    status text DEFAULT 'pending'::text NOT NULL,
    verified_at timestamp(6) with time zone,
    consumed_at timestamp(6) with time zone,
    invoice_id uuid,
    failure_reason text,
    renewal_attempt integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO retail;

--
-- Name: supplier_bill_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_bill_header (
    id uuid NOT NULL,
    bill_number text NOT NULL,
    bill_date date NOT NULL,
    due_date date,
    shop_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    purchase_order_id uuid,
    goods_receipt_id uuid,
    status public."SupplierBillStatus" DEFAULT 'DRAFT'::public."SupplierBillStatus" NOT NULL,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    total_value numeric(14,2) NOT NULL,
    paid_value numeric(14,2) DEFAULT 0 NOT NULL,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_bill_header OWNER TO retail;

--
-- Name: supplier_bill_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_bill_items (
    id uuid NOT NULL,
    bill_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL
);


ALTER TABLE public.supplier_bill_items OWNER TO retail;

--
-- Name: supplier_payments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_payments (
    id uuid NOT NULL,
    payment_number text NOT NULL,
    payment_date date NOT NULL,
    supplier_bill_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    amount numeric(14,2) NOT NULL,
    method text,
    reference text,
    remarks text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_payments OWNER TO retail;

--
-- Name: supplier_quote_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_quote_header (
    id uuid NOT NULL,
    quote_number text NOT NULL,
    quote_date date NOT NULL,
    shop_id uuid NOT NULL,
    rfq_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    notes text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_quote_header OWNER TO retail;

--
-- Name: supplier_quote_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_quote_items (
    id uuid NOT NULL,
    quote_header_id uuid NOT NULL,
    rfq_item_id uuid,
    product_id uuid,
    description text,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    specifications text,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_quote_items OWNER TO retail;

--
-- Name: supplier_return_images; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_return_images (
    id uuid NOT NULL,
    return_id uuid NOT NULL,
    return_item_id uuid,
    file_path text NOT NULL,
    public_url text NOT NULL,
    original_filename text NOT NULL,
    mime_type text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid
);


ALTER TABLE public.supplier_return_images OWNER TO retail;

--
-- Name: supplier_return_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_return_items (
    id uuid NOT NULL,
    return_id uuid NOT NULL,
    goods_receipt_item_id uuid,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    grn_quantity numeric(12,3),
    uom text NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    reason_code public."SupplierReturnReasonCode"
);


ALTER TABLE public.supplier_return_items OWNER TO retail;

--
-- Name: supplier_returns; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_returns (
    id uuid NOT NULL,
    return_number text NOT NULL,
    return_date date NOT NULL,
    shop_id uuid NOT NULL,
    supplier_name text NOT NULL,
    supplier_id uuid,
    purchase_order_id uuid,
    goods_receipt_id uuid,
    supplier_ref text,
    reason text,
    remarks text,
    internal_cc_email text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    status public."ReturnStatus" DEFAULT 'DRAFT'::public."ReturnStatus" NOT NULL,
    total_value numeric(14,2) DEFAULT 0 NOT NULL,
    posted_at timestamp(6) with time zone,
    submitted_at timestamp(6) with time zone,
    acknowledged_at timestamp(6) with time zone,
    email_sent_at timestamp(6) with time zone,
    ack_token_hash text,
    email_message_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_returns OWNER TO retail;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    supplier_code text NOT NULL,
    supplier_name text NOT NULL,
    company_id uuid,
    tax_id text,
    vat_number text,
    rating integer DEFAULT 0 NOT NULL,
    categories text[] DEFAULT ARRAY[]::text[],
    contact_person text,
    email text,
    phone text,
    street text,
    city text,
    state text,
    postal_code text,
    country text,
    payment_terms text,
    bank_name text,
    account_number text,
    routing_number text,
    iban text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(6) with time zone
);


ALTER TABLE public.suppliers OWNER TO retail;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.system_settings (
    id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.system_settings OWNER TO retail;

--
-- Name: trusted_mfa_devices; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.trusted_mfa_devices (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    ip text,
    user_agent text,
    last_used_at timestamp(6) with time zone,
    expires_at timestamp(6) with time zone NOT NULL,
    revoked_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.trusted_mfa_devices OWNER TO retail;

--
-- Name: user_backup_codes; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.user_backup_codes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    code_hash text NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_backup_codes OWNER TO retail;

--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.user_devices (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    device_id text NOT NULL,
    device_name text NOT NULL,
    platform text NOT NULL,
    os_version text,
    last_login_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.user_devices OWNER TO retail;

--
-- Name: user_invitations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.user_invitations (
    id uuid NOT NULL,
    email text NOT NULL,
    name text,
    role_id uuid NOT NULL,
    shop_id uuid,
    token_hash text NOT NULL,
    invited_by uuid NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_invitations OWNER TO retail;

--
-- Name: users; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    avatar_url text,
    role_id uuid NOT NULL,
    shop_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    deleted_at timestamp(6) with time zone,
    last_login_at timestamp(6) with time zone,
    mfa_enabled boolean DEFAULT false NOT NULL,
    mfa_method public."MfaMethod",
    mfa_enrolled_at timestamp(6) with time zone,
    mfa_secret_encrypted text,
    password_changed_at timestamp(6) with time zone,
    refresh_token_hash text,
    failed_login_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.users OWNER TO retail;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
65080713-ebae-4a08-846d-c9b6d6c4c889	53aa764f5ab32fef96d7af36d78c329fa22262a2fd5789c38987723e4917a11e	2026-06-13 14:31:35.542864+00	20260613143134_init	\N	\N	2026-06-13 14:31:34.711991+00	1
\.


--
-- Data for Name: alert_events; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.alert_events (id, alert_type, severity, title, message, shop_id, reference_type, reference_id, is_read, triggered_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: approval_comments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.approval_comments (id, approval_id, user_id, comment, created_at) FROM stdin;
\.


--
-- Data for Name: approval_escalations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.approval_escalations (id, approval_id, escalated_to, escalated_at, level, reason, resolved_at) FROM stdin;
\.


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.approval_requests (id, company_id, requested_by, assigned_to, approval_type, reference_id, status, document_number, amount, description, rejection_reason, approved_at, rejected_at, required_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.audit_logs (id, company_id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, device_id, metadata, reason, severity, request_id, created_at) FROM stdin;
806803ea-5233-42de-ae85-da81e3836acd	e6177fba-dc2f-4935-ad49-1646ff216a6d	72dc17dd-389f-4701-b46f-50bdc22ddeb3	LOGIN	\N	\N	\N	\N	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	{"attemptSource": "MOBILE"}	\N	\N	c3cfebd1-93c6-4934-acf8-7c36f81a187f	2026-06-13 15:26:12.493+00
5f52467b-dce8-4baa-8332-9d952a30b441	e6177fba-dc2f-4935-ad49-1646ff216a6d	72dc17dd-389f-4701-b46f-50bdc22ddeb3	LOGIN	\N	\N	\N	\N	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	{"attemptSource": "MOBILE"}	\N	\N	c4907e1d-9bd8-4cd8-bf19-ea6036b9283d	2026-06-13 15:42:13.775+00
d96d2c83-4a66-4496-bf6c-1b7f63c71f9e	e6177fba-dc2f-4935-ad49-1646ff216a6d	72dc17dd-389f-4701-b46f-50bdc22ddeb3	LOGIN	\N	\N	\N	\N	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	{"attemptSource": "MOBILE"}	\N	\N	4679fdc0-a8f7-4f63-a3dc-4d3ed0290b18	2026-06-13 16:16:42.818+00
\.


--
-- Data for Name: auth_challenges; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.auth_challenges (id, user_id, purpose, token_hash, totp_secret_encrypted, attempt_count, expires_at, consumed_at, created_at, requested_ip, requested_user_agent) FROM stdin;
\.


--
-- Data for Name: backup_artifacts; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.backup_artifacts (id, company_id, backup_job_id, file_name, storage_path, file_size, sha256, provider, drive_file_id, schema_version, created_at) FROM stdin;
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.backup_jobs (id, company_id, status, provider, error_message, started_at, completed_at, created_by, lifecycle_status, deleted_at, deleted_by, created_at) FROM stdin;
\.


--
-- Data for Name: backup_provider_credentials; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.backup_provider_credentials (id, company_id, provider, encrypted_tokens, account_email, drive_folder_id, connected_at, updated_at) FROM stdin;
\.


--
-- Data for Name: barcode_audit_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_audit_logs (id, company_id, barcode_id, barcode, product_id, action, detail, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: barcode_history; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_history (id, company_id, barcode, old_product_id, new_product_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: barcode_print_jobs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_print_jobs (id, user_id, template_id, pdf_url, status, quantities, created_at, updated_at, label_count) FROM stdin;
\.


--
-- Data for Name: barcode_template_versions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_template_versions (id, template_name, version, json_content, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: branding_profiles; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.branding_profiles (id, branding_version, logo_asset_id, watermark_asset_id, seal_asset_id, signature_asset_id, letterhead_asset_id, footer_text, email, phone, website, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.companies (id, company_code, company_name, address, branding_profile_id, is_active, subscription_plan, billing_cycle, subscription_status, trial_starts_at, trial_ends_at, subscription_ends_at, platform_marketing_opt_out, razorpay_subscription_id, paid_activated_at, created_at, updated_at, created_by, updated_by) FROM stdin;
76b3482f-477d-4a8c-a5f9-102715695bed	TESTCO	Test Company	\N	\N	t	TRIAL	\N	ACTIVE	\N	\N	\N	f	\N	\N	2026-06-13 14:31:35.620288+00	2026-06-13 14:31:35.620288+00	\N	\N
06d8ddd7-aa7d-4f02-8451-c8461173f691	TESTING_PLUS	Testing Plus Account	\N	\N	t	PLUS	\N	ACTIVE	\N	\N	\N	f	\N	\N	2026-06-13 14:36:40.818492+00	2026-06-13 14:36:40.818492+00	\N	\N
e6177fba-dc2f-4935-ad49-1646ff216a6d	SOFTDIGI	SoftDigits	77/44,2nd main road,gandhi nagar,Adyar	\N	t	TRIAL	\N	ACTIVE	2026-06-13 15:26:12.218+00	2026-06-20 15:26:12.218+00	\N	f	\N	\N	2026-06-13 15:26:12.246+00	2026-06-13 15:26:12.246+00	\N	\N
\.


--
-- Data for Name: company_engagement_snapshots; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.company_engagement_snapshots (id, company_id, snapshot_date, lifecycle_stage, last_login_at, login_count_30d, features_used, products_count, inventory_txn_count, team_members_count, reports_generated, trial_progress_pct, created_at) FROM stdin;
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.company_settings (id, company_id, key, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contract_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.contract_header (id, contract_number, shop_id, supplier_id, rfq_id, quotation_id, title, payment_terms, start_date, end_date, notes, status, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: contract_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.contract_items (id, contract_id, product_id, description, quantity, uom, unit_price, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: cost_layers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.cost_layers (id, shop_id, product_id, gr_id, ledger_id, qty_remaining, qty_original, unit_cost, created_at) FROM stdin;
\.


--
-- Data for Name: credit_notes; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.credit_notes (id, credit_number, credit_date, shop_id, customer_id, invoice_id, return_id, status, amount, applied_amount, remarks, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.currencies (code, name, decimals) FROM stdin;
\.


--
-- Data for Name: customer_return_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.customer_return_items (id, return_id, product_id, quantity, uom, unit_price, line_value) FROM stdin;
\.


--
-- Data for Name: customer_returns; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.customer_returns (id, return_number, return_date, shop_id, customer_id, invoice_id, sales_order_id, reason, remarks, status, total_value, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.customers (id, customer_code, customer_name, email, phone, tax_id, pan, street, city, state, postal_code, country, shop_id, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: damaged_stock; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.damaged_stock (id, damage_number, damage_date, shop_id, product_id, damaged_quantity, reason, remarks, status, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: data_retention_config; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.data_retention_config (id, entity, retain_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: device_registrations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.device_registrations (id, user_id, company_id, device_id, device_name, platform, push_token, app_version, os_version, is_active, last_active_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_email_outbox; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.document_email_outbox (id, entity_type, entity_id, document_number, template_id, company_id, shop_id, recipient, attachment_filename, status, trigger, attempts, retry_count, last_error, next_retry_at, payload_json, sent_at, sent_by_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_sequences; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.document_sequences (id, doc_type, shop_id, year_month, last_seq, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_series_config; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.document_series_config (id, company_id, shop_id, doc_type, module_label, prefix, starting_number, pad_width, restart_period, shop_scoped, enabled, use_category_prefix, created_at, updated_at, created_by, updated_by) FROM stdin;
5a6838cf-1ae7-4d31-9818-4b8097a372c1	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	PRD	Products	PRD	1	5	NONE	f	t	t	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
735703b1-8bd7-41ba-8aa8-76090a8ba4c6	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	CUS	Customers	CUS	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
0738fe35-f42f-4002-9ef7-8bf31b74d6c7	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	RFQ	RFQ	RFQ	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
5afbfc60-3143-42ee-b0aa-f37b0ea98f39	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	QUO	Supplier Quotation	QUO	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
e417770b-62ff-4e93-8186-cd343917e73b	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	CT	Contracts	CT	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
9dec5da0-c04b-419a-b120-5bf81092708a	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	PO	Purchase Order	PO	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
58a878d3-99f2-4e0f-bbef-d8810d27d0d3	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	GR	Goods Receipt	GR	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
b4dceb51-635a-4fe1-b843-044e08dc1132	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	CRT	Goods Return (Customer)	CRT	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
d17dfd06-4030-481f-bdf3-8540854df855	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	SRT	Goods Return (Supplier)	RMO	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
e7858532-6c64-4f6d-8bd1-08ab624ea33f	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	SQT	Sales Quotation	QT	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
402b8c74-4d35-420a-b3ee-6d770e4407e0	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	SO	Sales Order	SO	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
eebeba06-3e34-44d9-98a0-5bb35574bf55	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	GI	Goods Issue	GI	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
51956399-78ab-412f-b562-717f16fdf273	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	SC	Stock Count	SC	1	5	NONE	f	t	f	2026-06-13 15:45:31.699+00	2026-06-13 15:45:31.699+00	72dc17dd-389f-4701-b46f-50bdc22ddeb3	72dc17dd-389f-4701-b46f-50bdc22ddeb3
\.


--
-- Data for Name: email_delivery_log; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_delivery_log (id, template_id, entity_type, entity_id, recipient, sent_at, click_count, open_count) FROM stdin;
f1e9fbbb-5c42-40ad-a5a4-f80b05cb265b	platform_trial_welcome	company	e6177fba-dc2f-4935-ad49-1646ff216a6d	gstharunadhithya08@gmail.com	2026-06-13 15:26:12.813+00	0	0
\.


--
-- Data for Name: email_sender_domains; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_sender_domains (id, company_id, domain, dkim_selector, dkim_host, dkim_value, status, verified_at, last_checked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_sender_identities; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_sender_identities (id, company_id, domain_id, display_name, email, sender_type, is_primary, status, verified_at, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_password_enc, smtp_configured_at, smtp_last_verified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_sender_verifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_sender_verifications (id, sender_id, otp_hash, attempt_count, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: fx_rates; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.fx_rates (id, base, quote, rate, as_of) FROM stdin;
\.


--
-- Data for Name: goods_issue_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_issue_header (id, gi_number, gi_date, shop_id, issue_reason, issue_type, other_reason, remarks, branding_mode, branding_snapshot, branding_version, template_version, status, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: goods_issue_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_issue_items (id, gi_header_id, product_id, quantity, uom, available_stock_snapshot, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: goods_receipt_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_receipt_header (id, gr_number, gr_date, shop_id, supplier_name, purchase_order_id, receipt_type, receipt_source, inward_shift, supplier_ref, remarks, branding_mode, branding_snapshot, branding_version, template_version, status, posted_at, total_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: goods_receipt_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_receipt_items (id, gr_header_id, product_id, quantity, uom, purchase_rate, line_value, batch_number, serial_number, expiry_date, storage_location_id, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.idempotency_keys (id, key, scope, result, user_id, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: invoice_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.invoice_header (id, invoice_number, invoice_date, sales_order_id, customer_id, shop_id, status, branding_mode, branding_snapshot, branding_version, template_version, currency, fx_rate_used, discount_amount, tax_amount, total_value, paid_value, due_date, remarks, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: job_failures; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.job_failures (id, queue, job_name, job_id, data, error_name, error_message, stack, attempts, failed_at) FROM stdin;
\.


--
-- Data for Name: lifecycle_campaign_enrollments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.lifecycle_campaign_enrollments (id, company_id, campaign_key, scheduled_for, sent_at, status, email_delivery_log_id, metadata, created_at, updated_at) FROM stdin;
62305f29-17f2-49a6-9ed1-f93719db9ed6	e6177fba-dc2f-4935-ad49-1646ff216a6d	platform_trial_welcome	\N	2026-06-13 15:26:12.815+00	SENT	\N	\N	2026-06-13 15:26:12.815+00	2026-06-13 15:26:12.815+00
\.


--
-- Data for Name: low_stock_alerts; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.low_stock_alerts (id, company_id, product_id, shop_id, current_stock, min_stock, reorder_point, "alertLevel", notified, notified_at, resolved, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: media_assets; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.media_assets (id, company_id, shop_id, branding_profile_id, type, asset_key, file_name, version, metadata, uploaded_by, uploaded_at, active) FROM stdin;
\.


--
-- Data for Name: notification_audit_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notification_audit_logs (id, company_id, user_id, action, notification_id, approval_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notification_preferences (id, user_id, company_id, gr_created, gr_approved, gr_rejected, po_approval_required, po_approved, po_rejected, low_stock_alert, transfer_completed, inventory_adjustment, login_alert, device_alert, push_enabled, email_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_subscriptions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notification_subscriptions (id, user_id, company_id, push_token, platform, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notifications (id, user_id, company_id, title, message, type, priority, module, status, reference_type, reference_id, deep_link, action_url, is_read, read_at, created_at, expires_at, created_by) FROM stdin;
\.


--
-- Data for Name: password_reset_requests; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.password_reset_requests (id, user_id, email, method, otp_hash, link_token_hash, attempt_count, expires_at, consumed_at, created_at, last_sent_at, requested_ip, requested_user_agent) FROM stdin;
\.


--
-- Data for Name: payment_receipts; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.payment_receipts (id, receipt_number, receipt_date, invoice_id, shop_id, amount, currency, fx_rate_used, method, reference, remarks, branding_mode, branding_snapshot, branding_version, template_version, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: platform_notification_reads; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.platform_notification_reads (id, notification_id, admin_email, read_at) FROM stdin;
\.


--
-- Data for Name: platform_notifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.platform_notifications (id, category, severity, notification_key, title, message, action_url, reference_type, reference_id, company_id, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: po_cancel_verifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.po_cancel_verifications (id, po_id, user_id, reason, otp_hash, attempt_count, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: product_barcodes; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.product_barcodes (id, product_id, barcode, company_id, supplier_id, barcode_type, is_primary, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_plants; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.product_plants (id, product_id, shop_id, storage_location_id, opening_stock, batch_number, expiry_date, min_stock_level, max_stock_level, reorder_qty, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
d1d860e1-dc5a-4daf-9e9c-faaafc93891f	0eaaa560-fbfd-473a-8380-03b6d8c10af2	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	\N	100.000	\N	\N	10.000	\N	\N	t	2026-06-13 15:59:18.442+00	2026-06-13 15:59:18.442+00	\N	\N
76cf9c28-09cf-4e2d-a65e-3ccbaf05303a	9f767326-4ed0-4cb6-94ed-367261f6fdf9	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	\N	100.000	\N	\N	10.000	\N	\N	t	2026-06-13 15:59:18.448+00	2026-06-13 15:59:18.448+00	\N	\N
86e6c961-29ef-4177-9be8-0971d66f8d74	1fa94ec3-0a87-4c84-a25c-6d1286b7e623	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	\N	100.000	\N	\N	10.000	\N	\N	t	2026-06-13 15:59:18.449+00	2026-06-13 15:59:18.449+00	\N	\N
2bdd6848-f23c-40db-be8c-b671b6753723	1e9f7090-2f04-4a34-bc7f-346ceeac846f	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	\N	100.000	\N	\N	10.000	\N	\N	t	2026-06-13 15:59:18.451+00	2026-06-13 15:59:18.451+00	\N	\N
821a1405-0fa7-4f28-9376-481a6c4e595d	745a773d-27e2-4b09-ae8c-8074df51b0bb	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	\N	100.000	\N	\N	10.000	\N	\N	t	2026-06-13 15:59:18.452+00	2026-06-13 15:59:18.452+00	\N	\N
\.


--
-- Data for Name: product_specifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.product_specifications (id, product_id, label, value, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.products (id, product_code, description, uom, category, hsn_code, material_group, drawing_reference, brand, tax_preference, gst_rate, purchase_price, selling_price, image_url, thumbnail_url, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
0eaaa560-fbfd-473a-8380-03b6d8c10af2	PROD-1781365906625-1	Test Product 1	PCS	Test	\N	\N	\N	\N	TAXABLE	0.0000	1000.00	1500.00	\N	\N	t	2026-06-13 15:51:46.626+00	2026-06-13 15:51:46.626+00	\N	\N
9f767326-4ed0-4cb6-94ed-367261f6fdf9	PROD-1781365906629-2	Test Product 2	PCS	Test	\N	\N	\N	\N	TAXABLE	0.0000	1000.00	1500.00	\N	\N	t	2026-06-13 15:51:46.629+00	2026-06-13 15:51:46.629+00	\N	\N
1fa94ec3-0a87-4c84-a25c-6d1286b7e623	PROD-1781365906630-3	Test Product 3	PCS	Test	\N	\N	\N	\N	TAXABLE	0.0000	1000.00	1500.00	\N	\N	t	2026-06-13 15:51:46.631+00	2026-06-13 15:51:46.631+00	\N	\N
1e9f7090-2f04-4a34-bc7f-346ceeac846f	PROD-1781365906632-4	Test Product 4	PCS	Test	\N	\N	\N	\N	TAXABLE	0.0000	1000.00	1500.00	\N	\N	t	2026-06-13 15:51:46.632+00	2026-06-13 15:51:46.632+00	\N	\N
745a773d-27e2-4b09-ae8c-8074df51b0bb	PROD-1781365906633-5	Test Product 5	PCS	Test	\N	\N	\N	\N	TAXABLE	0.0000	1000.00	1500.00	\N	\N	t	2026-06-13 15:51:46.634+00	2026-06-13 15:51:46.634+00	\N	\N
\.


--
-- Data for Name: purchase_order_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.purchase_order_header (id, po_number, po_date, shop_id, rfq_id, contract_id, supplier, status, remarks, branding_mode, branding_snapshot, branding_version, template_version, currency, fx_rate_used, discount_amount, tax_amount, total_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.purchase_order_items (id, po_header_id, product_id, rfq_item_id, line_description, line_category, current_stock, min_stock, suggested_qty, order_qty, rate, discount_amount, tax_rate, tax_amount, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: report_saved_filters; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.report_saved_filters (id, user_id, report_type, name, filter_json, created_at) FROM stdin;
\.


--
-- Data for Name: restore_jobs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.restore_jobs (id, company_id, artifact_id, mode, status, dry_run_report, confirmation_token, error_message, started_at, completed_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: rfq_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.rfq_header (id, rfq_number, rfq_date, deadline, title, notes, shop_id, branding_mode, branding_snapshot, branding_version, template_version, status, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: rfq_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.rfq_items (id, rfq_header_id, product_id, description, quantity, uom, specifications, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: rfq_suppliers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.rfq_suppliers (id, rfq_id, supplier_id, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.roles (id, name, permissions, created_at, updated_at, created_by, updated_by) FROM stdin;
10bf132e-490b-405b-9f38-c2bd06378532	OWNER	["*", "report:view"]	2026-06-13 14:31:35.617714+00	2026-06-13 15:44:21.393+00	\N	\N
\.


--
-- Data for Name: sales_order_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_order_header (id, so_number, order_date, expected_date, customer_id, shop_id, status, branding_mode, branding_snapshot, branding_version, template_version, fulfillment_status, remarks, currency, fx_rate_used, discount_amount, tax_amount, total_value, gst_supply_type, subtotal_before_tax, total_cgst, total_sgst, total_igst, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: sales_order_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_order_items (id, so_header_id, product_id, quantity, shipped_qty, uom, unit_price, discount_amount, cgst_rate, sgst_rate, igst_rate, tax_rate, tax_amount, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: sales_quote_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_quote_header (id, quote_number, quote_date, valid_until, customer_id, shop_id, status, branding_mode, branding_snapshot, branding_version, template_version, sales_order_id, portal_token, remarks, total_value, customer_requested_total, customer_request_note, customer_responded_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: sales_quote_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_quote_items (id, quote_header_id, product_id, quantity, uom, unit_price, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: scan_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.scan_logs (id, company_id, shop_id, barcode, product_id, user_id, action, result, source, session_id, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sessions (id, user_id, refresh_hash, ip, user_agent, device_name, created_at, last_seen_at, revoked_at, expires_at) FROM stdin;
8306f802-8518-4007-89ab-87baf9d3b00d	72dc17dd-389f-4701-b46f-50bdc22ddeb3	$2b$12$NHi52XZu6yJXsLAFXnfBFulYa.qrrNx/m8pZxaegi0RMm3FOATd1O	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	2026-06-13 15:26:12.487+00	2026-06-13 15:41:25.313+00	2026-06-13 15:42:00.599+00	2026-06-20 15:26:12.486+00
0a7e24ab-2662-483f-b51c-1db4d6896ed2	7110edcb-9ae8-49a0-80dd-0bfb40dd2ead	$2b$12$DSu6xJdsTRlk/ry2jfezAuWLQSX4WDIqCNrkf4yOln5/kWc4DCwVy	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	2026-06-13 15:42:05.594+00	2026-06-13 15:42:05.594+00	\N	2026-06-20 15:42:05.593+00
fc621e7e-45aa-4382-9443-63cd7dd52c05	72dc17dd-389f-4701-b46f-50bdc22ddeb3	$2b$12$2taSgzDAasUpi.JzV4URBOiLxN4LLSJ7HaTL5UvUmzOQP9YAAm0vO	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	2026-06-13 15:42:13.771+00	2026-06-13 16:16:41.055+00	\N	2026-06-20 15:42:13.77+00
501fa11f-29fe-4368-8de1-937cc80b3a09	72dc17dd-389f-4701-b46f-50bdc22ddeb3	$2b$12$jK.wEa.ikQ7u6P.2qRSXPOkd5NNuXnZMMbD/Yv6krWgW6MSwNX8Fq	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	\N	2026-06-13 16:16:42.798+00	2026-06-13 16:42:11.531+00	\N	2026-06-20 16:16:42.797+00
\.


--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.shops (id, shop_number, shop_name, tax_id, address, contact_person, mobile, email, company_id, branding_profile_id, is_active, costing_method, functional_currency, created_at, updated_at, created_by, updated_by) FROM stdin;
aa5213d6-0f6b-4667-bfb6-fa2efa1b8ab8	SHOP001	Test Shop	\N	123 Main St	John Doe	555-1234	shop@test.com	76b3482f-477d-4a8c-a5f9-102715695bed	\N	t	AVERAGE	USD	2026-06-13 14:31:35.626265+00	2026-06-13 14:31:35.626265+00	\N	\N
b33d580e-4c5d-48e6-b6f4-cebff577bc5b	SOFTDI-001	Head Office	\N	Navalur , chennai	Tharun Adhithya	+919488329318	gstharunadhithya08@gmail.com	e6177fba-dc2f-4935-ad49-1646ff216a6d	\N	t	AVERAGE	USD	2026-06-13 15:26:12.249+00	2026-06-13 15:26:12.249+00	\N	\N
\.


--
-- Data for Name: signup_verifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.signup_verifications (id, email, payload, otp_hash, session_token_hash, totp_secret_encrypted, attempt_count, expires_at, consumed_at, created_at) FROM stdin;
0702c508-36f2-4265-82ac-1b918740f144	gstharunadhithya08@gmail.com	{"plan": "trial", "mobile": "+919488329318", "billing": "monthly", "adminName": "Tharun Adhithya", "plantName": "Head Office", "companyName": "SoftDigits", "passwordHash": "$2b$12$Cbe7qoww8atXUTHUP7nG2uR4Brc2t98Iuudb33so3TWqfTrhkp/G2", "plantAddress": "Navalur , chennai", "contactPerson": "Tharun Adhithya", "otpVerifiedAt": "2026-06-13T15:26:08.404Z", "companyAddress": "77/44,2nd main road,gandhi nagar,Adyar"}	$2b$12$UPM1AyST//jD2ifgfcjXhelgye1hw0EoH2CpTZeW3Qwoj7kFBtlqO	\N	\N	0	2026-06-13 16:26:08.405+00	2026-06-13 15:26:12.256+00	2026-06-13 15:25:40.04+00
\.


--
-- Data for Name: stock_count_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_count_items (id, session_id, product_id, counted_qty, expected_qty, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_count_sessions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_count_sessions (id, session_number, company_id, shop_id, status, remarks, started_by, approved_by, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_ledger; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_ledger (id, transaction_type, transaction_ref, transaction_date, shop_id, product_id, in_qty, out_qty, balance_qty, unit_rate, value, remarks, idempotency_key, created_at, updated_at, created_by, updated_by) FROM stdin;
0071f579-05f6-45b7-b601-1f0c399a17cc	OPENING	OPEN-1	2026-06-13	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	0eaaa560-fbfd-473a-8380-03b6d8c10af2	100.000	0.000	100.000	1000.00	100000.00	\N	\N	2026-06-13 15:57:18.183+00	2026-06-13 15:57:18.183+00	\N	\N
1070ca65-147b-4477-aae9-60b93e178d33	OPENING	OPEN-2	2026-06-13	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	9f767326-4ed0-4cb6-94ed-367261f6fdf9	100.000	0.000	100.000	1000.00	100000.00	\N	\N	2026-06-13 15:57:18.188+00	2026-06-13 15:57:18.188+00	\N	\N
f383039e-59ee-43d1-819f-658d47dbc19c	OPENING	OPEN-3	2026-06-13	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	1fa94ec3-0a87-4c84-a25c-6d1286b7e623	100.000	0.000	100.000	1000.00	100000.00	\N	\N	2026-06-13 15:57:18.19+00	2026-06-13 15:57:18.19+00	\N	\N
411033fb-3696-4500-9249-5efca2c7b920	OPENING	OPEN-4	2026-06-13	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	1e9f7090-2f04-4a34-bc7f-346ceeac846f	100.000	0.000	100.000	1000.00	100000.00	\N	\N	2026-06-13 15:57:18.191+00	2026-06-13 15:57:18.191+00	\N	\N
d8870835-4f88-4da3-a403-2b4c5dcfbfa4	OPENING	OPEN-5	2026-06-13	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	745a773d-27e2-4b09-ae8c-8074df51b0bb	100.000	0.000	100.000	1000.00	100000.00	\N	\N	2026-06-13 15:57:18.193+00	2026-06-13 15:57:18.193+00	\N	\N
\.


--
-- Data for Name: stock_summary; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_summary (id, shop_id, product_id, current_stock, avg_cost, last_movement_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: stock_transfer_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_transfer_header (id, transfer_number, transfer_date, from_shop_id, to_shop_id, from_storage_location_id, to_storage_location_id, status, notes, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_transfer_items (id, transfer_id, product_id, quantity, uom) FROM stdin;
\.


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.storage_locations (id, shop_id, code, name, description, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: subscription_invoices; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.subscription_invoices (id, invoice_number, company_id, plan, billing_cycle, amount_paise, tax_paise, total_paise, currency, gst_number, billing_address_snapshot, issued_at, pdf_storage_key, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.subscription_payments (id, company_id, plan, billing_cycle, amount_paise, currency, razorpay_order_id, razorpay_payment_id, status, verified_at, consumed_at, invoice_id, failure_reason, renewal_attempt, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_bill_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_bill_header (id, bill_number, bill_date, due_date, shop_id, supplier_id, purchase_order_id, goods_receipt_id, status, branding_mode, branding_snapshot, branding_version, template_version, total_value, paid_value, remarks, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: supplier_bill_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_bill_items (id, bill_header_id, product_id, quantity, uom, unit_cost, line_value) FROM stdin;
\.


--
-- Data for Name: supplier_payments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_payments (id, payment_number, payment_date, supplier_bill_id, shop_id, amount, method, reference, remarks, branding_mode, branding_snapshot, branding_version, template_version, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: supplier_quote_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_quote_header (id, quote_number, quote_date, shop_id, rfq_id, supplier_id, notes, status, posted_at, total_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: supplier_quote_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_quote_items (id, quote_header_id, rfq_item_id, product_id, description, quantity, uom, specifications, unit_price, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: supplier_return_images; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_return_images (id, return_id, return_item_id, file_path, public_url, original_filename, mime_type, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: supplier_return_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_return_items (id, return_id, goods_receipt_item_id, product_id, quantity, grn_quantity, uom, unit_cost, line_value, reason_code) FROM stdin;
\.


--
-- Data for Name: supplier_returns; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_returns (id, return_number, return_date, shop_id, supplier_name, supplier_id, purchase_order_id, goods_receipt_id, supplier_ref, reason, remarks, internal_cc_email, branding_mode, branding_snapshot, branding_version, template_version, status, total_value, posted_at, submitted_at, acknowledged_at, email_sent_at, ack_token_hash, email_message_id, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.suppliers (id, supplier_code, supplier_name, company_id, tax_id, vat_number, rating, categories, contact_person, email, phone, street, city, state, postal_code, country, payment_terms, bank_name, account_number, routing_number, iban, is_active, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.system_settings (id, key, value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: trusted_mfa_devices; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.trusted_mfa_devices (id, user_id, token_hash, ip, user_agent, last_used_at, expires_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_backup_codes; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.user_backup_codes (id, user_id, code_hash, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.user_devices (id, user_id, company_id, device_id, device_name, platform, os_version, last_login_at, revoked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_invitations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.user_invitations (id, email, name, role_id, shop_id, token_hash, invited_by, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.users (id, name, email, password_hash, avatar_url, role_id, shop_id, is_active, deleted_at, last_login_at, mfa_enabled, mfa_method, mfa_enrolled_at, mfa_secret_encrypted, password_changed_at, refresh_token_hash, failed_login_count, locked_until, created_at, updated_at, created_by, updated_by) FROM stdin;
7110edcb-9ae8-49a0-80dd-0bfb40dd2ead	Test User	testing@softims.com	$2b$10$GHdu3KTOKpPSkmKrFMI6Veuq4WgXmHb3UC.AyFX2QY.n/aZGDrPnm	\N	10bf132e-490b-405b-9f38-c2bd06378532	aa5213d6-0f6b-4667-bfb6-fa2efa1b8ab8	t	\N	\N	f	\N	\N	\N	\N	\N	0	\N	2026-06-13 14:36:40.821043+00	2026-06-13 15:53:36.098+00	\N	\N
e2df2db7-730c-4638-8787-ca1227051b0c	Test Owner	owner@test.com	$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36P4/VJO	\N	10bf132e-490b-405b-9f38-c2bd06378532	aa5213d6-0f6b-4667-bfb6-fa2efa1b8ab8	t	\N	\N	f	\N	\N	\N	\N	\N	1	\N	2026-06-13 14:31:35.621939+00	2026-06-13 16:01:58.517+00	\N	\N
72dc17dd-389f-4701-b46f-50bdc22ddeb3	Tharun Adhithya	gstharunadhithya08@gmail.com	$2b$12$Cbe7qoww8atXUTHUP7nG2uR4Brc2t98Iuudb33so3TWqfTrhkp/G2	\N	10bf132e-490b-405b-9f38-c2bd06378532	b33d580e-4c5d-48e6-b6f4-cebff577bc5b	t	\N	2026-06-13 16:16:42.815+00	f	\N	\N	\N	\N	\N	0	\N	2026-06-13 15:26:12.251+00	2026-06-13 16:16:42.816+00	\N	\N
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: alert_events alert_events_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_pkey PRIMARY KEY (id);


--
-- Name: approval_comments approval_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_pkey PRIMARY KEY (id);


--
-- Name: approval_escalations approval_escalations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_escalations
    ADD CONSTRAINT approval_escalations_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: backup_artifacts backup_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_artifacts
    ADD CONSTRAINT backup_artifacts_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: backup_provider_credentials backup_provider_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_provider_credentials
    ADD CONSTRAINT backup_provider_credentials_pkey PRIMARY KEY (id);


--
-- Name: barcode_audit_logs barcode_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_audit_logs
    ADD CONSTRAINT barcode_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: barcode_history barcode_history_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_history
    ADD CONSTRAINT barcode_history_pkey PRIMARY KEY (id);


--
-- Name: barcode_print_jobs barcode_print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_print_jobs
    ADD CONSTRAINT barcode_print_jobs_pkey PRIMARY KEY (id);


--
-- Name: barcode_template_versions barcode_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_template_versions
    ADD CONSTRAINT barcode_template_versions_pkey PRIMARY KEY (id);


--
-- Name: branding_profiles branding_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_engagement_snapshots company_engagement_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_engagement_snapshots
    ADD CONSTRAINT company_engagement_snapshots_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: contract_header contract_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_pkey PRIMARY KEY (id);


--
-- Name: contract_items contract_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_items
    ADD CONSTRAINT contract_items_pkey PRIMARY KEY (id);


--
-- Name: cost_layers cost_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.cost_layers
    ADD CONSTRAINT cost_layers_pkey PRIMARY KEY (id);


--
-- Name: credit_notes credit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (code);


--
-- Name: customer_return_items customer_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_pkey PRIMARY KEY (id);


--
-- Name: customer_returns customer_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: damaged_stock damaged_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.damaged_stock
    ADD CONSTRAINT damaged_stock_pkey PRIMARY KEY (id);


--
-- Name: data_retention_config data_retention_config_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.data_retention_config
    ADD CONSTRAINT data_retention_config_pkey PRIMARY KEY (id);


--
-- Name: device_registrations device_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_pkey PRIMARY KEY (id);


--
-- Name: document_email_outbox document_email_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_email_outbox
    ADD CONSTRAINT document_email_outbox_pkey PRIMARY KEY (id);


--
-- Name: document_sequences document_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_pkey PRIMARY KEY (id);


--
-- Name: document_series_config document_series_config_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_series_config
    ADD CONSTRAINT document_series_config_pkey PRIMARY KEY (id);


--
-- Name: email_delivery_log email_delivery_log_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_delivery_log
    ADD CONSTRAINT email_delivery_log_pkey PRIMARY KEY (id);


--
-- Name: email_sender_domains email_sender_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_domains
    ADD CONSTRAINT email_sender_domains_pkey PRIMARY KEY (id);


--
-- Name: email_sender_identities email_sender_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_identities
    ADD CONSTRAINT email_sender_identities_pkey PRIMARY KEY (id);


--
-- Name: email_sender_verifications email_sender_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_verifications
    ADD CONSTRAINT email_sender_verifications_pkey PRIMARY KEY (id);


--
-- Name: fx_rates fx_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT fx_rates_pkey PRIMARY KEY (id);


--
-- Name: goods_issue_header goods_issue_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_header
    ADD CONSTRAINT goods_issue_header_pkey PRIMARY KEY (id);


--
-- Name: goods_issue_items goods_issue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_header goods_receipt_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_header
    ADD CONSTRAINT goods_receipt_header_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: invoice_header invoice_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_pkey PRIMARY KEY (id);


--
-- Name: job_failures job_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.job_failures
    ADD CONSTRAINT job_failures_pkey PRIMARY KEY (id);


--
-- Name: lifecycle_campaign_enrollments lifecycle_campaign_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.lifecycle_campaign_enrollments
    ADD CONSTRAINT lifecycle_campaign_enrollments_pkey PRIMARY KEY (id);


--
-- Name: low_stock_alerts low_stock_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.low_stock_alerts
    ADD CONSTRAINT low_stock_alerts_pkey PRIMARY KEY (id);


--
-- Name: media_assets media_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_pkey PRIMARY KEY (id);


--
-- Name: notification_audit_logs notification_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_audit_logs
    ADD CONSTRAINT notification_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_subscriptions notification_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_subscriptions
    ADD CONSTRAINT notification_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_requests password_reset_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.password_reset_requests
    ADD CONSTRAINT password_reset_requests_pkey PRIMARY KEY (id);


--
-- Name: payment_receipts payment_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_pkey PRIMARY KEY (id);


--
-- Name: platform_notification_reads platform_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_notification_reads
    ADD CONSTRAINT platform_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: platform_notifications platform_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_notifications
    ADD CONSTRAINT platform_notifications_pkey PRIMARY KEY (id);


--
-- Name: po_cancel_verifications po_cancel_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.po_cancel_verifications
    ADD CONSTRAINT po_cancel_verifications_pkey PRIMARY KEY (id);


--
-- Name: product_barcodes product_barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_pkey PRIMARY KEY (id);


--
-- Name: product_plants product_plants_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_pkey PRIMARY KEY (id);


--
-- Name: product_specifications product_specifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_specifications
    ADD CONSTRAINT product_specifications_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_header purchase_order_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: report_saved_filters report_saved_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.report_saved_filters
    ADD CONSTRAINT report_saved_filters_pkey PRIMARY KEY (id);


--
-- Name: restore_jobs restore_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_pkey PRIMARY KEY (id);


--
-- Name: rfq_header rfq_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_header
    ADD CONSTRAINT rfq_header_pkey PRIMARY KEY (id);


--
-- Name: rfq_items rfq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_pkey PRIMARY KEY (id);


--
-- Name: rfq_suppliers rfq_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_suppliers
    ADD CONSTRAINT rfq_suppliers_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_order_header sales_order_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_header
    ADD CONSTRAINT sales_order_header_pkey PRIMARY KEY (id);


--
-- Name: sales_order_items sales_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_pkey PRIMARY KEY (id);


--
-- Name: sales_quote_header sales_quote_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_pkey PRIMARY KEY (id);


--
-- Name: sales_quote_items sales_quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_pkey PRIMARY KEY (id);


--
-- Name: scan_logs scan_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.scan_logs
    ADD CONSTRAINT scan_logs_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (id);


--
-- Name: signup_verifications signup_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.signup_verifications
    ADD CONSTRAINT signup_verifications_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_pkey PRIMARY KEY (id);


--
-- Name: stock_count_sessions stock_count_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_sessions
    ADD CONSTRAINT stock_count_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger stock_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_pkey PRIMARY KEY (id);


--
-- Name: stock_summary stock_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_summary
    ADD CONSTRAINT stock_summary_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_header stock_transfer_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: subscription_invoices subscription_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: supplier_bill_header supplier_bill_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_pkey PRIMARY KEY (id);


--
-- Name: supplier_bill_items supplier_bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_items
    ADD CONSTRAINT supplier_bill_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_payments supplier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_pkey PRIMARY KEY (id);


--
-- Name: supplier_quote_header supplier_quote_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_pkey PRIMARY KEY (id);


--
-- Name: supplier_quote_items supplier_quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_return_images supplier_return_images_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_images
    ADD CONSTRAINT supplier_return_images_pkey PRIMARY KEY (id);


--
-- Name: supplier_return_items supplier_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_returns supplier_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: trusted_mfa_devices trusted_mfa_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.trusted_mfa_devices
    ADD CONSTRAINT trusted_mfa_devices_pkey PRIMARY KEY (id);


--
-- Name: user_backup_codes user_backup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_backup_codes
    ADD CONSTRAINT user_backup_codes_pkey PRIMARY KEY (id);


--
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (id);


--
-- Name: user_invitations user_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: alert_events_alert_type_triggered_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX alert_events_alert_type_triggered_at_idx ON public.alert_events USING btree (alert_type, triggered_at);


--
-- Name: alert_events_shop_id_is_read_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX alert_events_shop_id_is_read_idx ON public.alert_events USING btree (shop_id, is_read);


--
-- Name: approval_comments_approval_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_comments_approval_id_idx ON public.approval_comments USING btree (approval_id);


--
-- Name: approval_escalations_approval_id_escalated_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_escalations_approval_id_escalated_at_idx ON public.approval_escalations USING btree (approval_id, escalated_at);


--
-- Name: approval_requests_approval_type_reference_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_requests_approval_type_reference_id_idx ON public.approval_requests USING btree (approval_type, reference_id);


--
-- Name: approval_requests_assigned_to_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_requests_assigned_to_status_idx ON public.approval_requests USING btree (assigned_to, status);


--
-- Name: approval_requests_company_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_requests_company_id_status_created_at_idx ON public.approval_requests USING btree (company_id, status, created_at);


--
-- Name: audit_logs_action_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_action_created_at_idx ON public.audit_logs USING btree (action, created_at);


--
-- Name: audit_logs_company_id_action_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_company_id_action_created_at_idx ON public.audit_logs USING btree (company_id, action, created_at);


--
-- Name: audit_logs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_company_id_created_at_idx ON public.audit_logs USING btree (company_id, created_at);


--
-- Name: audit_logs_entity_type_entity_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_entity_type_entity_id_created_at_idx ON public.audit_logs USING btree (entity_type, entity_id, created_at);


--
-- Name: audit_logs_reason_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_reason_created_at_idx ON public.audit_logs USING btree (reason, created_at);


--
-- Name: audit_logs_request_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_request_id_idx ON public.audit_logs USING btree (request_id);


--
-- Name: audit_logs_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_logs_user_id_created_at_idx ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: auth_challenges_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX auth_challenges_expires_at_idx ON public.auth_challenges USING btree (expires_at);


--
-- Name: auth_challenges_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX auth_challenges_token_hash_idx ON public.auth_challenges USING btree (token_hash);


--
-- Name: auth_challenges_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX auth_challenges_user_id_idx ON public.auth_challenges USING btree (user_id);


--
-- Name: backup_artifacts_backup_job_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX backup_artifacts_backup_job_id_key ON public.backup_artifacts USING btree (backup_job_id);


--
-- Name: backup_artifacts_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX backup_artifacts_company_id_created_at_idx ON public.backup_artifacts USING btree (company_id, created_at);


--
-- Name: backup_jobs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX backup_jobs_company_id_created_at_idx ON public.backup_jobs USING btree (company_id, created_at);


--
-- Name: backup_provider_credentials_company_id_provider_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX backup_provider_credentials_company_id_provider_key ON public.backup_provider_credentials USING btree (company_id, provider);


--
-- Name: barcode_audit_logs_barcode_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_audit_logs_barcode_id_idx ON public.barcode_audit_logs USING btree (barcode_id);


--
-- Name: barcode_audit_logs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_audit_logs_company_id_created_at_idx ON public.barcode_audit_logs USING btree (company_id, created_at);


--
-- Name: barcode_audit_logs_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_audit_logs_product_id_idx ON public.barcode_audit_logs USING btree (product_id);


--
-- Name: barcode_history_barcode_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_history_barcode_idx ON public.barcode_history USING btree (barcode);


--
-- Name: barcode_history_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_history_company_id_created_at_idx ON public.barcode_history USING btree (company_id, created_at);


--
-- Name: barcode_template_versions_template_name_version_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX barcode_template_versions_template_name_version_key ON public.barcode_template_versions USING btree (template_name, version);


--
-- Name: companies_company_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX companies_company_code_key ON public.companies USING btree (company_code);


--
-- Name: company_engagement_snapshots_company_id_snapshot_date_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX company_engagement_snapshots_company_id_snapshot_date_key ON public.company_engagement_snapshots USING btree (company_id, snapshot_date);


--
-- Name: company_engagement_snapshots_lifecycle_stage_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX company_engagement_snapshots_lifecycle_stage_idx ON public.company_engagement_snapshots USING btree (lifecycle_stage);


--
-- Name: company_engagement_snapshots_snapshot_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX company_engagement_snapshots_snapshot_date_idx ON public.company_engagement_snapshots USING btree (snapshot_date);


--
-- Name: company_settings_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX company_settings_company_id_idx ON public.company_settings USING btree (company_id);


--
-- Name: company_settings_company_id_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX company_settings_company_id_key_key ON public.company_settings USING btree (company_id, key);


--
-- Name: contract_header_contract_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX contract_header_contract_number_key ON public.contract_header USING btree (contract_number);


--
-- Name: contract_header_shop_id_start_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX contract_header_shop_id_start_date_idx ON public.contract_header USING btree (shop_id, start_date);


--
-- Name: contract_header_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX contract_header_supplier_id_idx ON public.contract_header USING btree (supplier_id);


--
-- Name: contract_items_contract_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX contract_items_contract_id_idx ON public.contract_items USING btree (contract_id);


--
-- Name: cost_layers_qty_remaining_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX cost_layers_qty_remaining_idx ON public.cost_layers USING btree (qty_remaining);


--
-- Name: cost_layers_shop_id_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX cost_layers_shop_id_product_id_created_at_idx ON public.cost_layers USING btree (shop_id, product_id, created_at);


--
-- Name: credit_notes_credit_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX credit_notes_credit_number_key ON public.credit_notes USING btree (credit_number);


--
-- Name: credit_notes_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX credit_notes_customer_id_idx ON public.credit_notes USING btree (customer_id);


--
-- Name: credit_notes_return_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX credit_notes_return_id_key ON public.credit_notes USING btree (return_id);


--
-- Name: credit_notes_shop_id_credit_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX credit_notes_shop_id_credit_date_idx ON public.credit_notes USING btree (shop_id, credit_date);


--
-- Name: customer_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_return_items_return_id_idx ON public.customer_return_items USING btree (return_id);


--
-- Name: customer_returns_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_returns_customer_id_idx ON public.customer_returns USING btree (customer_id);


--
-- Name: customer_returns_invoice_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_returns_invoice_id_idx ON public.customer_returns USING btree (invoice_id);


--
-- Name: customer_returns_return_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX customer_returns_return_number_key ON public.customer_returns USING btree (return_number);


--
-- Name: customer_returns_shop_id_return_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_returns_shop_id_return_date_idx ON public.customer_returns USING btree (shop_id, return_date);


--
-- Name: customers_shop_id_customer_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX customers_shop_id_customer_code_key ON public.customers USING btree (shop_id, customer_code);


--
-- Name: customers_shop_id_customer_name_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customers_shop_id_customer_name_idx ON public.customers USING btree (shop_id, customer_name);


--
-- Name: damaged_stock_damage_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX damaged_stock_damage_number_key ON public.damaged_stock USING btree (damage_number);


--
-- Name: damaged_stock_shop_id_damage_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX damaged_stock_shop_id_damage_date_idx ON public.damaged_stock USING btree (shop_id, damage_date);


--
-- Name: damaged_stock_shop_id_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX damaged_stock_shop_id_product_id_idx ON public.damaged_stock USING btree (shop_id, product_id);


--
-- Name: damaged_stock_status_damage_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX damaged_stock_status_damage_date_idx ON public.damaged_stock USING btree (status, damage_date);


--
-- Name: data_retention_config_entity_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX data_retention_config_entity_key ON public.data_retention_config USING btree (entity);


--
-- Name: device_registrations_company_id_platform_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX device_registrations_company_id_platform_idx ON public.device_registrations USING btree (company_id, platform);


--
-- Name: device_registrations_is_active_last_active_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX device_registrations_is_active_last_active_at_idx ON public.device_registrations USING btree (is_active, last_active_at);


--
-- Name: device_registrations_user_id_device_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX device_registrations_user_id_device_id_key ON public.device_registrations USING btree (user_id, device_id);


--
-- Name: document_email_outbox_entity_type_entity_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_email_outbox_entity_type_entity_id_created_at_idx ON public.document_email_outbox USING btree (entity_type, entity_id, created_at DESC);


--
-- Name: document_email_outbox_status_next_retry_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_email_outbox_status_next_retry_at_idx ON public.document_email_outbox USING btree (status, next_retry_at);


--
-- Name: document_sequences_doc_type_shop_id_year_month_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX document_sequences_doc_type_shop_id_year_month_key ON public.document_sequences USING btree (doc_type, shop_id, year_month);


--
-- Name: document_series_config_company_id_doc_type_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_series_config_company_id_doc_type_idx ON public.document_series_config USING btree (company_id, doc_type);


--
-- Name: document_series_config_company_id_shop_id_doc_type_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_series_config_company_id_shop_id_doc_type_idx ON public.document_series_config USING btree (company_id, shop_id, doc_type);


--
-- Name: email_delivery_log_template_entity_recipient_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX email_delivery_log_template_entity_recipient_key ON public.email_delivery_log USING btree (template_id, entity_type, entity_id, recipient);


--
-- Name: email_sender_domains_company_id_domain_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX email_sender_domains_company_id_domain_key ON public.email_sender_domains USING btree (company_id, domain);


--
-- Name: email_sender_identities_company_id_email_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX email_sender_identities_company_id_email_key ON public.email_sender_identities USING btree (company_id, email);


--
-- Name: email_sender_identities_company_id_is_primary_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX email_sender_identities_company_id_is_primary_idx ON public.email_sender_identities USING btree (company_id, is_primary);


--
-- Name: email_sender_verifications_sender_id_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX email_sender_verifications_sender_id_expires_at_idx ON public.email_sender_verifications USING btree (sender_id, expires_at);


--
-- Name: fx_rates_base_quote_as_of_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX fx_rates_base_quote_as_of_idx ON public.fx_rates USING btree (base, quote, as_of);


--
-- Name: fx_rates_base_quote_as_of_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX fx_rates_base_quote_as_of_key ON public.fx_rates USING btree (base, quote, as_of);


--
-- Name: goods_issue_header_gi_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX goods_issue_header_gi_number_key ON public.goods_issue_header USING btree (gi_number);


--
-- Name: goods_issue_header_shop_id_gi_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_header_shop_id_gi_date_idx ON public.goods_issue_header USING btree (shop_id, gi_date);


--
-- Name: goods_issue_header_shop_id_status_gi_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_header_shop_id_status_gi_date_idx ON public.goods_issue_header USING btree (shop_id, status, gi_date);


--
-- Name: goods_issue_items_gi_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_items_gi_header_id_idx ON public.goods_issue_items USING btree (gi_header_id);


--
-- Name: goods_issue_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_items_product_id_idx ON public.goods_issue_items USING btree (product_id);


--
-- Name: goods_receipt_header_gr_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX goods_receipt_header_gr_number_key ON public.goods_receipt_header USING btree (gr_number);


--
-- Name: goods_receipt_header_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_header_purchase_order_id_idx ON public.goods_receipt_header USING btree (purchase_order_id);


--
-- Name: goods_receipt_header_shop_id_gr_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_header_shop_id_gr_date_idx ON public.goods_receipt_header USING btree (shop_id, gr_date);


--
-- Name: goods_receipt_header_shop_id_status_gr_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_header_shop_id_status_gr_date_idx ON public.goods_receipt_header USING btree (shop_id, status, gr_date);


--
-- Name: goods_receipt_items_gr_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_items_gr_header_id_idx ON public.goods_receipt_items USING btree (gr_header_id);


--
-- Name: goods_receipt_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_items_product_id_idx ON public.goods_receipt_items USING btree (product_id);


--
-- Name: goods_receipt_items_storage_location_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_items_storage_location_id_idx ON public.goods_receipt_items USING btree (storage_location_id);


--
-- Name: idempotency_keys_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX idempotency_keys_expires_at_idx ON public.idempotency_keys USING btree (expires_at);


--
-- Name: idempotency_keys_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX idempotency_keys_key_key ON public.idempotency_keys USING btree (key);


--
-- Name: idempotency_keys_scope_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX idempotency_keys_scope_idx ON public.idempotency_keys USING btree (scope);


--
-- Name: invoice_header_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_customer_id_idx ON public.invoice_header USING btree (customer_id);


--
-- Name: invoice_header_invoice_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX invoice_header_invoice_number_key ON public.invoice_header USING btree (invoice_number);


--
-- Name: invoice_header_sales_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_sales_order_id_idx ON public.invoice_header USING btree (sales_order_id);


--
-- Name: invoice_header_shop_id_invoice_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_shop_id_invoice_date_idx ON public.invoice_header USING btree (shop_id, invoice_date);


--
-- Name: invoice_header_shop_id_status_invoice_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_shop_id_status_invoice_date_idx ON public.invoice_header USING btree (shop_id, status, invoice_date);


--
-- Name: job_failures_job_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX job_failures_job_id_idx ON public.job_failures USING btree (job_id);


--
-- Name: job_failures_queue_failed_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX job_failures_queue_failed_at_idx ON public.job_failures USING btree (queue, failed_at);


--
-- Name: lifecycle_campaign_enrollments_campaign_key_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX lifecycle_campaign_enrollments_campaign_key_idx ON public.lifecycle_campaign_enrollments USING btree (campaign_key);


--
-- Name: lifecycle_campaign_enrollments_company_id_campaign_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX lifecycle_campaign_enrollments_company_id_campaign_key_key ON public.lifecycle_campaign_enrollments USING btree (company_id, campaign_key);


--
-- Name: lifecycle_campaign_enrollments_scheduled_for_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX lifecycle_campaign_enrollments_scheduled_for_idx ON public.lifecycle_campaign_enrollments USING btree (scheduled_for);


--
-- Name: lifecycle_campaign_enrollments_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX lifecycle_campaign_enrollments_status_idx ON public.lifecycle_campaign_enrollments USING btree (status);


--
-- Name: low_stock_alerts_company_id_alertLevel_notified_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX "low_stock_alerts_company_id_alertLevel_notified_idx" ON public.low_stock_alerts USING btree (company_id, "alertLevel", notified);


--
-- Name: low_stock_alerts_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX low_stock_alerts_product_id_created_at_idx ON public.low_stock_alerts USING btree (product_id, created_at);


--
-- Name: low_stock_alerts_shop_id_resolved_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX low_stock_alerts_shop_id_resolved_at_idx ON public.low_stock_alerts USING btree (shop_id, resolved_at);


--
-- Name: media_assets_branding_profile_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_branding_profile_id_idx ON public.media_assets USING btree (branding_profile_id);


--
-- Name: media_assets_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_company_id_idx ON public.media_assets USING btree (company_id);


--
-- Name: media_assets_shop_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_shop_id_idx ON public.media_assets USING btree (shop_id);


--
-- Name: media_assets_type_active_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_type_active_idx ON public.media_assets USING btree (type, active);


--
-- Name: notification_audit_logs_company_id_action_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_audit_logs_company_id_action_created_at_idx ON public.notification_audit_logs USING btree (company_id, action, created_at);


--
-- Name: notification_audit_logs_user_id_action_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_audit_logs_user_id_action_idx ON public.notification_audit_logs USING btree (user_id, action);


--
-- Name: notification_preferences_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_preferences_company_id_idx ON public.notification_preferences USING btree (company_id);


--
-- Name: notification_preferences_user_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX notification_preferences_user_id_key ON public.notification_preferences USING btree (user_id);


--
-- Name: notification_subscriptions_company_id_platform_is_active_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_subscriptions_company_id_platform_is_active_idx ON public.notification_subscriptions USING btree (company_id, platform, is_active);


--
-- Name: notification_subscriptions_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_subscriptions_user_id_idx ON public.notification_subscriptions USING btree (user_id);


--
-- Name: notification_subscriptions_user_id_push_token_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX notification_subscriptions_user_id_push_token_key ON public.notification_subscriptions USING btree (user_id, push_token);


--
-- Name: notifications_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_company_id_created_at_idx ON public.notifications USING btree (company_id, created_at);


--
-- Name: notifications_is_read_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_is_read_expires_at_idx ON public.notifications USING btree (is_read, expires_at);


--
-- Name: notifications_type_priority_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_type_priority_idx ON public.notifications USING btree (type, priority);


--
-- Name: notifications_user_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_user_id_status_created_at_idx ON public.notifications USING btree (user_id, status, created_at);


--
-- Name: password_reset_requests_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_email_idx ON public.password_reset_requests USING btree (email);


--
-- Name: password_reset_requests_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_expires_at_idx ON public.password_reset_requests USING btree (expires_at);


--
-- Name: password_reset_requests_link_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_link_token_hash_idx ON public.password_reset_requests USING btree (link_token_hash);


--
-- Name: password_reset_requests_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_user_id_idx ON public.password_reset_requests USING btree (user_id);


--
-- Name: payment_receipts_invoice_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX payment_receipts_invoice_id_idx ON public.payment_receipts USING btree (invoice_id);


--
-- Name: payment_receipts_receipt_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX payment_receipts_receipt_number_key ON public.payment_receipts USING btree (receipt_number);


--
-- Name: payment_receipts_shop_id_receipt_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX payment_receipts_shop_id_receipt_date_idx ON public.payment_receipts USING btree (shop_id, receipt_date);


--
-- Name: platform_notification_reads_admin_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notification_reads_admin_email_idx ON public.platform_notification_reads USING btree (admin_email);


--
-- Name: platform_notification_reads_notification_id_admin_email_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX platform_notification_reads_notification_id_admin_email_key ON public.platform_notification_reads USING btree (notification_id, admin_email);


--
-- Name: platform_notifications_category_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notifications_category_created_at_idx ON public.platform_notifications USING btree (category, created_at);


--
-- Name: platform_notifications_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notifications_created_at_idx ON public.platform_notifications USING btree (created_at);


--
-- Name: platform_notifications_notification_key_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notifications_notification_key_idx ON public.platform_notifications USING btree (notification_key);


--
-- Name: po_cancel_verifications_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX po_cancel_verifications_expires_at_idx ON public.po_cancel_verifications USING btree (expires_at);


--
-- Name: po_cancel_verifications_po_id_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX po_cancel_verifications_po_id_user_id_idx ON public.po_cancel_verifications USING btree (po_id, user_id);


--
-- Name: product_barcodes_company_id_barcode_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX product_barcodes_company_id_barcode_key ON public.product_barcodes USING btree (company_id, barcode);


--
-- Name: product_barcodes_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_barcodes_supplier_id_idx ON public.product_barcodes USING btree (supplier_id);


--
-- Name: product_plants_product_id_shop_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX product_plants_product_id_shop_id_key ON public.product_plants USING btree (product_id, shop_id);


--
-- Name: product_plants_shop_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_plants_shop_id_idx ON public.product_plants USING btree (shop_id);


--
-- Name: product_plants_storage_location_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_plants_storage_location_id_idx ON public.product_plants USING btree (storage_location_id);


--
-- Name: product_specifications_product_id_sort_order_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_specifications_product_id_sort_order_idx ON public.product_specifications USING btree (product_id, sort_order);


--
-- Name: products_product_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX products_product_code_key ON public.products USING btree (product_code);


--
-- Name: purchase_order_header_contract_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_contract_id_idx ON public.purchase_order_header USING btree (contract_id);


--
-- Name: purchase_order_header_po_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX purchase_order_header_po_number_key ON public.purchase_order_header USING btree (po_number);


--
-- Name: purchase_order_header_rfq_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_rfq_id_idx ON public.purchase_order_header USING btree (rfq_id);


--
-- Name: purchase_order_header_shop_id_po_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_shop_id_po_date_idx ON public.purchase_order_header USING btree (shop_id, po_date);


--
-- Name: purchase_order_header_shop_id_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_shop_id_status_idx ON public.purchase_order_header USING btree (shop_id, status);


--
-- Name: purchase_order_items_po_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_items_po_header_id_idx ON public.purchase_order_items USING btree (po_header_id);


--
-- Name: purchase_order_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_items_product_id_idx ON public.purchase_order_items USING btree (product_id);


--
-- Name: purchase_order_items_rfq_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_items_rfq_item_id_idx ON public.purchase_order_items USING btree (rfq_item_id);


--
-- Name: report_saved_filters_user_id_report_type_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX report_saved_filters_user_id_report_type_idx ON public.report_saved_filters USING btree (user_id, report_type);


--
-- Name: restore_jobs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX restore_jobs_company_id_created_at_idx ON public.restore_jobs USING btree (company_id, created_at);


--
-- Name: rfq_header_rfq_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX rfq_header_rfq_number_key ON public.rfq_header USING btree (rfq_number);


--
-- Name: rfq_header_shop_id_rfq_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX rfq_header_shop_id_rfq_date_idx ON public.rfq_header USING btree (shop_id, rfq_date);


--
-- Name: rfq_items_rfq_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX rfq_items_rfq_header_id_idx ON public.rfq_items USING btree (rfq_header_id);


--
-- Name: rfq_suppliers_rfq_id_supplier_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX rfq_suppliers_rfq_id_supplier_id_key ON public.rfq_suppliers USING btree (rfq_id, supplier_id);


--
-- Name: rfq_suppliers_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX rfq_suppliers_supplier_id_idx ON public.rfq_suppliers USING btree (supplier_id);


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: sales_order_header_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_header_customer_id_idx ON public.sales_order_header USING btree (customer_id);


--
-- Name: sales_order_header_shop_id_fulfillment_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_header_shop_id_fulfillment_status_idx ON public.sales_order_header USING btree (shop_id, fulfillment_status);


--
-- Name: sales_order_header_shop_id_order_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_header_shop_id_order_date_idx ON public.sales_order_header USING btree (shop_id, order_date);


--
-- Name: sales_order_header_so_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_order_header_so_number_key ON public.sales_order_header USING btree (so_number);


--
-- Name: sales_order_items_so_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_items_so_header_id_idx ON public.sales_order_items USING btree (so_header_id);


--
-- Name: sales_quote_header_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_header_customer_id_idx ON public.sales_quote_header USING btree (customer_id);


--
-- Name: sales_quote_header_portal_token_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_quote_header_portal_token_key ON public.sales_quote_header USING btree (portal_token);


--
-- Name: sales_quote_header_quote_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_quote_header_quote_number_key ON public.sales_quote_header USING btree (quote_number);


--
-- Name: sales_quote_header_sales_order_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_quote_header_sales_order_id_key ON public.sales_quote_header USING btree (sales_order_id);


--
-- Name: sales_quote_header_shop_id_quote_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_header_shop_id_quote_date_idx ON public.sales_quote_header USING btree (shop_id, quote_date);


--
-- Name: sales_quote_header_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_header_status_idx ON public.sales_quote_header USING btree (status);


--
-- Name: sales_quote_items_quote_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_items_quote_header_id_idx ON public.sales_quote_items USING btree (quote_header_id);


--
-- Name: scan_logs_barcode_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_barcode_idx ON public.scan_logs USING btree (barcode);


--
-- Name: scan_logs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_company_id_created_at_idx ON public.scan_logs USING btree (company_id, created_at);


--
-- Name: scan_logs_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_product_id_idx ON public.scan_logs USING btree (product_id);


--
-- Name: scan_logs_session_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_session_id_idx ON public.scan_logs USING btree (session_id);


--
-- Name: sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sessions_expires_at_idx ON public.sessions USING btree (expires_at);


--
-- Name: sessions_user_id_revoked_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sessions_user_id_revoked_at_idx ON public.sessions USING btree (user_id, revoked_at);


--
-- Name: shops_shop_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX shops_shop_number_key ON public.shops USING btree (shop_number);


--
-- Name: signup_verifications_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX signup_verifications_email_idx ON public.signup_verifications USING btree (email);


--
-- Name: signup_verifications_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX signup_verifications_expires_at_idx ON public.signup_verifications USING btree (expires_at);


--
-- Name: signup_verifications_session_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX signup_verifications_session_token_hash_idx ON public.signup_verifications USING btree (session_token_hash);


--
-- Name: stock_count_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_count_items_product_id_idx ON public.stock_count_items USING btree (product_id);


--
-- Name: stock_count_items_session_id_product_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_count_items_session_id_product_id_key ON public.stock_count_items USING btree (session_id, product_id);


--
-- Name: stock_count_sessions_company_id_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_count_sessions_company_id_status_idx ON public.stock_count_sessions USING btree (company_id, status);


--
-- Name: stock_count_sessions_session_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_count_sessions_session_number_key ON public.stock_count_sessions USING btree (session_number);


--
-- Name: stock_count_sessions_shop_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_count_sessions_shop_id_idx ON public.stock_count_sessions USING btree (shop_id);


--
-- Name: stock_ledger_idempotency_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_ledger_idempotency_key_key ON public.stock_ledger USING btree (idempotency_key);


--
-- Name: stock_ledger_shop_id_product_id_transaction_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_ledger_shop_id_product_id_transaction_date_idx ON public.stock_ledger USING btree (shop_id, product_id, transaction_date);


--
-- Name: stock_summary_shop_id_product_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_summary_shop_id_product_id_key ON public.stock_summary USING btree (shop_id, product_id);


--
-- Name: stock_transfer_header_from_shop_id_transfer_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_header_from_shop_id_transfer_date_idx ON public.stock_transfer_header USING btree (from_shop_id, transfer_date);


--
-- Name: stock_transfer_header_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_header_status_idx ON public.stock_transfer_header USING btree (status);


--
-- Name: stock_transfer_header_to_shop_id_transfer_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_header_to_shop_id_transfer_date_idx ON public.stock_transfer_header USING btree (to_shop_id, transfer_date);


--
-- Name: stock_transfer_header_transfer_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_transfer_header_transfer_number_key ON public.stock_transfer_header USING btree (transfer_number);


--
-- Name: stock_transfer_items_transfer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_items_transfer_id_idx ON public.stock_transfer_items USING btree (transfer_id);


--
-- Name: storage_locations_shop_id_code_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX storage_locations_shop_id_code_idx ON public.storage_locations USING btree (shop_id, code);


--
-- Name: storage_locations_shop_id_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX storage_locations_shop_id_code_key ON public.storage_locations USING btree (shop_id, code);


--
-- Name: subscription_invoices_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_invoices_company_id_idx ON public.subscription_invoices USING btree (company_id);


--
-- Name: subscription_invoices_invoice_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX subscription_invoices_invoice_number_key ON public.subscription_invoices USING btree (invoice_number);


--
-- Name: subscription_invoices_issued_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_invoices_issued_at_idx ON public.subscription_invoices USING btree (issued_at);


--
-- Name: subscription_payments_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_payments_company_id_idx ON public.subscription_payments USING btree (company_id);


--
-- Name: subscription_payments_invoice_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_payments_invoice_id_idx ON public.subscription_payments USING btree (invoice_id);


--
-- Name: subscription_payments_razorpay_order_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX subscription_payments_razorpay_order_id_key ON public.subscription_payments USING btree (razorpay_order_id);


--
-- Name: subscription_payments_razorpay_payment_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX subscription_payments_razorpay_payment_id_key ON public.subscription_payments USING btree (razorpay_payment_id);


--
-- Name: supplier_bill_header_bill_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_bill_header_bill_number_key ON public.supplier_bill_header USING btree (bill_number);


--
-- Name: supplier_bill_header_goods_receipt_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_goods_receipt_id_idx ON public.supplier_bill_header USING btree (goods_receipt_id);


--
-- Name: supplier_bill_header_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_purchase_order_id_idx ON public.supplier_bill_header USING btree (purchase_order_id);


--
-- Name: supplier_bill_header_shop_id_bill_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_shop_id_bill_date_idx ON public.supplier_bill_header USING btree (shop_id, bill_date);


--
-- Name: supplier_bill_header_shop_id_status_bill_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_shop_id_status_bill_date_idx ON public.supplier_bill_header USING btree (shop_id, status, bill_date);


--
-- Name: supplier_bill_header_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_supplier_id_idx ON public.supplier_bill_header USING btree (supplier_id);


--
-- Name: supplier_bill_items_bill_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_items_bill_header_id_idx ON public.supplier_bill_items USING btree (bill_header_id);


--
-- Name: supplier_payments_payment_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_payments_payment_number_key ON public.supplier_payments USING btree (payment_number);


--
-- Name: supplier_payments_shop_id_payment_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_payments_shop_id_payment_date_idx ON public.supplier_payments USING btree (shop_id, payment_date);


--
-- Name: supplier_payments_supplier_bill_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_payments_supplier_bill_id_idx ON public.supplier_payments USING btree (supplier_bill_id);


--
-- Name: supplier_quote_header_quote_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_quote_header_quote_number_key ON public.supplier_quote_header USING btree (quote_number);


--
-- Name: supplier_quote_header_rfq_id_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_header_rfq_id_supplier_id_idx ON public.supplier_quote_header USING btree (rfq_id, supplier_id);


--
-- Name: supplier_quote_header_shop_id_quote_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_header_shop_id_quote_date_idx ON public.supplier_quote_header USING btree (shop_id, quote_date);


--
-- Name: supplier_quote_items_quote_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_items_quote_header_id_idx ON public.supplier_quote_items USING btree (quote_header_id);


--
-- Name: supplier_quote_items_rfq_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_items_rfq_item_id_idx ON public.supplier_quote_items USING btree (rfq_item_id);


--
-- Name: supplier_return_images_return_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_images_return_id_idx ON public.supplier_return_images USING btree (return_id);


--
-- Name: supplier_return_images_return_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_images_return_item_id_idx ON public.supplier_return_images USING btree (return_item_id);


--
-- Name: supplier_return_items_goods_receipt_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_items_goods_receipt_item_id_idx ON public.supplier_return_items USING btree (goods_receipt_item_id);


--
-- Name: supplier_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_items_return_id_idx ON public.supplier_return_items USING btree (return_id);


--
-- Name: supplier_returns_goods_receipt_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_goods_receipt_id_idx ON public.supplier_returns USING btree (goods_receipt_id);


--
-- Name: supplier_returns_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_purchase_order_id_idx ON public.supplier_returns USING btree (purchase_order_id);


--
-- Name: supplier_returns_return_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_returns_return_number_key ON public.supplier_returns USING btree (return_number);


--
-- Name: supplier_returns_shop_id_return_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_shop_id_return_date_idx ON public.supplier_returns USING btree (shop_id, return_date);


--
-- Name: supplier_returns_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_supplier_id_idx ON public.supplier_returns USING btree (supplier_id);


--
-- Name: suppliers_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX suppliers_company_id_idx ON public.suppliers USING btree (company_id);


--
-- Name: suppliers_deleted_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX suppliers_deleted_at_idx ON public.suppliers USING btree (deleted_at);


--
-- Name: suppliers_supplier_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX suppliers_supplier_code_key ON public.suppliers USING btree (supplier_code);


--
-- Name: suppliers_supplier_name_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX suppliers_supplier_name_idx ON public.suppliers USING btree (supplier_name);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: trusted_mfa_devices_token_hash_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX trusted_mfa_devices_token_hash_key ON public.trusted_mfa_devices USING btree (token_hash);


--
-- Name: trusted_mfa_devices_user_id_expires_at_revoked_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX trusted_mfa_devices_user_id_expires_at_revoked_at_idx ON public.trusted_mfa_devices USING btree (user_id, expires_at, revoked_at);


--
-- Name: user_backup_codes_user_id_consumed_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_backup_codes_user_id_consumed_at_idx ON public.user_backup_codes USING btree (user_id, consumed_at);


--
-- Name: user_devices_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_devices_company_id_created_at_idx ON public.user_devices USING btree (company_id, created_at);


--
-- Name: user_devices_device_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX user_devices_device_id_key ON public.user_devices USING btree (device_id);


--
-- Name: user_devices_user_id_device_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX user_devices_user_id_device_id_key ON public.user_devices USING btree (user_id, device_id);


--
-- Name: user_devices_user_id_revoked_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_devices_user_id_revoked_at_idx ON public.user_devices USING btree (user_id, revoked_at);


--
-- Name: user_invitations_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_invitations_email_idx ON public.user_invitations USING btree (email);


--
-- Name: user_invitations_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_invitations_expires_at_idx ON public.user_invitations USING btree (expires_at);


--
-- Name: user_invitations_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_invitations_token_hash_idx ON public.user_invitations USING btree (token_hash);


--
-- Name: users_deleted_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX users_deleted_at_idx ON public.users USING btree (deleted_at);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: alert_events alert_events_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_comments approval_comments_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.approval_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_comments approval_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_escalations approval_escalations_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_escalations
    ADD CONSTRAINT approval_escalations_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.approval_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_escalations approval_escalations_escalated_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_escalations
    ADD CONSTRAINT approval_escalations_escalated_to_fkey FOREIGN KEY (escalated_to) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_requests approval_requests_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_requests approval_requests_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: auth_challenges auth_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_artifacts backup_artifacts_backup_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_artifacts
    ADD CONSTRAINT backup_artifacts_backup_job_id_fkey FOREIGN KEY (backup_job_id) REFERENCES public.backup_jobs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: backup_artifacts backup_artifacts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_artifacts
    ADD CONSTRAINT backup_artifacts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_jobs backup_jobs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_provider_credentials backup_provider_credentials_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_provider_credentials
    ADD CONSTRAINT backup_provider_credentials_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: barcode_audit_logs barcode_audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_audit_logs
    ADD CONSTRAINT barcode_audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: barcode_history barcode_history_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_history
    ADD CONSTRAINT barcode_history_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: branding_profiles branding_profiles_letterhead_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_letterhead_asset_id_fkey FOREIGN KEY (letterhead_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_logo_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_logo_asset_id_fkey FOREIGN KEY (logo_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_seal_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_seal_asset_id_fkey FOREIGN KEY (seal_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_signature_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_signature_asset_id_fkey FOREIGN KEY (signature_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_watermark_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_watermark_asset_id_fkey FOREIGN KEY (watermark_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: companies companies_branding_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_branding_profile_id_fkey FOREIGN KEY (branding_profile_id) REFERENCES public.branding_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: company_engagement_snapshots company_engagement_snapshots_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_engagement_snapshots
    ADD CONSTRAINT company_engagement_snapshots_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_settings company_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contract_header contract_header_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_quotation_id_fkey FOREIGN KEY (quotation_id) REFERENCES public.supplier_quote_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contract_header contract_header_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contract_header contract_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contract_header contract_header_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contract_items contract_items_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_items
    ADD CONSTRAINT contract_items_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contract_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contract_items contract_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_items
    ADD CONSTRAINT contract_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cost_layers cost_layers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.cost_layers
    ADD CONSTRAINT cost_layers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cost_layers cost_layers_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.cost_layers
    ADD CONSTRAINT cost_layers_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: credit_notes credit_notes_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: credit_notes credit_notes_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: credit_notes credit_notes_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.customer_returns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: credit_notes credit_notes_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_return_items customer_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_return_items customer_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.customer_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_returns customer_returns_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_returns customer_returns_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_returns customer_returns_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_returns customer_returns_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customers customers_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: damaged_stock damaged_stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.damaged_stock
    ADD CONSTRAINT damaged_stock_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: damaged_stock damaged_stock_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.damaged_stock
    ADD CONSTRAINT damaged_stock_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: device_registrations device_registrations_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: device_registrations device_registrations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_sequences document_sequences_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_series_config document_series_config_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_series_config
    ADD CONSTRAINT document_series_config_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_series_config document_series_config_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_series_config
    ADD CONSTRAINT document_series_config_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sender_domains email_sender_domains_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_domains
    ADD CONSTRAINT email_sender_domains_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sender_identities email_sender_identities_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_identities
    ADD CONSTRAINT email_sender_identities_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sender_identities email_sender_identities_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_identities
    ADD CONSTRAINT email_sender_identities_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.email_sender_domains(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: email_sender_verifications email_sender_verifications_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_verifications
    ADD CONSTRAINT email_sender_verifications_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.email_sender_identities(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_issue_header goods_issue_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_header
    ADD CONSTRAINT goods_issue_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_issue_items goods_issue_items_gi_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_gi_header_id_fkey FOREIGN KEY (gi_header_id) REFERENCES public.goods_issue_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_issue_items goods_issue_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_header goods_receipt_header_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_header
    ADD CONSTRAINT goods_receipt_header_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: goods_receipt_header goods_receipt_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_header
    ADD CONSTRAINT goods_receipt_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_items goods_receipt_items_gr_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_gr_header_id_fkey FOREIGN KEY (gr_header_id) REFERENCES public.goods_receipt_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_receipt_items goods_receipt_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_items goods_receipt_items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoice_header invoice_header_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoice_header invoice_header_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoice_header invoice_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lifecycle_campaign_enrollments lifecycle_campaign_enrollments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.lifecycle_campaign_enrollments
    ADD CONSTRAINT lifecycle_campaign_enrollments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: low_stock_alerts low_stock_alerts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.low_stock_alerts
    ADD CONSTRAINT low_stock_alerts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: low_stock_alerts low_stock_alerts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.low_stock_alerts
    ADD CONSTRAINT low_stock_alerts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: low_stock_alerts low_stock_alerts_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.low_stock_alerts
    ADD CONSTRAINT low_stock_alerts_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_assets media_assets_branding_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_branding_profile_id_fkey FOREIGN KEY (branding_profile_id) REFERENCES public.branding_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notification_audit_logs notification_audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_audit_logs
    ADD CONSTRAINT notification_audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_audit_logs notification_audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_audit_logs
    ADD CONSTRAINT notification_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notification_preferences notification_preferences_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_subscriptions notification_subscriptions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_subscriptions
    ADD CONSTRAINT notification_subscriptions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_subscriptions notification_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_subscriptions
    ADD CONSTRAINT notification_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_reset_requests password_reset_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.password_reset_requests
    ADD CONSTRAINT password_reset_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_receipts payment_receipts_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_receipts payment_receipts_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_notification_reads platform_notification_reads_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_notification_reads
    ADD CONSTRAINT platform_notification_reads_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.platform_notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: po_cancel_verifications po_cancel_verifications_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.po_cancel_verifications
    ADD CONSTRAINT po_cancel_verifications_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_barcodes product_barcodes_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_plants product_plants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_plants product_plants_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_plants product_plants_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_specifications product_specifications_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_specifications
    ADD CONSTRAINT product_specifications_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_header purchase_order_header_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contract_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_header purchase_order_header_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_header purchase_order_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_po_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_po_header_id_fkey FOREIGN KEY (po_header_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_rfq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_rfq_item_id_fkey FOREIGN KEY (rfq_item_id) REFERENCES public.rfq_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: report_saved_filters report_saved_filters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.report_saved_filters
    ADD CONSTRAINT report_saved_filters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_artifact_id_fkey FOREIGN KEY (artifact_id) REFERENCES public.backup_artifacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_header rfq_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_header
    ADD CONSTRAINT rfq_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rfq_items rfq_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rfq_items rfq_items_rfq_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_rfq_header_id_fkey FOREIGN KEY (rfq_header_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_suppliers rfq_suppliers_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_suppliers
    ADD CONSTRAINT rfq_suppliers_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_suppliers rfq_suppliers_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_suppliers
    ADD CONSTRAINT rfq_suppliers_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_header sales_order_header_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_header
    ADD CONSTRAINT sales_order_header_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_header sales_order_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_header
    ADD CONSTRAINT sales_order_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_items sales_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_items sales_order_items_so_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_so_header_id_fkey FOREIGN KEY (so_header_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_quote_header sales_quote_header_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_quote_header sales_quote_header_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sales_quote_header sales_quote_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_quote_items sales_quote_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_quote_items sales_quote_items_quote_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_quote_header_id_fkey FOREIGN KEY (quote_header_id) REFERENCES public.sales_quote_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scan_logs scan_logs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.scan_logs
    ADD CONSTRAINT scan_logs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shops shops_branding_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_branding_profile_id_fkey FOREIGN KEY (branding_profile_id) REFERENCES public.branding_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shops shops_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_count_items stock_count_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_count_items stock_count_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.stock_count_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_ledger stock_ledger_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_ledger stock_ledger_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_summary stock_summary_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_summary
    ADD CONSTRAINT stock_summary_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_summary stock_summary_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_summary
    ADD CONSTRAINT stock_summary_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_header stock_transfer_header_from_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_from_shop_id_fkey FOREIGN KEY (from_shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_header stock_transfer_header_from_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_from_storage_location_id_fkey FOREIGN KEY (from_storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_transfer_header stock_transfer_header_to_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_to_shop_id_fkey FOREIGN KEY (to_shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_header stock_transfer_header_to_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_to_storage_location_id_fkey FOREIGN KEY (to_storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_transfer_items stock_transfer_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_items stock_transfer_items_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES public.stock_transfer_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_invoices subscription_invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_payments subscription_payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscription_payments subscription_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.subscription_invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_bill_header supplier_bill_header_goods_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_goods_receipt_id_fkey FOREIGN KEY (goods_receipt_id) REFERENCES public.goods_receipt_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_bill_header supplier_bill_header_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_bill_header supplier_bill_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_bill_header supplier_bill_header_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_bill_items supplier_bill_items_bill_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_items
    ADD CONSTRAINT supplier_bill_items_bill_header_id_fkey FOREIGN KEY (bill_header_id) REFERENCES public.supplier_bill_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_bill_items supplier_bill_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_items
    ADD CONSTRAINT supplier_bill_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_payments supplier_payments_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_payments supplier_payments_supplier_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_supplier_bill_id_fkey FOREIGN KEY (supplier_bill_id) REFERENCES public.supplier_bill_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_quote_header supplier_quote_header_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_quote_header supplier_quote_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_quote_header supplier_quote_header_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_quote_items supplier_quote_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_quote_items supplier_quote_items_quote_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_quote_header_id_fkey FOREIGN KEY (quote_header_id) REFERENCES public.supplier_quote_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_quote_items supplier_quote_items_rfq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_rfq_item_id_fkey FOREIGN KEY (rfq_item_id) REFERENCES public.rfq_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_return_images supplier_return_images_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_images
    ADD CONSTRAINT supplier_return_images_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.supplier_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_return_images supplier_return_images_return_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_images
    ADD CONSTRAINT supplier_return_images_return_item_id_fkey FOREIGN KEY (return_item_id) REFERENCES public.supplier_return_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_return_items supplier_return_items_goods_receipt_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_goods_receipt_item_id_fkey FOREIGN KEY (goods_receipt_item_id) REFERENCES public.goods_receipt_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_return_items supplier_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_return_items supplier_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.supplier_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_returns supplier_returns_goods_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_goods_receipt_id_fkey FOREIGN KEY (goods_receipt_id) REFERENCES public.goods_receipt_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_returns supplier_returns_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_returns supplier_returns_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_returns supplier_returns_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: suppliers suppliers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trusted_mfa_devices trusted_mfa_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.trusted_mfa_devices
    ADD CONSTRAINT trusted_mfa_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_backup_codes user_backup_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_backup_codes
    ADD CONSTRAINT user_backup_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_devices user_devices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_devices user_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_invitations user_invitations_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_invitations user_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_invitations user_invitations_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict gitdrVZmdcmCbZ63QNmeNefNU3TtpIfpv9N2K9ljn797Zpg4qBtDobUlvAQBlmQ

