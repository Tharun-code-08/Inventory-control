--
-- PostgreSQL database dump
--

\restrict HuMp4xhl18BrgnJQfTJyKOgddz2miYnssWamQzGgs6PHmH4lYLOJ4kLJjtD1udA

-- Dumped from database version 15.18
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AlertType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AlertType" AS ENUM (
    'LOW_STOCK',
    'CONTRACT_EXPIRY',
    'RFQ_DEADLINE',
    'PO_OVERDUE',
    'GOODS_RECEIPT_CREATED',
    'GOODS_RECEIPT_APPROVED',
    'GOODS_RECEIPT_REJECTED',
    'PURCHASE_ORDER_CREATED',
    'PURCHASE_ORDER_APPROVED',
    'PURCHASE_ORDER_REJECTED',
    'RFQ_CREATED',
    'RFQ_RESPONSE_RECEIVED',
    'RFQ_APPROVED',
    'RFQ_REJECTED',
    'SALES_QUOTATION_CREATED',
    'SALES_QUOTATION_APPROVED',
    'SALES_QUOTATION_REJECTED',
    'WAREHOUSE_TRANSFER_COMPLETED',
    'CRITICAL_STOCK',
    'NEGATIVE_STOCK_PREVENTION',
    'INVENTORY_ADJUSTMENT_COMPLETED',
    'WAREHOUSE_CAPACITY_ALERT',
    'NEW_DEVICE_LOGIN',
    'PASSWORD_CHANGED',
    'SESSION_REVOKED',
    'BIOMETRIC_LOGIN_ENABLED',
    'LOGIN_ATTEMPT_LOCKOUT',
    'SYSTEM_MAINTENANCE',
    'VERSION_UPDATE',
    'COMPANY_ANNOUNCEMENT',
    'FEATURE_RELEASE'
);


ALTER TYPE public."AlertType" OWNER TO retail;

--
-- Name: ApprovalStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ApprovalStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."ApprovalStatus" OWNER TO retail;

--
-- Name: ApprovalType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ApprovalType" AS ENUM (
    'GOODS_RECEIPT',
    'PURCHASE_ORDER',
    'RFQ',
    'SALES_QUOTATION',
    'WAREHOUSE_TRANSFER',
    'INVENTORY_ADJUSTMENT'
);


ALTER TYPE public."ApprovalType" OWNER TO retail;

--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AuditAction" AS ENUM (
    'LOGIN',
    'LOGOUT',
    'LOGIN_FAILED',
    'MFA_ENABLED',
    'MFA_DISABLED',
    'PASSWORD_CHANGED',
    'CREATE_PRODUCT',
    'UPDATE_PRODUCT',
    'DELETE_PRODUCT',
    'CREATE_GR',
    'UPDATE_GR',
    'RECEIVE_GOODS',
    'TRANSFER_STOCK',
    'CREATE_ISSUE',
    'CREATE_PO',
    'UPDATE_PO',
    'CONFIRM_PO',
    'CANCEL_PO',
    'APPROVE_PO',
    'REJECT_PO',
    'APPROVE',
    'REJECT',
    'ESCALATE',
    'CREATE_USER',
    'UPDATE_USER',
    'DELETE_USER',
    'UPDATE_ROLE',
    'REVOKE_SESSION',
    'EXPORT_REPORT',
    'EXPORT_AUDIT',
    'DELETE_DATA',
    'BULK_UPDATE',
    'CREATE',
    'UPDATE',
    'DELETE',
    'POST',
    'DEVICE_REGISTERED',
    'STOCK_ADJUSTMENT'
);


ALTER TYPE public."AuditAction" OWNER TO retail;

--
-- Name: AuthChallengePurpose; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."AuthChallengePurpose" AS ENUM (
    'SIGNUP_MFA_ENROLL',
    'LOGIN_MFA_VERIFY'
);


ALTER TYPE public."AuthChallengePurpose" OWNER TO retail;

--
-- Name: BackupJobStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BackupJobStatus" AS ENUM (
    'PENDING',
    'RUNNING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."BackupJobStatus" OWNER TO retail;

--
-- Name: BackupProvider; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BackupProvider" AS ENUM (
    'MANUAL',
    'GOOGLE_DRIVE',
    'EMAIL'
);


ALTER TYPE public."BackupProvider" OWNER TO retail;

--
-- Name: BarcodeType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BarcodeType" AS ENUM (
    'EAN13',
    'UPC_A',
    'CODE128',
    'CODE39',
    'QR',
    'INTERNAL'
);


ALTER TYPE public."BarcodeType" OWNER TO retail;

--
-- Name: BillingCycle; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BillingCycle" AS ENUM (
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."BillingCycle" OWNER TO retail;

--
-- Name: BrandingMode; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."BrandingMode" AS ENUM (
    'LIVE',
    'SNAPSHOT'
);


ALTER TYPE public."BrandingMode" OWNER TO retail;

--
-- Name: CostingMethod; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."CostingMethod" AS ENUM (
    'AVERAGE',
    'FIFO'
);


ALTER TYPE public."CostingMethod" OWNER TO retail;

--
-- Name: CreditNoteStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."CreditNoteStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'APPLIED',
    'VOID'
);


ALTER TYPE public."CreditNoteStatus" OWNER TO retail;

--
-- Name: DevicePlatform; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DevicePlatform" AS ENUM (
    'ANDROID',
    'IOS',
    'WEB'
);


ALTER TYPE public."DevicePlatform" OWNER TO retail;

--
-- Name: DocumentEmailStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentEmailStatus" AS ENUM (
    'PENDING_PDF',
    'PENDING_SEND',
    'SENT',
    'DELIVERED',
    'FAILED'
);


ALTER TYPE public."DocumentEmailStatus" OWNER TO retail;

--
-- Name: DocumentEmailTrigger; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentEmailTrigger" AS ENUM (
    'AUTO',
    'MANUAL',
    'RESEND'
);


ALTER TYPE public."DocumentEmailTrigger" OWNER TO retail;

--
-- Name: DocumentSeriesRestart; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentSeriesRestart" AS ENUM (
    'NONE',
    'MONTHLY',
    'YEARLY'
);


ALTER TYPE public."DocumentSeriesRestart" OWNER TO retail;

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'DRAFT',
    'POSTED'
);


ALTER TYPE public."DocumentStatus" OWNER TO retail;

--
-- Name: EmailSenderStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."EmailSenderStatus" AS ENUM (
    'PENDING',
    'VERIFIED',
    'FAILED'
);


ALTER TYPE public."EmailSenderStatus" OWNER TO retail;

--
-- Name: EmailSenderType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."EmailSenderType" AS ENUM (
    'CUSTOM_DOMAIN',
    'PUBLIC_DOMAIN'
);


ALTER TYPE public."EmailSenderType" OWNER TO retail;

--
-- Name: FulfillmentStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."FulfillmentStatus" AS ENUM (
    'NONE',
    'PARTIAL',
    'FULL'
);


ALTER TYPE public."FulfillmentStatus" OWNER TO retail;

--
-- Name: GstSupplyType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."GstSupplyType" AS ENUM (
    'INTRA_STATE',
    'INTER_STATE'
);


ALTER TYPE public."GstSupplyType" OWNER TO retail;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'PARTIALLY_PAID',
    'PAID',
    'VOID'
);


ALTER TYPE public."InvoiceStatus" OWNER TO retail;

--
-- Name: InwardShift; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."InwardShift" AS ENUM (
    'DAY_SHIFT',
    'NIGHT_SHIFT'
);


ALTER TYPE public."InwardShift" OWNER TO retail;

--
-- Name: LifecycleCampaignStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."LifecycleCampaignStatus" AS ENUM (
    'SCHEDULED',
    'SENT',
    'SKIPPED',
    'FAILED'
);


ALTER TYPE public."LifecycleCampaignStatus" OWNER TO retail;

--
-- Name: LifecycleStage; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."LifecycleStage" AS ENUM (
    'NEW',
    'ACTIVE',
    'ENGAGED',
    'AT_RISK',
    'RENEWAL_DUE',
    'EXPIRED',
    'TRIAL',
    'TRIAL_EXPIRED'
);


ALTER TYPE public."LifecycleStage" OWNER TO retail;

--
-- Name: LifecycleStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."LifecycleStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'OBSOLETE',
    'REPLACED'
);


ALTER TYPE public."LifecycleStatus" OWNER TO retail;

--
-- Name: MediaAssetType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."MediaAssetType" AS ENUM (
    'LOGO',
    'STAMP',
    'SIGNATURE',
    'LETTERHEAD',
    'WATERMARK'
);


ALTER TYPE public."MediaAssetType" OWNER TO retail;

--
-- Name: MfaMethod; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."MfaMethod" AS ENUM (
    'TOTP'
);


ALTER TYPE public."MfaMethod" OWNER TO retail;

--
-- Name: NotificationModule; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."NotificationModule" AS ENUM (
    'GOODS_RECEIPT',
    'PURCHASE_ORDER',
    'RFQ',
    'SALES_QUOTATION',
    'WAREHOUSE_TRANSFER',
    'INVENTORY',
    'SECURITY',
    'SYSTEM',
    'APPROVAL'
);


ALTER TYPE public."NotificationModule" OWNER TO retail;

--
-- Name: NotificationPriority; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."NotificationPriority" AS ENUM (
    'CRITICAL',
    'HIGH',
    'NORMAL',
    'LOW'
);


ALTER TYPE public."NotificationPriority" OWNER TO retail;

--
-- Name: NotificationStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."NotificationStatus" AS ENUM (
    'UNREAD',
    'READ',
    'DELETED'
);


ALTER TYPE public."NotificationStatus" OWNER TO retail;

--
-- Name: PasswordResetMethod; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PasswordResetMethod" AS ENUM (
    'OTP',
    'MAGIC_LINK'
);


ALTER TYPE public."PasswordResetMethod" OWNER TO retail;

--
-- Name: PlatformNotificationCategory; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PlatformNotificationCategory" AS ENUM (
    'REVENUE',
    'HEALTH',
    'SYSTEM'
);


ALTER TYPE public."PlatformNotificationCategory" OWNER TO retail;

--
-- Name: PlatformNotificationSeverity; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PlatformNotificationSeverity" AS ENUM (
    'CRITICAL',
    'HIGH',
    'WARNING',
    'INFO'
);


ALTER TYPE public."PlatformNotificationSeverity" OWNER TO retail;

--
-- Name: PurchaseOrderStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."PurchaseOrderStatus" AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'CANCELLED'
);


ALTER TYPE public."PurchaseOrderStatus" OWNER TO retail;

--
-- Name: ReceiptSource; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ReceiptSource" AS ENUM (
    'PURCHASE_ORDER',
    'OUTSIDE'
);


ALTER TYPE public."ReceiptSource" OWNER TO retail;

--
-- Name: ReceiptType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ReceiptType" AS ENUM (
    'FULL',
    'PARTIAL'
);


ALTER TYPE public."ReceiptType" OWNER TO retail;

--
-- Name: RestoreJobStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."RestoreJobStatus" AS ENUM (
    'PENDING',
    'DRY_RUN_COMPLETED',
    'RUNNING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public."RestoreJobStatus" OWNER TO retail;

--
-- Name: RestoreMode; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."RestoreMode" AS ENUM (
    'TENANT_REPLACE',
    'FULL_DB'
);


ALTER TYPE public."RestoreMode" OWNER TO retail;

--
-- Name: ReturnStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ReturnStatus" AS ENUM (
    'DRAFT',
    'POSTED',
    'CANCELLED',
    'SUBMITTED',
    'ACKNOWLEDGED',
    'DONE'
);


ALTER TYPE public."ReturnStatus" OWNER TO retail;

--
-- Name: RoleName; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."RoleName" AS ENUM (
    'OWNER',
    'ADMIN',
    'INVENTORY_MANAGER',
    'WAREHOUSE_STAFF',
    'VIEWER',
    'VENDOR',
    'SHOP_USER',
    'PURCHASE_MANAGER',
    'SALES',
    'EMPLOYEE'
);


ALTER TYPE public."RoleName" OWNER TO retail;

--
-- Name: SalesOrderStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SalesOrderStatus" AS ENUM (
    'DRAFT',
    'CONFIRMED',
    'FULFILLED',
    'CLOSED',
    'CANCELLED'
);


ALTER TYPE public."SalesOrderStatus" OWNER TO retail;

--
-- Name: SalesQuotationStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SalesQuotationStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'ACCEPTED',
    'USER_REQUESTED',
    'CANCELLED',
    'CONVERTED'
);


ALTER TYPE public."SalesQuotationStatus" OWNER TO retail;

--
-- Name: ScanAction; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ScanAction" AS ENUM (
    'LOOKUP',
    'GOODS_RECEIPT',
    'GOODS_ISSUE',
    'STOCK_COUNT',
    'SALES_ORDER',
    'PURCHASE_ORDER',
    'STOCK_TRANSFER'
);


ALTER TYPE public."ScanAction" OWNER TO retail;

--
-- Name: ScanResult; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ScanResult" AS ENUM (
    'FOUND',
    'NOT_FOUND',
    'INVALID'
);


ALTER TYPE public."ScanResult" OWNER TO retail;

--
-- Name: ScanSource; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."ScanSource" AS ENUM (
    'WEB',
    'MOBILE',
    'USB_SCANNER',
    'CAMERA',
    'API'
);


ALTER TYPE public."ScanSource" OWNER TO retail;

--
-- Name: StockCountStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."StockCountStatus" AS ENUM (
    'OPEN',
    'REVIEW',
    'APPROVED',
    'CANCELLED'
);


ALTER TYPE public."StockCountStatus" OWNER TO retail;

--
-- Name: SubscriptionPlan; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SubscriptionPlan" AS ENUM (
    'TRIAL',
    'PRO',
    'PLUS'
);


ALTER TYPE public."SubscriptionPlan" OWNER TO retail;

--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'CANCELLED',
    'SUSPENDED'
);


ALTER TYPE public."SubscriptionStatus" OWNER TO retail;

--
-- Name: SupplierBillStatus; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SupplierBillStatus" AS ENUM (
    'DRAFT',
    'ISSUED',
    'PARTIALLY_PAID',
    'PAID',
    'VOID'
);


ALTER TYPE public."SupplierBillStatus" OWNER TO retail;

--
-- Name: SupplierReturnReasonCode; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."SupplierReturnReasonCode" AS ENUM (
    'DAMAGED',
    'WRONG_ITEM',
    'EXPIRED',
    'EXCESS'
);


ALTER TYPE public."SupplierReturnReasonCode" OWNER TO retail;

--
-- Name: TaxPreference; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."TaxPreference" AS ENUM (
    'TAXABLE',
    'NON_TAXABLE'
);


ALTER TYPE public."TaxPreference" OWNER TO retail;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: retail
--

CREATE TYPE public."TransactionType" AS ENUM (
    'OPENING',
    'GOODS_RECEIPT',
    'GOODS_ISSUE',
    'DAMAGE',
    'ADJUSTMENT',
    'STOCK_TRANSFER_OUT',
    'STOCK_TRANSFER_IN'
);


ALTER TYPE public."TransactionType" OWNER TO retail;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO retail;

--
-- Name: alert_events; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.alert_events (
    id uuid NOT NULL,
    alert_type public."AlertType" NOT NULL,
    severity text DEFAULT 'MEDIUM'::text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    shop_id uuid,
    reference_type text,
    reference_id text,
    is_read boolean DEFAULT false NOT NULL,
    triggered_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp(6) with time zone
);


ALTER TABLE public.alert_events OWNER TO retail;

--
-- Name: approval_comments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.approval_comments (
    id uuid NOT NULL,
    approval_id uuid NOT NULL,
    user_id uuid NOT NULL,
    comment text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.approval_comments OWNER TO retail;

--
-- Name: approval_escalations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.approval_escalations (
    id uuid NOT NULL,
    approval_id uuid NOT NULL,
    escalated_to uuid NOT NULL,
    escalated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    reason text,
    resolved_at timestamp(6) with time zone
);


ALTER TABLE public.approval_escalations OWNER TO retail;

--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    requested_by uuid NOT NULL,
    assigned_to uuid NOT NULL,
    approval_type public."ApprovalType" NOT NULL,
    reference_id text NOT NULL,
    status public."ApprovalStatus" DEFAULT 'PENDING'::public."ApprovalStatus" NOT NULL,
    document_number text,
    amount numeric(14,2),
    description text,
    rejection_reason text,
    approved_at timestamp(6) with time zone,
    rejected_at timestamp(6) with time zone,
    required_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.approval_requests OWNER TO retail;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    entity_type text,
    entity_id uuid,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    company_id uuid,
    action text DEFAULT 'CREATE'::text NOT NULL,
    reason text,
    request_id text,
    device_id text,
    severity text,
    metadata jsonb
);


ALTER TABLE public.audit_logs OWNER TO retail;

--
-- Name: auth_challenges; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.auth_challenges (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    purpose public."AuthChallengePurpose" NOT NULL,
    token_hash text NOT NULL,
    totp_secret_encrypted text,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    requested_ip text,
    requested_user_agent text
);


ALTER TABLE public.auth_challenges OWNER TO retail;

--
-- Name: backup_artifacts; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.backup_artifacts (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    backup_job_id uuid,
    file_name text NOT NULL,
    storage_path text NOT NULL,
    file_size bigint NOT NULL,
    sha256 text NOT NULL,
    provider public."BackupProvider" NOT NULL,
    drive_file_id text,
    schema_version integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.backup_artifacts OWNER TO retail;

--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.backup_jobs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    status public."BackupJobStatus" DEFAULT 'PENDING'::public."BackupJobStatus" NOT NULL,
    provider public."BackupProvider" NOT NULL,
    error_message text,
    started_at timestamp(6) with time zone,
    completed_at timestamp(6) with time zone,
    created_by uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(6) with time zone,
    deleted_by uuid,
    lifecycle_status public."LifecycleStatus" DEFAULT 'ACTIVE'::public."LifecycleStatus" NOT NULL
);


ALTER TABLE public.backup_jobs OWNER TO retail;

--
-- Name: backup_provider_credentials; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.backup_provider_credentials (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    provider public."BackupProvider" DEFAULT 'GOOGLE_DRIVE'::public."BackupProvider" NOT NULL,
    encrypted_tokens text NOT NULL,
    account_email text,
    drive_folder_id text,
    connected_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.backup_provider_credentials OWNER TO retail;

--
-- Name: barcode_audit_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_audit_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    barcode_id uuid,
    barcode text NOT NULL,
    product_id uuid,
    action text NOT NULL,
    detail jsonb,
    user_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.barcode_audit_logs OWNER TO retail;

--
-- Name: barcode_history; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_history (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    barcode text NOT NULL,
    old_product_id uuid,
    new_product_id uuid,
    user_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.barcode_history OWNER TO retail;

--
-- Name: barcode_print_jobs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_print_jobs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    template_id uuid NOT NULL,
    pdf_url text,
    status text DEFAULT 'PENDING'::text NOT NULL,
    quantities jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    label_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.barcode_print_jobs OWNER TO retail;

--
-- Name: barcode_template_versions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.barcode_template_versions (
    id uuid NOT NULL,
    template_name text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    json_content jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid
);


ALTER TABLE public.barcode_template_versions OWNER TO retail;

--
-- Name: branding_profiles; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.branding_profiles (
    id uuid NOT NULL,
    branding_version integer DEFAULT 1 NOT NULL,
    logo_asset_id uuid,
    watermark_asset_id uuid,
    seal_asset_id uuid,
    signature_asset_id uuid,
    letterhead_asset_id uuid,
    footer_text text,
    email text,
    phone text,
    website text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.branding_profiles OWNER TO retail;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.companies (
    id uuid NOT NULL,
    company_code text NOT NULL,
    company_name text NOT NULL,
    address text,
    is_active boolean DEFAULT true NOT NULL,
    subscription_plan public."SubscriptionPlan" DEFAULT 'TRIAL'::public."SubscriptionPlan" NOT NULL,
    billing_cycle public."BillingCycle",
    subscription_status public."SubscriptionStatus" DEFAULT 'ACTIVE'::public."SubscriptionStatus" NOT NULL,
    trial_starts_at timestamp(6) with time zone,
    trial_ends_at timestamp(6) with time zone,
    subscription_ends_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    platform_marketing_opt_out boolean DEFAULT false NOT NULL,
    razorpay_subscription_id text,
    paid_activated_at timestamp(6) with time zone,
    branding_profile_id uuid
);


ALTER TABLE public.companies OWNER TO retail;

--
-- Name: company_engagement_snapshots; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.company_engagement_snapshots (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    lifecycle_stage public."LifecycleStage" NOT NULL,
    last_login_at timestamp(6) with time zone,
    login_count_30d integer DEFAULT 0 NOT NULL,
    features_used jsonb DEFAULT '{}'::jsonb NOT NULL,
    products_count integer DEFAULT 0 NOT NULL,
    inventory_txn_count integer DEFAULT 0 NOT NULL,
    team_members_count integer DEFAULT 0 NOT NULL,
    reports_generated integer DEFAULT 0 NOT NULL,
    trial_progress_pct integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.company_engagement_snapshots OWNER TO retail;

--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.company_settings (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.company_settings OWNER TO retail;

--
-- Name: contract_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.contract_header (
    id uuid NOT NULL,
    contract_number text NOT NULL,
    shop_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    rfq_id uuid,
    quotation_id uuid,
    title text NOT NULL,
    payment_terms text,
    start_date date NOT NULL,
    end_date date,
    notes text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.contract_header OWNER TO retail;

--
-- Name: contract_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.contract_items (
    id uuid NOT NULL,
    contract_id uuid NOT NULL,
    product_id uuid,
    description text,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.contract_items OWNER TO retail;

--
-- Name: cost_layers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.cost_layers (
    id uuid NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    gr_id uuid,
    ledger_id uuid,
    qty_remaining numeric(12,3) NOT NULL,
    qty_original numeric(12,3) NOT NULL,
    unit_cost numeric(14,4) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.cost_layers OWNER TO retail;

--
-- Name: credit_notes; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.credit_notes (
    id uuid NOT NULL,
    credit_number text NOT NULL,
    credit_date date NOT NULL,
    shop_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    invoice_id uuid,
    return_id uuid,
    status public."CreditNoteStatus" DEFAULT 'DRAFT'::public."CreditNoteStatus" NOT NULL,
    amount numeric(14,2) NOT NULL,
    applied_amount numeric(14,2) DEFAULT 0 NOT NULL,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.credit_notes OWNER TO retail;

--
-- Name: currencies; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.currencies (
    code text NOT NULL,
    name text NOT NULL,
    decimals integer DEFAULT 2 NOT NULL
);


ALTER TABLE public.currencies OWNER TO retail;

--
-- Name: customer_return_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.customer_return_items (
    id uuid NOT NULL,
    return_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL
);


ALTER TABLE public.customer_return_items OWNER TO retail;

--
-- Name: customer_returns; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.customer_returns (
    id uuid NOT NULL,
    return_number text NOT NULL,
    return_date date NOT NULL,
    shop_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    invoice_id uuid,
    sales_order_id uuid,
    reason text,
    remarks text,
    status public."ReturnStatus" DEFAULT 'DRAFT'::public."ReturnStatus" NOT NULL,
    total_value numeric(14,2) DEFAULT 0 NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.customer_returns OWNER TO retail;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.customers (
    id uuid NOT NULL,
    customer_code text NOT NULL,
    customer_name text NOT NULL,
    email text,
    phone text,
    tax_id text,
    street text,
    city text,
    state text,
    postal_code text,
    country text,
    shop_id uuid NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    pan text
);


ALTER TABLE public.customers OWNER TO retail;

--
-- Name: damaged_stock; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.damaged_stock (
    id uuid NOT NULL,
    damage_number text NOT NULL,
    damage_date date NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    damaged_quantity numeric(12,3) NOT NULL,
    reason text NOT NULL,
    remarks text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.damaged_stock OWNER TO retail;

--
-- Name: data_retention_config; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.data_retention_config (
    id uuid NOT NULL,
    entity text NOT NULL,
    retain_days integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.data_retention_config OWNER TO retail;

--
-- Name: device_registrations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.device_registrations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    device_id text NOT NULL,
    device_name text,
    platform public."DevicePlatform" NOT NULL,
    push_token text,
    app_version text,
    os_version text,
    is_active boolean DEFAULT true NOT NULL,
    last_active_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.device_registrations OWNER TO retail;

--
-- Name: document_email_outbox; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.document_email_outbox (
    id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    document_number text NOT NULL,
    template_id text NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid,
    recipient text NOT NULL,
    attachment_filename text,
    status public."DocumentEmailStatus" DEFAULT 'PENDING_PDF'::public."DocumentEmailStatus" NOT NULL,
    trigger public."DocumentEmailTrigger" DEFAULT 'MANUAL'::public."DocumentEmailTrigger" NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    last_error text,
    next_retry_at timestamp(6) with time zone,
    payload_json jsonb NOT NULL,
    sent_at timestamp(6) with time zone,
    sent_by_id uuid,
    message_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.document_email_outbox OWNER TO retail;

--
-- Name: document_sequences; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.document_sequences (
    id uuid NOT NULL,
    doc_type text NOT NULL,
    shop_id uuid NOT NULL,
    year_month text NOT NULL,
    last_seq integer NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.document_sequences OWNER TO retail;

--
-- Name: document_series_config; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.document_series_config (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid,
    doc_type text NOT NULL,
    module_label text NOT NULL,
    prefix text NOT NULL,
    starting_number integer DEFAULT 1 NOT NULL,
    pad_width integer DEFAULT 5 NOT NULL,
    restart_period public."DocumentSeriesRestart" DEFAULT 'NONE'::public."DocumentSeriesRestart" NOT NULL,
    shop_scoped boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    use_category_prefix boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.document_series_config OWNER TO retail;

--
-- Name: email_delivery_log; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_delivery_log (
    id uuid NOT NULL,
    template_id text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    recipient text NOT NULL,
    sent_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    click_count integer DEFAULT 0 NOT NULL,
    open_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.email_delivery_log OWNER TO retail;

--
-- Name: email_sender_domains; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_sender_domains (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    domain text NOT NULL,
    dkim_selector text NOT NULL,
    dkim_host text NOT NULL,
    dkim_value text NOT NULL,
    status public."EmailSenderStatus" DEFAULT 'PENDING'::public."EmailSenderStatus" NOT NULL,
    verified_at timestamp(6) with time zone,
    last_checked_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.email_sender_domains OWNER TO retail;

--
-- Name: email_sender_identities; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_sender_identities (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    domain_id uuid,
    display_name text NOT NULL,
    email text NOT NULL,
    sender_type public."EmailSenderType" NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    status public."EmailSenderStatus" DEFAULT 'PENDING'::public."EmailSenderStatus" NOT NULL,
    verified_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    smtp_host text,
    smtp_port integer,
    smtp_secure boolean,
    smtp_user text,
    smtp_password_enc text,
    smtp_configured_at timestamp(6) with time zone,
    smtp_last_verified_at timestamp(6) with time zone
);


ALTER TABLE public.email_sender_identities OWNER TO retail;

--
-- Name: email_sender_verifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.email_sender_verifications (
    id uuid NOT NULL,
    sender_id uuid NOT NULL,
    otp_hash text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.email_sender_verifications OWNER TO retail;

--
-- Name: fx_rates; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.fx_rates (
    id uuid NOT NULL,
    base text NOT NULL,
    quote text NOT NULL,
    rate numeric(18,8) NOT NULL,
    as_of timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.fx_rates OWNER TO retail;

--
-- Name: goods_issue_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_issue_header (
    id uuid NOT NULL,
    gi_number text NOT NULL,
    gi_date date NOT NULL,
    shop_id uuid NOT NULL,
    issue_reason text NOT NULL,
    remarks text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    issue_type text NOT NULL,
    other_reason text
);


ALTER TABLE public.goods_issue_header OWNER TO retail;

--
-- Name: goods_issue_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_issue_items (
    id uuid NOT NULL,
    gi_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    available_stock_snapshot numeric(12,3) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.goods_issue_items OWNER TO retail;

--
-- Name: goods_receipt_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_receipt_header (
    id uuid NOT NULL,
    gr_number text NOT NULL,
    gr_date date NOT NULL,
    shop_id uuid NOT NULL,
    supplier_name text NOT NULL,
    purchase_order_id uuid,
    supplier_ref text,
    remarks text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    receipt_type public."ReceiptType" DEFAULT 'FULL'::public."ReceiptType" NOT NULL,
    receipt_source public."ReceiptSource" DEFAULT 'PURCHASE_ORDER'::public."ReceiptSource" NOT NULL,
    inward_shift public."InwardShift"
);


ALTER TABLE public.goods_receipt_header OWNER TO retail;

--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.goods_receipt_items (
    id uuid NOT NULL,
    gr_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    purchase_rate numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    batch_number text,
    serial_number text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    expiry_date date,
    storage_location_id uuid
);


ALTER TABLE public.goods_receipt_items OWNER TO retail;

--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.idempotency_keys (
    id uuid NOT NULL,
    key text NOT NULL,
    scope text,
    result jsonb NOT NULL,
    user_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone
);


ALTER TABLE public.idempotency_keys OWNER TO retail;

--
-- Name: invoice_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.invoice_header (
    id uuid NOT NULL,
    invoice_number text NOT NULL,
    invoice_date date NOT NULL,
    sales_order_id uuid,
    customer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_value numeric(14,2) NOT NULL,
    paid_value numeric(14,2) DEFAULT 0 NOT NULL,
    due_date date,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.invoice_header OWNER TO retail;

--
-- Name: job_failures; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.job_failures (
    id uuid NOT NULL,
    queue text NOT NULL,
    job_name text NOT NULL,
    job_id text,
    data jsonb,
    error_name text,
    error_message text,
    stack text,
    attempts integer DEFAULT 0 NOT NULL,
    failed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.job_failures OWNER TO retail;

--
-- Name: lifecycle_campaign_enrollments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.lifecycle_campaign_enrollments (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    campaign_key text NOT NULL,
    scheduled_for timestamp(6) with time zone,
    sent_at timestamp(6) with time zone,
    status public."LifecycleCampaignStatus" DEFAULT 'SCHEDULED'::public."LifecycleCampaignStatus" NOT NULL,
    email_delivery_log_id uuid,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.lifecycle_campaign_enrollments OWNER TO retail;

--
-- Name: media_assets; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.media_assets (
    id uuid NOT NULL,
    company_id uuid,
    shop_id uuid,
    branding_profile_id uuid,
    type public."MediaAssetType" NOT NULL,
    asset_key text NOT NULL,
    file_name text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    uploaded_by uuid,
    uploaded_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.media_assets OWNER TO retail;

--
-- Name: notification_audit_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notification_audit_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action text NOT NULL,
    notification_id uuid,
    approval_id uuid,
    details jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notification_audit_logs OWNER TO retail;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notification_preferences (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    gr_created boolean DEFAULT true NOT NULL,
    gr_approved boolean DEFAULT true NOT NULL,
    gr_rejected boolean DEFAULT true NOT NULL,
    po_approval_required boolean DEFAULT true NOT NULL,
    po_approved boolean DEFAULT true NOT NULL,
    po_rejected boolean DEFAULT true NOT NULL,
    low_stock_alert boolean DEFAULT true NOT NULL,
    transfer_completed boolean DEFAULT true NOT NULL,
    inventory_adjustment boolean DEFAULT true NOT NULL,
    login_alert boolean DEFAULT true NOT NULL,
    device_alert boolean DEFAULT true NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    email_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO retail;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    company_id uuid NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type public."AlertType" NOT NULL,
    priority public."NotificationPriority" DEFAULT 'NORMAL'::public."NotificationPriority" NOT NULL,
    module public."NotificationModule" NOT NULL,
    status public."NotificationStatus" DEFAULT 'UNREAD'::public."NotificationStatus" NOT NULL,
    reference_type text,
    reference_id text,
    deep_link text,
    action_url text,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone,
    created_by uuid
);


ALTER TABLE public.notifications OWNER TO retail;

--
-- Name: password_reset_requests; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.password_reset_requests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    email text NOT NULL,
    method public."PasswordResetMethod" NOT NULL,
    otp_hash text,
    link_token_hash text,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_sent_at timestamp(6) with time zone,
    requested_ip text,
    requested_user_agent text
);


ALTER TABLE public.password_reset_requests OWNER TO retail;

--
-- Name: payment_receipts; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.payment_receipts (
    id uuid NOT NULL,
    receipt_number text NOT NULL,
    receipt_date date NOT NULL,
    invoice_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    amount numeric(14,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    method text,
    reference text,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.payment_receipts OWNER TO retail;

--
-- Name: platform_audit_log; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.platform_audit_log (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    action text DEFAULT 'CREATE'::text NOT NULL
);


ALTER TABLE public.platform_audit_log OWNER TO retail;

--
-- Name: platform_notification_reads; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.platform_notification_reads (
    id uuid NOT NULL,
    notification_id uuid NOT NULL,
    admin_email text NOT NULL,
    read_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.platform_notification_reads OWNER TO retail;

--
-- Name: platform_notifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.platform_notifications (
    id uuid NOT NULL,
    category public."PlatformNotificationCategory" NOT NULL,
    severity public."PlatformNotificationSeverity" DEFAULT 'INFO'::public."PlatformNotificationSeverity" NOT NULL,
    notification_key text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    action_url text,
    reference_type text,
    reference_id uuid,
    company_id uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone
);


ALTER TABLE public.platform_notifications OWNER TO retail;

--
-- Name: po_cancel_verifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.po_cancel_verifications (
    id uuid NOT NULL,
    po_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reason text NOT NULL,
    otp_hash text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.po_cancel_verifications OWNER TO retail;

--
-- Name: product_barcodes; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.product_barcodes (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    company_id uuid,
    barcode text NOT NULL,
    barcode_type public."BarcodeType" DEFAULT 'INTERNAL'::public."BarcodeType" NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    supplier_id uuid,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.product_barcodes OWNER TO retail;

--
-- Name: product_plants; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.product_plants (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    storage_location_id uuid,
    opening_stock numeric(12,3) DEFAULT 0 NOT NULL,
    min_stock_level numeric(12,3) DEFAULT 0 NOT NULL,
    max_stock_level numeric(12,3),
    reorder_qty numeric(12,3),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    batch_number text,
    expiry_date date
);


ALTER TABLE public.product_plants OWNER TO retail;

--
-- Name: product_specifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.product_specifications (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    label text NOT NULL,
    value text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.product_specifications OWNER TO retail;

--
-- Name: products; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    product_code text NOT NULL,
    description text NOT NULL,
    uom text NOT NULL,
    category text NOT NULL,
    hsn_code text,
    material_group text,
    drawing_reference text,
    brand text,
    tax_preference public."TaxPreference" DEFAULT 'TAXABLE'::public."TaxPreference" NOT NULL,
    purchase_price numeric(12,2) NOT NULL,
    selling_price numeric(12,2) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    gst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    image_url text,
    thumbnail_url text
);


ALTER TABLE public.products OWNER TO retail;

--
-- Name: purchase_order_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.purchase_order_header (
    id uuid NOT NULL,
    po_number text NOT NULL,
    po_date date NOT NULL,
    shop_id uuid NOT NULL,
    rfq_id uuid,
    contract_id uuid,
    supplier text NOT NULL,
    status public."PurchaseOrderStatus" DEFAULT 'DRAFT'::public."PurchaseOrderStatus" NOT NULL,
    remarks text,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.purchase_order_header OWNER TO retail;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.purchase_order_items (
    id uuid NOT NULL,
    po_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    rfq_item_id uuid,
    current_stock numeric(12,3) NOT NULL,
    min_stock numeric(12,3) NOT NULL,
    suggested_qty numeric(12,3) NOT NULL,
    order_qty numeric(12,3) NOT NULL,
    rate numeric(12,2) NOT NULL,
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_rate numeric(7,4) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    line_description text,
    line_category text
);


ALTER TABLE public.purchase_order_items OWNER TO retail;

--
-- Name: report_saved_filters; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.report_saved_filters (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    report_type text NOT NULL,
    name text NOT NULL,
    filter_json jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.report_saved_filters OWNER TO retail;

--
-- Name: restore_jobs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.restore_jobs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    artifact_id uuid NOT NULL,
    mode public."RestoreMode" DEFAULT 'TENANT_REPLACE'::public."RestoreMode" NOT NULL,
    status public."RestoreJobStatus" DEFAULT 'PENDING'::public."RestoreJobStatus" NOT NULL,
    dry_run_report jsonb,
    confirmation_token text,
    error_message text,
    started_at timestamp(6) with time zone,
    completed_at timestamp(6) with time zone,
    created_by uuid,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.restore_jobs OWNER TO retail;

--
-- Name: rfq_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.rfq_header (
    id uuid NOT NULL,
    rfq_number text NOT NULL,
    rfq_date date NOT NULL,
    deadline date,
    title text NOT NULL,
    notes text,
    shop_id uuid NOT NULL,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'LIVE'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.rfq_header OWNER TO retail;

--
-- Name: rfq_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.rfq_items (
    id uuid NOT NULL,
    rfq_header_id uuid NOT NULL,
    product_id uuid,
    description text,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    specifications text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.rfq_items OWNER TO retail;

--
-- Name: rfq_suppliers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.rfq_suppliers (
    id uuid NOT NULL,
    rfq_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.rfq_suppliers OWNER TO retail;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name public."RoleName" NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.roles OWNER TO retail;

--
-- Name: sales_order_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_order_header (
    id uuid NOT NULL,
    so_number text NOT NULL,
    order_date date NOT NULL,
    expected_date date,
    customer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."SalesOrderStatus" DEFAULT 'DRAFT'::public."SalesOrderStatus" NOT NULL,
    fulfillment_status public."FulfillmentStatus" DEFAULT 'NONE'::public."FulfillmentStatus" NOT NULL,
    remarks text,
    currency text DEFAULT 'USD'::text NOT NULL,
    fx_rate_used numeric(18,8),
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL,
    gst_supply_type public."GstSupplyType" DEFAULT 'INTRA_STATE'::public."GstSupplyType" NOT NULL,
    subtotal_before_tax numeric(14,2) DEFAULT 0 NOT NULL,
    total_cgst numeric(14,2) DEFAULT 0 NOT NULL,
    total_sgst numeric(14,2) DEFAULT 0 NOT NULL,
    total_igst numeric(14,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.sales_order_header OWNER TO retail;

--
-- Name: sales_order_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_order_items (
    id uuid NOT NULL,
    so_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    shipped_qty numeric(12,3) DEFAULT 0 NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    discount_amount numeric(14,2) DEFAULT 0 NOT NULL,
    tax_rate numeric(7,4) DEFAULT 0 NOT NULL,
    tax_amount numeric(14,2) DEFAULT 0 NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    cgst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    sgst_rate numeric(7,4) DEFAULT 0 NOT NULL,
    igst_rate numeric(7,4) DEFAULT 0 NOT NULL
);


ALTER TABLE public.sales_order_items OWNER TO retail;

--
-- Name: sales_quote_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_quote_header (
    id uuid NOT NULL,
    quote_number text NOT NULL,
    quote_date date NOT NULL,
    valid_until date,
    customer_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."SalesQuotationStatus" DEFAULT 'DRAFT'::public."SalesQuotationStatus" NOT NULL,
    sales_order_id uuid,
    portal_token text,
    remarks text,
    total_value numeric(14,2),
    customer_requested_total numeric(14,2),
    customer_request_note text,
    customer_responded_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'LIVE'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.sales_quote_header OWNER TO retail;

--
-- Name: sales_quote_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sales_quote_items (
    id uuid NOT NULL,
    quote_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.sales_quote_items OWNER TO retail;

--
-- Name: scan_logs; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.scan_logs (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid,
    barcode text NOT NULL,
    product_id uuid,
    user_id uuid NOT NULL,
    action public."ScanAction" DEFAULT 'LOOKUP'::public."ScanAction" NOT NULL,
    result public."ScanResult" DEFAULT 'FOUND'::public."ScanResult" NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source public."ScanSource" DEFAULT 'API'::public."ScanSource" NOT NULL,
    session_id uuid
);


ALTER TABLE public.scan_logs OWNER TO retail;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_hash text NOT NULL,
    ip text,
    user_agent text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_seen_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_at timestamp(6) with time zone,
    expires_at timestamp(6) with time zone,
    device_name text
);


ALTER TABLE public.sessions OWNER TO retail;

--
-- Name: shops; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.shops (
    id uuid NOT NULL,
    shop_number text NOT NULL,
    shop_name text NOT NULL,
    tax_id text,
    address text NOT NULL,
    contact_person text NOT NULL,
    mobile text NOT NULL,
    email text NOT NULL,
    company_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    costing_method public."CostingMethod" DEFAULT 'AVERAGE'::public."CostingMethod" NOT NULL,
    functional_currency text DEFAULT 'USD'::text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_profile_id uuid
);


ALTER TABLE public.shops OWNER TO retail;

--
-- Name: signup_verifications; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.signup_verifications (
    id uuid NOT NULL,
    email text NOT NULL,
    payload jsonb NOT NULL,
    otp_hash text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    session_token_hash text,
    totp_secret_encrypted text
);


ALTER TABLE public.signup_verifications OWNER TO retail;

--
-- Name: stock_count_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_count_items (
    id uuid NOT NULL,
    session_id uuid NOT NULL,
    product_id uuid NOT NULL,
    counted_qty numeric(12,3) DEFAULT 0 NOT NULL,
    expected_qty numeric(12,3),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.stock_count_items OWNER TO retail;

--
-- Name: stock_count_sessions; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_count_sessions (
    id uuid NOT NULL,
    session_number text NOT NULL,
    company_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    status public."StockCountStatus" DEFAULT 'OPEN'::public."StockCountStatus" NOT NULL,
    remarks text,
    started_by uuid NOT NULL,
    approved_by uuid,
    approved_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.stock_count_sessions OWNER TO retail;

--
-- Name: stock_ledger; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_ledger (
    id uuid NOT NULL,
    transaction_type public."TransactionType" NOT NULL,
    transaction_ref text NOT NULL,
    transaction_date date NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    in_qty numeric(12,3) DEFAULT 0 NOT NULL,
    out_qty numeric(12,3) DEFAULT 0 NOT NULL,
    balance_qty numeric(12,3) NOT NULL,
    unit_rate numeric(12,2),
    value numeric(14,2),
    remarks text,
    idempotency_key text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.stock_ledger OWNER TO retail;

--
-- Name: stock_summary; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_summary (
    id uuid NOT NULL,
    shop_id uuid NOT NULL,
    product_id uuid NOT NULL,
    current_stock numeric(12,3) NOT NULL,
    avg_cost numeric(14,4) DEFAULT 0 NOT NULL,
    last_movement_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.stock_summary OWNER TO retail;

--
-- Name: stock_transfer_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_transfer_header (
    id uuid NOT NULL,
    transfer_number text NOT NULL,
    transfer_date date NOT NULL,
    from_shop_id uuid NOT NULL,
    to_shop_id uuid NOT NULL,
    from_storage_location_id uuid,
    to_storage_location_id uuid,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    notes text,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.stock_transfer_header OWNER TO retail;

--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.stock_transfer_items (
    id uuid NOT NULL,
    transfer_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL
);


ALTER TABLE public.stock_transfer_items OWNER TO retail;

--
-- Name: storage_locations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.storage_locations (
    id uuid NOT NULL,
    shop_id uuid NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.storage_locations OWNER TO retail;

--
-- Name: subscription_invoices; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.subscription_invoices (
    id uuid NOT NULL,
    invoice_number text NOT NULL,
    company_id uuid NOT NULL,
    plan public."SubscriptionPlan" NOT NULL,
    billing_cycle public."BillingCycle" NOT NULL,
    amount_paise integer NOT NULL,
    tax_paise integer DEFAULT 0 NOT NULL,
    total_paise integer NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    gst_number text,
    billing_address_snapshot jsonb,
    issued_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    pdf_storage_key text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.subscription_invoices OWNER TO retail;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.subscription_payments (
    id uuid NOT NULL,
    company_id uuid,
    plan public."SubscriptionPlan" NOT NULL,
    billing_cycle public."BillingCycle" NOT NULL,
    amount_paise integer NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    razorpay_order_id text NOT NULL,
    razorpay_payment_id text,
    status text DEFAULT 'pending'::text NOT NULL,
    verified_at timestamp(6) with time zone,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    invoice_id uuid,
    failure_reason text,
    renewal_attempt integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO retail;

--
-- Name: supplier_bill_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_bill_header (
    id uuid NOT NULL,
    bill_number text NOT NULL,
    bill_date date NOT NULL,
    due_date date,
    shop_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    purchase_order_id uuid,
    goods_receipt_id uuid,
    status public."SupplierBillStatus" DEFAULT 'DRAFT'::public."SupplierBillStatus" NOT NULL,
    total_value numeric(14,2) NOT NULL,
    paid_value numeric(14,2) DEFAULT 0 NOT NULL,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.supplier_bill_header OWNER TO retail;

--
-- Name: supplier_bill_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_bill_items (
    id uuid NOT NULL,
    bill_header_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL
);


ALTER TABLE public.supplier_bill_items OWNER TO retail;

--
-- Name: supplier_payments; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_payments (
    id uuid NOT NULL,
    payment_number text NOT NULL,
    payment_date date NOT NULL,
    supplier_bill_id uuid NOT NULL,
    shop_id uuid NOT NULL,
    amount numeric(14,2) NOT NULL,
    method text,
    reference text,
    remarks text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.supplier_payments OWNER TO retail;

--
-- Name: supplier_quote_header; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_quote_header (
    id uuid NOT NULL,
    quote_number text NOT NULL,
    quote_date date NOT NULL,
    shop_id uuid NOT NULL,
    rfq_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    notes text,
    status public."DocumentStatus" DEFAULT 'DRAFT'::public."DocumentStatus" NOT NULL,
    posted_at timestamp(6) with time zone,
    total_value numeric(14,2),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_quote_header OWNER TO retail;

--
-- Name: supplier_quote_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_quote_items (
    id uuid NOT NULL,
    quote_header_id uuid NOT NULL,
    rfq_item_id uuid,
    product_id uuid,
    description text,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    specifications text,
    unit_price numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.supplier_quote_items OWNER TO retail;

--
-- Name: supplier_return_images; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_return_images (
    id uuid NOT NULL,
    return_id uuid NOT NULL,
    return_item_id uuid,
    file_path text NOT NULL,
    public_url text NOT NULL,
    original_filename text NOT NULL,
    mime_type text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid
);


ALTER TABLE public.supplier_return_images OWNER TO retail;

--
-- Name: supplier_return_items; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_return_items (
    id uuid NOT NULL,
    return_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(12,3) NOT NULL,
    uom text NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    line_value numeric(14,2) NOT NULL,
    goods_receipt_item_id uuid,
    grn_quantity numeric(12,3),
    reason_code public."SupplierReturnReasonCode"
);


ALTER TABLE public.supplier_return_items OWNER TO retail;

--
-- Name: supplier_returns; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.supplier_returns (
    id uuid NOT NULL,
    return_number text NOT NULL,
    return_date date NOT NULL,
    shop_id uuid NOT NULL,
    supplier_name text NOT NULL,
    purchase_order_id uuid,
    reason text,
    remarks text,
    status public."ReturnStatus" DEFAULT 'DRAFT'::public."ReturnStatus" NOT NULL,
    total_value numeric(14,2) DEFAULT 0 NOT NULL,
    posted_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    supplier_id uuid,
    goods_receipt_id uuid,
    supplier_ref text,
    internal_cc_email text,
    submitted_at timestamp(6) with time zone,
    acknowledged_at timestamp(6) with time zone,
    email_sent_at timestamp(6) with time zone,
    ack_token_hash text,
    email_message_id text,
    branding_mode public."BrandingMode" DEFAULT 'SNAPSHOT'::public."BrandingMode" NOT NULL,
    branding_snapshot jsonb,
    branding_version integer,
    template_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.supplier_returns OWNER TO retail;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    supplier_code text NOT NULL,
    supplier_name text NOT NULL,
    company_id uuid,
    tax_id text,
    vat_number text,
    rating integer DEFAULT 0 NOT NULL,
    categories text[] DEFAULT ARRAY[]::text[],
    contact_person text,
    email text,
    phone text,
    street text,
    city text,
    state text,
    postal_code text,
    country text,
    payment_terms text,
    bank_name text,
    account_number text,
    routing_number text,
    iban text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    deleted_at timestamp(6) with time zone
);


ALTER TABLE public.suppliers OWNER TO retail;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.system_settings (
    id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.system_settings OWNER TO retail;

--
-- Name: trusted_mfa_devices; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.trusted_mfa_devices (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    ip text,
    user_agent text,
    last_used_at timestamp(6) with time zone,
    expires_at timestamp(6) with time zone NOT NULL,
    revoked_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.trusted_mfa_devices OWNER TO retail;

--
-- Name: user_backup_codes; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.user_backup_codes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    code_hash text NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_backup_codes OWNER TO retail;

--
-- Name: user_invitations; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.user_invitations (
    id uuid NOT NULL,
    email text NOT NULL,
    name text,
    role_id uuid NOT NULL,
    shop_id uuid,
    token_hash text NOT NULL,
    invited_by uuid NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_invitations OWNER TO retail;

--
-- Name: users; Type: TABLE; Schema: public; Owner: retail
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    avatar_url text,
    role_id uuid NOT NULL,
    shop_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    deleted_at timestamp(6) with time zone,
    last_login_at timestamp(6) with time zone,
    refresh_token_hash text,
    failed_login_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by uuid,
    updated_by uuid,
    password_changed_at timestamp(6) with time zone,
    mfa_enabled boolean DEFAULT false NOT NULL,
    mfa_method public."MfaMethod",
    mfa_enrolled_at timestamp(6) with time zone,
    mfa_secret_encrypted text
);


ALTER TABLE public.users OWNER TO retail;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
fe618f34-4495-4741-a3a3-bdfcb11e9d1c	395bf7b251d1c3e49e25ccbea2febd13bf1d57ab756bea31b38865e3630e2f90	2026-05-24 19:06:05.573271+00	20260412000000_init		\N	2026-05-24 19:06:05.573271+00	0
40e97216-1eee-4613-b52b-0e9b7ba179c5	643965f6eb56bb98a098c5d4086868e699e0225bfd7f40207d386dbae1ae26cd	2026-05-24 19:06:07.035075+00	20260412120000_fix_stock_ledger_balance_trigger		\N	2026-05-24 19:06:07.035075+00	0
d9ebe1c5-6a97-4ffd-b1b7-867928259c56	89153ce122025f9541cf8beccdad0ef688156aac0a2c1afb49ed07d655c48ee0	2026-05-24 19:06:08.589737+00	20260412140000_stock_trigger_coalesce_new_qty		\N	2026-05-24 19:06:08.589737+00	0
ba5430ed-4245-463b-be15-84c1db3b973d	aa8e79339cb9b1067a8f65da6005dca8d5c8c13bda4e065ab6588882f065322f	2026-05-24 19:06:10.265467+00	20260415185536_add_avatar_url		\N	2026-05-24 19:06:10.265467+00	0
31667e79-30a0-423d-a9c0-aa2b3c6df27f	4996096dc6dd0177eb1ece4c58eacf963afbf31a791969fea58e9b5b5234dd42	2026-05-24 19:06:11.747009+00	20260422170000_add_procurement_master		\N	2026-05-24 19:06:11.747009+00	0
afe8eacc-1f20-4b31-aae5-e3610f8a5f56	a74be1370dd5b1be4a7423dda5c60515f5c388496d4eaab27bdb6384f7f18164	2026-05-24 19:06:13.311018+00	20260422173000_add_supplier_quotations		\N	2026-05-24 19:06:13.311018+00	0
e564b00f-ccb8-4af3-bcdc-083c3bce0621	b987d5131402d34f092775b855673983585276940c3d2409979296047bbaa95a	2026-05-24 19:06:14.94519+00	20260501153000_add_product_storage_location		\N	2026-05-24 19:06:14.94519+00	0
c52f8f69-3f7a-44e1-b33d-e9a917ee6f48	f9d2d5f013e72397ad6c865a478dbcada864e7df7d99de772060620784a585ca	2026-05-24 19:06:16.500978+00	20260505000000_phase1_data_integrity		\N	2026-05-24 19:06:16.500978+00	0
28a5d128-4049-4774-9ade-2aafd503cdc1	2437d3f5a188f2dd3ae7be65257ac1d7bd758b0f3182b3dd4d128912de0b1386	2026-05-24 19:06:18.043701+00	20260505000100_phase3_indexes		\N	2026-05-24 19:06:18.043701+00	0
98e834f4-f518-478a-86d4-43e2dd4a4404	9c6caf3014d25604a7b9f443deeb870abc3c7c894e944faa6a62986e301bf9d7	2026-05-24 19:06:19.69332+00	20260505160000_tier2_phase1_phase3_schema		\N	2026-05-24 19:06:19.69332+00	0
e040ceb0-cb6d-482f-8200-d79640e9a4a5	fa9af234f180a07e0cfc0d67856b429daa2fc0309a6d590d91606b793a84e00d	2026-05-24 19:06:21.248659+00	20260505180000_tier2_phase4_domain		\N	2026-05-24 19:06:21.248659+00	0
faa657ca-398d-4777-a642-64102bbe3703	1a3b04af0b31001c32a7ef5f68ef92acc62dc2317c0cea5efa5c1e9959971dd3	2026-05-24 19:06:22.801333+00	20260508120000_multi_plant_products		\N	2026-05-24 19:06:22.801333+00	0
fe59d8d4-8b15-43ca-9115-1fe0ef0ca6b3	24ce951b2e2f7b1fd2010497345e904aff79935e0b8c2aa314e66dbbe6d6c6be	2026-05-24 19:06:24.361165+00	20260522120000_gr_item_batch_serial		\N	2026-05-24 19:06:24.361165+00	0
05646b0d-78a8-46e8-b4f1-1ab742e68437	9e50ab672f4e996eb326a2bacc7ec753ecf9eb77be7350b838046ec576dc8753	2026-05-24 19:06:26.023322+00	20260522140000_product_hsn_code		\N	2026-05-24 19:06:26.023322+00	0
f48e92f7-4bbd-45a6-b7b6-d03bf508c0e6	8d0709e759830928bdf75453ded5eb0ddafc3e0ff0a26ab6a0e7ed5821186245	2026-05-24 19:06:27.563857+00	20260523120000_signup_verification		\N	2026-05-24 19:06:27.563857+00	0
737c4b82-41a4-4e4e-b534-d97b84650f54	2e46a4fdc1d8bffc0b07e3f26306d18d46f35bcf61eb9792e62f4d9ec0af50c1	2026-05-24 19:06:29.075974+00	20260523133000_user_invitations		\N	2026-05-24 19:06:29.075974+00	0
a1483ff7-ae63-4865-a948-9de451041935	27855cf22b17adad845edc5f26c811833499427706fa747e88f7ef4c9bf35eb3	2026-05-24 19:06:30.724029+00	20260523141200_rls_phase1		\N	2026-05-24 19:06:30.724029+00	0
5fbf6e25-83ab-40ce-8d59-7483f6eb02aa	f15d497a79cf5f474ad9bf0eae9333ad2e9f2258b7ece5bf7cf5db58c3d6d2a5	2026-05-24 19:06:32.280927+00	20260523150000_product_brand_tax_preference		\N	2026-05-24 19:06:32.280927+00	0
8cc1de0c-9a4a-4f0a-8116-963c2610898a	f690ee0e7291ee054f81110cec2c1e9efc7f447e4acef6086db9f27634a8d934	2026-05-24 19:10:10.634539+00	20260523160000_supplier_vendor_profile		\N	2026-05-24 19:10:10.634539+00	0
a88abae0-ddb6-4158-9c8c-6faf72a118da	e4e5c732dc2c66dbcd93ba9355244a796a4cf714c7eb435225d3b030dcb370ef	2026-05-24 19:10:12.211858+00	20260523170000_system_roles_owner		\N	2026-05-24 19:10:12.211858+00	0
08102345-1880-4a00-a685-d654d86a3287	36090dde5fb76a2431257bc7f52a361d368ead38324e48dbe03630c22edf140a	2026-05-24 19:10:13.771597+00	20260523170100_system_roles_data		\N	2026-05-24 19:10:13.771597+00	0
7b993e92-131d-4bc2-a6ed-df664c8d6789	ffbfdc2d4e3a0af046553216419f203f0f0b15138e6d32f0791d6b4fe8211ab0	2026-05-24 19:10:15.325278+00	20260524140000_company_subscriptions		\N	2026-05-24 19:10:15.325278+00	0
51c8090b-39be-405b-b5d2-a2a7291f754d	1ea1692394285b5bdcf3d57025a1c1766bad2765f5aa869c5f2f62957918384f	2026-05-24 19:10:16.852138+00	20260524_add_rfq_links_to_po		\N	2026-05-24 19:10:16.852138+00	0
1f92e264-d1e6-4d94-829b-8e744974d58e	3e902a94a3263487765210da3ab5d92ea6719e9878df213ad2086aa2b2a8fe54	2026-05-27 11:22:53.204869+00	20260529120000_add_email_sender_identities	\N	\N	2026-05-27 11:22:53.171974+00	1
710ccd4e-bef3-4a4d-b466-d2567ca008ae	edb15c2d9cc79399c69f0450c53a743dc5b9921640ca2c57445551c121bae35e	2026-05-25 08:06:26.510838+00	20260525133000_supplier_return_ack_flow	\N	\N	2026-05-25 08:06:26.475587+00	1
7bffbf09-3b76-40d8-b2be-2160bba4a21a	ce22384a1ac1db4da9374c3870b2816df2f598c1c8b6719cb2dc5585adbd7fed	2026-05-26 13:13:20.854117+00	20260526140000_add_email_backup_provider	\N	\N	2026-05-26 13:13:20.848845+00	1
4dcfe481-2e2e-4e46-a16a-993d0ec80584	fe72411970ebd97b605a96f8115b211c31fc73a68542413511f93c71d275afcf	2026-05-25 08:51:58.301192+00	20260525141000_password_reset_flow	\N	\N	2026-05-25 08:51:58.279307+00	1
aac61a55-9400-470d-91b8-91e96f3bc1fa	8efd71d595c34cfd6c489e23d9d790a10d4e782cd6bee45a7e65e4d776eb86de	2026-05-25 09:54:48.189428+00	20260525150000_totp_mfa_auth	\N	\N	2026-05-25 09:54:48.155443+00	1
e75b54af-4ee3-435b-a18d-2d311f4f3609	5f8a7a204a2929516f6c69d0ea4e99563b31e01a263b7265cb7fcdbb78a15e52	2026-05-27 10:21:10.280952+00	20260527143000_add_customer_pan	\N	\N	2026-05-27 10:21:10.275215+00	1
a5296c47-dfb5-4688-b9e3-295d25cb4c64	82abc60e0b33b3a703932b39a596b8827b99e2b7205b595d0bd431e46d1225b7	2026-05-25 10:34:09.779851+00	20260525170000_signup_staged_finalization	\N	\N	2026-05-25 10:34:09.771524+00	1
835347da-0356-4633-b7cc-7f2ffdb33d7f	1573c0d32146904724c505be887fcf606c218748f563f94fcb2458e2b65bfea5	2026-05-26 15:06:29.912346+00	20260526160000_po_line_description	\N	\N	2026-05-26 15:06:29.90348+00	1
63daba35-5db8-4114-a531-6ed1401baed6	a6728f7a5336fabf08f6226c387bfbce69b75cf8a09e6a7c8b1975889a789ea2	2026-05-26 10:21:23.397067+00	20260526120000_company_backups	\N	\N	2026-05-26 10:21:23.358501+00	1
5e20ed56-bcf1-40f9-82f9-684e6f81cb0e	babb35487c386e439028a4756b55ab3722a81fbad2d523d77702b8c9a6fde651	2026-05-26 15:06:29.991681+00	20260526170000_procurement_epic_remaining	\N	\N	2026-05-26 15:06:29.913408+00	1
8a6427bd-5bf2-46b6-beba-f69da27eea65	af8b853b5caa3fee3d1aeff8e47f0a3103fbce9c3e6eb976171d764bbeedb395	2026-05-27 10:58:29.006487+00	20260528120000_add_email_delivery_log	\N	\N	2026-05-27 10:58:28.992893+00	1
1dd613b8-cec9-4e74-9de5-107a9584f0fd	33a0d7669e72762efd41d43fcc798d7ab7dc5d8ca526eb0ae13f7bc5418f7741	2026-05-27 10:21:10.308696+00	20260527160000_add_document_series_config	\N	\N	2026-05-27 10:21:10.281669+00	1
d2d76500-596a-451c-bb49-1cd5650969f3	82973b270ed19c823c11abbfab0387f22dcceed315b546849c4e1d682dfa6d4c	2026-05-27 12:16:16.478871+00	20260530120000_add_email_sender_smtp	\N	\N	2026-05-27 12:16:16.472206+00	1
31dbfdf0-b0a3-4499-8332-ba17ec091d69	e2ae1640fa71a9c030177733fb40067e1a8c80d28e3458ade3ce3017b8d88fb0	2026-05-29 06:22:13.622186+00	20260531120000_flat_document_series_format	\N	\N	2026-05-29 06:22:13.584679+00	1
4489c723-7b10-47e2-baf3-80c9f846c3e8	ae616366d76c6f952b6b3d05185ebcfc5856e24d75d0d6a567b375d82108591d	2026-05-29 06:53:49.486717+00	20260529180000_add_purchase_employee_sales_roles	\N	\N	2026-05-29 06:53:49.473365+00	1
9f27358c-ea78-4d46-8c1d-6b2847557e47	ab6320c30bcef5852cc59c0853948c6c7d12149160de4c0ae1ad4d56fa7410d6	2026-05-29 07:47:16.106806+00	20260531200000_add_document_email_outbox	\N	\N	2026-05-29 07:47:16.058208+00	1
520e509b-a8cb-436b-9b36-6663040a188e	76b7b4ea072e0a660179446c618e128aa8b52563fd232a662cbf723138ee19bf	2026-05-29 10:53:51.57927+00	20260601120000_add_subscription_lifecycle	\N	\N	2026-05-29 10:53:51.377647+00	1
e68c8247-d884-4ade-9fb9-9c11d16a39a3	223c9566b3050a0c9d5c096204a0ea587488a2ab59dad99d71111a6f971571e0	2026-05-29 12:38:37.263853+00	20260603120000_add_platform_notifications	\N	\N	2026-05-29 12:38:37.162621+00	1
24cf7167-6b42-461a-a31e-77fb74fe0eb6	8c93d427ff95a889c435e81d4ce56c76cfce2c7a4e040092da9dbd6a22cb801b	\N	20260602192000_add_procurement_supplier_rfq_master	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260602192000_add_procurement_supplier_rfq_master\n\nDatabase error code: 42703\n\nDatabase error:\nERROR: column "display_name" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42703), message: "column \\"display_name\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("indexcmds.c"), line: Some(1831), routine: Some("ComputeIndexAttrs") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260602192000_add_procurement_supplier_rfq_master"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260602192000_add_procurement_supplier_rfq_master"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-02 15:44:54.874717+00	2026-06-02 15:44:05.501923+00	0
5f1c4691-78d4-4a19-906b-e91e1f2d666c	ac8b7a609c94e3c573dd1327c94d06bdc81a98ad1328ee40a60368709c424d9e	2026-05-30 09:56:56.077501+00	20260604120000_po_idempotency_and_line_columns	\N	\N	2026-05-30 09:56:55.983371+00	1
217e162b-47bc-4a40-8770-95d6c3c6b02f	d8b1d8442c750b11922ed57d58f50817c7724b04c57b4c068fac9057e2c27c4f	2026-05-30 11:43:43.05889+00	20260605120000_add_product_plant_batch_expiry	\N	\N	2026-05-30 11:43:42.996896+00	1
63a7e5a7-b44d-4eb2-bae8-4da32e8fc359	6d4eb85dd903f847a106ff131689ad76d890414d54d17fc9e8febc5bc86fb3dd	2026-05-30 11:43:43.072785+00	20260630123000_add_report_saved_filters	\N	\N	2026-05-30 11:43:43.059557+00	1
4cd2a59b-d1b9-4608-ad00-e477cfca2602	75b7dab793461fdce96f13829117a1e7753fa05f50189faf9fb210298f322596	\N	20260602192000_add_procurement_supplier_rfq_master	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260602192000_add_procurement_supplier_rfq_master\n\nDatabase error code: 42704\n\nDatabase error:\nERROR: type "GstTreatment" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42704), message: "type \\"GstTreatment\\" does not exist", detail: None, hint: None, position: Some(Internal { position: 1434, query: "ALTER TABLE \\"suppliers\\"\\n      ADD COLUMN IF NOT EXISTS \\"company_id\\" UUID,\\n      ADD COLUMN IF NOT EXISTS \\"tax_id\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"vat_number\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"rating\\" INTEGER NOT NULL DEFAULT 0,\\n      ADD COLUMN IF NOT EXISTS \\"categories\\" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],\\n      ADD COLUMN IF NOT EXISTS \\"contact_person\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"email\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"phone\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"street\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"city\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"state\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"postal_code\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"country\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"payment_terms\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"bank_name\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"account_number\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"routing_number\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"iban\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"is_active\\" BOOLEAN NOT NULL DEFAULT true,\\n      ADD COLUMN IF NOT EXISTS \\"deleted_at\\" TIMESTAMPTZ(6),\\n      ADD COLUMN IF NOT EXISTS \\"display_name\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"company_name\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"salutation\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"first_name\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"last_name\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"gstin\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"gst_treatment\\" \\"GstTreatment\\",\\n      ADD COLUMN IF NOT EXISTS \\"source_of_supply\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"pan\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"msme_registered\\" BOOLEAN NOT NULL DEFAULT false,\\n      ADD COLUMN IF NOT EXISTS \\"currency\\" TEXT DEFAULT 'INR',\\n      ADD COLUMN IF NOT EXISTS \\"tds_section\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"remarks\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"work_phone\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"mobile_phone\\" TEXT,\\n      ADD COLUMN IF NOT EXISTS \\"language\\" TEXT DEFAULT 'English'" }), where_: Some("PL/pgSQL function inline_code_block line 4 at SQL statement"), schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("parse_type.c"), line: Some(270), routine: Some("typenameType") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260602192000_add_procurement_supplier_rfq_master"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260602192000_add_procurement_supplier_rfq_master"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-02 15:45:50.115927+00	2026-06-02 15:44:56.492077+00	0
15deb9ef-9cb2-4fa5-9887-a331cd1d5b13	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	2026-06-02 11:41:34.100473+00	20260602123000_add_branding_profiles	\N	\N	2026-06-02 11:41:34.095928+00	1
626f5b22-e57d-4151-98b8-64e21cf78e81	ab243c9b97004eba88ddde3ae04c171da149fabbb6de7dda05bd20044d809c74	2026-06-03 08:29:45.527674+00	20260702120000_add_customers_master_table	\N	\N	2026-06-03 08:29:45.502593+00	1
302c4686-07da-4268-8e11-4e2a7d6ecb2f	02afd311d1a558d0afb8286cb32036962ccb9b7eff48ff59f4f81112f1a10276	2026-06-02 11:41:34.150221+00	20260602140000_add_branding_profiles	\N	\N	2026-06-02 11:41:34.101214+00	1
95b85fc6-e7cd-4fc1-8853-c604f135ba6b	c76f219e3efc79a315558b700b19f69a2efc3d532f72817cabd17fb36a37251c	2026-06-02 15:45:51.871491+00	20260602192000_add_procurement_supplier_rfq_master	\N	\N	2026-06-02 15:45:51.823195+00	1
1e844454-f115-4632-a9e5-ae17f742b43b	23da9305590eb9cd4addc0b1075e8072b0fbb370774239f64a8eecc07c9b470a	\N	20260602193000_add_contracts	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260602193000_add_contracts\n\nDatabase error code: 42P07\n\nDatabase error:\nERROR: relation "contract_header" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P07), message: "relation \\"contract_header\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("heap.c"), line: Some(1164), routine: Some("heap_create_with_catalog") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260602193000_add_contracts"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260602193000_add_contracts"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-02 12:45:58.35274+00	2026-06-02 12:43:48.223823+00	0
ec1cd6bb-4f3b-4d3b-98f5-fe68ad88f1d2	23da9305590eb9cd4addc0b1075e8072b0fbb370774239f64a8eecc07c9b470a	2026-06-02 12:45:58.355886+00	20260602193000_add_contracts		\N	2026-06-02 12:45:58.355886+00	0
bd96f828-010c-4584-8bbe-9073a915fad0	3e70e96641c9e1449f5395e96b84a0c6d5575009288414c5fa64000968dfcf4a	2026-06-02 15:45:51.882074+00	20260701120000_add_shop_tax_id_and_company	\N	\N	2026-06-02 15:45:51.87218+00	1
25d139d3-aad2-45ad-be5a-8981080a6efe	18291e258383ffc89ed335f947bf8c08318db61f6c74d472b3540c9782efd926	2026-06-08 13:53:33.86518+00	20260708120000_add_sales_order_gst_breakdown	\N	\N	2026-06-08 13:53:33.844577+00	1
ac88bec8-536d-4aeb-a0b9-c490a41e7b05	cc023e0c8c9752e25280ce0c8ee7ee2ac90acaa7ec22c01ff0721abde651d762	2026-06-03 08:29:45.547814+00	20260703120000_workflow_e2e_master_tables	\N	\N	2026-06-03 08:29:45.528563+00	1
f0552782-48df-4877-8b9c-af34e629bf2a	0dec0027a839ddbd1c563123ec5dadd3e080d37d327229e46e30f5233f1e428d	2026-06-08 13:53:33.870732+00	20260709120000_sprint3_gst_rate_and_total_igst	\N	\N	2026-06-08 13:53:33.865804+00	1
69d8e5bf-560d-41ea-8741-f262ce5ea89d	e8de4c1af40633bfeb3a6dc4309f7143931b345b5e45ec55993cdb60bd9318c1	2026-06-08 16:47:57.133593+00	20260608120000_add_gr_gi_metadata_fields	\N	\N	2026-06-08 16:47:57.124403+00	1
8b91c082-852e-4d40-9942-90adea464ba6	97112deb191c2e92380f949bf2bde42aab516e9abc23d304963376d5414fecaa	2026-06-09 02:04:51.394359+00	20260609000000_fix_gr_metadata_enum_types	\N	\N	2026-06-09 02:04:51.360449+00	1
fa14eeca-d1a2-4160-99b0-b46624d15825	e31245f8aa3afabf70df8ffff1fe98a1a22e885b9eaf7726aa6f1d496b2afa45	2026-06-11 11:00:21.093002+00	20260611120000_add_barcode_system	\N	\N	2026-06-11 11:00:21.044671+00	1
0375ba06-33a3-461c-a585-32abd5626c49	212d7d9842481ebdb307161c2c7658debf355138fef40712e42ab40b50982940	2026-06-11 11:00:21.097312+00	20260611123000_add_barcode_scan_counters	\N	\N	2026-06-11 11:00:21.093706+00	1
ca6e2540-99a1-4acb-ad0d-a27e0424dc19	bd78982b7bced03186434ac3f208b9d2870ef6768475daafaf8fe0a40d02d43d	2026-06-11 11:00:21.101751+00	20260611130000_add_scan_source	\N	\N	2026-06-11 11:00:21.097879+00	1
62d8a5ea-410c-49ef-963f-fa11e93532c8	35f943c68ca650ad25f6ffb174150c0bd42784081e971aefa0a0cc5bf4bbddae	2026-06-12 05:30:15.032142+00	20260710120000_barcode_enterprise_features	\N	\N	2026-06-12 05:30:14.73865+00	1
de69a6c2-f8b7-4221-a01c-ad895a268cd2	8f81f1f3d13f98c741a7f980e7c1f3f9c35c0186f77f8ca2645bfd3b16e85d88	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "SalesQuotationStatus" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"SalesQuotationStatus\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 09:50:05.135969+00	2026-06-12 08:54:08.630318+00	0
909cc49e-9e43-490d-85a6-937dde091469	8f81f1f3d13f98c741a7f980e7c1f3f9c35c0186f77f8ca2645bfd3b16e85d88	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "SalesQuotationStatus" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"SalesQuotationStatus\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 09:54:26.593773+00	2026-06-12 09:50:06.90228+00	0
da655ef1-4014-40fe-8761-b2214a3006a8	c55694551a1403a903793bba7502779d9655b2f351d0958255defc839c14bea2	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42601\n\nDatabase error:\nERROR: syntax error at or near "NOT"\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateEnum\n[1m  2[1;31m CREATE TYPE IF NOT EXISTS "SalesQuotationStatus" AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'USER_REQUESTED', 'CANCELLED', 'CONVERTED');[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42601), message: "syntax error at or near \\"NOT\\"", detail: None, hint: None, position: Some(Original(30)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("scan.l"), line: Some(1188), routine: Some("scanner_yyerror") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 09:57:51.744348+00	2026-06-12 09:54:28.268398+00	0
bb508fea-4c00-4c99-bdcf-a82086a5535b	7ff1f864793cba8870c797b88bc643b18a4668baad184dcb5e41334c6f12882d	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42601\n\nDatabase error:\nERROR: syntax error at or near "AS"\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateEnum\n[1m  2[1;31m DROP TYPE IF EXISTS "SalesQuotationStatus" AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'USER_REQUESTED', 'CANCELLED', 'CONVERTED');[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42601), message: "syntax error at or near \\"AS\\"", detail: None, hint: None, position: Some(Original(58)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("scan.l"), line: Some(1188), routine: Some("scanner_yyerror") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 09:57:59.689805+00	2026-06-12 09:57:53.592952+00	0
49602330-19fc-4fcb-881d-a5ec69df81ef	7ff1f864793cba8870c797b88bc643b18a4668baad184dcb5e41334c6f12882d	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42601\n\nDatabase error:\nERROR: syntax error at or near "AS"\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateEnum\n[1m  2[1;31m DROP TYPE IF EXISTS "SalesQuotationStatus" AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'USER_REQUESTED', 'CANCELLED', 'CONVERTED');[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42601), message: "syntax error at or near \\"AS\\"", detail: None, hint: None, position: Some(Original(58)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("scan.l"), line: Some(1188), routine: Some("scanner_yyerror") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 10:01:26.679972+00	2026-06-12 09:58:01.433699+00	0
3f4eae0a-b6ed-491a-a2ef-4cc42c41c307	c00ccb6c60042405c4deee9ff87bc0424a1cd3957a2482645a3c69d0764fcd1b	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42601\n\nDatabase error:\nERROR: syntax error at or near "CREATE"\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateEnum\n[1m  2[0m DROP TYPE IF EXISTS "SalesQuotationStatus" CASCADE\n[1m  3[1;31m CREATE TYPE "SalesQuotationStatus" AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'USER_REQUESTED', 'CANCELLED', 'CONVERTED');[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42601), message: "syntax error at or near \\"CREATE\\"", detail: None, hint: None, position: Some(Original(66)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("scan.l"), line: Some(1188), routine: Some("scanner_yyerror") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 10:01:35.902061+00	2026-06-12 10:01:28.482306+00	0
686cbe20-e875-40c9-bcee-f376e15b0383	c00ccb6c60042405c4deee9ff87bc0424a1cd3957a2482645a3c69d0764fcd1b	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42601\n\nDatabase error:\nERROR: syntax error at or near "CREATE"\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateEnum\n[1m  2[0m DROP TYPE IF EXISTS "SalesQuotationStatus" CASCADE\n[1m  3[1;31m CREATE TYPE "SalesQuotationStatus" AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'USER_REQUESTED', 'CANCELLED', 'CONVERTED');[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42601), message: "syntax error at or near \\"CREATE\\"", detail: None, hint: None, position: Some(Original(66)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("scan.l"), line: Some(1188), routine: Some("scanner_yyerror") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 10:12:56.194718+00	2026-06-12 10:01:37.640231+00	0
9321db85-71c6-4d4c-b2d7-f3d414900aa1	487c25e66a388d28eca0015540dc0747892ad53e13b0fb4af6aaa9f39c6b1137	2026-06-12 13:34:54.322871+00	20260712090000_sprint3_notifications_approvals	\N	\N	2026-06-12 13:34:54.24043+00	1
68a54631-2630-4331-ae8c-1a0df9e9a271	8f81f1f3d13f98c741a7f980e7c1f3f9c35c0186f77f8ca2645bfd3b16e85d88	\N	20260711130000_product_images	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260711130000_product_images\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "SalesQuotationStatus" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"SalesQuotationStatus\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260711130000_product_images"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260711130000_product_images"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-12 13:34:50.735193+00	2026-06-12 13:33:33.843336+00	0
356c615a-e2cd-4b2f-ac9b-4e32b60c6291	8f81f1f3d13f98c741a7f980e7c1f3f9c35c0186f77f8ca2645bfd3b16e85d88	2026-06-12 13:34:52.445834+00	20260711130000_product_images		\N	2026-06-12 13:34:52.445834+00	0
8d12fd69-e4e2-400e-8567-8156c61d3bab	0d7a99cb81ae4969e7a1bf072d69affa59d0aabc178e0c08128f3e40ec2e75e4	2026-06-12 13:34:54.239634+00	20260711140000_session_device_name	\N	\N	2026-06-12 13:34:54.234181+00	1
aee778f8-a93b-423f-aa49-610edecbe909	9b50f970cde64e546d6b1255e470ff72dd443d1cdf67f445f464ab3324882bdb	2026-06-12 13:34:54.328805+00	20260712100000_extend_alert_type_enum	\N	\N	2026-06-12 13:34:54.323608+00	1
c1be9a24-0855-47cf-a450-04f2b8f1fb3d	0d976cb603964a0f4f570c301df9c9b38e92383a01ad1746931d654b5f5c3537	2026-06-13 08:08:45.728877+00	20260613132242_add_stock_adjustment_audit_action	\N	\N	2026-06-13 08:08:45.72357+00	1
ae768503-558e-42ac-a67d-9c13eccf47d2	b38ec5ed2530757ba06540206aaf0f1409e9ede7b0e0c9e3e24d4df9812e57c9	\N	20260613028950_add_audit_enums	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260613028950_add_audit_enums\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "audit_logs" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"audit_logs\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(433), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260613028950_add_audit_enums"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260613028950_add_audit_enums"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-06-13 07:27:20.573651+00	2026-06-13 07:26:13.907475+00	0
6d756dec-4358-431c-b545-c9261e358618	dd0637b8582016a8426411399ccdf4e8904a5fd13ddd138e52e51e50e06bad82	\N	20260613132243_add_created_at_to_audit_entity_index	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260613132243_add_created_at_to_audit_entity_index\n\nDatabase error code: 42P01\n\nDatabase error:\nERROR: relation "audit_logs" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P01), message: "relation \\"audit_logs\\" does not exist", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("namespace.c"), line: Some(433), routine: Some("RangeVarGetRelidExtended") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260613132243_add_created_at_to_audit_entity_index"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260613132243_add_created_at_to_audit_entity_index"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	\N	2026-06-13 08:08:45.729568+00	0
\.


--
-- Data for Name: alert_events; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.alert_events (id, alert_type, severity, title, message, shop_id, reference_type, reference_id, is_read, triggered_at, resolved_at) FROM stdin;
4a08ec3d-173a-4605-910b-cc8a604ecf61	LOW_STOCK	HIGH	Low stock: PRD003	Data Point is below minimum stock level (2 / 3).	d53ce4ee-7da6-4709-b944-348687fb0843	PRODUCT	be5bee46-21eb-47e0-98a2-8aeecde1e954	f	2026-06-09 11:10:40.224+00	\N
43fb4c6b-9aaa-4f7f-a4b3-53c057a53771	LOW_STOCK	HIGH	Low stock: AUT001	Diesel Engine is below minimum stock level (0 / 10).	5c1f22f6-978a-43fe-ad41-28359edf08d4	PRODUCT	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	f	2026-06-09 11:10:40.224+00	\N
d9698a3a-8fdb-4d2d-96e3-37e0e82e44b3	LOW_STOCK	HIGH	Low stock: PRO02	Sample product B is below minimum stock level (50 / 100).	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	PRODUCT	1a84efe0-44bc-4661-ba46-ac6b5a2bcd0f	t	2026-06-09 11:10:40.224+00	2026-06-09 11:11:11.21+00
8763b37a-a90b-44a8-96d8-310a0c9cf677	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00006	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	t	2026-06-09 11:10:40.224+00	2026-06-09 11:11:12.207+00
7cc80482-5747-4add-ad3d-b681928dd33f	LOW_STOCK	HIGH	Low stock: PRO01	Sample product A is below minimum stock level (28 / 100).	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	PRODUCT	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	t	2026-06-09 11:10:40.224+00	2026-06-09 11:11:13.581+00
0b9c1f7b-8d94-49f3-bcd3-25dd7ad5cf30	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00002	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	t	2026-06-09 11:10:40.224+00	2026-06-09 11:11:14.082+00
9947313b-718a-48b9-a73a-cab80a4a6cb1	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00005	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	t	2026-06-09 11:10:40.224+00	2026-06-09 11:11:14.59+00
2f6cf072-3e3d-457c-95d2-cd01746f006c	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00003	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	t	2026-06-09 11:10:40.224+00	2026-06-09 11:11:14.97+00
a62d1343-8a3d-4a1b-b94d-41a60bc88189	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00001	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	t	2026-06-09 11:10:40.224+00	2026-06-09 16:27:26.474+00
15fb1285-2216-4037-8532-3db110c9211c	LOW_STOCK	HIGH	Low stock: PRO02	Sample product B is below minimum stock level (50 / 100).	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	PRODUCT	1a84efe0-44bc-4661-ba46-ac6b5a2bcd0f	f	2026-06-10 13:59:45.808+00	\N
15289b49-e05d-42af-83e5-c71081c100f2	LOW_STOCK	HIGH	Low stock: PRO01	Sample product A is below minimum stock level (28 / 100).	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	PRODUCT	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	f	2026-06-10 13:59:45.808+00	\N
6a73b052-37df-4604-86e6-4da8bbc98582	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00006	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
0c12ae56-ffb9-42f9-968a-27f81466ad4a	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00002	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
85ccc468-942c-408b-aae9-992dc550d4c9	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00004	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
f33a4d99-6540-43b9-875b-4027bed37419	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00005	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
ebeb0559-7ceb-46b0-b871-03f5a7dbc919	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00007	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
9762edb8-fbdb-4d9a-bbd4-2664dcb9e3d2	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00003	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
65ee7157-c8e3-411c-ba8b-3c513891ff88	PO_OVERDUE	HIGH	PO overdue: PO-HQ001-202605-00001	Purchase order is pending beyond expected timeline.	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	f	2026-06-10 13:59:45.808+00	\N
\.


--
-- Data for Name: approval_comments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.approval_comments (id, approval_id, user_id, comment, created_at) FROM stdin;
\.


--
-- Data for Name: approval_escalations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.approval_escalations (id, approval_id, escalated_to, escalated_at, level, reason, resolved_at) FROM stdin;
\.


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.approval_requests (id, company_id, requested_by, assigned_to, approval_type, reference_id, status, document_number, amount, description, rejection_reason, approved_at, rejected_at, required_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.audit_logs (id, user_id, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at, company_id, action, reason, request_id, device_id, severity, metadata) FROM stdin;
23739cb6-cc7e-491d-8d18-3e07a6b69865	\N	\N	\N	\N	\N	192.168.1.1	curl/8.5.0	2026-06-13 07:45:44.198+00	\N	LOGIN_FAILED	USER_NOT_FOUND	47ad16ad-50e5-4b9f-aae2-32e295065d33	\N	\N	{"email": "wrong@company.com", "companyCode": "ABC", "attemptSource": "MOBILE"}
829fd8bf-e7a5-475e-8e40-b75c77d8ec90	\N	\N	\N	\N	\N	192.168.1.1	curl/8.5.0	2026-06-13 07:46:07.544+00	\N	LOGIN_FAILED	USER_NOT_FOUND	16d1e6e4-b5f5-460c-879d-973ab5adb8a6	\N	\N	{"email": "admin@example.com", "companyCode": "ABC", "attemptSource": "MOBILE"}
962b9dc3-5ac9-4327-b151-f99d77f1d33b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N	\N	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-13 07:55:44.032+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	0dc0f8da-ea4e-4313-b9ea-a4c0b762af5d	\N	\N	{"attemptSource": "MOBILE"}
6f2f1753-3d9b-4f6d-9096-25acee0bc811	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	c0322c43-144e-416e-8ccc-005b82f19897	{"status": "DRAFT"}	{"status": "CONFIRMED"}	\N	\N	2026-05-26 07:26:25.109+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
ac82a81b-bc72-4d11-b341-8607ad517378	f20022c7-d1e2-46df-8743-c91fc33601dd	\N	\N	\N	\N	127.0.0.1	curl/8.5.0	2026-06-13 08:14:31.408+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	298bff2a-1dca-4577-8784-d41942a07452	\N	\N	{"attemptSource": "MOBILE"}
20886b0b-af2a-412b-ab68-a1eff1034ca8	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	\N	\N	\N	\N	127.0.0.1	curl/8.5.0	2026-06-13 08:16:38.358+00	ff82dfb2-daf8-4f8f-a813-19033c69ea47	LOGIN	\N	c4ba274b-a1b5-4f46-91d2-c30f47da3e8f	\N	\N	{"attemptSource": "MOBILE"}
0e92b428-0c11-47b8-b87d-fe30936b3b37	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N	\N	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-13 09:07:42.34+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	24671ee4-c51f-406b-a615-950ffc558f34	\N	\N	{"attemptSource": "MOBILE"}
13239b47-3360-48aa-a406-6325383dba84	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N	\N	127.0.0.1	curl/8.5.0	2026-06-13 09:35:54.307+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	ca59a052-0953-4c87-af0b-364d4ec74d47	\N	\N	{"attemptSource": "MOBILE"}
66c1a3a3-b34f-419a-ac82-b3a6b30ae543	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N	\N	127.0.0.1	curl/8.5.0	2026-06-13 09:36:40.038+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	277fabeb-bdc6-4306-9b28-acc121429181	\N	\N	{"attemptSource": "MOBILE"}
ae590fc5-d916-4fd0-891e-ff3f9de99d33	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N	\N	127.0.0.1	curl/8.5.0	2026-06-13 09:37:13.558+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	f12ecdcd-12cc-4e9c-9677-650948a06585	\N	\N	{"attemptSource": "MOBILE"}
7551bc9a-16d2-47b7-aeb3-50fdc8031947	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N	\N	127.0.0.1	curl/8.5.0	2026-06-13 09:37:29.596+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	LOGIN	\N	19a370a5-a12d-4850-8c06-fe04d06335b8	\N	\N	{"attemptSource": "MOBILE"}
e5a6579f-6356-4f79-8916-2911911c3b3f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	USER_INVITATION	4976c4d6-175a-4dce-b20c-e10368af4f93	\N	{"email": "gstharunadhithya08@gmail.com", "roleId": "b6ec9a6f-ced1-4e32-8d46-eada8cae9565", "shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "expiresAt": {}}	\N	\N	2026-05-24 19:28:16.699+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
608d84a2-a105-44e5-9bb1-6216530dea17	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	8f914892-94f8-44a0-888c-c6d2867c8805	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00003", "itemCount": 1, "totalValue": "500"}	\N	\N	2026-05-25 08:10:02.07+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
f0e0a263-023b-4f32-9034-054909a7f24f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	943c0a1f-0367-4504-81fc-c7c934db14a7	\N	{"supplierId": "7c961808-5a79-4c95-8c40-a36f4839609c", "totalValue": "500", "returnNumber": "RMO-202605-00001", "goodsReceiptId": "8f914892-94f8-44a0-888c-c6d2867c8805"}	\N	\N	2026-05-25 08:11:53.121+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
a6dca5c6-b9ca-40b7-b109-f3e5b59c02db	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	943c0a1f-0367-4504-81fc-c7c934db14a7	\N	{"status": "SUBMITTED", "emailSentAt": "2026-05-25T08:12:33.408Z"}	\N	\N	2026-05-25 08:12:33.418+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
4bd9c9c3-6577-4172-aed7-1b03e4e19df4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	943c0a1f-0367-4504-81fc-c7c934db14a7	\N	{"status": "DONE", "postedAt": "2026-05-25T08:13:48.779Z", "acknowledgedAt": "2026-05-25T08:13:48.769Z"}	\N	\N	2026-05-25 08:13:48.787+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
044c81fd-0517-4548-a612-bd1fbc257b64	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	f4e729b2-02ea-4fd7-b315-f52347704c5b	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "product:read", "product:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "vendor_portal:access"]}	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "vendor_portal:access"]}	\N	\N	2026-05-25 12:39:38.652+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
2afa15f4-7dd0-4600-9509-1b34b8fdc76c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	f4e729b2-02ea-4fd7-b315-f52347704c5b	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "vendor_portal:access"]}	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "vendor_portal:access", "product:read", "product:write"]}	\N	\N	2026-05-25 12:40:16.084+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
2a83d800-94ed-4600-b6fc-3374d69f6802	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	f4e729b2-02ea-4fd7-b315-f52347704c5b	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "vendor_portal:access", "product:read", "product:write"]}	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "product:read", "product:write"]}	\N	\N	2026-05-25 12:40:23.336+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7493487f-321e-4726-9342-624935e67600	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	f4e729b2-02ea-4fd7-b315-f52347704c5b	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "product:read", "product:write"]}	{"permissions": ["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "product:read", "product:write", "vendor_portal:access"]}	\N	\N	2026-05-25 12:40:41.068+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
965e1f45-8ce6-4d4d-963b-1268ef9856b1	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	950a2f19-23be-47c3-8cbd-7db822639954	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-HQ001-202605-00004", "supplier": "Heaven Electrical Supply", "itemCount": 2, "totalValue": "1100"}	\N	\N	2026-05-25 14:52:10.24+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
cd9ade0d-e726-43fe-b484-12696b263760	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	950a2f19-23be-47c3-8cbd-7db822639954	{"status": "DRAFT"}	{"status": "CONFIRMED"}	\N	\N	2026-05-25 16:16:33.968+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
0ec04324-af49-43f4-99d5-9f669c4b6b02	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	45646ecc-b754-4e18-8325-9ced2130180f	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00006", "itemCount": 2, "totalValue": "1100"}	\N	\N	2026-05-25 16:19:32.344+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
ed338310-6a13-4c60-b460-6821f04bb485	47a8b4e9-c9ee-4239-b6c1-129e71d74587	product	49245a86-ab86-48e2-89f6-b9b86658936e	{"description": "SHIMANO chain Ring FC-E6000", "productCode": "ELC0001"}	\N	\N	\N	2026-05-25 16:58:12.132+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
b95b35e5-c2da-4065-b1e9-656bbadf7a88	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	7aa747e6-053b-4195-a602-336b745fa59d	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00007", "itemCount": 2, "totalValue": "11000"}	\N	\N	2026-05-25 17:04:52.565+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
5103a6e5-a9ab-4e50-ab98-e73335dbacc4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	1106b90e-4c5b-4583-b8cf-90a80d92ef99	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00008", "itemCount": 1, "totalValue": "100"}	\N	\N	2026-05-25 17:06:46.707+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b3cc7d12-1419-430d-88aa-5b2a36d8ff8f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	7265e3e8-c9d0-4c1e-9deb-c84c79b747e2	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00009", "itemCount": 1, "totalValue": "2000"}	\N	\N	2026-05-25 17:11:09.982+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
0d8cd6f0-553d-46a5-9eab-c20d28fb9295	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	c0322c43-144e-416e-8ccc-005b82f19897	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-HQ001-202605-00007", "supplier": "Bharat Electricals Supply", "itemCount": 1, "totalValue": "500"}	\N	\N	2026-05-25 17:56:43.757+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
aa7932e3-04bf-4040-b017-f195e465776a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	c940051f-3ff8-4982-a627-ac3f1dd24018	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00010", "itemCount": 1, "totalValue": "1000"}	\N	\N	2026-05-26 07:27:34.655+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
df5639ff-5198-40f7-b9d5-9a6340373233	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	c5973c42-3a93-484d-ac68-c64ca799accc	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-HQ001-202605-00008", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "15000"}	\N	\N	2026-05-26 07:55:03.952+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
eb24e6b5-01be-4136-b35f-d7ae2d5731ab	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	c5973c42-3a93-484d-ac68-c64ca799accc	{"status": "DRAFT"}	{"status": "CONFIRMED"}	\N	\N	2026-05-26 07:55:40.528+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
f33b1307-1465-41c9-bfd6-9beef30974c4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	dbe84bee-6afc-411a-943c-32c4467b05d6	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00011", "itemCount": 1, "totalValue": "7500"}	\N	\N	2026-05-26 07:57:58.282+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
e9461697-0df8-4138-9735-03750f3c85d0	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	f60f8cee-b969-45fa-b000-ce4880f495c1	\N	{"soNumber": "SO-HQ001-202605-00001", "itemCount": 1, "customerId": "ac6eb189-b321-4104-810c-f90c3db4b0f7", "totalValue": "5000"}	\N	\N	2026-05-26 08:25:21.345+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
8c49ef48-f736-4196-bba3-3de4dc863026	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	f60f8cee-b969-45fa-b000-ce4880f495c1	\N	{"status": "CONFIRMED"}	\N	\N	2026-05-26 08:25:48.073+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
64759471-938d-47a8-9a06-509283e251cb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	f60f8cee-b969-45fa-b000-ce4880f495c1	\N	{"qty": "10", "event": "fulfillItem", "itemId": "e9aadfae-da93-4c43-8dba-cb4b57a63c95", "fulfillmentStatus": "FULL"}	\N	\N	2026-05-26 08:26:45.232+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b8f2beca-8386-4772-a0ed-9730e990e092	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	d2031d2e-f4f8-40d5-ba30-d2e7870037ac	\N	{"supplierId": "a94916e2-72a6-4b9c-985d-01de9bc20a2a", "totalValue": "1500", "returnNumber": "RMO-202605-00002", "goodsReceiptId": "dbe84bee-6afc-411a-943c-32c4467b05d6"}	\N	\N	2026-05-26 08:29:59.424+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
1b72dc0f-1d17-411d-8a3d-1617cc623bc5	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	d2031d2e-f4f8-40d5-ba30-d2e7870037ac	\N	{"status": "SUBMITTED", "emailSentAt": "2026-05-26T08:30:05.476Z"}	\N	\N	2026-05-26 08:30:05.486+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
d96e49a0-b168-4d94-a815-67ca9bac87fb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	d2031d2e-f4f8-40d5-ba30-d2e7870037ac	\N	{"status": "DONE", "postedAt": "2026-05-26T08:30:31.545Z", "acknowledgedAt": "2026-05-26T08:30:31.537Z"}	\N	\N	2026-05-26 08:30:31.553+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
8e1935f1-495f-4a8e-8382-af7b345cebc1	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	7bfd4712-c3e3-4481-b439-cdcc0c189522	\N	{"shopId": "d53ce4ee-7da6-4709-b944-348687fb0843", "poNumber": "PO-REVATH001-202605-00001", "supplier": "Nadar depart store", "itemCount": 3, "totalValue": "28700"}	\N	\N	2026-05-26 12:59:49.091+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
64b2b01f-af5f-48d1-889c-6f93f2847e9d	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	84ba57d6-7085-46b5-863e-cf279a415a11	\N	{"shopId": "d53ce4ee-7da6-4709-b944-348687fb0843", "poNumber": "PO-REVATH001-202605-00002", "supplier": "Nadar depart store", "itemCount": 1, "totalValue": "13000"}	\N	\N	2026-05-26 13:04:16.532+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
8dad9465-408d-4266-8f49-17c252c9ff7d	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	84ba57d6-7085-46b5-863e-cf279a415a11	{"status": "DRAFT"}	{"status": "CONFIRMED"}	\N	\N	2026-05-26 13:12:13.583+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
bb25a5da-1071-410d-bce8-31f3862a03da	47a8b4e9-c9ee-4239-b6c1-129e71d74587	GOODS_RECEIPT	4c30dcfe-1b7f-453f-928f-35fe9d255115	\N	{"status": "POSTED", "grNumber": "GR-REVATH001-202605-00001", "itemCount": 1, "totalValue": "13000"}	\N	\N	2026-05-26 13:13:23.098+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
51a64c1f-467d-403f-9c9f-cabccc02f0ba	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	71157456-86b7-491c-890d-1614271ae667	\N	{"soNumber": "SO-HQ001-202605-00002", "itemCount": 1, "customerId": "1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca", "totalValue": "500"}	\N	\N	2026-05-26 15:02:54.599+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
a75e04fd-9011-49fc-8872-ce3fe3efa5ea	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	71157456-86b7-491c-890d-1614271ae667	\N	{"status": "CONFIRMED"}	\N	\N	2026-05-26 15:03:14.209+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
1981e729-9f45-4014-bc48-68286b21d0d3	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	98d38f13-ae33-4bea-aa30-f5633f590ae8	\N	{"shopId": "d53ce4ee-7da6-4709-b944-348687fb0843", "poNumber": "PO-REVATH001-202605-00003", "supplier": "Nadar depart store", "itemCount": 1, "totalValue": "32500"}	\N	\N	2026-05-26 15:10:58.614+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
dc0ee73d-0b9d-44e4-b5c6-f867da6f1a58	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	4a3f2dfe-53e4-4867-9d43-06172ae206b3	\N	{"shopId": "d53ce4ee-7da6-4709-b944-348687fb0843", "poNumber": "PO-REVATH001-202605-00004", "supplier": "Nadar depart store", "itemCount": 1, "totalValue": "34800"}	\N	\N	2026-05-26 15:12:23.684+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
8a16f88c-95fe-4e0f-a2d4-c8ec5cb4a3c6	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	98d38f13-ae33-4bea-aa30-f5633f590ae8	{"status": "DRAFT"}	{"status": "CONFIRMED"}	\N	\N	2026-05-26 15:12:47.525+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
e8f8b3bb-e594-42f3-80d5-497dd43c7f12	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	4a3f2dfe-53e4-4867-9d43-06172ae206b3	{"status": "DRAFT"}	{"status": "CANCELLED"}	\N	\N	2026-05-26 15:14:20.247+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
57884a89-5e6a-4064-8187-5daf496dbef2	47a8b4e9-c9ee-4239-b6c1-129e71d74587	PURCHASE_ORDER	2a5a864c-14e5-4926-bcc8-0eba58535da8	\N	{"shopId": "d53ce4ee-7da6-4709-b944-348687fb0843", "poNumber": "GSTPO-01", "supplier": "Nadar depart store", "itemCount": 1, "totalValue": "1450"}	\N	\N	2026-05-26 15:20:54.871+00	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	CREATE	\N	\N	\N	\N	\N
70c6e6e5-2dc4-4c47-af1d-15928fbce3d8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_ISSUE	6045be97-ea41-4a8c-ba88-ae1ca2882767	\N	{"status": "POSTED", "giNumber": "GI-HQ001-202605-00001", "itemCount": 1}	\N	\N	2026-05-26 15:23:12.684+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
791931a9-48bb-4246-a761-45404f65d906	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	aad38599-ea83-40b3-a98b-34f8da4358a6	\N	{"soNumber": "SO-HQ001-202605-00003", "itemCount": 1, "customerId": "1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca", "totalValue": "10000"}	\N	\N	2026-05-26 15:24:37.369+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
d2d5ae9f-7139-4b03-a37f-c8427614a2cc	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	aad38599-ea83-40b3-a98b-34f8da4358a6	\N	{"status": "CONFIRMED"}	\N	\N	2026-05-26 15:24:46.636+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
1feb68ce-f2be-46fa-bd4f-9af6fe899da7	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	aad38599-ea83-40b3-a98b-34f8da4358a6	\N	{"qty": "20", "event": "fulfillItem", "itemId": "0b9c93be-dd15-4db8-bab9-98e2a1970f19", "fulfillmentStatus": "FULL"}	\N	\N	2026-05-26 15:25:06.239+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
8bfdbeb9-90fe-4fb8-8b29-a096ffe608a2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	b433c3de-9c5f-4b45-9579-0e90e669981f	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-0099", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "15000"}	\N	\N	2026-05-26 15:57:19.428+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
88605fe3-e7a4-425a-9321-9645c5b592c8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	70daea11-f9f3-40c2-aab2-5a33b3840e43	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00012", "itemCount": 1, "totalValue": "7500"}	\N	\N	2026-05-26 15:59:30.248+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
840cbb86-fdc1-4a85-b75d-8af35f4340dd	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	805be505-2858-4642-abf1-8d09549077d6	\N	{"status": "POSTED", "grNumber": "GR-HQ001-202605-00013", "itemCount": 1, "totalValue": "7500"}	\N	\N	2026-05-26 16:01:55.625+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
459b67ca-b527-4ffc-8eda-66d1f636b16e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	5e625cbc-80a3-4163-9ac0-f66dba7dba6c	\N	{"status": "CONFIRMED"}	\N	\N	2026-05-26 16:06:46.044+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
36d9eac3-aa2c-4fa8-86b6-d864bd1042ff	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_ISSUE	19ef01b3-9b42-4d70-89af-7e0bd8cad27d	\N	{"status": "POSTED", "giNumber": "GI-HQ001-202605-00002", "itemCount": 1}	\N	\N	2026-05-26 16:11:35.853+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
379859c7-1047-43f3-9d23-19c098d15fce	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	e740e26e-9481-4282-b21e-e899dc6e7771	\N	{"soNumber": "SO-HQ001-202605-00005", "totalValue": "880"}	\N	\N	2026-05-26 16:26:46.651+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
18cfbbce-8d01-46f5-b45c-41cbaad6c020	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	e740e26e-9481-4282-b21e-e899dc6e7771	\N	{"status": "CONFIRMED"}	\N	\N	2026-05-26 16:27:03.696+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
d74f20e1-8a38-4f01-be3f-d1f51a237ca7	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	e740e26e-9481-4282-b21e-e899dc6e7771	\N	{"qty": "11", "event": "fulfillItem", "itemId": "ed9805c9-6f20-4ec3-bda6-1c55e7e7d9d1", "fulfillmentStatus": "FULL"}	\N	\N	2026-05-26 16:27:22.602+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b4fc046c-e6ac-47f5-86b5-f54dd7fb1645	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_ISSUE	b3e554ba-0efa-49cd-9e9b-ef1558d44982	\N	{"status": "POSTED", "giNumber": "GI-HQ001-202605-00003", "itemCount": 1}	\N	\N	2026-05-26 16:28:52.415+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
89efaf9a-3ff2-48da-88df-debfb65ded1e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	9205e8da-e7d2-41cb-9ccd-98944f0f34e9	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-HQ001-202605-00009", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "100"}	\N	\N	2026-05-27 11:35:08.396+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
0d9d8b00-d8e2-49fb-a128-2ba6ad2f2c31	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	36ee7bf2-03b4-496d-a832-910cba96f8a1	{"permissions": ["shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "product:read", "product:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "vendor_portal:access"]}	{"permissions": ["shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "product:read", "product:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "vendor_portal:access"]}	\N	\N	2026-05-29 06:37:14.705+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
036d4fdd-d093-4f7b-8152-80738dcb9e60	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	64812ff7-4367-442a-b18a-5df47e3bb4fc	{"permissions": ["shop:read", "company:read", "contract:read", "product:read", "storage_location:read", "supplier:read", "rfq:read", "quote:read", "purchase_order:read", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view"]}	{"permissions": ["shop:read", "company:read", "contract:read", "product:read", "storage_location:read", "supplier:read", "purchase_order:read", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export"]}	\N	\N	2026-05-29 06:37:50.335+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
5dd9e0b4-ada2-4501-b4bc-8d8390bcad04	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	9b6c084c-6063-400d-a3e2-be0bcac06ab6	{"permissions": ["shop:read", "company:read", "contract:read", "product:read", "storage_location:read", "supplier:read", "rfq:read", "quote:read", "purchase_order:read", "goods_receipt:read", "goods_issue:read", "damage:read", "report:view"]}	{"permissions": ["shop:read", "company:read", "contract:read", "product:read", "storage_location:read", "supplier:read", "rfq:read", "quote:read", "purchase_order:read", "goods_receipt:read", "goods_issue:read", "damage:read", "report:view"]}	\N	\N	2026-05-29 06:38:07.038+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
2ed2079b-015c-4f9c-a589-20b6ca080f17	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	ROLE	4ecbad9f-8440-4df2-8bf9-dc4ed4295223	{"permissions": ["vendor_portal:access"]}	{"permissions": ["vendor_portal:access"]}	\N	\N	2026-05-29 06:38:15.762+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
be520b16-02aa-40b0-9825-47f6caa35a12	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	USER_INVITATION	09488a2f-633b-44f9-8534-df6b148d0a5e	\N	{"email": "kolandasamy.sss@gmail.com", "roleId": "36ee7bf2-03b4-496d-a832-910cba96f8a1", "shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "expiresAt": {}}	\N	\N	2026-05-29 06:42:20.492+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
f5012efc-eebe-43cd-8eb6-8a3912a28226	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	24e5f5c4-3725-469e-9c5c-5e1bc438faa0	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-00001", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "300"}	\N	\N	2026-05-29 07:50:08.383+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
0b4ca6ad-1420-465a-840a-d5affca667fb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	24e5f5c4-3725-469e-9c5c-5e1bc438faa0	\N	{"error": "Failed to launch the browser process:  Code: 127\\n\\nstderr:\\n/root/.cache/puppeteer/chrome/linux-146.0.7680.153/chrome-linux64/chrome: error while loading shared libraries: libgbm.so.1: cannot open shared object file: No such file or directory\\n\\nTROUBLESHOOTING: https://pptr.dev/troubleshooting\\n", "status": "failed", "message": "PO-00001 email failed: Failed to launch the browser process:  Code: 127\\n\\nstderr:\\n/root/.cache/puppeteer/chrome/linux-146.0.7680.153/chrome-linux64/chrome: error while loading shared libraries: libgbm.so.1: cannot open shared object file: No such file or directory\\n\\nTROUBLESHOOTING: https://pptr.dev/troubleshooting\\n", "trigger": "manual", "poNumber": "PO-00001", "recipient": "kolandasamy.sss@gmail.com", "templateId": "purchase_order_supplier", "documentNumber": "PO-00001", "attachmentFilename": null}	\N	\N	2026-05-29 07:50:09.601+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
01b2c7d2-e515-4997-b897-133783824fa3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	53a1c699-58cd-4d6f-b3b3-071cfd584544	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-00002", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "300"}	\N	\N	2026-05-29 07:50:17.822+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7c255aef-488c-4306-83e2-6ab306d657b6	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	53a1c699-58cd-4d6f-b3b3-071cfd584544	\N	{"error": "Failed to launch the browser process:  Code: 127\\n\\nstderr:\\n/root/.cache/puppeteer/chrome/linux-146.0.7680.153/chrome-linux64/chrome: error while loading shared libraries: libgbm.so.1: cannot open shared object file: No such file or directory\\n\\nTROUBLESHOOTING: https://pptr.dev/troubleshooting\\n", "status": "failed", "message": "PO-00002 email failed: Failed to launch the browser process:  Code: 127\\n\\nstderr:\\n/root/.cache/puppeteer/chrome/linux-146.0.7680.153/chrome-linux64/chrome: error while loading shared libraries: libgbm.so.1: cannot open shared object file: No such file or directory\\n\\nTROUBLESHOOTING: https://pptr.dev/troubleshooting\\n", "trigger": "manual", "poNumber": "PO-00002", "recipient": "kolandasamy.sss@gmail.com", "templateId": "purchase_order_supplier", "documentNumber": "PO-00002", "attachmentFilename": null}	\N	\N	2026-05-29 07:50:19.013+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
234d7dbe-bfc0-4e7f-ae32-70de6e9ae911	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	b433c3de-9c5f-4b45-9579-0e90e669981f	\N	{"error": null, "status": "sent", "message": "PO-0099 emailed to kolandasamy.sss@gmail.com (resent manually)", "trigger": "resend", "poNumber": "PO-0099", "recipient": "kolandasamy.sss@gmail.com", "templateId": "purchase_order_supplier", "documentNumber": "PO-0099", "attachmentFilename": "PO-0099.pdf"}	\N	\N	2026-05-29 09:00:28.877+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
14e687e4-3b53-4051-b8e6-904d0978e769	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	9205e8da-e7d2-41cb-9ccd-98944f0f34e9	\N	{"error": null, "status": "sent", "message": "PO-HQ001-202605-00009 emailed to kolandasamy.sss@gmail.com (resent manually)", "trigger": "resend", "poNumber": "PO-HQ001-202605-00009", "recipient": "kolandasamy.sss@gmail.com", "templateId": "purchase_order_supplier", "documentNumber": "PO-HQ001-202605-00009", "attachmentFilename": "PO-HQ001-202605-00009.pdf"}	\N	\N	2026-05-29 11:26:15.907+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
6b0d3e0f-a27f-4a8a-8266-b7685f8dfd37	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	17904c2f-5358-489d-8f81-b2945ca9f79a	\N	{"shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "poNumber": "PO-00003", "supplier": "PowerDrive Engines", "itemCount": 1, "totalValue": "300000"}	\N	\N	2026-05-30 04:16:01.273+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
683b1b67-baa3-47f3-b608-075ced711992	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	17904c2f-5358-489d-8f81-b2945ca9f79a	\N	{"error": null, "status": "sent", "message": "PO-00003 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-00003", "recipient": "kolandasamy.sss@gmail.com", "templateId": "purchase_order_supplier", "documentNumber": "PO-00003", "attachmentFilename": "PO-00003.pdf"}	\N	\N	2026-05-30 04:16:06.606+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b0b5e0ee-ef81-450b-b204-4dfe736fda3d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	bd3940c3-fefd-4511-bd92-552eeff4740f	\N	{"status": "POSTED", "grNumber": "GR-00001", "itemCount": 1, "totalValue": "150000"}	\N	\N	2026-05-30 04:26:39.978+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
88008632-cf8c-4496-9a79-22275875ddd9	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	bd3940c3-fefd-4511-bd92-552eeff4740f	\N	{"error": null, "status": "sent", "message": "GR-00001 emailed to kolandasamy.sss@gmail.com", "trigger": "auto", "grNumber": "GR-00001", "recipient": "kolandasamy.sss@gmail.com", "templateId": "goods_receipt_supplier", "documentNumber": "GR-00001", "attachmentFilename": "GR-00001.pdf"}	\N	\N	2026-05-30 04:26:57.508+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
af497ba9-a8ca-4fcb-b925-d5e31f79c471	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	345870ff-1253-4b69-9a2a-9a9648742362	\N	{"status": "POSTED", "grNumber": "GR-00002", "itemCount": 1, "totalValue": "450"}	\N	\N	2026-05-30 05:30:08.377+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7c0c273d-b918-46b7-8e26-79734d17d999	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	345870ff-1253-4b69-9a2a-9a9648742362	\N	{"error": null, "status": "sent", "message": "GR-00002 emailed to kolandasamy.sss@gmail.com", "trigger": "auto", "grNumber": "GR-00002", "recipient": "kolandasamy.sss@gmail.com", "templateId": "goods_receipt_supplier", "documentNumber": "GR-00002", "attachmentFilename": "GR-00002.pdf"}	\N	\N	2026-05-30 05:30:30.371+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
08f608b6-d86d-4905-98b4-7f7b79d68873	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_QUOTATION	3ad198fd-f636-4f80-b9b8-96d64788d70e	\N	{"error": null, "status": "sent", "message": "QT-00001 emailed to gstharunadhithya08@gmail.com", "trigger": "manual", "ipAddress": "36.255.17.5", "recipient": "gstharunadhithya08@gmail.com", "requestId": "6795d374-90c5-4d71-a7ca-c8c48b1c2f38", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36", "templateId": "sales_quotation_customer", "quoteNumber": "QT-00001", "documentNumber": "QT-00001", "attachmentFilename": "QT-00001.pdf"}	\N	\N	2026-05-30 07:49:46.657+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
3dad89b5-6de0-4431-93e3-90afaff3f30c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	69b227da-8e82-4bf9-b4a8-b17c47d559e0	\N	{"soNumber": "SO-00001", "totalValue": "120500"}	\N	\N	2026-05-30 07:53:36.16+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
cb1de8ef-f213-43ea-b65c-a1230f744d2b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	69b227da-8e82-4bf9-b4a8-b17c47d559e0	\N	{"status": "CONFIRMED"}	\N	\N	2026-05-30 07:53:57.655+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7b725795-738d-4a01-a415-c6b202b113f4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	408aea7a-6b67-4fab-af46-3321ed698642	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": null, "toStatus": "POSTED", "auditType": "STATUS_TRANSITION", "requestId": "08fe35f1-dedb-4b71-9ffe-56b705b2c346", "timestamp": "2026-06-09T05:23:01.765Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:23:01.766+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
96bd5bab-21f9-4320-88c4-fc1839bd80ba	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	69b227da-8e82-4bf9-b4a8-b17c47d559e0	\N	{"error": null, "status": "sent", "message": "SO-00001 emailed to gstharunadhithya08@gmail.com", "trigger": "auto", "soNumber": "SO-00001", "ipAddress": "36.255.17.5", "recipient": "gstharunadhithya08@gmail.com", "requestId": "eda5e314-595c-49d0-b5f4-46831bc78571", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36", "templateId": "sales_order_customer", "documentNumber": "SO-00001", "attachmentFilename": "SO-00001.pdf"}	\N	\N	2026-05-30 07:54:02.813+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
a8e67792-72f8-4e5d-b547-d0e71aa37708	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_ISSUE	11970999-986b-42db-bf4b-90d0d04642a6	\N	{"status": "POSTED", "giNumber": "GI-00001", "itemCount": 10}	\N	\N	2026-05-30 07:55:42.372+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
2e43607a-bd1e-4467-8345-71184d265d0f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	RFQ	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": null, "toStatus": "POSTED", "auditType": "STATUS_TRANSITION", "requestId": "e00f9415-9a8d-42e6-ba78-40ffdcdd059c", "timestamp": "2026-05-30T08:20:30.796Z"}	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 08:20:30.798+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
824c406c-b1fb-41f7-a869-71ec8e57cd7a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	RFQ	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	\N	{"action": "POST_RFQ", "result": "success", "auditType": "ACTION", "requestId": "e00f9415-9a8d-42e6-ba78-40ffdcdd059c", "timestamp": "2026-05-30T08:20:30.799Z", "recipients": 1}	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 08:20:30.801+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
3d7c237b-6d33-4d23-885e-27c5a2649147	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	\N	{"rfqId": "9da63c07-1b8b-4ae6-a239-024fe9cf23c1", "shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "status": "DRAFT", "poNumber": "PO-00004", "supplier": "Bright Power Distributors", "itemCount": 5, "totalValue": "37600"}	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:02:26.063+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
17d42867-fc1c-4670-8c4e-790d08de6356	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": null, "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "dfa8bbf2-e3dc-4757-a968-9790439ef860", "timestamp": "2026-05-30T10:03:59.977Z"}	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:03:59.978+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
470c40d4-f9b2-4aa5-99be-f4dcf123f1b1	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	9dbceae8-fc02-403b-8b8c-3cd7c6513498	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": null, "toStatus": "POSTED", "auditType": "STATUS_TRANSITION", "requestId": "b331fe62-2d45-4008-9251-d28ba374a65c", "timestamp": "2026-05-30T10:05:40.961Z"}	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:05:40.962+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
9a26ff87-b7d4-4601-a544-18360282d1e2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	9dbceae8-fc02-403b-8b8c-3cd7c6513498	\N	{"error": null, "status": "sent", "message": "GR-00003 emailed to kolandasamy.sss@gmail.com", "trigger": "auto", "grNumber": "GR-00003", "ipAddress": "36.255.17.5", "recipient": "kolandasamy.sss@gmail.com", "requestId": "b331fe62-2d45-4008-9251-d28ba374a65c", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36", "templateId": "goods_receipt_supplier", "documentNumber": "GR-00003", "attachmentFilename": "GR-00003.pdf"}	\N	\N	2026-05-30 10:06:13.269+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
97b715bf-e0aa-4592-8af7-27b9206d25b3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	RFQ	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	\N	{"action": "SEND_RFQ", "resend": true, "result": "success", "auditType": "ACTION", "requestId": "e3f0c0a3-1998-43b7-8721-95d07a7d5b55", "timestamp": "2026-05-31T17:54:03.133Z", "recipients": 1}	36.255.17.237	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-31 17:54:03.134+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b7ea2e14-456f-4189-8a0e-77ddb957ce1a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	e293bebe-4b10-4880-ba04-9e2d01f15679	\N	{"soNumber": "SO-00002", "itemCount": 1, "customerId": "c1663e2a-177a-4bde-90a2-2afb1fc922f4", "totalValue": "750"}	\N	\N	2026-06-08 11:59:15.223+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b47ba67d-068b-4d51-a61d-185238976c31	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SALES_ORDER	338e7bb0-7631-4a64-802c-7ee734ddb780	\N	{"soNumber": "SO-00003", "itemCount": 1, "customerId": "c1663e2a-177a-4bde-90a2-2afb1fc922f4", "totalValue": "1357"}	\N	\N	2026-06-08 14:20:23.682+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
bd95112c-be76-48e0-9f0d-dcd0163d1100	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000000", "supplier": "Bharat Electricals Supply", "itemCount": 1, "totalValue": "14500"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 17:42:07.844+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
bf7ca9e7-6707-4565-9f9a-80f678bb743c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "e4ecadbc-c2db-414e-93b9-54bc8ae49b61", "timestamp": "2026-06-08T17:42:07.846Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 17:42:07.847+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b79ef4ec-9571-49e6-ba0a-7d66ceee7d72	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "gstharunadhithya08@gmail.com", "requestId": "e4ecadbc-c2db-414e-93b9-54bc8ae49b61", "timestamp": "2026-06-08T17:42:07.874Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 17:42:07.875+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
0ece9f44-d0c0-45aa-9ba4-cfdb6e75b09c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	\N	{"error": null, "status": "sent", "message": "PO-5000000 emailed to gstharunadhithya08@gmail.com", "trigger": "manual", "poNumber": "PO-5000000", "ipAddress": null, "recipient": "gstharunadhithya08@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000000", "attachmentFilename": "PO-5000000.pdf"}	\N	\N	2026-06-08 17:42:13.488+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
4cd0ef84-aab7-49a5-bf6e-5eee03dbe7c3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	\N	{"supplierId": "a94916e2-72a6-4b9c-985d-01de9bc20a2a", "totalValue": "4750", "returnNumber": "RMO-00001", "goodsReceiptId": "408aea7a-6b67-4fab-af46-3321ed698642"}	\N	\N	2026-06-09 05:24:46.893+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
1500ccc7-4f35-4a3e-b157-90b369c27488	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	748dd9cf-1fdd-4f95-840d-22ab88262a03	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000001", "supplier": "Bharat Electricals Supply", "itemCount": 1, "totalValue": "10800"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 17:46:13.74+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
67faa287-d3c2-4a93-9dc6-2f49483fbe0c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	748dd9cf-1fdd-4f95-840d-22ab88262a03	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "6c70e4c2-1f25-4aab-ac40-48014b365ca4", "timestamp": "2026-06-08T17:46:13.742Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 17:46:13.743+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
abdc1813-626c-464f-ace7-44aa26b93694	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	748dd9cf-1fdd-4f95-840d-22ab88262a03	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "gstharunadhithya08@gmail.com", "requestId": "6c70e4c2-1f25-4aab-ac40-48014b365ca4", "timestamp": "2026-06-08T17:46:13.783Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 17:46:13.784+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
e73fbf9d-f4b9-4803-8738-2db7cbcfc474	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	748dd9cf-1fdd-4f95-840d-22ab88262a03	\N	{"error": null, "status": "sent", "message": "PO-5000001 emailed to gstharunadhithya08@gmail.com", "trigger": "manual", "poNumber": "PO-5000001", "ipAddress": null, "recipient": "gstharunadhithya08@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000001", "attachmentFilename": "PO-5000001.pdf"}	\N	\N	2026-06-08 17:46:18.386+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
710f8239-86c3-4816-bb40-2b26ca358fa8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	05ae51ad-18be-4ee5-bafe-8c658db0eb89	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000002", "supplier": "PowerDrive Engines", "itemCount": 1, "totalValue": "600000"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 01:47:33.967+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
60cc9902-2da7-46ad-bee4-f9a2bccf55c2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	05ae51ad-18be-4ee5-bafe-8c658db0eb89	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "246a110e-172f-4102-b8f2-1fb01f0a4b99", "timestamp": "2026-06-09T01:47:33.968Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 01:47:33.969+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
06f4f932-0bb4-48cb-8240-d1e5a0ef3605	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	05ae51ad-18be-4ee5-bafe-8c658db0eb89	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "246a110e-172f-4102-b8f2-1fb01f0a4b99", "timestamp": "2026-06-09T01:47:34.004Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 01:47:34.005+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7da3a05a-ad3d-440e-95d3-3e8090da8488	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	05ae51ad-18be-4ee5-bafe-8c658db0eb89	\N	{"error": null, "status": "sent", "message": "PO-5000002 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000002", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000002", "attachmentFilename": "PO-5000002.pdf"}	\N	\N	2026-06-09 01:47:40.561+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
f2f1a0b2-e454-49bf-b249-8c87297bd538	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000003", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1200"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 02:06:26.504+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
4434a14e-c589-44d8-82f5-de54b1ced39c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "230ef76d-e0b5-4baf-8096-183b99d29021", "timestamp": "2026-06-09T02:06:26.506Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 02:06:26.507+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
310d4211-83cc-42ac-a3ee-78f62144e8bb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "230ef76d-e0b5-4baf-8096-183b99d29021", "timestamp": "2026-06-09T02:06:26.536Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 02:06:26.537+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
4a64490c-bffa-4b82-9902-8acc9d00b909	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	\N	{"error": null, "status": "sent", "message": "PO-5000003 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000003", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000003", "attachmentFilename": "PO-5000003.pdf"}	\N	\N	2026-06-09 02:06:32.525+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
6a1c4fe0-89d4-4346-a5b2-25eed358dfc4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	245324eb-1995-4571-963a-8c776fcd047e	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000004", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1000"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 03:51:57.943+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
8f0399fe-98c0-4731-aa9c-b038dc828246	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	245324eb-1995-4571-963a-8c776fcd047e	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "0bdb01d6-6ba4-4a9a-baa4-a162fa912556", "timestamp": "2026-06-09T03:51:57.945Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 03:51:57.946+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
42e2e25f-fdc4-48c4-b65f-6785215e9462	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	245324eb-1995-4571-963a-8c776fcd047e	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "0bdb01d6-6ba4-4a9a-baa4-a162fa912556", "timestamp": "2026-06-09T03:51:57.976Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 03:51:57.977+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
dd65a20e-8402-4235-9907-c66d170215fc	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	245324eb-1995-4571-963a-8c776fcd047e	\N	{"error": null, "status": "sent", "message": "PO-5000004 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000004", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000004", "attachmentFilename": "PO-5000004.pdf"}	\N	\N	2026-06-09 03:52:04.363+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
1176b81d-14f1-4adc-bd24-49d43056d815	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000005", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1200"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:15:47.327+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
da58e5c5-15b6-4081-97bc-5222ec269622	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "d9247846-9dae-443d-bfc3-15822de1fbaf", "timestamp": "2026-06-09T04:15:47.328Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:15:47.329+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7f814e1d-5098-4bfe-8393-af24f1e7ab9a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "d9247846-9dae-443d-bfc3-15822de1fbaf", "timestamp": "2026-06-09T04:15:47.359Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:15:47.36+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
3730a02b-2208-47c5-9693-1eba552e8b13	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	\N	{"error": null, "status": "sent", "message": "PO-5000005 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000005", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000005", "attachmentFilename": "PO-5000005.pdf"}	\N	\N	2026-06-09 04:15:53.312+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
58e1a70e-bbf2-4801-87c3-a3a26ce4199a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	2325cf74-910a-4065-9a29-e9c5c9b9bb38	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000006", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "19000"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:50:28.707+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
791ba02f-7ee7-4c6e-999d-502db947018d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	2325cf74-910a-4065-9a29-e9c5c9b9bb38	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "8d963188-3b68-4bc4-9ee7-6ad821479e35", "timestamp": "2026-06-09T04:50:28.709Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:50:28.709+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
f5a21b86-baf7-4c72-8ac7-2695054b4a67	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	2325cf74-910a-4065-9a29-e9c5c9b9bb38	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "8d963188-3b68-4bc4-9ee7-6ad821479e35", "timestamp": "2026-06-09T04:50:28.735Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:50:28.736+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
4ad08f73-e523-4d2f-92c2-1e97e4b2f909	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	2325cf74-910a-4065-9a29-e9c5c9b9bb38	\N	{"error": null, "status": "sent", "message": "PO-5000006 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000006", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000006", "attachmentFilename": "PO-5000006.pdf"}	\N	\N	2026-06-09 04:50:32.756+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
fdc526bc-faa0-4d34-9e1c-30e7ea58625c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	f1732149-a034-4689-ad21-901760bba457	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000007", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1450"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:02:19.944+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
5780f6f7-96fc-494d-aeec-2516899ebb7f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	f1732149-a034-4689-ad21-901760bba457	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "29351dec-fed5-4bc1-b237-2aac9d800c42", "timestamp": "2026-06-09T05:02:19.945Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:02:19.946+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
c9bc26b5-507f-4cd7-b038-2f7a53813ff1	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	f1732149-a034-4689-ad21-901760bba457	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "29351dec-fed5-4bc1-b237-2aac9d800c42", "timestamp": "2026-06-09T05:02:19.977Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:02:19.977+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
05bc3a8c-225a-4208-a18a-72b0c19c18cb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	f1732149-a034-4689-ad21-901760bba457	\N	{"error": null, "status": "sent", "message": "PO-5000007 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000007", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000007", "attachmentFilename": "PO-5000007.pdf"}	\N	\N	2026-06-09 05:02:24.434+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
b55a1ccf-3016-43a3-b1c2-d18917605249	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	e62b76c6-23ef-4d71-ba48-9d10ae494065	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000008", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1800"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:12:37.216+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
c68f5f20-5142-4ef2-9ebb-2943e1e9d59c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	e62b76c6-23ef-4d71-ba48-9d10ae494065	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "b4d633f0-74ad-43ea-a563-1aaccf5ae845", "timestamp": "2026-06-09T05:12:37.218Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:12:37.219+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
e4fdd480-9f89-4bfa-87cc-4a70cc928c25	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	e62b76c6-23ef-4d71-ba48-9d10ae494065	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "b4d633f0-74ad-43ea-a563-1aaccf5ae845", "timestamp": "2026-06-09T05:12:37.246Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:12:37.247+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
05896d5b-6f57-4a33-afd5-03cdd4fc11c4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	e62b76c6-23ef-4d71-ba48-9d10ae494065	\N	{"error": null, "status": "sent", "message": "PO-5000008 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000008", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000008", "attachmentFilename": "PO-5000008.pdf"}	\N	\N	2026-06-09 05:12:41.553+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
74f59d57-ad5c-4d70-9b95-ac4eb2ee1ac3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	265ba202-982a-4bfa-bbd6-51ea0bff27e8	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": null, "toStatus": "POSTED", "auditType": "STATUS_TRANSITION", "requestId": "bb1ea424-b713-4f9b-9178-e9838f44fcdb", "timestamp": "2026-06-09T05:19:50.665Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:19:50.666+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
a066c0fb-6111-41b9-8ee2-e9eb6eb2ab24	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	265ba202-982a-4bfa-bbd6-51ea0bff27e8	\N	{"error": null, "status": "sent", "message": "GR-00004 emailed to kolandasamy.sss@gmail.com", "trigger": "auto", "grNumber": "GR-00004", "ipAddress": "27.4.240.166", "recipient": "kolandasamy.sss@gmail.com", "requestId": "bb1ea424-b713-4f9b-9178-e9838f44fcdb", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", "templateId": "goods_receipt_supplier", "documentNumber": "GR-00004", "attachmentFilename": "GR-00004.pdf"}	\N	\N	2026-06-09 05:20:06.658+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
f2371c38-c5a5-4695-9498-a15e984a588f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RECEIPT	408aea7a-6b67-4fab-af46-3321ed698642	\N	{"error": null, "status": "sent", "message": "GR-00005 emailed to kolandasamy.sss@gmail.com", "trigger": "auto", "grNumber": "GR-00005", "ipAddress": "27.4.240.166", "recipient": "kolandasamy.sss@gmail.com", "requestId": "08fe35f1-dedb-4b71-9ffe-56b705b2c346", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", "templateId": "goods_receipt_supplier", "documentNumber": "GR-00005", "attachmentFilename": "GR-00005.pdf"}	\N	\N	2026-06-09 05:23:16.736+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
4c9db21e-e354-443b-8f4f-1e44109a6220	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_RETURN	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	\N	{"error": null, "status": "sent", "message": "RMO-00001 emailed to kolandasamy.sss@gmail.com", "trigger": "auto", "ipAddress": "27.4.240.166", "recipient": "kolandasamy.sss@gmail.com", "requestId": "ad71ba3f-4ce5-4f20-9890-eca07d1f6410", "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", "templateId": "supplier_return_notice", "returnNumber": "RMO-00001", "documentNumber": "RMO-00001", "attachmentFilename": "RMO-00001.pdf"}	\N	\N	2026-06-09 05:25:44.074+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
8f74b9ad-c89d-450c-93be-57f9fbf76ccf	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SUPPLIER_RETURN	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	\N	{"status": "SUBMITTED", "emailSentAt": "2026-06-09T05:25:44.076Z"}	\N	\N	2026-06-09 05:25:44.086+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
e4baad2c-9144-4875-aee4-c308fd709844	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	6a65724c-dc91-465a-ba9e-e79e7d88234c	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000009", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1450"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:39:30.345+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
72768014-971d-4ca2-a6e9-0e2dded05d06	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	6a65724c-dc91-465a-ba9e-e79e7d88234c	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "3c8a8e03-378f-4aec-962e-d909e9206a4f", "timestamp": "2026-06-09T05:39:30.347Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:39:30.348+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
0231532a-ff0e-471d-bee3-0838fcd16c9d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	6a65724c-dc91-465a-ba9e-e79e7d88234c	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "3c8a8e03-378f-4aec-962e-d909e9206a4f", "timestamp": "2026-06-09T05:39:30.374Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:39:30.375+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
a83e654b-fc53-41c4-aa59-9a0e861060e5	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	6a65724c-dc91-465a-ba9e-e79e7d88234c	\N	{"error": null, "status": "sent", "message": "PO-5000009 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000009", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000009", "attachmentFilename": "PO-5000009.pdf"}	\N	\N	2026-06-09 05:39:34.854+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
a3c45897-0628-40e0-a981-e75f036a1e46	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000010", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "180.26"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:44:33.068+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
3ac64dac-5f31-4dcc-80f0-1b73b114b138	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "9dd07fa7-f693-4c48-b9d8-a2b19b029bc4", "timestamp": "2026-06-09T05:44:33.070Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:44:33.071+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
2defc64d-6ce0-4c43-8f13-e7b70028c66b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "9dd07fa7-f693-4c48-b9d8-a2b19b029bc4", "timestamp": "2026-06-09T05:44:33.098Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:44:33.099+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
3dc527df-7055-469d-a850-42e914df1b27	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	\N	{"error": null, "status": "sent", "message": "PO-5000010 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000010", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000010", "attachmentFilename": "PO-5000010.pdf"}	\N	\N	2026-06-09 05:44:37.146+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
cc770163-0757-4478-8134-d73d6f043c16	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000011", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "21750"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 09:59:27.504+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
ae6bce97-0765-44ce-b055-755150015ab2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "a0787730-8db6-47ad-ac04-ff5bd779ddbe", "timestamp": "2026-06-09T09:59:27.505Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 09:59:27.506+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
e50793a0-90dc-44df-a213-5db74884adbe	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "a0787730-8db6-47ad-ac04-ff5bd779ddbe", "timestamp": "2026-06-09T09:59:27.537Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 09:59:27.537+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
bf4f88b3-5b95-4d06-b0b9-87ed329057d0	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	\N	{"error": null, "status": "sent", "message": "PO-5000011 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000011", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000011", "attachmentFilename": "PO-5000011.pdf"}	\N	\N	2026-06-09 09:59:34.008+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
822b90d7-ad0a-460b-856d-c80927921edd	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	714d8e69-25db-490c-af43-8c6168c774d4	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000012", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1800"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 10:06:59.703+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
2141d85c-d1b3-4733-b5a4-29e644a9091a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	714d8e69-25db-490c-af43-8c6168c774d4	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "f2e01984-a1f3-4a46-a82b-8e75db7f731b", "timestamp": "2026-06-09T10:06:59.704Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 10:06:59.705+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
7a20f1ae-89e9-449f-b414-2a57ff431cd8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	714d8e69-25db-490c-af43-8c6168c774d4	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "f2e01984-a1f3-4a46-a82b-8e75db7f731b", "timestamp": "2026-06-09T10:06:59.727Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 10:06:59.729+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
e7820f36-c870-40e9-bf0e-64d1ebdb1072	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	714d8e69-25db-490c-af43-8c6168c774d4	\N	{"error": null, "status": "sent", "message": "PO-5000012 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000012", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000012", "attachmentFilename": "PO-5000012.pdf"}	\N	\N	2026-06-09 10:07:05.436+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
de66e258-7945-4b8a-a3bc-1637a92d9be4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	eaafa0b8-8e26-4636-9e0b-1039689f82a6	\N	{"rfqId": null, "shopId": "5c1f22f6-978a-43fe-ad41-28359edf08d4", "status": "CONFIRMED", "poNumber": "PO-5000013", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "100"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 10:10:49.368+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
ebd7bdcb-9912-45d9-9149-45acbec2087c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	eaafa0b8-8e26-4636-9e0b-1039689f82a6	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "e1f0c697-7a23-4632-ab57-cc04f300d8fd", "timestamp": "2026-06-09T10:10:49.370Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 10:10:49.37+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
03541529-2bf8-462c-87c6-6f0fa177a5b0	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	eaafa0b8-8e26-4636-9e0b-1039689f82a6	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "e1f0c697-7a23-4632-ab57-cc04f300d8fd", "timestamp": "2026-06-09T10:10:49.405Z"}	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 10:10:49.405+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
fd76ffbd-170f-498c-b6e5-ef68b232f74d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	eaafa0b8-8e26-4636-9e0b-1039689f82a6	\N	{"error": null, "status": "sent", "message": "PO-5000013 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-5000013", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-5000013", "attachmentFilename": "PO-5000013.pdf"}	\N	\N	2026-06-09 10:10:55.784+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
640aa4b5-f4b2-4744-8f82-6a02e316cfaf	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	93ae57bd-78e2-44cc-bfce-eaf421970398	\N	{"rfqId": null, "shopId": "0f2ae8d3-b590-4b93-9c27-198ef987b2ad", "status": "CONFIRMED", "poNumber": "PO-00005", "supplier": "Heaven Electrical Supply", "itemCount": 1, "totalValue": "1450"}	2401:4900:265d:dfdc:cc6e:9755:84eb:6ce8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 17:16:03.877+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
851b1fb7-908d-41ca-b810-0014681b4a9f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	93ae57bd-78e2-44cc-bfce-eaf421970398	{"auditType": "STATUS_TRANSITION", "fromStatus": "DRAFT"}	{"reason": "confirmOnSend", "toStatus": "CONFIRMED", "auditType": "STATUS_TRANSITION", "requestId": "55b88df9-d018-43d5-9630-217c3f552346", "timestamp": "2026-06-09T17:16:03.879Z"}	2401:4900:265d:dfdc:cc6e:9755:84eb:6ce8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 17:16:03.879+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
912ed07b-2fe1-4c74-9229-e5281452b9b0	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	93ae57bd-78e2-44cc-bfce-eaf421970398	\N	{"sent": false, "action": "SEND_PO", "queued": true, "result": "success", "auditType": "ACTION", "recipient": "kolandasamy.sss@gmail.com", "requestId": "55b88df9-d018-43d5-9630-217c3f552346", "timestamp": "2026-06-09T17:16:03.914Z"}	2401:4900:265d:dfdc:cc6e:9755:84eb:6ce8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 17:16:03.916+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
62e38784-ddef-4c77-873a-3f387a46c42d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	PURCHASE_ORDER	93ae57bd-78e2-44cc-bfce-eaf421970398	\N	{"error": null, "status": "sent", "message": "PO-00005 emailed to kolandasamy.sss@gmail.com", "trigger": "manual", "poNumber": "PO-00005", "ipAddress": null, "recipient": "kolandasamy.sss@gmail.com", "requestId": null, "userAgent": null, "templateId": "purchase_order_supplier", "documentNumber": "PO-00005", "attachmentFilename": "PO-00005.pdf"}	\N	\N	2026-06-09 17:16:10.296+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
c98ecd57-4a14-4791-a2af-2699eaf2ce68	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	GOODS_ISSUE	508241a7-af1a-4fca-8454-20511c911948	\N	{"status": "POSTED", "giNumber": "GI-00002", "itemCount": 3}	\N	\N	2026-06-11 07:05:10.22+00	582b08bd-2a7a-475b-84c2-e4ef8f834a83	CREATE	\N	\N	\N	\N	\N
\.


--
-- Data for Name: auth_challenges; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.auth_challenges (id, user_id, purpose, token_hash, totp_secret_encrypted, attempt_count, expires_at, consumed_at, created_at, requested_ip, requested_user_agent) FROM stdin;
db22d29e-0094-4930-8c66-75108adb0670	d0eda257-86b4-4510-93bc-103cfe0d86e4	SIGNUP_MFA_ENROLL	c8d6790ff718fd4e2677e957a0972ace05917372b0313390a5a117202013d61b	CqoK71MU4VSrPvLd.glkl8uWZFtADJ5JJjWwVJw._eh4kM689h_8jMgshk4yb8QSmb-h4z1Ypdh1EgchRmg	0	2026-05-25 10:14:42.522+00	\N	2026-05-25 09:59:42.523+00	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36
c83129cc-87ad-4b3d-b3e3-0e150bbd2c89	73670f0a-df99-4e54-88fc-9b64dee80a28	SIGNUP_MFA_ENROLL	852fa49d323fe30919bfa3e700699cceab2f2543341f9abc43cd769de1e5d3bc	TDYzkafS_GtqdPfi.5FytJ2Wx9I7W3Ge9wVXJyw.TIdiPMlSDjBUT-BvjlQDg7eE1yqAalEGI4rfv0g7EQ0	0	2026-05-25 10:23:06.458+00	\N	2026-05-25 10:08:06.458+00	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36
6bda13c9-9ba4-4c67-84e0-3bf81b4c7119	47a8b4e9-c9ee-4239-b6c1-129e71d74587	LOGIN_MFA_VERIFY	976d057383c217644f11c8f467378de6b05642db375460dc12284c620853ecc9	\N	0	2026-05-25 12:41:35.099+00	2026-05-25 12:27:02.176+00	2026-05-25 12:26:35.1+00	2405:201:e033:6187:e0b6:506f:a6f:e174	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0
e65e21ed-680a-4ec5-ab91-25bc804fc3f4	47a8b4e9-c9ee-4239-b6c1-129e71d74587	LOGIN_MFA_VERIFY	6ca3ea3c70ef1758f4d0caecbe0287e815c63b3e1838cd62190726e669d1c976	\N	0	2026-05-25 12:51:07.134+00	2026-05-25 12:36:26.935+00	2026-05-25 12:36:07.136+00	2405:201:e033:6187:e0b6:506f:a6f:e174	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0
6e7a839c-a639-4b07-95fb-4ca1d3c265d1	47a8b4e9-c9ee-4239-b6c1-129e71d74587	LOGIN_MFA_VERIFY	a4d3ae7d7ecfa76650a40ec4c15f93d843ecc81091a18242a0bba198bf9dc084	\N	0	2026-05-25 16:06:28.4+00	2026-05-25 15:51:56.158+00	2026-05-25 15:51:28.401+00	2405:201:e033:6187:3c92:3a2f:93b3:75b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0
371f79f1-c9e4-4d69-b340-586c2e0b2561	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	LOGIN_MFA_VERIFY	c3ef25239183b8303b638580ed34cf1cbbd31e4a72d68b74dce5d1f3a04bfbc0	\N	0	2026-05-26 11:19:08.002+00	2026-05-26 11:05:07.773+00	2026-05-26 11:04:08.003+00	2405:201:e033:6187:14e6:65a4:a5d4:1ea	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36
dfa83e7f-ff43-489c-ab54-a1cadf42d777	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SIGNUP_MFA_ENROLL	8dc6567421d822a5217ff05bbfbc74ec278c684e43877265b687a87252512c1a	edjwZye2YlOmUdff.aofWWrl0bTrzYOmgU-kutg.CxZl0aMeWcsKqhoNwXUkbNwqEvf7nxye4k6DsW_AsEg	0	2026-05-26 16:45:08.765+00	2026-05-26 16:33:13.307+00	2026-05-26 16:30:08.766+00	220.158.156.250	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36
bf2a52e3-d8c0-43b5-880c-5c5741daad3e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOGIN_MFA_VERIFY	66104cec26afdb5ddbc7097ced55fe12a9c651b78b8e08c129d09fefc00371ef	\N	0	2026-05-26 16:48:41.836+00	2026-05-26 16:34:08.441+00	2026-05-26 16:33:41.837+00	220.158.156.250	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36
267f8716-f6c1-49d8-82c7-71d9d7d7cd41	47a8b4e9-c9ee-4239-b6c1-129e71d74587	LOGIN_MFA_VERIFY	afb2ce0eaa2b00248cb80e755f2d46fc1d3f543fb10fa57d87084d70dc97eec9	\N	0	2026-06-08 11:06:29.524+00	2026-06-08 10:51:58.015+00	2026-06-08 10:51:29.525+00	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0
98af9dba-c52e-4d71-b125-6191d9fa21c4	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	LOGIN_MFA_VERIFY	2213fe66b62e4c899958e5b1b4cd185ea6ff40a42693face304a2730ac24e1f5	\N	0	2026-06-13 08:30:34.288+00	2026-06-13 08:15:58.762+00	2026-06-13 08:15:34.289+00	127.0.0.1	curl/8.5.0
c2f0688f-d935-41a8-ad96-d50b54cf7e2c	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	LOGIN_MFA_VERIFY	23211485c9d8ea341ccf0744eb3721c7b81375d1a664c364f8c0b85c870d8814	\N	0	2026-06-13 08:30:58.764+00	2026-06-13 08:16:13.418+00	2026-06-13 08:15:58.765+00	127.0.0.1	curl/8.5.0
dd6ead3f-4dff-465d-9573-6eda0c4c2e87	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	LOGIN_MFA_VERIFY	80c51cc0b3874eae7296514cb17c3f06f3867322060036a64d84344c380dd906	\N	0	2026-06-13 08:31:13.42+00	\N	2026-06-13 08:16:13.421+00	127.0.0.1	curl/8.5.0
\.


--
-- Data for Name: backup_artifacts; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.backup_artifacts (id, company_id, backup_job_id, file_name, storage_path, file_size, sha256, provider, drive_file_id, schema_version, created_at) FROM stdin;
7640a968-be70-4b01-9a6f-0483c4b06efc	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5fd5b3d8-227b-4753-aa85-a1558d03b8d2	tenant-582b08bd-1779790949510.json.gz	storage/backups/tenant-582b08bd-1779790949510.json.gz	6301	f8dfc64a93c9e3014271ce2daa5cde4eda25803828788c52529be0a92856747c	MANUAL	\N	1	2026-05-26 10:22:29.512+00
ca534fcb-f625-451d-933d-54dcaa537a13	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	47b48fe6-a5ba-4ab1-b410-83fcee20743a	tenant-97321e34-1779791108026.json.gz	storage/backups/tenant-97321e34-1779791108026.json.gz	3244	db450fa01226b8c5d8c4a9b7ccca51ad0eacc21bd300d3983e5f549e1dff9aac	MANUAL	\N	1	2026-05-26 10:25:08.028+00
3d330926-4cf9-40a2-83d7-8bfdb611b86d	ff82dfb2-daf8-4f8f-a813-19033c69ea47	6fb207d8-084f-4d5d-8ca6-4bbf8155b108	tenant-ff82dfb2-1779793955231.json.gz	storage/backups/tenant-ff82dfb2-1779793955231.json.gz	646	840e44f91235ae5144016f03f49130105a9eaf9fbaab2a8c204e88518c4ee8d0	MANUAL	\N	1	2026-05-26 11:12:35.232+00
7304040a-236b-459f-a716-11f11162f6e3	582b08bd-2a7a-475b-84c2-e4ef8f834a83	79219713-44d3-4cbe-bbeb-8a50e6743105	tenant-582b08bd-1779794416727.json.gz	storage/backups/tenant-582b08bd-1779794416727.json.gz	6301	583dea753526ecc496d21e857c93fbad14e5740cc25a464ef15713563b6919b9	MANUAL	\N	1	2026-05-26 11:20:16.728+00
ae13214f-b317-4d76-96c8-eac87530c328	582b08bd-2a7a-475b-84c2-e4ef8f834a83	e42ea908-8493-48f3-94a6-3c62bebc7c7a	tenant-582b08bd-1779801305946.json.gz	storage/backups/tenant-582b08bd-1779801305946.json.gz	6302	c35f23836d65cc2e5c9740485a585389cbc88f6dd889c7351b94126cc5808f35	EMAIL	\N	1	2026-05-26 13:15:05.948+00
89cc7f23-08fd-4fa6-b06c-2f1be2bf1596	582b08bd-2a7a-475b-84c2-e4ef8f834a83	592e9512-a8dc-4d7e-be36-b76412a73a4b	tenant-582b08bd-1779813291457.json.gz	storage/backups/tenant-582b08bd-1779813291457.json.gz	8850	3193ec8e86e950aae8033f5afd4423088d1c72ca4cc9c36d6c86d36b2b41722c	MANUAL	\N	1	2026-05-26 16:34:51.46+00
dcb00710-e88d-4c8e-a0cf-b4c12af181fc	582b08bd-2a7a-475b-84c2-e4ef8f834a83	d338b701-5bd8-4845-8a72-84a7e52e6d20	tenant-582b08bd-1780054063578.json.gz	storage/backups/tenant-582b08bd-1780054063578.json.gz	9671	84ab98b80b9a975a957600938715e6188ec64151b62f3cae8c895bbcea1b170f	MANUAL	\N	1	2026-05-29 11:27:43.58+00
4ee232c2-a4a3-4194-ba89-c9b4e6302040	582b08bd-2a7a-475b-84c2-e4ef8f834a83	d1cbc27a-9601-445b-a028-2c9b9777ada8	tenant-582b08bd-1781001352835.json.gz	storage/backups/tenant-582b08bd-1781001352835.json.gz	25864	86556d661849dbdefc4ea162c9a25e224713372779910f8870af1c29a87ca973	MANUAL	\N	1	2026-06-09 10:35:52.838+00
5c45858a-39ff-4edb-b4be-743c92409576	582b08bd-2a7a-475b-84c2-e4ef8f834a83	9989d88d-ca35-429a-a931-aca6366c0d15	tenant-582b08bd-1781001365920.json.gz	storage/backups/tenant-582b08bd-1781001365920.json.gz	25863	39dff176d262c0a9c8c9c4e45369bf76f6c9ed33f7830724c703a7dfef164a30	EMAIL	\N	1	2026-06-09 10:36:05.922+00
eba0165f-b291-4361-9df6-658540300b87	582b08bd-2a7a-475b-84c2-e4ef8f834a83	f6e52437-7bf5-42e6-bbe9-c0476b827a5b	tenant-582b08bd-1781149202041.json.gz	storage/backups/tenant-582b08bd-1781149202041.json.gz	25946	1941537d7e3cd358193754332afc54f931436e8fa48b1e958f9fa182efd2a865	MANUAL	\N	1	2026-06-11 03:40:02.042+00
978d5ce0-408b-49c4-b77e-b5038ba1f3c0	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2f1cb1c3-ffab-4ecf-9a65-3ad5fe1eb461	tenant-582b08bd-1781149211166.json.gz	storage/backups/tenant-582b08bd-1781149211166.json.gz	25946	84279b87846d7e630c118f28d6eef382833de9fc034359571bc7e40274d63ba3	MANUAL	\N	1	2026-06-11 03:40:11.168+00
f64e12cd-582d-4e04-a023-d8266519b3b9	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0a279b88-9cd3-4de0-b691-59781d43df6d	tenant-582b08bd-1781244666406.json.gz	storage/backups/tenant-582b08bd-1781244666406.json.gz	26394	b09b9e1785c98fa228342b2419ccee26aa274cf7cfc66f3fd6fff44885c10bb2	MANUAL	\N	1	2026-06-12 06:11:06.408+00
7cb10f05-4852-4e0a-9070-f1ad09003f59	582b08bd-2a7a-475b-84c2-e4ef8f834a83	ec6bee7c-e923-460e-a455-9208fb7575c7	tenant-582b08bd-1781339269481.json.gz	storage/backups/tenant-582b08bd-1781339269481.json.gz	26541	845d8ecd3bfd960ccef4209682422538592caeca1c345bd26dd4836c854bc6d4	MANUAL	\N	1	2026-06-13 08:27:49.484+00
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.backup_jobs (id, company_id, status, provider, error_message, started_at, completed_at, created_by, created_at, deleted_at, deleted_by, lifecycle_status) FROM stdin;
5fd5b3d8-227b-4753-aa85-a1558d03b8d2	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-05-26 10:22:29.475+00	2026-05-26 10:22:29.514+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 10:22:29.467+00	\N	\N	ACTIVE
47b48fe6-a5ba-4ab1-b410-83fcee20743a	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	COMPLETED	MANUAL	\N	2026-05-26 10:25:07.997+00	2026-05-26 10:25:08.029+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	2026-05-26 10:25:07.992+00	\N	\N	ACTIVE
6fb207d8-084f-4d5d-8ca6-4bbf8155b108	ff82dfb2-daf8-4f8f-a813-19033c69ea47	COMPLETED	MANUAL	\N	2026-05-26 11:12:35.199+00	2026-05-26 11:12:35.234+00	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	2026-05-26 11:12:35.191+00	\N	\N	ACTIVE
79219713-44d3-4cbe-bbeb-8a50e6743105	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-05-26 11:20:16.69+00	2026-05-26 11:20:16.73+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 11:20:16.685+00	\N	\N	ACTIVE
e42ea908-8493-48f3-94a6-3c62bebc7c7a	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	EMAIL	\N	2026-05-26 13:15:05.898+00	2026-05-26 13:15:09.209+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 13:15:05.888+00	\N	\N	ACTIVE
592e9512-a8dc-4d7e-be36-b76412a73a4b	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-05-26 16:34:51.418+00	2026-05-26 16:34:51.462+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 16:34:51.406+00	\N	\N	ACTIVE
d338b701-5bd8-4845-8a72-84a7e52e6d20	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-05-29 11:27:43.444+00	2026-05-29 11:27:43.581+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-29 11:27:43.436+00	\N	\N	ACTIVE
d1cbc27a-9601-445b-a028-2c9b9777ada8	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-06-09 10:35:52.766+00	2026-06-09 10:35:52.84+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 10:35:52.757+00	\N	\N	ACTIVE
9989d88d-ca35-429a-a931-aca6366c0d15	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	EMAIL	\N	2026-06-09 10:36:05.872+00	2026-06-09 10:36:07.59+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 10:36:05.867+00	\N	\N	ACTIVE
f6e52437-7bf5-42e6-bbe9-c0476b827a5b	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-06-11 03:40:01.97+00	2026-06-11 03:40:02.044+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-11 03:40:01.963+00	\N	\N	ACTIVE
2f1cb1c3-ffab-4ecf-9a65-3ad5fe1eb461	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-06-11 03:40:11.109+00	2026-06-11 03:40:11.169+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-11 03:40:11.1+00	\N	\N	ACTIVE
0a279b88-9cd3-4de0-b691-59781d43df6d	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-06-12 06:11:06.326+00	2026-06-12 06:11:06.411+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-12 06:11:06.32+00	\N	\N	ACTIVE
ec6bee7c-e923-460e-a455-9208fb7575c7	582b08bd-2a7a-475b-84c2-e4ef8f834a83	COMPLETED	MANUAL	\N	2026-06-13 08:27:49.403+00	2026-06-13 08:27:49.492+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-13 08:27:49.396+00	\N	\N	ACTIVE
\.


--
-- Data for Name: backup_provider_credentials; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.backup_provider_credentials (id, company_id, provider, encrypted_tokens, account_email, drive_folder_id, connected_at, updated_at) FROM stdin;
\.


--
-- Data for Name: barcode_audit_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_audit_logs (id, company_id, barcode_id, barcode, product_id, action, detail, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: barcode_history; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_history (id, company_id, barcode, old_product_id, new_product_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: barcode_print_jobs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_print_jobs (id, user_id, template_id, pdf_url, status, quantities, created_at, updated_at, label_count) FROM stdin;
\.


--
-- Data for Name: barcode_template_versions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.barcode_template_versions (id, template_name, version, json_content, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: branding_profiles; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.branding_profiles (id, branding_version, logo_asset_id, watermark_asset_id, seal_asset_id, signature_asset_id, letterhead_asset_id, footer_text, email, phone, website, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.companies (id, company_code, company_name, address, is_active, subscription_plan, billing_cycle, subscription_status, trial_starts_at, trial_ends_at, subscription_ends_at, created_at, updated_at, created_by, updated_by, platform_marketing_opt_out, razorpay_subscription_id, paid_activated_at, branding_profile_id) FROM stdin;
41168db8-acc2-46f2-87e0-d07b6b813bc8	SAMITECH	Sami tech	77/44,2nd main road,gandhi nagar,Adyar	t	PLUS	MONTHLY	ACTIVE	\N	\N	2026-06-25 09:59:42.503+00	2026-05-25 09:59:42.51+00	2026-05-25 09:59:42.51+00	\N	\N	f	\N	\N	\N
c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	THARUNPV	Tharun Pvt Ltd	77/44,2nd main road,gandhi nagar,Adyar	t	PLUS	MONTHLY	ACTIVE	\N	\N	2026-06-25 10:08:06.423+00	2026-05-25 10:08:06.432+00	2026-05-25 10:08:06.432+00	\N	\N	f	\N	\N	\N
97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	REVATHIH	Revathi Hotels	2/235,Udaya Nagar, Sivaram nagar	t	PLUS	MONTHLY	ACTIVE	\N	\N	2026-06-25 12:10:30.14+00	2026-05-25 12:10:30.166+00	2026-05-25 12:10:30.166+00	\N	\N	f	\N	\N	\N
ff82dfb2-daf8-4f8f-a813-19033c69ea47	SOFTDIGI	SoftDigits	77/44,2nd main road,gandhi nagar,Adyar	t	PLUS	MONTHLY	ACTIVE	2026-05-25 12:04:20.848+00	\N	2026-06-26 11:06:36.382+00	2026-05-25 12:04:20.859+00	2026-05-26 11:06:36.384+00	\N	\N	f	\N	\N	\N
582b08bd-2a7a-475b-84c2-e4ef8f834a83	SDC-001	Softdigit Consulting	1 Main Street	t	PLUS	MONTHLY	ACTIVE	2026-05-24 19:37:34.610417+00	\N	2026-06-25 04:42:43.787+00	2026-05-24 19:37:34.610417+00	2026-05-29 13:50:05.39+00	\N	6fd97d36-05d1-4617-8c81-0d54da73ace8	f	\N	\N	\N
5c4b301a-5ddc-4777-acbd-adddeee7ef37	SAMANDCO	Sam and co	12 Industrial area Hosur	t	TRIAL	\N	EXPIRED	2026-05-31 03:18:01.901+00	2026-06-07 03:18:01.901+00	\N	2026-05-31 03:18:01.913+00	2026-06-07 09:00:00.358+00	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: company_engagement_snapshots; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.company_engagement_snapshots (id, company_id, snapshot_date, lifecycle_stage, last_login_at, login_count_30d, features_used, products_count, inventory_txn_count, team_members_count, reports_generated, trial_progress_pct, created_at) FROM stdin;
bf04ee4b-dc54-4457-9812-6c30fa445ebe	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-05-30	NEW	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-05-30 09:00:00.669+00
95d9b204-9c42-436a-a1f6-814235ce2d43	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-05-30	NEW	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-05-30 09:00:00.963+00
6c202501-6da5-4f32-82cd-4c470e091c1e	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-05-30	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-05-30 09:00:01.056+00
97cf2f5c-f3a1-4425-8106-1e0da042aa71	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-05-30	NEW	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-05-30 09:00:01.077+00
53400912-89e4-41bd-9655-b61d5982c846	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-05-30	ENGAGED	2026-05-30 08:50:00.875+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	15	2	0	86	2026-05-30 09:00:01.164+00
8fdc709e-7141-4c1f-94cc-0c7d2b360d0a	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-05-31	NEW	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-05-31 09:00:00.286+00
426570c2-b83c-4b3b-a946-020847d497ea	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-05-31	NEW	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-05-31 09:00:00.378+00
5f691b59-c7e6-43dc-ba2e-99b40d7d17b2	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-05-31	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-05-31 09:00:00.394+00
c6aa9132-be22-4720-b462-cbf0abb02bc8	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-05-31	NEW	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-05-31 09:00:00.405+00
772986f4-0d7f-42c4-9fd5-2962614962c6	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-05-31	ENGAGED	2026-05-31 07:15:40.903+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-05-31 09:00:00.471+00
f4356b9e-1aae-4426-aa5d-9ad6ea11ff21	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-05-31	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-05-31 09:00:00.488+00
88dd727c-2a29-4f45-9b13-36e7fe793112	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-01	NEW	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-01 09:00:00.201+00
a4b811ce-c90c-4aee-95cd-1d89fd4cb064	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-01	NEW	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-01 09:00:00.224+00
4e1255b3-1029-4c46-a3cf-839ab8bee40b	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-01	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-01 09:00:00.264+00
f8440062-cb97-4c90-bb3c-a17a2f731506	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-01	NEW	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-01 09:00:00.281+00
3464e755-dae1-4865-942f-9ce6a4886b9f	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-01	ENGAGED	2026-05-31 10:56:02.487+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-01 09:00:00.293+00
a37b959a-3290-475f-bc30-c0debe5675c2	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-01	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-01 09:00:00.31+00
c478b606-c177-4826-8d8c-2babfba675e9	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-02	NEW	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-02 09:00:00.112+00
a88c4d9d-c564-41ae-8632-c68d9ef1da4f	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-02	NEW	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-02 09:00:00.133+00
7da9825d-ba08-409e-aa12-5693d762653e	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-02	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-02 09:00:00.152+00
2e0e08ee-ca76-4a75-9ef8-ffd9cebd4712	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-02	NEW	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-02 09:00:00.161+00
313c2d66-f9bb-4dab-bbb7-bfee9a2ccbb0	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-02	ENGAGED	2026-06-02 05:39:11.136+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-02 09:00:00.174+00
5fec5d85-4934-456c-b0ba-365cd688e25f	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-02	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-02 09:00:00.189+00
8ffd7ef7-fd0d-4e40-914e-a69405a090a0	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-03	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-03 09:00:00.179+00
4ac570c2-b891-45ae-b34a-4542a098ed42	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-03	ACTIVE	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-03 09:00:00.222+00
ba3509c4-44e8-41ab-b1de-e68467393309	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-03	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-03 09:00:00.286+00
f0417d34-a00e-42c2-873b-36177d5f2c42	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-03	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-03 09:00:00.313+00
11eb7955-3d5d-4388-8cdb-5c4d72ff5fa1	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-03	ENGAGED	2026-06-03 08:31:00.593+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-03 09:00:00.325+00
0183a528-bfe4-4fe1-a36f-094ac2a24191	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-03	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-03 09:00:00.34+00
1249712f-e199-433e-9f9d-932734a07083	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-04	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-04 09:00:00.16+00
2a530470-cd25-48ff-9c1e-e33248f504c8	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-04	ACTIVE	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-04 09:00:00.183+00
c1f61e2f-2400-45ee-9ebb-fef47820d83a	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-04	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-04 09:00:00.2+00
51bf4460-1da0-4875-b1b2-8c4fe241696b	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-04	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-04 09:00:00.212+00
f298549f-6c07-414b-81ba-78642a66a70c	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-04	ENGAGED	2026-06-03 16:08:02.922+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-04 09:00:00.228+00
30ae6d0a-ba07-4792-b160-f030a1150d98	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-04	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-04 09:00:00.242+00
724276d6-d724-40d0-9fad-321090517535	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-05	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-05 09:00:00.169+00
e2797239-1ea3-4861-a8a7-5d62275f1cbb	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-05	ACTIVE	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-05 09:00:00.188+00
98ba3e5c-0e03-4dfe-9278-32269da60cc8	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-05	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-05 09:00:00.199+00
f0a0da79-ac84-4a01-9e23-9ac4512013e4	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-05	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-05 09:00:00.209+00
90074798-2a07-498b-b849-e1ee18b330d1	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-05	ENGAGED	2026-06-03 16:08:02.922+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-05 09:00:00.223+00
70eaba2d-9114-4355-89a0-592a9de87196	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-05	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-05 09:00:00.235+00
a3333498-489d-4e07-b498-19a621a66b61	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-06	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-06 09:00:00.138+00
532401b5-5307-4528-9881-96ae39b3cf0d	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-06	ACTIVE	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-06 09:00:00.162+00
0d877aba-ec26-4746-ab70-83a27669b1a7	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-06	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-06 09:00:00.18+00
026d387c-34ec-4c6a-9f5f-7c0a0f1efda8	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-06	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-06 09:00:00.193+00
ae3aed71-c9e3-46d4-b96e-39b828e00666	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-06	ENGAGED	2026-06-06 05:17:54.834+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-06 09:00:00.206+00
cf98d46a-b6af-4e16-b487-f083b0ab0197	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-06	TRIAL	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-06 09:00:00.216+00
dc4cdec6-e5ad-4e99-8dc0-904294a77cbc	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-07	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-07 09:00:00.264+00
2a37721f-3529-4cee-8fcc-521da90e3396	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-07	ACTIVE	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-07 09:00:00.29+00
27f4d82e-f491-494e-823c-da0becceff3b	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-07	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-07 09:00:00.307+00
f59b23a3-31e4-4655-b488-8e42a042ac2a	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-07	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-07 09:00:00.318+00
121328ca-a4ef-49ad-8575-42414ab70a42	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-07	ENGAGED	2026-06-06 14:25:55.862+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-07 09:00:00.33+00
0e28ca09-2977-4a98-bd83-e7048d342d8a	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-07	TRIAL_EXPIRED	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-07 09:00:00.34+00
681a20d0-3356-41bf-8bd0-d7340d64705b	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-08	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-08 09:00:00.095+00
8073cbce-17ff-41a9-ac28-86c4c40e2f74	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-08	ACTIVE	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-08 09:00:00.126+00
c5058693-1c13-4bb5-9489-1251bb507e1a	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-08	ENGAGED	2026-05-27 12:38:46.777+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-08 09:00:00.163+00
935cbb4e-4397-4949-91cb-b60e7bfcb745	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-08	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-08 09:00:00.175+00
834d8731-7622-4988-8724-8a2a8ccba422	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-08	ENGAGED	2026-06-08 07:04:35.059+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	54	16	2	0	86	2026-06-08 09:00:00.189+00
d51040ad-04ff-47fa-81de-a5403c0b8d92	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-08	TRIAL_EXPIRED	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-08 09:00:00.199+00
d8cf1518-2a41-4714-9f82-3f46440ba794	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-09	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-09 09:00:00.185+00
e82e47a7-d062-4d59-81bb-7a9bc0a230d6	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-09	AT_RISK	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-09 09:00:00.201+00
4d53de14-e966-4e3f-a2b2-721f4bd2c3fc	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-09	ENGAGED	2026-06-08 10:51:58.233+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-09 09:00:00.218+00
a3e9ff3c-7fda-47c1-95de-7366620810a2	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-09	ACTIVE	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-09 09:00:00.23+00
70723d8e-d77b-423a-82b4-e36b2f42cf6d	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-09	ENGAGED	2026-06-09 07:40:16.443+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	55	18	2	0	86	2026-06-09 09:00:00.241+00
9a7c54ee-3a59-424e-9342-52b7c019f718	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-09	TRIAL_EXPIRED	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-09 09:00:00.25+00
432a575f-29c4-44c9-ab52-5bf0e31d5852	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-10	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-10 09:00:00.136+00
0c60839f-f1d6-435c-af50-1cac1f89c322	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-10	AT_RISK	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-10 09:00:00.154+00
be1921d5-246d-4a15-b81c-e4a35b98f596	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-10	ENGAGED	2026-06-08 10:51:58.233+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-10 09:00:00.165+00
9a5821a1-b44a-442b-af50-2927e953e820	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-10	AT_RISK	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-10 09:00:00.176+00
b8240bb2-ecff-4a8d-8c4b-51eb231d1c0f	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-10	ENGAGED	2026-06-10 08:46:22.985+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	55	18	2	0	86	2026-06-10 09:00:00.191+00
5edcb788-72b8-4a64-ab64-588c5871dc8f	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-10	TRIAL_EXPIRED	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-10 09:00:00.203+00
a5f16da2-27f1-42c2-9768-4eb6f7eb1121	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-11	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-11 09:00:00.142+00
4e3cf794-9241-4976-ac60-0670a4c1869b	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-11	AT_RISK	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-11 09:00:00.162+00
6ecc194e-79ef-4e2a-aa36-17a64c5a9289	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-11	ENGAGED	2026-06-08 10:51:58.233+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-11 09:00:00.179+00
38b3fb16-b798-4b60-be60-bedd7e35ba4f	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-11	AT_RISK	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-11 09:00:00.193+00
44d5647f-a04f-427e-b450-750fd96701f7	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-11	ENGAGED	2026-06-11 08:10:49.728+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	55	19	2	0	86	2026-06-11 09:00:00.21+00
43051ad2-40fc-4083-b1f7-a94e3ecc6e04	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-11	TRIAL_EXPIRED	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-11 09:00:00.221+00
fee2bbb8-a78f-4b4c-a531-93b6dc979fa8	41168db8-acc2-46f2-87e0-d07b6b813bc8	2026-06-12	ACTIVE	2026-05-30 10:26:37.182+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-12 09:00:00.167+00
f8b4ff80-9fd5-48bf-a021-e5e836a88f9b	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	2026-06-12	AT_RISK	\N	0	{"login": false, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": false}	0	0	1	0	0	2026-06-12 09:00:00.189+00
bb2990ac-ce18-4e57-89c3-1a58315a1f60	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	2026-06-12	ENGAGED	2026-06-08 10:51:58.233+00	1	{"login": true, "gi_posted": false, "gr_posted": true, "user_invited": false, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	12	1	1	0	57	2026-06-12 09:00:00.202+00
87b34849-ae3c-48ee-9f92-6e8cf22831f0	ff82dfb2-daf8-4f8f-a813-19033c69ea47	2026-06-12	AT_RISK	2026-05-26 11:05:07.988+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-12 09:00:00.215+00
748b27d2-05e0-4e9d-9dc6-196a390fdd7c	582b08bd-2a7a-475b-84c2-e4ef8f834a83	2026-06-12	ENGAGED	2026-06-12 07:28:22.917+00	2	{"login": true, "gi_posted": true, "gr_posted": true, "user_invited": true, "report_viewed": false, "product_created": true, "dashboard_viewed": true}	56	19	2	0	86	2026-06-12 09:00:00.229+00
9fc4847c-eee3-4e98-a8ef-7e59511e4790	5c4b301a-5ddc-4777-acbd-adddeee7ef37	2026-06-12	TRIAL_EXPIRED	2026-05-31 03:18:02.368+00	1	{"login": true, "gi_posted": false, "gr_posted": false, "user_invited": false, "report_viewed": false, "product_created": false, "dashboard_viewed": true}	0	0	1	0	29	2026-06-12 09:00:00.237+00
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.company_settings (id, company_id, key, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contract_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.contract_header (id, contract_number, shop_id, supplier_id, rfq_id, quotation_id, title, payment_terms, start_date, end_date, notes, status, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
e7b2d519-f497-4d56-b8bb-199d5381f5a3	CT-HQ001-202605-00001	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7c961808-5a79-4c95-8c40-a36f4839609c	e3ba67e8-f91b-4d30-90d8-1c0b3a338774	3169c1cc-0e34-4f9a-a766-6d7e1f1c18e5	Auto Contract QUO-HQ001-202605-00001	\N	2026-05-25	\N	Submitted via supplier portal	POSTED	2026-05-25 05:28:26.475+00	2026-05-25 05:28:26.475+00	2026-05-25 05:28:26.475+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
966015a8-2576-4b9a-a415-67aab1ae9c7d	CT-HQ001-202605-00002	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7c961808-5a79-4c95-8c40-a36f4839609c	cbba0db5-cda0-4cfc-97df-26985042ff4d	0410cc07-87eb-41fc-8813-a297207a902e	Auto Contract QUO-HQ001-202605-00002	\N	2026-05-25	\N	Lead time: 12 days\nSubmitted via supplier portal	POSTED	2026-05-25 06:01:34.397+00	2026-05-25 06:01:34.397+00	2026-05-25 06:01:34.397+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3187e01c-3304-43f7-8e78-e1e73743879d	CT-HQ001-202605-00003	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7c961808-5a79-4c95-8c40-a36f4839609c	5daf69be-ed64-4841-931e-0de22ee61183	d4165258-cb44-41c0-b7ef-72a5019aa73c	Auto Contract QUO-HQ001-202605-00003	\N	2026-05-25	\N	Lead time: 3 days\nSubmitted via supplier portal	POSTED	2026-05-25 06:10:15.625+00	2026-05-25 06:10:15.626+00	2026-05-25 06:10:15.626+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
c0f121eb-b090-446c-8322-bfd1d832eee6	CT-HQ001-202605-00004	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	a94916e2-72a6-4b9c-985d-01de9bc20a2a	8e4dcbdf-a386-42b6-916c-ff4d83490d15	0839653d-55ac-4e4a-b4c5-03dd3166edcd	Auto Contract QUO-HQ001-202605-00004	\N	2026-05-25	\N	LED\nLead time: 1 days\nSubmitted via supplier portal	POSTED	2026-05-25 15:48:10.501+00	2026-05-25 15:48:10.502+00	2026-05-25 15:48:10.502+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
b440d2ed-42d3-45c5-a2c1-90978429a616	CT-HQ001-202605-00005	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	a94916e2-72a6-4b9c-985d-01de9bc20a2a	e890e821-c818-46b4-9e4b-bda34532983d	b4d5b54d-e4a2-46d8-aba3-283dca75f3d6	Auto Contract QUO-HQ001-202605-00006	\N	2026-05-25	\N	Lead time: 10 days\nSubmitted via supplier portal	POSTED	2026-05-25 16:16:13.403+00	2026-05-25 16:16:13.405+00	2026-05-25 16:16:13.405+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: contract_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.contract_items (id, contract_id, product_id, description, quantity, uom, unit_price, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
260e7c50-11e3-4f05-b41c-771f12fa5eb4	e7b2d519-f497-4d56-b8bb-199d5381f5a3	57812718-33b2-4585-ba16-e4a95bec7405	LED	1.000	pcs	99.00	99.00	2026-05-25 05:28:26.475+00	2026-05-25 05:28:26.475+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
a4ae81ac-ec43-45e4-92af-170614348999	966015a8-2576-4b9a-a415-67aab1ae9c7d	57812718-33b2-4585-ba16-e4a95bec7405	LED	20.000	pcs	130.00	2600.00	2026-05-25 06:01:34.397+00	2026-05-25 06:01:34.397+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
438f729d-ffdd-42eb-ba4b-9fbcf7efc97d	3187e01c-3304-43f7-8e78-e1e73743879d	57812718-33b2-4585-ba16-e4a95bec7405	LED	1.000	pcs	500.00	500.00	2026-05-25 06:10:15.626+00	2026-05-25 06:10:15.626+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
e01e874a-3405-422f-947e-21e27bbf54d1	c0f121eb-b090-446c-8322-bfd1d832eee6	57812718-33b2-4585-ba16-e4a95bec7405	LED	10.000	pcs	50.00	500.00	2026-05-25 15:48:10.502+00	2026-05-25 15:48:10.502+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ca0d1460-4b22-4328-9b6d-45d1c4b0fb9c	b440d2ed-42d3-45c5-a2c1-90978429a616	57812718-33b2-4585-ba16-e4a95bec7405	LED	20.000	pcs	100.00	2000.00	2026-05-25 16:16:13.405+00	2026-05-25 16:16:13.405+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bd6fd54e-bdf9-4114-92b1-43855598d0a7	b440d2ed-42d3-45c5-a2c1-90978429a616	53457790-5c18-4f3a-a2d6-709ded27ed4a	MCB (Miniature Circuit Breaker)	30.000	pcs	200.00	6000.00	2026-05-25 16:16:13.405+00	2026-05-25 16:16:13.405+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: cost_layers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.cost_layers (id, shop_id, product_id, gr_id, ledger_id, qty_remaining, qty_original, unit_cost, created_at) FROM stdin;
\.


--
-- Data for Name: credit_notes; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.credit_notes (id, credit_number, credit_date, shop_id, customer_id, invoice_id, return_id, status, amount, applied_amount, remarks, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.currencies (code, name, decimals) FROM stdin;
\.


--
-- Data for Name: customer_return_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.customer_return_items (id, return_id, product_id, quantity, uom, unit_price, line_value) FROM stdin;
\.


--
-- Data for Name: customer_returns; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.customer_returns (id, return_number, return_date, shop_id, customer_id, invoice_id, sales_order_id, reason, remarks, status, total_value, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.customers (id, customer_code, customer_name, email, phone, tax_id, street, city, state, postal_code, country, shop_id, is_active, created_at, updated_at, created_by, updated_by, pan) FROM stdin;
ac6eb189-b321-4104-810c-f90c3db4b0f7	CUS-00001	Sri Balaji Constructions Pvt Ltd	kolandasamy.sss@gmail.com	9876541230	\N	\N	Bhavani	Tamil Nadu	638314	\N	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	2026-05-25 12:54:21.393+00	2026-05-25 12:54:21.393+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
c1663e2a-177a-4bde-90a2-2afb1fc922f4	CUS-HQ001-202605-00001	Krithik Traders	tharunbackup08@gmail.com	09566376859	\N	\N	Chennai	Tamil Nadu	600020	\N	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	2026-05-26 15:27:01.481+00	2026-05-26 15:27:01.481+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
42d771b0-21b6-4ad8-8a9e-4cfe514f1670	CUS-REVATH001-202605-00001	Pepsi Bottling India Pvt Ltd	samiedge@outlook.com	9080467818	\N	\N	Chennai	Tamilnadu	600034	\N	d53ce4ee-7da6-4709-b944-348687fb0843	t	2026-05-26 16:45:17.271+00	2026-05-26 16:47:11.111+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
90d8ced8-0995-4a35-8389-8a962703c2ea	CUS-00012	PowerDrive Pvt Ltd	gstharunafhithya08@gmail.com	09566376859	\N	\N	Chennai	Tamil Nadu	600020	\N	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	2026-05-30 03:48:55.115+00	2026-05-30 03:48:55.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca	CUS-00002	Tharun Traders	gstharunadhithya08@gmail.com	9488329318	\N	\N	Oggiyamduraipakkam	Tamil Nadu	600097	\N	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	2026-05-26 08:19:26.154+00	2026-05-30 06:54:15.575+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
011faebb-2952-4b7d-affd-a9e450b8cc11	CUS-00013	Green City Apartments	gstharunadhithya08@gmail.com	09677878856	33AAACE1234F1Z5	\N	Oggiyamduraipakkam	Tamil Nadu	600097	\N	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	2026-05-30 06:53:38.477+00	2026-05-30 07:52:03.279+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	COYPK34567Q
\.


--
-- Data for Name: damaged_stock; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.damaged_stock (id, damage_number, damage_date, shop_id, product_id, damaged_quantity, reason, remarks, status, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: data_retention_config; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.data_retention_config (id, entity, retain_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: device_registrations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.device_registrations (id, user_id, company_id, device_id, device_name, platform, push_token, app_version, os_version, is_active, last_active_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_email_outbox; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.document_email_outbox (id, entity_type, entity_id, document_number, template_id, company_id, shop_id, recipient, attachment_filename, status, trigger, attempts, retry_count, last_error, next_retry_at, payload_json, sent_at, sent_by_id, message_id, created_at, updated_at) FROM stdin;
f99e0c98-923d-4fe0-af15-f43034c615e7	purchase-order	24e5f5c4-3725-469e-9c5c-5e1bc438faa0	PO-00001	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	\N	PENDING_PDF	MANUAL	1	1	Failed to launch the browser process:  Code: 127\n\nstderr:\n/root/.cache/puppeteer/chrome/linux-146.0.7680.153/chrome-linux64/chrome: error while loading shared libraries: libgbm.so.1: cannot open shared object file: No such file or directory\n\nTROUBLESHOOTING: https://pptr.dev/troubleshooting\n	2026-05-29 07:55:09.613+00	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE002", "quantity": "1", "lineValue": "₹300.00", "unitPrice": "₹300.00", "description": "MCB (Miniature Circuit Breaker)"}], "poDate": "30 May 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"53457790-5c18-4f3a-a2d6-709ded27ed4a\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"System Admin\\",\\"shipToCompany\\":\\"Headquarters\\",\\"shipToAddress\\":\\"1 Main Street\\",\\"shipToPhone\\":\\"+0000000000\\",\\"contactName\\":\\"System Admin\\",\\"contactPhone\\":\\"+0000000000\\",\\"contactEmail\\":\\"hq@retailims.local\\"}-->", "poNumber": "PO-00001", "shopName": "Headquarters", "totalValue": "₹300.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-00001</strong> dated 30 May 2026 for Headquarters.</p><p>Total: ₹300.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-00001 dated 30 May 2026 for Headquarters.\\nTotal: ₹300.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-00001 — Softdigit Consulting"}}	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-29 07:50:08.454+00	2026-05-29 07:50:09.615+00
e9f997cb-555d-4260-9057-0aa516223160	purchase-order	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	PO-5000011	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000011.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE050", "quantity": "15", "lineValue": "₹21,750.00", "unitPrice": "₹1,450.00", "description": "Power Capacitor"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"f9865733-a9f7-44f6-a031-9c3925042cea\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000011", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹21,750.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000011</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹21,750.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000011 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹21,750.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000011 — Softdigit Consulting"}}	2026-06-09 09:59:33.995+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<904102dd-9ef9-024e-6fa4-11a64d7e00ce@gmail.com>	2026-06-09 09:59:27.532+00	2026-06-09 09:59:33.997+00
e492f44f-c198-422b-ad82-02754ffc5002	purchase-order	53a1c699-58cd-4d6f-b3b3-071cfd584544	PO-00002	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	\N	PENDING_PDF	MANUAL	1	1	Failed to launch the browser process:  Code: 127\n\nstderr:\n/root/.cache/puppeteer/chrome/linux-146.0.7680.153/chrome-linux64/chrome: error while loading shared libraries: libgbm.so.1: cannot open shared object file: No such file or directory\n\nTROUBLESHOOTING: https://pptr.dev/troubleshooting\n	2026-05-29 07:55:19.019+00	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE002", "quantity": "1", "lineValue": "₹300.00", "unitPrice": "₹300.00", "description": "MCB (Miniature Circuit Breaker)"}], "poDate": "30 May 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"53457790-5c18-4f3a-a2d6-709ded27ed4a\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"System Admin\\",\\"shipToCompany\\":\\"Headquarters\\",\\"shipToAddress\\":\\"1 Main Street\\",\\"shipToPhone\\":\\"+0000000000\\",\\"contactName\\":\\"System Admin\\",\\"contactPhone\\":\\"+0000000000\\",\\"contactEmail\\":\\"hq@retailims.local\\"}-->", "poNumber": "PO-00002", "shopName": "Headquarters", "totalValue": "₹300.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-00002</strong> dated 30 May 2026 for Headquarters.</p><p>Total: ₹300.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-00002 dated 30 May 2026 for Headquarters.\\nTotal: ₹300.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-00002 — Softdigit Consulting"}}	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-29 07:50:17.885+00	2026-05-29 07:50:19.02+00
263a87e0-95ef-4253-8eae-38de1a91a514	purchase-order	714d8e69-25db-490c-af43-8c6168c774d4	PO-5000012	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000012.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE049", "quantity": "1", "lineValue": "₹1,800.00", "unitPrice": "₹1,800.00", "description": "Busbar Copper"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"7a494ea2-2cf1-419c-ba0a-37da9f178b41\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000012", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,800.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000012</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,800.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000012 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,800.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000012 — Softdigit Consulting"}}	2026-06-09 10:07:05.429+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<6c95c7a9-53b8-88f2-ba68-5ccc5d0af373@gmail.com>	2026-06-09 10:06:59.723+00	2026-06-09 10:07:05.431+00
4f5263d8-35d4-43c7-9d6b-ac5f7acb3e36	purchase-order	b433c3de-9c5f-4b45-9579-0e90e669981f	PO-0099	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	PO-0099.pdf	SENT	RESEND	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE002", "quantity": "50", "lineValue": "₹15,000.00", "unitPrice": "₹300.00", "description": "MCB (Miniature Circuit Breaker)"}], "poDate": "27 May 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"department\\":\\"IT\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"53457790-5c18-4f3a-a2d6-709ded27ed4a\\",\\"taxPercent\\":18}],\\"shipToName\\":\\"System Admin\\",\\"shipToCompany\\":\\"Headquarters\\",\\"shipToAddress\\":\\"1 Main Street\\",\\"shipToPhone\\":\\"+0000000000\\",\\"contactName\\":\\"System Admin\\",\\"contactPhone\\":\\"+0000000000\\",\\"contactEmail\\":\\"hq@retailims.local\\"}-->", "poNumber": "PO-0099", "shopName": "Headquarters", "totalValue": "₹15,000.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-0099</strong> dated 27 May 2026 for Headquarters.</p><p>Total: ₹15,000.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-0099 dated 27 May 2026 for Headquarters.\\nTotal: ₹15,000.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-0099 — Softdigit Consulting"}}	2026-05-29 09:00:28.853+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<1db99490-a26d-a7ce-16c5-9394499aaa24@gmail.com>	2026-05-29 09:00:22.617+00	2026-05-29 09:00:28.854+00
899e15a0-e520-4391-965a-d4f57abb1794	purchase-order	eaafa0b8-8e26-4636-9e0b-1039689f82a6	PO-5000013	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000013.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-PL003", "quantity": "1", "lineValue": "₹100.00", "unitPrice": "₹100.00", "description": "Service line (PO)"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"96718ee2-4ff3-4de9-bf6f-7bc023e8338f\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000013", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹100.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000013</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹100.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000013 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹100.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000013 — Softdigit Consulting"}}	2026-06-09 10:10:55.777+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<47f0584e-569c-e9ba-a2d4-fcc9844a62fb@gmail.com>	2026-06-09 10:10:49.4+00	2026-06-09 10:10:55.778+00
439d6af5-6ab8-4eab-b417-ba8cec188c30	purchase-order	9205e8da-e7d2-41cb-9ccd-98944f0f34e9	PO-HQ001-202605-00009	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	PO-HQ001-202605-00009.pdf	SENT	RESEND	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-HQ001", "quantity": "1", "lineValue": "₹100.00", "unitPrice": "₹100.00", "description": "Service line (PO)"}], "poDate": "28 May 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipToName\\":\\"System Admin\\",\\"shipToCompany\\":\\"Headquarters\\",\\"shipToAddress\\":\\"1 Main Street\\",\\"shipToPhone\\":\\"+0000000000\\",\\"contactName\\":\\"System Admin\\",\\"contactPhone\\":\\"+0000000000\\",\\"contactEmail\\":\\"hq@retailims.local\\"}-->", "poNumber": "PO-HQ001-202605-00009", "shopName": "Headquarters", "totalValue": "₹100.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-HQ001-202605-00009</strong> dated 28 May 2026 for Headquarters.</p><p>Total: ₹100.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-HQ001-202605-00009 dated 28 May 2026 for Headquarters.\\nTotal: ₹100.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-HQ001-202605-00009 — Softdigit Consulting"}}	2026-05-29 11:26:15.901+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<9b166255-3aa2-9219-e045-5fdf4b33201f@gmail.com>	2026-05-29 11:26:08.039+00	2026-05-29 11:26:15.902+00
4e1579d4-32c1-4d7b-a344-1b1b5d98d3f2	purchase-order	17904c2f-5358-489d-8f81-b2945ca9f79a	PO-00003	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	PO-00003.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "AUT001", "quantity": "3", "lineValue": "₹3,00,000.00", "unitPrice": "₹1,00,000.00", "description": "Diesel Engine"}], "poDate": "30 May 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"1f99fcd4-52c2-4c2c-a79d-132838abe2d0\\",\\"taxPercent\\":17.99}],\\"shipToName\\":\\"System Admin\\",\\"shipToCompany\\":\\"Headquarters\\",\\"shipToAddress\\":\\"1 Main Street\\",\\"shipToPhone\\":\\"+0000000000\\",\\"contactName\\":\\"System Admin\\",\\"contactPhone\\":\\"+0000000000\\",\\"contactEmail\\":\\"hq@retailims.local\\"}-->", "poNumber": "PO-00003", "shopName": "Headquarters", "totalValue": "₹3,00,000.00", "companyName": "Softdigit Consulting", "supplierName": "PowerDrive Engines"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello PowerDrive Engines,</p><p>Please find purchase order <strong>PO-00003</strong> dated 30 May 2026 for Headquarters.</p><p>Total: ₹3,00,000.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello PowerDrive Engines,\\n\\nPlease find purchase order PO-00003 dated 30 May 2026 for Headquarters.\\nTotal: ₹3,00,000.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-00003 — Softdigit Consulting"}}	2026-05-30 04:16:06.6+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<800acb04-5870-f93b-5c4b-ef2c56402387@gmail.com>	2026-05-30 04:16:01.377+00	2026-05-30 04:16:06.601+00
aa34482a-d895-4afa-8a8f-fdcf694a673b	goods-receipt	bd3940c3-fefd-4511-bd92-552eeff4740f	GR-00001	goods_receipt_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	GR-00001.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "goods-receipt", "content": {"grDate": "30 May 2026", "grNumber": "GR-00001", "poNumber": "PO-00003", "shopName": "Headquarters", "companyName": "Softdigit Consulting", "totalAmount": "₹1,50,000.00", "supplierName": "PowerDrive Engines"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Notification</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello PowerDrive Engines,</p><p>Goods receipt <strong>GR-00001</strong> dated 30 May 2026 has been posted for Headquarters.</p><p>Purchase order: PO-00003<br/>Total: ₹1,50,000.00</p><p>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello PowerDrive Engines,\\n\\nGoods receipt GR-00001 dated 30 May 2026 has been posted for Headquarters.\\nPurchase order: PO-00003\\nTotal: ₹1,50,000.00\\n\\nSoftdigit Consulting", "enabled": true, "subject": "Goods Receipt GR-00001 — Softdigit Consulting"}}	2026-05-30 04:26:57.5+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<3e93af72-3ec3-c2b1-1aff-5d0705c1c2a8@gmail.com>	2026-05-30 04:26:52.393+00	2026-05-30 04:26:57.501+00
d11e66df-20db-4427-8725-d859b2a6ba6e	purchase-order	93ae57bd-78e2-44cc-bfce-eaf421970398	PO-00005	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	PO-00005.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE050", "quantity": "1", "lineValue": "₹1,450.00", "unitPrice": "₹1,450.00", "description": "Power Capacitor"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"f9865733-a9f7-44f6-a031-9c3925042cea\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"System Admin\\",\\"shipToCompany\\":\\"Headquarters\\",\\"shipToAddress\\":\\"1 Main Street\\",\\"shipToPhone\\":\\"+0000000000\\",\\"contactName\\":\\"System Admin\\",\\"contactPhone\\":\\"+0000000000\\",\\"contactEmail\\":\\"hq@retailims.local\\"}-->", "poNumber": "PO-00005", "shopName": "Headquarters", "totalValue": "₹1,450.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-00005</strong> dated 09 Jun 2026 for Headquarters.</p><p>Total: ₹1,450.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-00005 dated 09 Jun 2026 for Headquarters.\\nTotal: ₹1,450.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-00005 — Softdigit Consulting"}}	2026-06-09 17:16:10.29+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<55af0819-3a8d-fbf3-2d67-4320cfd562bb@gmail.com>	2026-06-09 17:16:03.91+00	2026-06-09 17:16:10.291+00
63a50a32-f5f2-4459-8d9c-da180df5e51a	goods-receipt	345870ff-1253-4b69-9a2a-9a9648742362	GR-00002	goods_receipt_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	GR-00002.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "goods-receipt", "content": {"grDate": "30 May 2026", "grNumber": "GR-00002", "poNumber": "PO-00002", "shopName": "Headquarters", "companyName": "Softdigit Consulting", "totalAmount": "₹450.00", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Notification</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Goods receipt <strong>GR-00002</strong> dated 30 May 2026 has been posted for Headquarters.</p><p>Purchase order: PO-00002<br/>Total: ₹450.00</p><p>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nGoods receipt GR-00002 dated 30 May 2026 has been posted for Headquarters.\\nPurchase order: PO-00002\\nTotal: ₹450.00\\n\\nSoftdigit Consulting", "enabled": true, "subject": "Goods Receipt GR-00002 — Softdigit Consulting"}}	2026-05-30 05:30:30.365+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<1c53c01b-1dc1-4090-adcf-8e888f4c42f2@gmail.com>	2026-05-30 05:30:25.475+00	2026-05-30 05:30:30.366+00
5c4c32fe-6eaa-4c1e-99f6-a91a2a27317b	sales-quotation	3ad198fd-f636-4f80-b9b8-96d64788d70e	QT-00001	sales_quotation_customer	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	gstharunadhithya08@gmail.com	QT-00001.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "sales-quotation", "content": {"lines": [{"uom": "pcs", "code": "ELE050", "quantity": "10", "lineValue": "₹18,500.00", "unitPrice": "₹1,850.00", "description": "Power Capacitor"}, {"uom": "pcs", "code": "ELE049", "quantity": "10", "lineValue": "₹23,000.00", "unitPrice": "₹2,300.00", "description": "Busbar Copper"}, {"uom": "pcs", "code": "ELE048", "quantity": "10", "lineValue": "₹40,000.00", "unitPrice": "₹4,000.00", "description": "Lightning Arrester"}, {"uom": "pcs", "code": "ELE047", "quantity": "10", "lineValue": "₹5,800.00", "unitPrice": "₹580.00", "description": "Earth Rod"}, {"uom": "pcs", "code": "ELE046", "quantity": "10", "lineValue": "₹8,500.00", "unitPrice": "₹850.00", "description": "Cable Tray"}, {"uom": "pcs", "code": "ELE045", "quantity": "10", "lineValue": "₹2,400.00", "unitPrice": "₹240.00", "description": "Flexible Conduit"}, {"uom": "pcs", "code": "ELE045", "quantity": "10", "lineValue": "₹2,400.00", "unitPrice": "₹240.00", "description": "Flexible Conduit"}, {"uom": "pcs", "code": "ELE044", "quantity": "10", "lineValue": "₹12,500.00", "unitPrice": "₹1,250.00", "description": "Control Transformer"}, {"uom": "pcs", "code": "ELE043", "quantity": "10", "lineValue": "₹1,200.00", "unitPrice": "₹120.00", "description": "Selector Switch"}, {"uom": "pcs", "code": "ELE042", "quantity": "10", "lineValue": "₹6,200.00", "unitPrice": "₹620.00", "description": "Timer Switch"}], "remarks": null, "shopName": "Headquarters", "portalUrl": "https://softdigitconsulting.com/quotation-portal/review?token=13fc98188031536a84363a26eb509e16ccaac70304592ae52ba19b9eb3f420be", "quoteDate": "30 May 2026", "isRevision": false, "totalValue": "₹1,20,500.00", "validUntil": "02 Jun 2026", "companyName": "Softdigit Consulting", "quoteNumber": "QT-00001", "customerName": "Green City Apartments"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Sales Quotation</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Dear Green City Apartments,</p><p>Please find quotation <strong>QT-00001</strong> dated 30 May 2026.</p><p>Valid until: 02 Jun 2026<br/>Total: ₹1,20,500.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Dear Green City Apartments,\\n\\nPlease find quotation QT-00001 dated 30 May 2026.\\nValid until: 02 Jun 2026\\nTotal: ₹1,20,500.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Sales Quotation QT-00001 — Softdigit Consulting"}}	2026-05-30 07:49:46.611+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<66c707c7-3266-1214-aed6-c64ad9109684@gmail.com>	2026-05-30 07:49:37.166+00	2026-05-30 07:49:46.612+00
c48a6509-1d9c-4dd3-a6a3-bf6c551d6d2a	sales-order	69b227da-8e82-4bf9-b4a8-b17c47d559e0	SO-00001	sales_order_customer	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	gstharunadhithya08@gmail.com	SO-00001.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "sales-order", "content": {"shopName": "Headquarters", "soNumber": "SO-00001", "orderDate": "30 May 2026", "companyName": "Softdigit Consulting", "totalAmount": "$1,20,500.00", "customerName": "Green City Apartments", "expectedDate": "—"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Notification</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Dear Green City Apartments,</p><p>Please find sales order <strong>SO-00001</strong> dated 30 May 2026.</p><p>Expected date: —<br/>Plant: Headquarters<br/>Total: $1,20,500.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Dear Green City Apartments,\\n\\nPlease find sales order SO-00001 dated 30 May 2026.\\nExpected date: —\\nPlant: Headquarters\\nTotal: $1,20,500.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Sales Order SO-00001 — Softdigit Consulting"}}	2026-05-30 07:54:02.807+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<25e1a6b2-66ff-b7fb-de75-3d6c5db9d59c@gmail.com>	2026-05-30 07:53:57.668+00	2026-05-30 07:54:02.808+00
80b7938b-ccb0-4d8c-92e1-ead9dc5ca47c	goods-receipt	9dbceae8-fc02-403b-8b8c-3cd7c6513498	GR-00003	goods_receipt_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	GR-00003.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "goods-receipt", "content": {"grDate": "30 May 2026", "grNumber": "GR-00003", "poNumber": "PO-00004", "shopName": "Headquarters", "companyName": "Softdigit Consulting", "totalAmount": "₹37,600.00", "supplierName": "Bright Power Distributors"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Notification</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Bright Power Distributors,</p><p>Goods receipt <strong>GR-00003</strong> dated 30 May 2026 has been posted for Headquarters.</p><p>Purchase order: PO-00004<br/>Total: ₹37,600.00</p><p>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Bright Power Distributors,\\n\\nGoods receipt GR-00003 dated 30 May 2026 has been posted for Headquarters.\\nPurchase order: PO-00004\\nTotal: ₹37,600.00\\n\\nSoftdigit Consulting", "enabled": true, "subject": "Goods Receipt GR-00003 — Softdigit Consulting"}}	2026-05-30 10:06:13.259+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<62531cb2-1efc-e625-2297-f3d619f27b7d@gmail.com>	2026-05-30 10:06:06.981+00	2026-05-30 10:06:13.26+00
b202ecc7-2cca-4dd6-913e-34546fc571b6	purchase-order	748dd9cf-1fdd-4f95-840d-22ab88262a03	PO-5000001	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	gstharunadhithya08@gmail.com	PO-5000001.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE049", "quantity": "6", "lineValue": "₹10,800.00", "unitPrice": "₹1,800.00", "description": "Busbar Copper"}], "poDate": "08 Jun 2026", "remarks": "fsddsds\\n<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"department\\":\\"Operations\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"7a494ea2-2cf1-419c-ba0a-37da9f178b41\\",\\"taxPercent\\":9}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000001", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹10,800.00", "companyName": "Softdigit Consulting", "supplierName": "Bharat Electricals Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Bharat Electricals Supply,</p><p>Please find purchase order <strong>PO-5000001</strong> dated 08 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹10,800.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Bharat Electricals Supply,\\n\\nPlease find purchase order PO-5000001 dated 08 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹10,800.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000001 — Softdigit Consulting"}}	2026-06-08 17:46:18.379+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<6469737f-996e-97da-fd70-d3c1d253128b@gmail.com>	2026-06-08 17:46:13.779+00	2026-06-08 17:46:18.38+00
d8288480-9851-4db7-9123-3265b5f93796	purchase-order	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	PO-5000000	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	gstharunadhithya08@gmail.com	PO-5000000.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE050", "quantity": "10", "lineValue": "₹14,500.00", "unitPrice": "₹1,450.00", "description": "Power Capacitor"}], "poDate": "08 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"department\\":\\"Warehouse\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipVia\\":\\"UPS — Ground / 2-Day / Next Day Air\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"f9865733-a9f7-44f6-a031-9c3925042cea\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000000", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹14,500.00", "companyName": "Softdigit Consulting", "supplierName": "Bharat Electricals Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Bharat Electricals Supply,</p><p>Please find purchase order <strong>PO-5000000</strong> dated 08 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹14,500.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Bharat Electricals Supply,\\n\\nPlease find purchase order PO-5000000 dated 08 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹14,500.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000000 — Softdigit Consulting"}}	2026-06-08 17:42:13.482+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<80fa8ee1-bf6f-aaba-c803-a6d8b941b61b@gmail.com>	2026-06-08 17:42:07.868+00	2026-06-08 17:42:13.483+00
eb36ed1e-f8ef-4bb3-8675-ae1b94440ac1	purchase-order	05ae51ad-18be-4ee5-bafe-8c658db0eb89	PO-5000002	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000002.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "AUT001", "quantity": "12", "lineValue": "₹6,00,000.00", "unitPrice": "₹50,000.00", "description": "Diesel Engine"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipVia\\":\\"USPS — Priority Mail / First Class\\",\\"fob\\":\\"FOB Origin, Freight Collect\\",\\"shippingTerms\\":\\"Prepaid — Seller pays freight\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"1f99fcd4-52c2-4c2c-a79d-132838abe2d0\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000002", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹6,00,000.00", "companyName": "Softdigit Consulting", "supplierName": "PowerDrive Engines"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello PowerDrive Engines,</p><p>Please find purchase order <strong>PO-5000002</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹6,00,000.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello PowerDrive Engines,\\n\\nPlease find purchase order PO-5000002 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹6,00,000.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000002 — Softdigit Consulting"}}	2026-06-09 01:47:40.556+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<fdaaf5cf-8028-fe16-ae13-979b389b0d25@gmail.com>	2026-06-09 01:47:33.999+00	2026-06-09 01:47:40.556+00
3110da4f-a550-4ce3-8b57-3dcec142cad8	purchase-order	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	PO-5000003	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000003.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-PL003", "quantity": "1", "lineValue": "₹1,200.00", "unitPrice": "₹1,200.00", "description": "Service line (PO)"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipVia\\":\\"DHL — Domestic & international express\\",\\"fob\\":\\"FOB Origin, Freight Prepaid\\",\\"shippingTerms\\":\\"Prepaid & Add — Seller pays, invoices buyer\\",\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000003", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,200.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000003</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,200.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000003 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,200.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000003 — Softdigit Consulting"}}	2026-06-09 02:06:32.511+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<66547802-c617-1492-b6c8-07a6152d754d@gmail.com>	2026-06-09 02:06:26.532+00	2026-06-09 02:06:32.513+00
d6a65af0-98ea-48ab-8903-932059010214	goods-receipt	408aea7a-6b67-4fab-af46-3321ed698642	GR-00005	goods_receipt_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	GR-00005.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "goods-receipt", "content": {"grDate": "09 Jun 2026", "grNumber": "GR-00005", "poNumber": "—", "shopName": "Headquarters", "companyName": "Softdigit Consulting", "totalAmount": "₹9,500.00", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Notification</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Goods receipt <strong>GR-00005</strong> dated 09 Jun 2026 has been posted for Headquarters.</p><p>Purchase order: —<br/>Total: ₹9,500.00</p><p>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nGoods receipt GR-00005 dated 09 Jun 2026 has been posted for Headquarters.\\nPurchase order: —\\nTotal: ₹9,500.00\\n\\nSoftdigit Consulting", "enabled": true, "subject": "Goods Receipt GR-00005 — Softdigit Consulting"}}	2026-06-09 05:23:16.731+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<870c5bd6-4cd5-8e35-b313-c424280b9293@gmail.com>	2026-06-09 05:23:12.803+00	2026-06-09 05:23:16.733+00
26327df1-fb63-4fc1-9466-37be65872ac3	purchase-order	245324eb-1995-4571-963a-8c776fcd047e	PO-5000004	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000004.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-PL003", "quantity": "1", "lineValue": "₹1,000.00", "unitPrice": "₹1,000.00", "description": "Service line (PO)"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"96718ee2-4ff3-4de9-bf6f-7bc023e8338f\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000004", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,000.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000004</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,000.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000004 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,000.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000004 — Softdigit Consulting"}}	2026-06-09 03:52:04.352+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<78704f3b-ee67-9a55-8620-5b8dec64b14f@gmail.com>	2026-06-09 03:51:57.972+00	2026-06-09 03:52:04.354+00
83f909d2-64d6-4878-a5dc-d8c4038a8c67	purchase-order	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	PO-5000005	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000005.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-PL003", "quantity": "1", "lineValue": "₹1,200.00", "unitPrice": "₹1,200.00", "description": "Service line (PO)"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000005", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,200.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000005</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,200.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000005 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,200.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000005 — Softdigit Consulting"}}	2026-06-09 04:15:53.306+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<2189b293-2d8f-2f18-eb8f-4ee6324db2b9@gmail.com>	2026-06-09 04:15:47.356+00	2026-06-09 04:15:53.307+00
3ca36bc2-289c-49fa-83f1-49a18b82920b	purchase-order	2325cf74-910a-4065-9a29-e9c5c9b9bb38	PO-5000006	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000006.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-PL003", "quantity": "1", "lineValue": "₹19,000.00", "unitPrice": "₹19,000.00", "description": "Service line (PO)"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000006", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹19,000.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000006</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹19,000.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000006 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹19,000.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000006 — Softdigit Consulting"}}	2026-06-09 04:50:32.75+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<a63de025-7972-7e22-c594-0231353d8fd0@gmail.com>	2026-06-09 04:50:28.732+00	2026-06-09 04:50:32.751+00
620e45ac-f7fe-48bd-a17d-4860b26f58f8	purchase-order	f1732149-a034-4689-ad21-901760bba457	PO-5000007	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000007.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE050", "quantity": "1", "lineValue": "₹1,450.00", "unitPrice": "₹1,450.00", "description": "Power Capacitor"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"f9865733-a9f7-44f6-a031-9c3925042cea\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000007", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,450.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000007</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,450.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000007 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,450.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000007 — Softdigit Consulting"}}	2026-06-09 05:02:24.429+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<129819c4-6940-8a5d-ad43-18fff500bb1d@gmail.com>	2026-06-09 05:02:19.973+00	2026-06-09 05:02:24.43+00
5493081f-9c00-4f74-b50e-a6271f3d1884	purchase-order	e62b76c6-23ef-4d71-ba48-9d10ae494065	PO-5000008	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000008.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "SVC-PL003", "quantity": "1", "lineValue": "₹1,800.00", "unitPrice": "₹1,800.00", "description": "Service line (PO)"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000008", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,800.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000008</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,800.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000008 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,800.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000008 — Softdigit Consulting"}}	2026-06-09 05:12:41.544+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<665675ca-56f9-45ce-8370-9239a1f840e3@gmail.com>	2026-06-09 05:12:37.242+00	2026-06-09 05:12:41.545+00
93f148f4-c8b3-4cd6-8c5f-75c61dd66505	goods-receipt	265ba202-982a-4bfa-bbd6-51ea0bff27e8	GR-00004	goods_receipt_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	GR-00004.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "goods-receipt", "content": {"grDate": "09 Jun 2026", "grNumber": "GR-00004", "poNumber": "—", "shopName": "Headquarters", "companyName": "Softdigit Consulting", "totalAmount": "₹17,100.00", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Notification</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Goods receipt <strong>GR-00004</strong> dated 09 Jun 2026 has been posted for Headquarters.</p><p>Purchase order: —<br/>Total: ₹17,100.00</p><p>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nGoods receipt GR-00004 dated 09 Jun 2026 has been posted for Headquarters.\\nPurchase order: —\\nTotal: ₹17,100.00\\n\\nSoftdigit Consulting", "enabled": true, "subject": "Goods Receipt GR-00004 — Softdigit Consulting"}}	2026-06-09 05:20:06.653+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<ab672fe0-f265-2fdb-9564-c7f89da753b3@gmail.com>	2026-06-09 05:20:02.513+00	2026-06-09 05:20:06.654+00
caf50cb0-5e00-4591-b6bc-52fffa497f2f	goods-return	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	RMO-00001	supplier_return_notice	582b08bd-2a7a-475b-84c2-e4ef8f834a83	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	kolandasamy.sss@gmail.com	RMO-00001.pdf	SENT	AUTO	1	0	\N	\N	{"kind": "goods-return", "content": {"lines": [{"code": "ELE044", "reason": "Excess", "imageCount": 1, "description": "Control Transformer", "grnQuantity": "10", "returnQuantity": "5"}], "remarks": null, "grNumber": "GR-00005", "shopName": "Headquarters", "returnDate": "09 Jun 2026", "companyName": "Softdigit Consulting", "supplierRef": null, "returnNumber": "RMO-00001", "supplierName": "Heaven Electrical Supply", "acknowledgementUrl": "https://softdigitconsulting.com/returns/acknowledge?token=cd526b9bdc5dc96c8a9732f2e441c46cf3548f5369f592d3"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Goods Return</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>A goods return <strong>RMO-00001</strong> has been submitted against GR GR-00005.</p><p>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nA goods return RMO-00001 has been submitted against GR GR-00005.\\n\\nSoftdigit Consulting", "enabled": true, "subject": "Goods Return RMO-00001 — Softdigit Consulting"}}	2026-06-09 05:25:44.065+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<49956894-6f36-c284-9cf6-81f5bb03c960@gmail.com>	2026-06-09 05:25:38.561+00	2026-06-09 05:25:44.066+00
2bfb26be-cc7c-487a-9e77-6177413a9902	purchase-order	6a65724c-dc91-465a-ba9e-e79e7d88234c	PO-5000009	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000009.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE050", "quantity": "1", "lineValue": "₹1,450.00", "unitPrice": "₹1,450.00", "description": "Power Capacitor"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"f9865733-a9f7-44f6-a031-9c3925042cea\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000009", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹1,450.00", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000009</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹1,450.00</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000009 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹1,450.00\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000009 — Softdigit Consulting"}}	2026-06-09 05:39:34.848+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<9cb8e7cd-0f3c-270a-1423-ec542fe5a236@gmail.com>	2026-06-09 05:39:30.37+00	2026-06-09 05:39:34.849+00
cc7add37-d801-4793-91fa-e8d35ffd9196	purchase-order	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	PO-5000010	purchase_order_supplier	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	kolandasamy.sss@gmail.com	PO-5000010.pdf	SENT	MANUAL	1	0	\N	\N	{"kind": "purchase-order", "content": {"lines": [{"uom": "UNIT", "code": "ELE045", "quantity": "1", "lineValue": "₹180.26", "unitPrice": "₹180.26", "description": "Flexible Conduit"}], "poDate": "09 Jun 2026", "remarks": "<!--PO_DOCUMENT:{\\"requisitioner\\":\\"Owner\\",\\"paymentTerms\\":\\"Net 30\\",\\"lineItemTaxes\\":[{\\"productId\\":\\"2d8107ad-f2ff-4862-b269-9b274a65b530\\",\\"taxPercent\\":0}],\\"shipToName\\":\\"Kolandasamy\\",\\"shipToCompany\\":\\"Automobile Manafac. plant chennai\\",\\"shipToAddress\\":\\"chennai\\",\\"shipToPhone\\":\\"9677878824\\",\\"contactName\\":\\"Kolandasamy\\",\\"contactPhone\\":\\"9677878824\\",\\"contactEmail\\":\\"kolandasamy.sss@gmail.com\\"}-->", "poNumber": "PO-5000010", "shopName": "Automobile Manafac. plant chennai", "totalValue": "₹180.26", "companyName": "Softdigit Consulting", "supplierName": "Heaven Electrical Supply"}, "overrides": {"cc": [], "bcc": [], "html": "<!DOCTYPE html>\\n<html>\\n<head>\\n  <meta name=\\"color-scheme\\" content=\\"light dark\\" />\\n  <meta name=\\"supported-color-schemes\\" content=\\"light dark\\" />\\n  <style>\\n    @media (prefers-color-scheme: dark) {\\n      .email-bg { background: #0f172a !important; }\\n      .email-card { background: #1e293b !important; }\\n      .email-body-text { color: #cbd5e1 !important; }\\n      .email-muted { color: #94a3b8 !important; }\\n    }\\n  </style>\\n</head>\\n<body style=\\"margin:0;padding:0;background:#f1f5f9;font-family:Segoe UI,Helvetica,Arial,sans-serif;\\" class=\\"email-bg\\">\\n  <table width=\\"100%\\" cellpadding=\\"0\\" cellspacing=\\"0\\" style=\\"background:#f1f5f9;padding:32px 16px;\\" class=\\"email-bg\\">\\n    <tr>\\n      <td align=\\"center\\">\\n        <table width=\\"100%\\" style=\\"max-width:520px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.08);\\" class=\\"email-card\\">\\n          <tr>\\n            <td style=\\"background:linear-gradient(135deg,#312e81,#4338ca);padding:24px 28px;\\">\\n              <p style=\\"margin:0;font-size:12px;color:#c7d2fe;letter-spacing:0.08em;text-transform:uppercase;\\">Retail IMS</p>\\n              <h1 style=\\"margin:8px 0 0;font-size:22px;color:#ffffff;font-weight:700;\\">Purchase Order</h1>\\n              <p style=\\"margin:6px 0 0;font-size:14px;color:#c7d2fe;\\">Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n          <tr>\\n            <td style=\\"padding:24px 28px;\\" class=\\"email-body-text\\">\\n              <p>Hello Heaven Electrical Supply,</p><p>Please find purchase order <strong>PO-5000010</strong> dated 09 Jun 2026 for Automobile Manafac. plant chennai.</p><p>Total: ₹180.26</p><p>Thank you,<br/>Softdigit Consulting</p>\\n            </td>\\n          </tr>\\n        </table>\\n      </td>\\n    </tr>\\n  </table>\\n</body>\\n</html>", "text": "Hello Heaven Electrical Supply,\\n\\nPlease find purchase order PO-5000010 dated 09 Jun 2026 for Automobile Manafac. plant chennai.\\nTotal: ₹180.26\\n\\nThank you,\\nSoftdigit Consulting", "enabled": true, "subject": "Purchase Order PO-5000010 — Softdigit Consulting"}}	2026-06-09 05:44:37.14+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	<28b05a26-fe06-6bc2-57b1-2234e41d6010@gmail.com>	2026-06-09 05:44:33.093+00	2026-06-09 05:44:37.141+00
\.


--
-- Data for Name: document_sequences; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.document_sequences (id, doc_type, shop_id, year_month, last_seq, created_at, updated_at) FROM stdin;
7f3b12f4-823d-4f1b-a654-595c5cc7e998	PO	d53ce4ee-7da6-4709-b944-348687fb0843	202605	4	2026-05-26 12:59:49.075+00	2026-05-26 15:12:23.672+00
ee4835cd-fab1-4d1c-9efa-0f38d691d17b	CUS	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	1	2026-05-26 15:27:01.479+00	2026-05-26 15:27:01.479+00
cbeaf16c-663e-4f64-a3d7-3748ea9e8e07	GR	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	13	2026-05-25 05:28:26.488+00	2026-05-26 16:01:22.018+00
a113f3b9-eef3-4a20-83aa-2ad595399c72	SQT	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	3	2026-05-26 08:20:02.06+00	2026-05-26 16:19:59.602+00
bb47a313-ebdf-4925-8929-51f9051385fa	SO	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	5	2026-05-26 08:25:21.334+00	2026-05-26 16:26:16.296+00
52502403-d88c-423e-a2a1-dcafb1fa4808	GI	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	3	2026-05-26 15:23:12.517+00	2026-05-26 16:28:51.856+00
e5cda986-3498-4b0e-a73d-d180d824fb93	CUS	d53ce4ee-7da6-4709-b944-348687fb0843	202605	1	2026-05-26 16:45:17.269+00	2026-05-26 16:45:17.269+00
bc9f6a3a-de8b-41f4-b42b-40bcecd8e65a	PO	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	9	2026-05-25 05:28:26.481+00	2026-05-27 11:35:08.38+00
69521a91-d553-4e6b-9c41-e0d619a03bfd	CT	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	5	2026-05-25 05:28:26.474+00	2026-05-25 16:16:13.402+00
3ae34b12-8e9c-4735-bce7-60c4123dfa38	GR	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	5	2026-05-30 04:26:35.561+00	2026-06-09 05:23:01.574+00
9efb3837-1472-4194-bb9f-bec1aa692160	SRT	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	1	2026-06-09 05:24:46.879+00	2026-06-09 05:24:46.879+00
aff00e48-edbf-46d0-b427-af3440c713a8	RFQ	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	6	2026-05-25 05:25:07.797+00	2026-05-26 07:40:44.235+00
40801e5d-8540-4d24-9f64-a6aeeeb3aa0b	QUO	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	9	2026-05-25 05:28:12.383+00	2026-05-26 07:45:07.338+00
e34d526c-7d84-4670-a8bc-c4b1bf21ed53	PO	5c1f22f6-978a-43fe-ad41-28359edf08d4	000000	5000013	2026-06-08 17:42:07.835+00	2026-06-09 10:10:49.36+00
51512a43-cd55-416a-a4a3-79bd48aaa8a0	PO	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	5	2026-05-29 07:50:08.357+00	2026-06-09 17:16:03.869+00
90a98ea7-de0b-46d8-8dd9-4f43b2e09d29	GI	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	2	2026-05-30 07:55:42.076+00	2026-06-11 07:05:05.477+00
0838014b-39ca-4fc3-a795-784bd6ddfe75	SRT	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	202605	2	2026-05-25 08:11:53.108+00	2026-05-26 08:29:59.411+00
7a77d95c-3cc1-4a4d-abd2-d25ccae168ff	GR	d53ce4ee-7da6-4709-b944-348687fb0843	202605	1	2026-05-26 13:13:16.229+00	2026-05-26 13:13:16.229+00
52b71441-8ca2-4b94-99e6-c004e80f083e	CUS	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	13	2026-05-30 03:48:55.113+00	2026-05-30 06:53:38.475+00
0551a2aa-958b-4692-a3df-628c4368680c	SQT	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	1	2026-05-30 07:49:29.467+00	2026-05-30 07:49:29.467+00
12f96527-eae4-4b09-a310-3776388195c0	RFQ	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	3	2026-05-29 09:07:27.878+00	2026-05-30 08:19:20.368+00
c1f819b2-184e-4ec7-af0c-066eec6d1fb1	QUO	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	2	2026-05-30 04:04:22.257+00	2026-05-30 08:24:50.462+00
70836bab-8c22-40a3-ba67-2e3ddd0d20f3	SO	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	000000	3	2026-05-30 07:52:59.36+00	2026-06-08 14:20:23.672+00
\.


--
-- Data for Name: document_series_config; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.document_series_config (id, company_id, shop_id, doc_type, module_label, prefix, starting_number, pad_width, restart_period, shop_scoped, enabled, use_category_prefix, created_at, updated_at, created_by, updated_by) FROM stdin;
a5574a2b-f359-4be5-aa48-4b241cf40325	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	PRD	Products	PRD	1	5	NONE	f	t	t	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.617+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
463aa18c-e6ef-4131-992c-56d0fac89af5	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	PRD	Products	PRD	1	5	NONE	f	t	t	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.524+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
81a720f2-9252-482b-af70-569d444307b9	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	CUS	Customers	CUS	3	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.529+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
7ffae396-2fc2-4a16-a4d6-31390691b981	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	RFQ	RFQ	RFQ	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.533+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
26b36af6-2f1a-4626-a61c-e6ca70bc8bed	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	CT	Contracts	CT	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.54+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
6dd3ee69-3290-4933-aeab-748630476b83	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	PO	Purchase Order	PO	5	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.543+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
a577e492-447f-497f-ba16-bee749fa0683	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	GR	Goods Receipt	GR	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.545+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
7bbd8ba4-1b5c-4a60-9918-14a7a8a30735	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	CRT	Goods Return (Customer)	CRT	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.547+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
80948e6d-d2b3-424b-8a4c-37fd2a2f728f	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	SRT	Goods Return (Supplier)	RMO	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.549+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
aa7fd602-14e6-454f-93cd-58eaa1777d90	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	SQT	Sales Quotation	QT	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.552+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
8768b123-888a-4198-9e48-5c70e887d77f	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	SO	Sales Order	SO	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.554+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
c552e1b2-0630-4425-8b94-fb419a48b8aa	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	GI	Goods Issue	GI	1	5	NONE	f	t	f	2026-05-27 10:22:26.327+00	2026-06-09 10:06:45.556+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
fa17ee2c-e4fc-4e7b-ac37-9b6d9a3f0a60	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	CUS	Customers	CUS	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.623+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
bfca0cad-d0f0-4387-aec5-0a816c4cf53a	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	RFQ	RFQ	RFQ	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.627+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
6143d3c4-9125-414f-93d9-4be4b81ca884	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	CT	Contracts	CT	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.629+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
411817db-2593-4f67-b707-e225af5fb0c9	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	PO	Purchase Order	DIRPO	10001	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.634+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
7c978e2a-a191-436e-b01c-99d64648ec65	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	GR	Goods Receipt	GR	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.636+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
eac44a04-8eaf-4de3-8a3b-bca6a7eac626	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	CRT	Goods Return (Customer)	CRT	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.638+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
5d09374a-8a83-4440-8ec5-63c55b1b6692	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	SRT	Goods Return (Supplier)	RMO	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.64+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
b0cb8f13-844b-46e4-ad6c-b5ddf79be6e0	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	SQT	Sales Quotation	QT	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.642+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
815397bd-343f-4652-a929-7bcb7581b6b6	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	SO	Sales Order	SO	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.644+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
fae9b5db-649d-4c34-a037-3e012ecda876	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	GI	Goods Issue	GI	1	5	NONE	f	t	f	2026-05-27 12:39:08.627+00	2026-05-27 12:40:22.646+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587
b025e049-aaa2-4f4e-a692-8081235920ce	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	QUO	Supplier Quotation	QUO	1	5	NONE	f	t	f	2026-05-29 10:19:28.27+00	2026-06-09 10:06:45.536+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
462c8ec1-d048-470b-a774-bb998a86aac2	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	SC	Stock Count	SC	1	5	NONE	f	t	f	2026-06-12 06:11:23.792+00	2026-06-12 06:11:23.792+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
\.


--
-- Data for Name: email_delivery_log; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_delivery_log (id, template_id, entity_type, entity_id, recipient, sent_at, click_count, open_count) FROM stdin;
f787110c-b344-4dfc-8ea0-655693a6373f	purchase_order_supplier	purchase-order	b433c3de-9c5f-4b45-9579-0e90e669981f	kolandasamy.sss@gmail.com	2026-05-29 09:00:28.866+00	0	0
0844393b-19d3-4a63-adb4-dbdaf42314be	purchase_order_supplier	purchase-order	9205e8da-e7d2-41cb-9ccd-98944f0f34e9	kolandasamy.sss@gmail.com	2026-05-29 11:26:15.905+00	0	0
4cee1dbb-7457-4d2c-bd3e-d636680a75c4	purchase_order_supplier	purchase-order	17904c2f-5358-489d-8f81-b2945ca9f79a	kolandasamy.sss@gmail.com	2026-05-30 04:16:06.604+00	0	0
d7131240-c06b-49b3-ae5f-307aceac9a9a	goods_receipt_posted	goods-receipt	bd3940c3-fefd-4511-bd92-552eeff4740f	kolandasamy.sss@gmail.com	2026-05-30 04:26:45.256+00	0	0
346251be-bcb7-4c3a-a868-ce32ff9a235c	goods_receipt_posted	goods-receipt	bd3940c3-fefd-4511-bd92-552eeff4740f	admin@retailims.com	2026-05-30 04:26:48.803+00	0	0
8904a09e-d63e-4fed-9ec3-3aaf1bba34f2	goods_receipt_posted	goods-receipt	bd3940c3-fefd-4511-bd92-552eeff4740f	hq@retailims.local	2026-05-30 04:26:52.384+00	0	0
62ba5945-54e2-4854-9c6a-8394487b58ba	goods_receipt_supplier	goods-receipt	bd3940c3-fefd-4511-bd92-552eeff4740f	kolandasamy.sss@gmail.com	2026-05-30 04:26:57.504+00	0	0
4056df68-9191-41c2-a72b-f765f06c55c4	goods_receipt_posted	goods-receipt	345870ff-1253-4b69-9a2a-9a9648742362	kolandasamy.sss@gmail.com	2026-05-30 05:30:17.65+00	0	0
bfa37316-2d80-4446-aa1e-611be920e01f	goods_receipt_posted	goods-receipt	345870ff-1253-4b69-9a2a-9a9648742362	admin@retailims.com	2026-05-30 05:30:21.603+00	0	0
0b3f0dac-d2f3-406a-acc3-6311bb8c3d81	goods_receipt_posted	goods-receipt	345870ff-1253-4b69-9a2a-9a9648742362	hq@retailims.local	2026-05-30 05:30:25.467+00	0	0
3b256b00-2b43-4626-b895-f29dc97ffd32	goods_receipt_supplier	goods-receipt	345870ff-1253-4b69-9a2a-9a9648742362	kolandasamy.sss@gmail.com	2026-05-30 05:30:30.369+00	0	0
df9bafc6-4022-4902-861f-53e5dfe8b211	sales_quotation_customer	sales-quotation	3ad198fd-f636-4f80-b9b8-96d64788d70e	gstharunadhithya08@gmail.com	2026-05-30 07:49:46.614+00	0	0
b8134036-2cc9-4880-85be-21d2b931dace	sales_order_customer	sales-order	69b227da-8e82-4bf9-b4a8-b17c47d559e0	gstharunadhithya08@gmail.com	2026-05-30 07:54:02.811+00	0	0
ac67a687-6ac0-4132-a60b-5beb9e26cce7	goods_receipt_posted	goods-receipt	9dbceae8-fc02-403b-8b8c-3cd7c6513498	kolandasamy.sss@gmail.com	2026-05-30 10:05:58.074+00	0	0
af222c74-d7a6-47ef-ab4b-80cb76d6005d	goods_receipt_posted	goods-receipt	9dbceae8-fc02-403b-8b8c-3cd7c6513498	admin@retailims.com	2026-05-30 10:06:02.56+00	0	0
d02df7a7-84d4-42ff-bcd2-ec74297cad4f	goods_receipt_posted	goods-receipt	9dbceae8-fc02-403b-8b8c-3cd7c6513498	hq@retailims.local	2026-05-30 10:06:06.767+00	0	0
66e38404-ad5d-4acb-a513-1047792c8206	goods_receipt_supplier	goods-receipt	9dbceae8-fc02-403b-8b8c-3cd7c6513498	kolandasamy.sss@gmail.com	2026-05-30 10:06:13.266+00	0	0
a2ea5f19-b8f0-42de-85ea-94a2798789e0	platform_trial_welcome	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-05-31 03:18:02.583+00	0	0
4d480036-b6be-4038-83bb-3c5c81ff9e5e	platform_trial_edu_inventory	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-05-31 09:00:02.816+00	0	0
31959420-1514-46da-b7fb-7b799c972f9f	platform_trial_edu_purchase	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-05-31 09:00:03.444+00	0	0
a81f3858-46ec-463f-9f43-5594de47dec1	platform_trial_edu_reports	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-05-31 09:00:04.371+00	0	0
fa6c1eea-2563-41a5-98ef-a85e37b5c4d4	platform_trial_expiry_7	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-05-31 09:00:04.828+00	0	0
5fe529f4-6350-4a46-b3d5-7e2fb37d7cde	platform_trial_day_1	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-01 09:00:02.661+00	0	0
cdb8a97c-c6e5-4b3c-8144-f267fbec455c	platform_trial_day_3	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-03 09:00:03.094+00	0	0
9e57502e-f534-4d34-a0be-0cdc19a5e217	platform_trial_expiry_3	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-04 09:00:03.091+00	0	0
7039eacc-d4db-4e53-9e35-4e5616b075fd	platform_trial_expiry_1	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-06 09:00:03.404+00	0	0
4b978266-2dc7-40f5-9501-dfa3686c8184	platform_trial_expired_day_0	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-07 09:00:02.936+00	0	0
33cb10e5-3694-415c-8546-96575a1d2082	platform_trial_day_7	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-07 09:00:03.474+00	0	0
7ad1188a-ee38-421a-91fa-f310a42543fb	platform_trial_inactive_7d	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-07 09:00:03.978+00	0	0
1e82ea25-3612-43a5-b1fb-b2dd67358ce7	purchase_order_supplier	purchase-order	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	gstharunadhithya08@gmail.com	2026-06-08 17:42:13.486+00	0	0
d7686929-ee14-49a2-981e-25acfbf1df2a	purchase_order_supplier	purchase-order	748dd9cf-1fdd-4f95-840d-22ab88262a03	gstharunadhithya08@gmail.com	2026-06-08 17:46:18.384+00	0	0
b8ebc4c4-fec7-4394-8c39-9e5cb0423fe6	purchase_order_supplier	purchase-order	05ae51ad-18be-4ee5-bafe-8c658db0eb89	kolandasamy.sss@gmail.com	2026-06-09 01:47:40.559+00	0	0
b1050b1d-06e1-42d3-aeea-7896f2a40d5d	purchase_order_supplier	purchase-order	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	kolandasamy.sss@gmail.com	2026-06-09 02:06:32.52+00	0	0
f66de182-52b2-4245-9229-effcea6992f9	purchase_order_supplier	purchase-order	245324eb-1995-4571-963a-8c776fcd047e	kolandasamy.sss@gmail.com	2026-06-09 03:52:04.359+00	0	0
8f715829-7374-4546-a1dc-77059e8d52e5	purchase_order_supplier	purchase-order	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	kolandasamy.sss@gmail.com	2026-06-09 04:15:53.31+00	0	0
4ffbb813-f9ae-4abf-97e8-b064c977deb9	purchase_order_supplier	purchase-order	2325cf74-910a-4065-9a29-e9c5c9b9bb38	kolandasamy.sss@gmail.com	2026-06-09 04:50:32.754+00	0	0
12e4cb6b-85f3-49c0-888e-bee13290aa02	purchase_order_supplier	purchase-order	f1732149-a034-4689-ad21-901760bba457	kolandasamy.sss@gmail.com	2026-06-09 05:02:24.433+00	0	0
7843967b-f71b-447b-bad0-1fb3eedf7807	purchase_order_supplier	purchase-order	e62b76c6-23ef-4d71-ba48-9d10ae494065	kolandasamy.sss@gmail.com	2026-06-09 05:12:41.548+00	0	0
8893e9db-bca4-4ccc-a314-1712c707c792	goods_receipt_posted	goods-receipt	265ba202-982a-4bfa-bbd6-51ea0bff27e8	kolandasamy.sss@gmail.com	2026-06-09 05:19:54.778+00	0	0
3e2e112c-7b70-4610-a0aa-c5c47cd51b54	goods_receipt_posted	goods-receipt	265ba202-982a-4bfa-bbd6-51ea0bff27e8	admin@retailims.com	2026-06-09 05:19:58.511+00	0	0
d89cf952-61e9-4e20-a172-3e11d7f3c89f	goods_receipt_posted	goods-receipt	265ba202-982a-4bfa-bbd6-51ea0bff27e8	hq@retailims.local	2026-06-09 05:20:02.503+00	0	0
470c2f0a-a52c-4c26-ae93-17b23eed7bde	goods_receipt_supplier	goods-receipt	265ba202-982a-4bfa-bbd6-51ea0bff27e8	kolandasamy.sss@gmail.com	2026-06-09 05:20:06.657+00	0	0
49cdbf6d-f25c-417b-9e10-109949788847	goods_receipt_posted	goods-receipt	408aea7a-6b67-4fab-af46-3321ed698642	kolandasamy.sss@gmail.com	2026-06-09 05:23:05.709+00	0	0
03c5bc2a-fd57-4185-988e-f917fc52baba	goods_receipt_posted	goods-receipt	408aea7a-6b67-4fab-af46-3321ed698642	admin@retailims.com	2026-06-09 05:23:09.27+00	0	0
f3a5c784-294e-4396-87c9-0d540bc58e75	goods_receipt_posted	goods-receipt	408aea7a-6b67-4fab-af46-3321ed698642	hq@retailims.local	2026-06-09 05:23:12.794+00	0	0
1067bfe1-d1d7-4b9b-926f-b984874723fa	goods_receipt_supplier	goods-receipt	408aea7a-6b67-4fab-af46-3321ed698642	kolandasamy.sss@gmail.com	2026-06-09 05:23:16.735+00	0	0
7b05c54e-2823-4cc3-a793-70fff6a06ad1	supplier_return_notice	goods-return	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	kolandasamy.sss@gmail.com	2026-06-09 05:25:44.07+00	0	0
75f861c6-dfd8-48b2-801d-afb2be79b860	purchase_order_supplier	purchase-order	6a65724c-dc91-465a-ba9e-e79e7d88234c	kolandasamy.sss@gmail.com	2026-06-09 05:39:34.853+00	0	0
282a606d-f2fd-4a0c-8f93-c3845520dd8b	purchase_order_supplier	purchase-order	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	kolandasamy.sss@gmail.com	2026-06-09 05:44:37.144+00	0	0
79576874-5fb9-4818-a0d6-28bd890d5673	purchase_order_supplier	purchase-order	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	kolandasamy.sss@gmail.com	2026-06-09 09:59:34.004+00	0	0
74cab5aa-8ad5-4f26-b7aa-1e3d8fd415cf	purchase_order_supplier	purchase-order	714d8e69-25db-490c-af43-8c6168c774d4	kolandasamy.sss@gmail.com	2026-06-09 10:07:05.434+00	0	0
a67fb65f-b589-4710-8494-fd0de188b596	purchase_order_supplier	purchase-order	eaafa0b8-8e26-4636-9e0b-1039689f82a6	kolandasamy.sss@gmail.com	2026-06-09 10:10:55.782+00	0	0
5c648645-a5d8-470c-be6a-6f027eaeff87	purchase_order_supplier	purchase-order	93ae57bd-78e2-44cc-bfce-eaf421970398	kolandasamy.sss@gmail.com	2026-06-09 17:16:10.294+00	0	0
4c879c40-d83b-46b9-af04-72120f9e468f	platform_trial_expired_3d	company	5c4b301a-5ddc-4777-acbd-adddeee7ef37	samrithags12@gmail.com	2026-06-10 09:00:02.248+00	0	0
\.


--
-- Data for Name: email_sender_domains; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_sender_domains (id, company_id, domain, dkim_selector, dkim_host, dkim_value, status, verified_at, last_checked_at, created_at, updated_at) FROM stdin;
776c92be-c635-4878-943e-fd835e94873b	582b08bd-2a7a-475b-84c2-e4ef8f834a83	retailims.com	retailims-sdc001	retailims-sdc001._domainkey.retailims.com	retailims-verification=ffa0896f8eea1f0136109115e9da9a3e	FAILED	\N	2026-05-27 11:33:05.64+00	2026-05-27 11:31:37.318+00	2026-05-27 11:33:05.641+00
\.


--
-- Data for Name: email_sender_identities; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_sender_identities (id, company_id, domain_id, display_name, email, sender_type, is_primary, status, verified_at, created_at, updated_at, smtp_host, smtp_port, smtp_secure, smtp_user, smtp_password_enc, smtp_configured_at, smtp_last_verified_at) FROM stdin;
e12edc36-4faf-43ee-98ff-c897cf0ed4fd	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	Tharun	gstharunadhithya08@gmail.com	PUBLIC_DOMAIN	t	VERIFIED	2026-05-27 11:33:38.585+00	2026-05-27 11:32:31.571+00	2026-05-27 12:24:28.314+00	smtp.gmail.com	587	f	gstharunadhithya08@gmail.com	KEeGvqChbloBL8KO:Awa1O1WulZM2Uf5q6RHWbw==:O8Og5p3Cie5O2SY6GvOGNA==	2026-05-27 12:24:28.312+00	2026-05-27 12:24:28.312+00
9bcf8db7-29f2-48c2-95b2-92fc52d11ce8	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	\N	Sami	swamiedge@gmail.com	PUBLIC_DOMAIN	t	VERIFIED	2026-05-27 12:41:29.134+00	2026-05-27 12:40:27.851+00	2026-05-27 12:41:29.135+00	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: email_sender_verifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.email_sender_verifications (id, sender_id, otp_hash, attempt_count, expires_at, consumed_at, created_at) FROM stdin;
b10576e3-27b4-4aa8-a146-4bd76295edb3	e12edc36-4faf-43ee-98ff-c897cf0ed4fd	b9bfcbb0eed6b3607753dd3b19b1dc8d1fbec863c758884d1fbed10e7386c873	0	2026-05-27 11:43:11.967+00	2026-05-27 11:33:38.585+00	2026-05-27 11:33:11.968+00
da5d4c85-aab1-4e4e-b3aa-fe8c2d56fe55	9bcf8db7-29f2-48c2-95b2-92fc52d11ce8	ab83eab2817bcfb7f5d908b0ad43af3459227edd753483fa239876026a2e1dd6	0	2026-05-27 12:50:56.048+00	2026-05-27 12:41:29.134+00	2026-05-27 12:40:56.049+00
\.


--
-- Data for Name: fx_rates; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.fx_rates (id, base, quote, rate, as_of) FROM stdin;
\.


--
-- Data for Name: goods_issue_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_issue_header (id, gi_number, gi_date, shop_id, issue_reason, remarks, status, posted_at, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version, issue_type, other_reason) FROM stdin;
6045be97-ea41-4a8c-ba88-ae1ca2882767	GI-HQ001-202605-00001	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Sales Order	Reference: SO-HQ001-202605-00002\nStorage: Raw material store	POSTED	2026-05-26 15:23:12.677+00	2026-05-26 15:23:12.52+00	2026-05-26 15:23:12.677+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	Sales Order	\N
19ef01b3-9b42-4d70-89af-7e0bd8cad27d	GI-HQ001-202605-00002	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Sales Order	Reference: SO-HQ001-202605-00004\nStorage: Raw material store	POSTED	2026-05-26 16:11:35.843+00	2026-05-26 16:11:35.692+00	2026-05-26 16:11:35.844+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	Sales Order	\N
b3e554ba-0efa-49cd-9e9b-ef1558d44982	GI-HQ001-202605-00003	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Sales Order	Reference: SO-HQ001-202605-00005\nStorage: Raw material store	POSTED	2026-05-26 16:28:52.409+00	2026-05-26 16:28:51.862+00	2026-05-26 16:28:52.41+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	Sales Order	\N
11970999-986b-42db-bf4b-90d0d04642a6	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Sales Order	Reference: SO-00001\nElectrical items	POSTED	2026-05-30 07:55:42.299+00	2026-05-30 07:55:42.159+00	2026-06-09 05:29:03.403+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:29:03.402Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1	Sales Order	\N
508241a7-af1a-4fca-8454-20511c911948	GI-00002	2026-06-11	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Sales Order	\N	POSTED	2026-06-11 07:05:10.21+00	2026-06-11 07:05:05.481+00	2026-06-11 07:05:10.211+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	Sales Order	\N
\.


--
-- Data for Name: goods_issue_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_issue_items (id, gi_header_id, product_id, quantity, uom, available_stock_snapshot, created_at, updated_at, created_by, updated_by) FROM stdin;
3152f35b-6047-43cd-963b-c8b0ef7a6a7c	6045be97-ea41-4a8c-ba88-ae1ca2882767	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	pcs	42.000	2026-05-26 15:23:12.52+00	2026-05-26 15:23:12.52+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6cb6191b-6db8-47c8-9334-e91eb5ac7b1d	19ef01b3-9b42-4d70-89af-7e0bd8cad27d	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	UNIT	71.000	2026-05-26 16:11:35.692+00	2026-05-26 16:11:35.692+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3deecc26-d7b3-4342-ad14-f14029fa3fbc	b3e554ba-0efa-49cd-9e9b-ef1558d44982	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	11.000	UNIT	39.000	2026-05-26 16:28:51.862+00	2026-05-26 16:28:51.862+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4235b367-11c0-4e43-873e-344f0ab272b6	11970999-986b-42db-bf4b-90d0d04642a6	f9865733-a9f7-44f6-a031-9c3925042cea	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
8019a04c-f38c-4c64-a921-4787e5661d7c	11970999-986b-42db-bf4b-90d0d04642a6	7a494ea2-2cf1-419c-ba0a-37da9f178b41	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
e813a95f-0858-440d-9b7f-790200ba41c8	11970999-986b-42db-bf4b-90d0d04642a6	8c42805b-90f8-4c3d-9784-b6821ad9272a	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
676f070b-ec2f-430e-95f2-d06729d2312a	11970999-986b-42db-bf4b-90d0d04642a6	b196efdd-24e4-4435-a798-aab2e1ec69a0	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
f7bfa51a-73eb-4a68-bccf-e6722a3007bd	11970999-986b-42db-bf4b-90d0d04642a6	6cf057a6-6a6e-46ac-be49-a0417acd71c3	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
046ae86d-baf2-4945-b9c7-bf8b4c2c1eb0	11970999-986b-42db-bf4b-90d0d04642a6	2d8107ad-f2ff-4862-b269-9b274a65b530	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
c6c7f113-aeff-44fc-adcb-27ab9a12e035	11970999-986b-42db-bf4b-90d0d04642a6	2d8107ad-f2ff-4862-b269-9b274a65b530	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
657064aa-34a9-4b53-9158-2cd9371e3aa9	11970999-986b-42db-bf4b-90d0d04642a6	166c4ba0-232b-484f-ad54-fab5379410fa	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
355e9419-8b3b-43f4-9d3e-bd5e3441f78b	11970999-986b-42db-bf4b-90d0d04642a6	6344a746-687f-48d0-af2e-329cc0932fc7	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
55a4357f-e113-4f65-af34-cd5dcd755385	11970999-986b-42db-bf4b-90d0d04642a6	0459f473-75f9-463a-8237-9ca65fee69f8	10.000	pcs	100.000	2026-05-30 07:55:42.159+00	2026-05-30 07:55:42.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
a2c8ea4a-22e7-4473-af2c-462fc32d862f	508241a7-af1a-4fca-8454-20511c911948	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	1.000	pcs	3.000	2026-06-11 07:05:05.481+00	2026-06-11 07:05:05.481+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
34af0e21-a2bb-4c00-adbd-dea07894bcf5	508241a7-af1a-4fca-8454-20511c911948	b196efdd-24e4-4435-a798-aab2e1ec69a0	1.000	pcs	95.000	2026-06-11 07:05:05.481+00	2026-06-11 07:05:05.481+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
38956dd1-500d-4ea1-b0a2-953c98ff9be9	508241a7-af1a-4fca-8454-20511c911948	7a494ea2-2cf1-419c-ba0a-37da9f178b41	1.000	pcs	95.000	2026-06-11 07:05:05.481+00	2026-06-11 07:05:05.481+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: goods_receipt_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_receipt_header (id, gr_number, gr_date, shop_id, supplier_name, purchase_order_id, supplier_ref, remarks, status, posted_at, total_value, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version, receipt_type, receipt_source, inward_shift) FROM stdin;
3b59bae8-9fed-4f21-8321-ba3fc7d43670	GR-HQ001-202605-00001	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	d62e1dc9-f157-4ce1-9aad-788ae4e5f9d2	PO-HQ001-202605-00001	Auto-draft from PO PO-HQ001-202605-00001	DRAFT	\N	\N	2026-05-25 05:28:26.489+00	2026-05-25 05:28:26.489+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
5df575db-39e7-41a3-8c84-54b8bc1de69b	GR-HQ001-202605-00002	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	58c296bd-7d95-40cb-a083-15e50c03b941	PO-HQ001-202605-00002	Auto-draft from PO PO-HQ001-202605-00002	DRAFT	\N	\N	2026-05-25 06:01:34.413+00	2026-05-25 06:01:34.413+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
8f914892-94f8-44a0-888c-c6d2867c8805	GR-HQ001-202605-00003	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	d16a81c5-d5e6-4a5e-ae2c-85069bf8cea6	PO-HQ001-202605-00003	Auto-draft from PO PO-HQ001-202605-00003	POSTED	2026-05-25 08:10:02.066+00	500.00	2026-05-25 06:10:15.644+00	2026-05-25 08:10:02.067+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
5ad915fa-a080-492f-9642-f5e333664d21	GR-HQ001-202605-00004	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	a0305a74-81dc-44c7-b479-93732db5d98e	PO-HQ001-202605-00005	Auto-draft from PO PO-HQ001-202605-00005	DRAFT	\N	\N	2026-05-25 15:48:10.518+00	2026-05-25 15:48:10.518+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
c07c6c06-a05f-47a6-9490-45fae52eb335	GR-HQ001-202605-00005	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	0b050ead-40cc-4b1d-9228-480db2ea54f4	PO-HQ001-202605-00006	Auto-draft from PO PO-HQ001-202605-00006	DRAFT	\N	\N	2026-05-25 16:16:13.419+00	2026-05-25 16:16:13.419+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
45646ecc-b754-4e18-8325-9ced2130180f	GR-HQ001-202605-00006	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	950a2f19-23be-47c3-8cbd-7db822639954			POSTED	2026-05-25 16:19:32.339+00	1100.00	2026-05-25 16:19:24.123+00	2026-05-25 16:19:32.34+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
7aa747e6-053b-4195-a602-336b745fa59d	GR-HQ001-202605-00007	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	0b050ead-40cc-4b1d-9228-480db2ea54f4			POSTED	2026-05-25 17:04:52.561+00	11000.00	2026-05-25 17:04:43.673+00	2026-05-25 17:04:52.562+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
1106b90e-4c5b-4583-b8cf-90a80d92ef99	GR-HQ001-202605-00008	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	d62e1dc9-f157-4ce1-9aad-788ae4e5f9d2			POSTED	2026-05-25 17:06:46.703+00	100.00	2026-05-25 17:06:42.628+00	2026-05-25 17:06:46.704+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
7265e3e8-c9d0-4c1e-9deb-c84c79b747e2	GR-HQ001-202605-00009	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	58c296bd-7d95-40cb-a083-15e50c03b941			POSTED	2026-05-25 17:11:09.978+00	2000.00	2026-05-25 17:10:44.657+00	2026-05-25 17:11:09.979+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
c940051f-3ff8-4982-a627-ac3f1dd24018	GR-HQ001-202605-00010	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	c0322c43-144e-416e-8ccc-005b82f19897			POSTED	2026-05-26 07:27:34.651+00	1000.00	2026-05-26 07:27:24.722+00	2026-05-26 07:27:34.652+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
dbe84bee-6afc-411a-943c-32c4467b05d6	GR-HQ001-202605-00011	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	c5973c42-3a93-484d-ac68-c64ca799accc			POSTED	2026-05-26 07:57:58.275+00	7500.00	2026-05-26 07:56:15.82+00	2026-05-26 07:57:58.276+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
4c30dcfe-1b7f-453f-928f-35fe9d255115	GR-REVATH001-202605-00001	2026-05-26	d53ce4ee-7da6-4709-b944-348687fb0843	Nadar depart store	84ba57d6-7085-46b5-863e-cf279a415a11	INV001203/05-26		POSTED	2026-05-26 13:13:23.094+00	13000.00	2026-05-26 13:13:16.231+00	2026-05-26 13:13:23.094+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
70daea11-f9f3-40c2-aab2-5a33b3840e43	GR-HQ001-202605-00012	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	b433c3de-9c5f-4b45-9579-0e90e669981f			POSTED	2026-05-26 15:59:30.241+00	7500.00	2026-05-26 15:59:11.111+00	2026-05-26 15:59:30.241+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
805be505-2858-4642-abf1-8d09549077d6	GR-HQ001-202605-00013	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	b433c3de-9c5f-4b45-9579-0e90e669981f			POSTED	2026-05-26 16:01:55.621+00	7500.00	2026-05-26 16:01:22.019+00	2026-05-26 16:01:55.622+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
bd3940c3-fefd-4511-bd92-552eeff4740f	GR-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	PowerDrive Engines	17904c2f-5358-489d-8f81-b2945ca9f79a			POSTED	2026-05-30 04:26:39.971+00	150000.00	2026-05-30 04:26:35.564+00	2026-05-30 04:26:39.972+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
345870ff-1253-4b69-9a2a-9a9648742362	GR-00002	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	53a1c699-58cd-4d6f-b3b3-071cfd584544			POSTED	2026-05-30 05:30:08.371+00	450.00	2026-05-30 05:30:08.163+00	2026-05-30 05:30:08.372+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
9dbceae8-fc02-403b-8b8c-3cd7c6513498	GR-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bright Power Distributors	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b			POSTED	2026-05-30 10:05:40.882+00	37600.00	2026-05-30 10:05:33.474+00	2026-05-30 10:05:40.883+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	FULL	PURCHASE_ORDER	\N
265ba202-982a-4bfa-bbd6-51ea0bff27e8	GR-00004	2026-06-09	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	\N			POSTED	2026-06-09 05:19:50.657+00	17100.00	2026-06-09 05:19:50.336+00	2026-06-09 05:19:50.683+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:19:50.683Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1	PARTIAL	OUTSIDE	NIGHT_SHIFT
408aea7a-6b67-4fab-af46-3321ed698642	GR-00005	2026-06-09	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	\N			POSTED	2026-06-09 05:23:01.761+00	9500.00	2026-06-09 05:23:01.576+00	2026-06-09 05:23:01.779+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:23:01.778Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1	FULL	OUTSIDE	DAY_SHIFT
\.


--
-- Data for Name: goods_receipt_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.goods_receipt_items (id, gr_header_id, product_id, quantity, uom, purchase_rate, line_value, batch_number, serial_number, created_at, updated_at, created_by, updated_by, expiry_date, storage_location_id) FROM stdin;
1b0b09b4-4e76-472c-bf63-c2b6ba637f32	3b59bae8-9fed-4f21-8321-ba3fc7d43670	57812718-33b2-4585-ba16-e4a95bec7405	1.000	pcs	99.00	99.00	\N	\N	2026-05-25 05:28:26.489+00	2026-05-25 05:28:26.489+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
54436d82-0eee-450f-a5d0-05fba68a6eca	5df575db-39e7-41a3-8c84-54b8bc1de69b	57812718-33b2-4585-ba16-e4a95bec7405	20.000	pcs	130.00	2600.00	\N	\N	2026-05-25 06:01:34.413+00	2026-05-25 06:01:34.413+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
712b800e-a15b-40af-a194-a251015627e8	8f914892-94f8-44a0-888c-c6d2867c8805	57812718-33b2-4585-ba16-e4a95bec7405	1.000	pcs	500.00	500.00	\N	\N	2026-05-25 06:10:15.644+00	2026-05-25 06:10:15.644+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
82548639-2930-4137-8b9d-768a02617bdb	5ad915fa-a080-492f-9642-f5e333664d21	57812718-33b2-4585-ba16-e4a95bec7405	4.000	pcs	50.00	200.00	\N	\N	2026-05-25 15:48:10.518+00	2026-05-25 15:48:10.518+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
60a524fc-5828-42e6-b971-a591a2a525e8	c07c6c06-a05f-47a6-9490-45fae52eb335	57812718-33b2-4585-ba16-e4a95bec7405	20.000	pcs	100.00	2000.00	\N	\N	2026-05-25 16:16:13.419+00	2026-05-25 16:16:13.419+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
ddf45d24-8aa8-4614-9868-bc25ae4eadd1	c07c6c06-a05f-47a6-9490-45fae52eb335	53457790-5c18-4f3a-a2d6-709ded27ed4a	30.000	pcs	200.00	6000.00	\N	\N	2026-05-25 16:16:13.419+00	2026-05-25 16:16:13.419+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
5161a057-b0fe-40c0-a2a3-4b6a7cf05709	45646ecc-b754-4e18-8325-9ced2130180f	53457790-5c18-4f3a-a2d6-709ded27ed4a	2.000	pcs	300.00	600.00	\N	\N	2026-05-25 16:19:24.123+00	2026-05-25 16:19:24.123+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
a44d547d-2d99-4a43-8308-2a6a6605b24b	45646ecc-b754-4e18-8325-9ced2130180f	57812718-33b2-4585-ba16-e4a95bec7405	5.000	pcs	100.00	500.00	\N	\N	2026-05-25 16:19:24.123+00	2026-05-25 16:19:24.123+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
03e76f66-9390-4725-bd49-44953ca15cc8	7aa747e6-053b-4195-a602-336b745fa59d	57812718-33b2-4585-ba16-e4a95bec7405	20.000	pcs	100.00	2000.00	\N	\N	2026-05-25 17:04:43.673+00	2026-05-25 17:04:43.673+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
f3ea3c13-b9ff-4394-983c-ad06416cabe1	7aa747e6-053b-4195-a602-336b745fa59d	53457790-5c18-4f3a-a2d6-709ded27ed4a	30.000	pcs	300.00	9000.00	\N	\N	2026-05-25 17:04:43.673+00	2026-05-25 17:04:43.673+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
65a6f65b-0ead-4b46-ac62-88f963e35c60	1106b90e-4c5b-4583-b8cf-90a80d92ef99	57812718-33b2-4585-ba16-e4a95bec7405	1.000	pcs	100.00	100.00	\N	\N	2026-05-25 17:06:42.628+00	2026-05-25 17:06:42.628+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
017bbec9-1bf9-45b0-bfe1-64f9dd9d7aa3	7265e3e8-c9d0-4c1e-9deb-c84c79b747e2	57812718-33b2-4585-ba16-e4a95bec7405	20.000	pcs	100.00	2000.00	\N	\N	2026-05-25 17:10:44.657+00	2026-05-25 17:10:44.657+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
cb1e7995-b594-468e-aa75-e6c6b7a5d5e5	c940051f-3ff8-4982-a627-ac3f1dd24018	57812718-33b2-4585-ba16-e4a95bec7405	10.000	pcs	100.00	1000.00	\N	\N	2026-05-26 07:27:24.722+00	2026-05-26 07:27:24.722+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
7b68abf4-513a-458d-ba15-2554cbb7caa0	dbe84bee-6afc-411a-943c-32c4467b05d6	53457790-5c18-4f3a-a2d6-709ded27ed4a	25.000	pcs	300.00	7500.00	\N	\N	2026-05-26 07:56:15.82+00	2026-05-26 07:56:15.82+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
7abfa4ee-23da-4fcf-8d46-0a73ff15b4d0	4c30dcfe-1b7f-453f-928f-35fe9d255115	c493edaf-78ef-4954-b311-3d45c05cfeaa	10.000	pcs	1300.00	13000.00	Bar04348	\N	2026-05-26 13:13:16.231+00	2026-05-26 13:13:16.231+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
1726baa5-8c18-4827-8302-60beb2b612f9	70daea11-f9f3-40c2-aab2-5a33b3840e43	53457790-5c18-4f3a-a2d6-709ded27ed4a	25.000	pcs	300.00	7500.00	\N	\N	2026-05-26 15:59:11.111+00	2026-05-26 15:59:11.111+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-26	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
43166535-c7da-43b6-9402-42d8131c5183	805be505-2858-4642-abf1-8d09549077d6	53457790-5c18-4f3a-a2d6-709ded27ed4a	25.000	pcs	300.00	7500.00	\N	\N	2026-05-26 16:01:22.019+00	2026-05-26 16:01:22.019+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-26	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
9ac72c0b-2a94-4197-9b6f-38465812db97	bd3940c3-fefd-4511-bd92-552eeff4740f	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	3.000	pcs	50000.00	150000.00	\N	\N	2026-05-30 04:26:35.564+00	2026-05-30 04:26:35.564+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
83cfd615-46ce-484b-bcb9-bfa211994a21	345870ff-1253-4b69-9a2a-9a9648742362	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	pcs	450.00	450.00	\N	\N	2026-05-30 05:30:08.163+00	2026-05-30 05:30:08.163+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
9cbfffc8-53a0-4190-88de-e945eb0262ba	9dbceae8-fc02-403b-8b8c-3cd7c6513498	f9865733-a9f7-44f6-a031-9c3925042cea	5.000	pcs	1450.00	7250.00	\N	\N	2026-05-30 10:05:33.474+00	2026-05-30 10:05:33.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
4b2d6a69-af52-455f-8c53-0324679a4075	9dbceae8-fc02-403b-8b8c-3cd7c6513498	7a494ea2-2cf1-419c-ba0a-37da9f178b41	5.000	pcs	1800.00	9000.00	\N	\N	2026-05-30 10:05:33.474+00	2026-05-30 10:05:33.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
860d8347-96fd-48c0-8af0-069eb327d680	9dbceae8-fc02-403b-8b8c-3cd7c6513498	8c42805b-90f8-4c3d-9784-b6821ad9272a	5.000	pcs	3200.00	16000.00	\N	\N	2026-05-30 10:05:33.474+00	2026-05-30 10:05:33.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
ff36bfe7-753b-45cb-a338-c4ab749ce514	9dbceae8-fc02-403b-8b8c-3cd7c6513498	b196efdd-24e4-4435-a798-aab2e1ec69a0	5.000	pcs	420.00	2100.00	\N	\N	2026-05-30 10:05:33.474+00	2026-05-30 10:05:33.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
e7939424-5c56-4104-b28b-6613f0bc54e4	9dbceae8-fc02-403b-8b8c-3cd7c6513498	6cf057a6-6a6e-46ac-be49-a0417acd71c3	5.000	pcs	650.00	3250.00	\N	\N	2026-05-30 10:05:33.474+00	2026-05-30 10:05:33.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-05-30	69dcad3c-97ea-435f-a7b7-a1b59e7ed543
7a5e0905-f8a9-46fa-8bd4-f9d0ffde4452	265ba202-982a-4bfa-bbd6-51ea0bff27e8	166c4ba0-232b-484f-ad54-fab5379410fa	18.000	pcs	950.00	17100.00	B290	S.NO 9022	2026-06-09 05:19:50.336+00	2026-06-09 05:19:50.336+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-07-02	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093
ca23639e-85aa-406f-b802-5387df7ebe1d	408aea7a-6b67-4fab-af46-3321ed698642	166c4ba0-232b-484f-ad54-fab5379410fa	10.000	pcs	950.00	9500.00	B290	\N	2026-06-09 05:23:01.576+00	2026-06-09 05:23:01.576+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	2026-06-09	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.idempotency_keys (id, key, scope, result, user_id, created_at, expires_at) FROM stdin;
1b4deac9-af7e-4729-98f4-17f69909f3af	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:da556c8a-4d3f-4f65-8d41-4957b8aa5da2	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "950a2f19-23be-47c3-8cbd-7db822639954"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-25 14:52:10.243+00	\N
7659f0f9-2d89-4d9c-962a-442b695d562f	alerts:automation:2026-05-25T16	\N	{"generated": 0}	\N	2026-05-25 16:05:38.779+00	\N
915d3d38-7fed-4235-88c9-cb2a3f6a3f37	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:ce737307-79c3-4033-89cf-c312c185f4e0	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "c0322c43-144e-416e-8ccc-005b82f19897"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-25 17:56:43.76+00	\N
c801c8d3-6fc8-4ea1-8501-2da4c78ee430	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:5a77ed17-7d01-4ca7-91aa-f665bab3e6a8	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "c5973c42-3a93-484d-ac68-c64ca799accc"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 07:55:03.954+00	\N
5520110c-ee90-4ea8-b89b-1f7066b2ac59	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec:a618f91f-3838-4500-bf2b-f196cabea67a	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	{"poId": "7bfd4712-c3e3-4481-b439-cdcc0c189522"}	47a8b4e9-c9ee-4239-b6c1-129e71d74587	2026-05-26 12:59:49.093+00	\N
2d21c1d4-89f8-454f-844f-81e15cb252c4	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec:f41ec34a-e77d-45c0-baa4-4ad987bab4f5	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	{"poId": "84ba57d6-7085-46b5-863e-cf279a415a11"}	47a8b4e9-c9ee-4239-b6c1-129e71d74587	2026-05-26 13:04:16.534+00	\N
74b29ebc-f749-43fd-ba1b-124b6c44032a	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec:6a958719-d287-4d45-a9de-17b3cdbb67c6	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	{"poId": "98d38f13-ae33-4bea-aa30-f5633f590ae8"}	47a8b4e9-c9ee-4239-b6c1-129e71d74587	2026-05-26 15:10:58.616+00	\N
6097e407-d81b-4206-b83e-2736b379d722	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec:b12d1b52-245d-4256-9130-9c46678b8997	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	{"poId": "4a3f2dfe-53e4-4867-9d43-06172ae206b3"}	47a8b4e9-c9ee-4239-b6c1-129e71d74587	2026-05-26 15:12:23.686+00	\N
8b966be5-e926-4e87-ac68-93c24e5da04a	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec:849a6342-3100-43af-a720-ba5c80d11951	company:97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	{"poId": "2a5a864c-14e5-4926-bcc8-0eba58535da8"}	47a8b4e9-c9ee-4239-b6c1-129e71d74587	2026-05-26 15:20:54.873+00	\N
9dcff6f4-408e-4030-9117-78627204142c	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:0f31732b-60ce-41a2-a184-19b6088a23ae	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "b433c3de-9c5f-4b45-9579-0e90e669981f"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 15:57:19.43+00	\N
24273333-c25e-477a-8bc1-7d8b0c43c54b	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:2c4f5508-05e5-480a-ad3a-98e373526570	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "9205e8da-e7d2-41cb-9ccd-98944f0f34e9"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-27 11:35:08.398+00	\N
119e614b-3fd4-4040-a490-1c97cf995fd0	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:daab9371-56dc-4632-964a-ecd5b4731f0b	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "24e5f5c4-3725-469e-9c5c-5e1bc438faa0"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-29 07:50:08.39+00	\N
f34d1688-e9cd-4427-b9f3-34daa9fa7b14	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:a9dcc75c-acc0-425c-bcca-28968a8132d2	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "53a1c699-58cd-4d6f-b3b3-071cfd584544"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-29 07:50:17.827+00	\N
c96f019f-6e18-4052-9083-91a660d6c911	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:8d642db4-9b26-4a32-956d-427b3ba2fca9	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "17904c2f-5358-489d-8f81-b2945ca9f79a"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-30 04:16:01.275+00	\N
33878a6a-7ac7-47ca-aba5-803eaf577806	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:0e9fa8c5-55d2-4b1d-ae49-ca6d6261503b	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-30 10:02:26.067+00	\N
26200358-41c4-4ae0-bbf0-540dccd45a90	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:3521819f-8764-41bb-bdef-da479ba15e3e	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "5deef4ed-cdfb-4baf-966f-dc36ca76b14b"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-08 17:42:07.848+00	\N
c1e3191d-9006-4445-8ef6-1408fe59604d	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:bc2880c4-84d6-4da1-9ad2-2ea4d2bab712	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "748dd9cf-1fdd-4f95-840d-22ab88262a03"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-08 17:46:13.745+00	\N
27616c22-ab69-460d-a0b6-20d59f61771e	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:46bc5c03-f8a1-416d-96d4-77de5ed60aed	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "05ae51ad-18be-4ee5-bafe-8c658db0eb89"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 01:47:33.97+00	\N
8a3cdd74-f24e-4eb0-9ab3-aec6191da6fa	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:574d8348-7900-4add-8c83-71e87db0868b	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "4f91da5c-9b7e-4344-a78b-2dd21950e8a9"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 02:06:26.508+00	\N
bbed71ac-8163-4b78-ba5a-8a7cd5cfd6a7	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:481b648f-b1d5-442d-a97e-efeda4361bf1	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "245324eb-1995-4571-963a-8c776fcd047e"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 03:51:57.947+00	\N
5e811de3-7b78-43ac-a909-55f64f443a3d	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:1d6e26ed-a29a-453a-8167-8340864eab27	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 04:15:47.331+00	\N
3f93651b-81a7-4136-8972-f873ce36bc2e	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:f3dc10cd-8c2c-4575-9c30-ac2f5b285d7e	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "2325cf74-910a-4065-9a29-e9c5c9b9bb38"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 04:50:28.712+00	\N
3f2a96f1-4c15-446e-980d-938fd7a3fcb3	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:3249df01-f5db-4550-b58d-4b246f53ac4b	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "f1732149-a034-4689-ad21-901760bba457"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 05:02:19.947+00	\N
4f522627-961e-4fb1-a8bc-683de1c4958c	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:2c6243cc-d95f-4c80-8606-df4ee068cba1	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "e62b76c6-23ef-4d71-ba48-9d10ae494065"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 05:12:37.22+00	\N
de7c9b5e-8b84-4511-9b7a-af4501078276	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:cfdadec6-6601-486d-8c07-a167a1982439	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "6a65724c-dc91-465a-ba9e-e79e7d88234c"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 05:39:30.349+00	\N
d9c66d91-ac62-4a58-970d-f92da5f22fd7	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:d4af9739-9d86-455b-ba75-dd091b2e7c40	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 05:44:33.072+00	\N
2af73094-59d0-47ba-a508-61616589df4e	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:b3fb2fd8-3328-4c84-9b60-c9dc9e50c229	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "8ee5a865-3e8a-4e6a-8ebc-cf877d413f01"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 09:59:27.507+00	\N
93b086cb-5386-431e-8138-f1ba6c63a8dd	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:55088836-9f53-4b76-91cc-0dc3aca2e930	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "714d8e69-25db-490c-af43-8c6168c774d4"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 10:06:59.706+00	\N
ce08d532-5435-4d64-b7a4-8b79fb54794d	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:2893b733-4f7e-4811-9fdc-00e2022fe60c	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "eaafa0b8-8e26-4636-9e0b-1039689f82a6"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 10:10:49.372+00	\N
9dcaacf0-940c-403a-9339-88f6de28d5e0	alerts:automation:2026-06-09T11	\N	{"generated": 9}	\N	2026-06-09 11:10:40.229+00	\N
59ce2527-e32a-43bf-b330-10bfb10c9ec9	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83:po:create:cf09ceb9-561a-43d1-8766-f1aa71ebb93d	company:582b08bd-2a7a-475b-84c2-e4ef8f834a83	{"poId": "93ae57bd-78e2-44cc-bfce-eaf421970398"}	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-09 17:16:03.882+00	\N
9c2d4bb6-b3a7-4988-a349-39097b669ae8	alerts:automation:2026-06-10T13	\N	{"generated": 9}	\N	2026-06-10 13:59:45.812+00	\N
\.


--
-- Data for Name: invoice_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.invoice_header (id, invoice_number, invoice_date, sales_order_id, customer_id, shop_id, status, currency, fx_rate_used, discount_amount, tax_amount, total_value, paid_value, due_date, remarks, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
\.


--
-- Data for Name: job_failures; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.job_failures (id, queue, job_name, job_id, data, error_name, error_message, stack, attempts, failed_at) FROM stdin;
\.


--
-- Data for Name: lifecycle_campaign_enrollments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.lifecycle_campaign_enrollments (id, company_id, campaign_key, scheduled_for, sent_at, status, email_delivery_log_id, metadata, created_at, updated_at) FROM stdin;
71f49050-2872-40e4-b372-ddb51670f859	5c4b301a-5ddc-4777-acbd-adddeee7ef37	platform_trial_welcome	\N	2026-05-31 03:18:02.584+00	SENT	\N	\N	2026-05-31 03:18:02.585+00	2026-05-31 03:18:02.585+00
7ab0823b-655f-45ee-81c6-7b3015402775	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_edu_inventory	\N	2026-05-31 09:00:02.818+00	SENT	\N	\N	2026-05-31 09:00:02.818+00	2026-05-31 09:00:02.818+00
1fbb8ff5-d417-4d5f-bbce-49e7f3db9eb0	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_edu_purchase	\N	2026-05-31 09:00:03.445+00	SENT	\N	\N	2026-05-31 09:00:03.446+00	2026-05-31 09:00:03.446+00
f3313610-f9f4-4abc-bb15-ec0608abb522	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_edu_reports	\N	2026-05-31 09:00:04.372+00	SENT	\N	\N	2026-05-31 09:00:04.373+00	2026-05-31 09:00:04.373+00
b076dfbd-5893-460a-8abf-f94f9ea98cd7	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_expiry_7	\N	2026-05-31 09:00:04.829+00	SENT	\N	\N	2026-05-31 09:00:04.83+00	2026-05-31 09:00:04.83+00
9676dec3-b109-4429-85f1-18f4da6ae268	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_day_1	\N	2026-06-01 09:00:02.663+00	SENT	\N	\N	2026-06-01 09:00:02.663+00	2026-06-01 09:00:02.663+00
dae5a6ea-87f0-45b9-9b8a-c026a1ea3da1	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_day_3	\N	2026-06-03 09:00:03.096+00	SENT	\N	\N	2026-06-03 09:00:03.096+00	2026-06-03 09:00:03.096+00
601b75ea-1f76-4d90-b1df-841bb2b5e6b6	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_expiry_3	\N	2026-06-04 09:00:03.093+00	SENT	\N	\N	2026-06-04 09:00:03.095+00	2026-06-04 09:00:03.095+00
b4f1c869-1df3-4985-a23c-1b6fc04f4484	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_expiry_1	\N	2026-06-06 09:00:03.405+00	SENT	\N	\N	2026-06-06 09:00:03.406+00	2026-06-06 09:00:03.406+00
376228b6-9f97-4448-a4ea-24e3e91d3f7a	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_expired_day_0	\N	2026-06-07 09:00:02.938+00	SENT	\N	\N	2026-06-07 09:00:02.938+00	2026-06-07 09:00:02.938+00
2f8ba674-f476-4083-8e90-f283ff6fb612	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_day_7	\N	2026-06-07 09:00:03.475+00	SENT	\N	\N	2026-06-07 09:00:03.476+00	2026-06-07 09:00:03.476+00
bcc37f92-5bdf-456f-99c9-1998264d6140	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_inactive_7d	\N	2026-06-07 09:00:03.979+00	SENT	\N	\N	2026-06-07 09:00:03.98+00	2026-06-07 09:00:03.98+00
c53b9f6e-3232-42dd-a953-2b776364709b	5c4b301a-5ddc-4777-acbd-adddeee7ef37	trial_expired_3d	\N	2026-06-10 09:00:02.249+00	SENT	\N	\N	2026-06-10 09:00:02.25+00	2026-06-10 09:00:02.25+00
\.


--
-- Data for Name: media_assets; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.media_assets (id, company_id, shop_id, branding_profile_id, type, asset_key, file_name, version, metadata, uploaded_by, uploaded_at, active) FROM stdin;
\.


--
-- Data for Name: notification_audit_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notification_audit_logs (id, company_id, user_id, action, notification_id, approval_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notification_preferences (id, user_id, company_id, gr_created, gr_approved, gr_rejected, po_approval_required, po_approved, po_rejected, low_stock_alert, transfer_completed, inventory_adjustment, login_alert, device_alert, push_enabled, email_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.notifications (id, user_id, company_id, title, message, type, priority, module, status, reference_type, reference_id, deep_link, action_url, is_read, read_at, created_at, expires_at, created_by) FROM stdin;
\.


--
-- Data for Name: password_reset_requests; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.password_reset_requests (id, user_id, email, method, otp_hash, link_token_hash, attempt_count, expires_at, consumed_at, created_at, last_sent_at, requested_ip, requested_user_agent) FROM stdin;
3322091b-842e-4794-bc1c-2ba95f171f9d	d0eda257-86b4-4510-93bc-103cfe0d86e4	gstharunadhithya08@gmail.com	OTP	$2b$12$nBbbJE4DP36uzuttt.8G8e2tTban4fqqOV3IIZhcUpJy4zSw.6/n2	\N	0	2026-06-13 09:18:06.047+00	\N	2026-06-13 09:08:06.255+00	2026-06-13 09:08:06.047+00	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36
\.


--
-- Data for Name: payment_receipts; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.payment_receipts (id, receipt_number, receipt_date, invoice_id, shop_id, amount, currency, fx_rate_used, method, reference, remarks, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
\.


--
-- Data for Name: platform_audit_log; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.platform_audit_log (id, user_id, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at, action) FROM stdin;
\.


--
-- Data for Name: platform_notification_reads; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.platform_notification_reads (id, notification_id, admin_email, read_at) FROM stdin;
\.


--
-- Data for Name: platform_notifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.platform_notifications (id, category, severity, notification_key, title, message, action_url, reference_type, reference_id, company_id, created_at, expires_at) FROM stdin;
7512898a-4fcd-4fa1-a101-44475c48d775	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-29 13:10:03.374+00	\N
6e275de4-8c59-4e96-a294-7339888da8c9	HEALTH	HIGH	api_error_rate_high	API error rate elevated	22 server errors recorded since the last health check.	\N	\N	\N	\N	2026-05-29 13:20:00.261+00	\N
988d51a1-4f52-4263-a38f-046518af50c9	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-29 16:10:00.174+00	\N
a59f029f-0d80-4d3b-bce1-9b6237e75eac	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 83% across 1 cores.	\N	\N	\N	\N	2026-05-29 19:10:00.168+00	\N
cf9a9ae7-9fe7-4c66-bfdf-d81f9fa7debe	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 92% across 1 cores.	\N	\N	\N	\N	2026-05-29 21:10:00.177+00	\N
baa3564b-c282-4603-a6de-d14dbdb51a95	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-29 23:05:00.764+00	\N
ab23c7b0-0a64-4f6b-840d-0ad486c32f20	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-30 03:25:00.473+00	\N
c012adf6-7fb9-462f-a37c-788a34758079	HEALTH	HIGH	api_error_rate_high	API error rate elevated	11 server errors recorded since the last health check.	\N	\N	\N	\N	2026-05-30 03:40:00.177+00	\N
29fcc7d0-78ca-4f0e-ae35-74bc142c0951	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-30 06:30:01.367+00	\N
78311217-4b67-4722-b318-72303e246279	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-30 08:15:00.555+00	\N
cc56c267-0a05-4f18-94b4-0ecdb47c9f9c	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-30 09:20:00.272+00	\N
69257c4d-d072-44b7-b8c5-75bdc43c3f31	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-30 11:05:00.279+00	\N
62f8e59b-df44-4e4c-9dbc-2edaacc14332	HEALTH	HIGH	api_error_rate_high	API error rate elevated	10 server errors recorded since the last health check.	\N	\N	\N	\N	2026-05-30 11:50:00.159+00	\N
31a21a00-dc3e-469a-81fa-30ba5735d9eb	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-30 12:05:00.966+00	\N
c2aba90f-1e3a-4794-bb00-5271917868be	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 83% across 1 cores.	\N	\N	\N	\N	2026-05-30 18:15:00.046+00	\N
bfbdfd11-e07a-44b2-9f02-a7bad1e07a7e	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 95% across 1 cores.	\N	\N	\N	\N	2026-05-30 21:05:00.098+00	\N
9178c1e7-3bb2-4b6c-9b25-bb0136c08ee2	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 91% across 1 cores.	\N	\N	\N	\N	2026-05-31 00:15:00.119+00	\N
77ddf472-95ef-4bfb-8b4a-e8b3cbba4205	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-31 09:10:00.157+00	\N
c595d8a1-cf1c-40f7-b8d3-6a805c1e376e	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 91% across 1 cores.	\N	\N	\N	\N	2026-05-31 14:10:00.5+00	\N
7edd59d2-d788-4a58-b456-2a3577e9100d	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-05-31 16:55:00.052+00	\N
eb706d31-2eec-41fb-a2e9-18c4f6b80834	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 85% across 1 cores.	\N	\N	\N	\N	2026-05-31 22:05:00.188+00	\N
50258d48-cbe4-4cb8-b14e-c40170bae429	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 98% across 1 cores.	\N	\N	\N	\N	2026-06-01 23:05:00.102+00	\N
be218e23-f6c4-4868-9832-412c91c8e5cf	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 89% across 1 cores.	\N	\N	\N	\N	2026-06-03 02:10:00.134+00	\N
98796616-fc16-4ed4-b1cc-deca8ef32b5a	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 87% across 1 cores.	\N	\N	\N	\N	2026-06-03 08:30:00.16+00	\N
b39b492c-4388-46e6-bbe6-b82d2f197c74	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 94% across 1 cores.	\N	\N	\N	\N	2026-06-04 16:05:00.118+00	\N
92b4e54c-bbd1-44fb-adbd-27c3ad30d16e	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-04 20:05:00.04+00	\N
30bc6f6f-a2fa-4f63-89f6-d0924e64b0a5	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 95% across 1 cores.	\N	\N	\N	\N	2026-06-05 21:05:00.091+00	\N
c02e077b-3269-4b8c-9fc2-1812cf75f59e	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 98% across 1 cores.	\N	\N	\N	\N	2026-06-06 05:40:00.067+00	\N
a6dbf023-4cc7-4a6a-b13c-f1cffc5ba4d3	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 88% across 1 cores.	\N	\N	\N	\N	2026-06-07 07:50:00.081+00	\N
757b576e-c85b-4509-8d3d-7714e6ff39d7	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-08 03:10:00.035+00	\N
2a6d75d2-853f-4870-aaf9-771c036baf14	HEALTH	HIGH	api_error_rate_high	API error rate elevated	10 server errors recorded since the last health check.	\N	\N	\N	\N	2026-06-08 16:05:00.141+00	\N
37f6f7bd-5740-451b-a633-0b1958014e67	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-08 17:15:00.083+00	\N
b58b026c-94a9-4195-b15e-c8cf4cb7ed7f	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-09 02:05:00.08+00	\N
f9583fa4-bdff-4a9f-98a6-0691a8519499	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-09 03:50:00.056+00	\N
b2986b22-bd08-48d9-ae6f-c4fe19ab43ce	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-09 05:35:00.078+00	\N
7e6b58d4-b7cc-46f4-9c2e-dfd64fcb25a3	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-09 16:40:00.117+00	\N
850924fc-78ed-4a93-89ac-f1f4f6314ee4	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 81% across 1 cores.	\N	\N	\N	\N	2026-06-09 22:10:00.073+00	\N
17063c29-de89-4648-9414-4d928bed9610	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 84% across 1 cores.	\N	\N	\N	\N	2026-06-10 03:35:00.051+00	\N
828a1c93-27bc-4143-b021-cd9f0c58e32f	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 93% across 1 cores.	\N	\N	\N	\N	2026-06-10 04:40:00.108+00	\N
1e8c69f7-5fed-4815-95c5-fd1b00620422	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-10 08:35:00.12+00	\N
3f9fccfb-f3f7-4f78-9599-759a67850197	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-10 09:45:00.157+00	\N
e2171bf7-bd7f-4e07-ad00-a4cf352c7877	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-10 10:50:00.184+00	\N
3bca9302-d3cb-4b7c-90f6-7fa30c5419f3	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-10 13:00:00.214+00	\N
1d3d8173-2423-4126-94e9-5f024295693d	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-11 06:50:00.069+00	\N
ec6b07b2-c395-4cd9-8c3f-66d329f67db5	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-11 10:25:00.152+00	\N
54067ccf-5768-4f70-963d-2a03352a5b2b	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-11 12:05:00.139+00	\N
8281fb52-797f-486e-82d3-f1734eb32102	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-11 13:40:00.156+00	\N
77dd2a4a-547c-462f-8033-5eb7f5fe59c1	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 85% across 1 cores.	\N	\N	\N	\N	2026-06-11 15:50:00.171+00	\N
6387134a-71ca-42d5-b516-650c05ff508b	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 93% across 1 cores.	\N	\N	\N	\N	2026-06-12 03:05:00.115+00	\N
fd7c421a-08d3-45bb-b282-dc049ef4f352	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-12 04:05:00.352+00	\N
0d21ebdb-59b4-4362-8840-426bce172c55	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-12 05:35:00.161+00	\N
d8157786-b60a-4ab8-a546-7cca51cb680f	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-12 06:45:00.214+00	\N
4e25799a-2dfd-4169-b58a-fa1ff89bd005	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-12 08:55:00.149+00	\N
dbb025c0-157b-4f6f-81d7-ba00682165c3	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-12 10:55:00.128+00	\N
87f5727e-0ff8-4d5a-aa6e-04545398bc0e	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 94% across 1 cores.	\N	\N	\N	\N	2026-06-12 13:35:00.121+00	\N
8eb7d0e4-5676-47c1-94f5-ea21af853008	HEALTH	WARNING	server_cpu_high	Server CPU high	CPU load is 100% across 1 cores.	\N	\N	\N	\N	2026-06-13 06:40:00.192+00	\N
\.


--
-- Data for Name: po_cancel_verifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.po_cancel_verifications (id, po_id, user_id, reason, otp_hash, attempt_count, expires_at, consumed_at, created_at) FROM stdin;
6f2ac068-0f2b-4cd1-b0ce-b53adc5e0848	98d38f13-ae33-4bea-aa30-f5633f590ae8	47a8b4e9-c9ee-4239-b6c1-129e71d74587	canelled	4b941912b35d2e9efb8806d699ddeeb8ca47970d6e0f58c28baff2aae8e187cd	0	2026-05-26 15:25:45.551+00	\N	2026-05-26 15:15:45.552+00
\.


--
-- Data for Name: product_barcodes; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.product_barcodes (id, product_id, company_id, barcode, barcode_type, is_primary, created_at, supplier_id, updated_at) FROM stdin;
\.


--
-- Data for Name: product_plants; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.product_plants (id, product_id, shop_id, storage_location_id, opening_stock, min_stock_level, max_stock_level, reorder_qty, is_active, created_at, updated_at, created_by, updated_by, batch_number, expiry_date) FROM stdin;
0b65a4e7-194b-4df1-b5f5-cd86aa80dc1e	0f509c46-26de-435c-8e5c-6054e05f60a2	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	10.000	2.000	2.000	2.000	t	2026-05-25 16:00:17.464+00	2026-05-25 16:00:17.464+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
e219075e-3956-4867-ac41-1be7c8b0982f	be5bee46-21eb-47e0-98a2-8aeecde1e954	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	2.000	3.000	3.000	3.000	t	2026-05-25 16:00:18.915+00	2026-05-25 16:00:18.915+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
edb3a313-0f82-4708-9cc9-e1d778ead479	431b4546-2745-432c-8ebe-7c1d298450a0	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	23.000	4.000	4.000	4.000	t	2026-05-25 16:00:31.133+00	2026-05-25 16:00:31.133+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
b305656c-8824-4cd2-b802-c63c009f10f8	b5c9e408-27d3-4dba-b7dd-483825322976	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	54.000	4.000	4.000	4.000	t	2026-05-25 16:00:38.816+00	2026-05-25 16:00:38.816+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
64fb817f-8600-41e5-a5e4-4e213ddf8625	d493fddc-f3b3-4002-ba2a-bb5dc7e7df02	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	12.000	0.000	\N	\N	t	2026-05-25 16:00:47.233+00	2026-05-25 16:00:47.233+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
ee71391e-7816-456c-b70c-b5b0f9f78af5	63c5f664-dc5f-4a7f-abdd-b57561288775	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	22.000	4.000	4.000	4.000	t	2026-05-25 16:00:51.875+00	2026-05-25 16:00:51.875+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
ac957ab4-78f9-4053-96eb-087057018fa3	97fbabe5-c40e-466d-8a3d-0b1fcc1de16f	d53ce4ee-7da6-4709-b944-348687fb0843	6fc11bf0-7d35-445e-8077-0725a0285028	9.000	4.000	4.000	4.000	t	2026-05-25 16:00:57.396+00	2026-05-25 16:00:57.396+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
ab05c226-d9c8-4826-a92d-0adc3d7c3140	bd4951e4-39b2-4fdc-bc82-d7120963d4cd	d53ce4ee-7da6-4709-b944-348687fb0843	ba130361-208a-420e-a1a8-0d04b8028734	13.000	6.000	6.000	6.000	t	2026-05-25 16:01:04.971+00	2026-05-25 16:01:04.971+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
9415e5eb-f520-40df-8153-f6cccf314d71	c493edaf-78ef-4954-b311-3d45c05cfeaa	d53ce4ee-7da6-4709-b944-348687fb0843	ba130361-208a-420e-a1a8-0d04b8028734	7.000	7.000	7.000	7.000	t	2026-05-25 16:01:11.62+00	2026-05-25 16:01:11.62+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
8c9f5bb9-9c98-43d0-9d90-b91b8b1f0320	30e0ab96-c69d-466c-a806-6f05591d8733	d53ce4ee-7da6-4709-b944-348687fb0843	ba130361-208a-420e-a1a8-0d04b8028734	43.000	20.000	20.000	20.000	t	2026-05-25 16:01:16.16+00	2026-05-25 16:01:16.16+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
8c036e94-2574-44ed-abc5-d251dc0f37b8	ca4e1bca-91a2-4dbb-9886-869563a27c28	d53ce4ee-7da6-4709-b944-348687fb0843	ba130361-208a-420e-a1a8-0d04b8028734	2.000	1.000	1.000	1.000	t	2026-05-25 16:01:21.037+00	2026-05-25 16:01:21.037+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
9a546ae8-e908-4669-b2fb-df626209c5aa	343ccd4b-e7da-4108-a785-3de8313a96e3	d53ce4ee-7da6-4709-b944-348687fb0843	ba130361-208a-420e-a1a8-0d04b8028734	3.000	2.000	2.000	2.000	t	2026-05-25 16:01:23.33+00	2026-05-25 16:01:23.33+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
18afa261-5c98-4240-a58a-35a36db68dc6	fee8fa94-4b72-4796-943f-ac72ce47cea9	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	0.000	0.000	\N	\N	t	2026-05-27 11:35:08.384+00	2026-05-29 07:14:40.365+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
fed9ba29-6ab4-49c8-9802-f273e2688e15	1a84efe0-44bc-4661-ba46-ac6b5a2bcd0f	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	50.000	100.000	200.000	10.000	t	2026-05-26 16:17:09.292+00	2026-05-29 11:21:09.88+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
475f112a-6a87-4e58-a5f8-aab8cee67c5c	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	50.000	100.000	200.000	25.000	t	2026-05-26 16:17:09.276+00	2026-05-29 11:21:23.976+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
fb1037ce-4dc8-4d6d-b948-eff082d7ff69	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	5c1f22f6-978a-43fe-ad41-28359edf08d4	f3bd7054-d585-468c-9c6f-6bb5e42b6a51	0.000	10.000	100.000	\N	t	2026-05-29 13:56:01.989+00	2026-05-30 03:20:29.134+00	6fd97d36-05d1-4617-8c81-0d54da73ace8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
cb93d00a-334f-4f77-b7a6-1a517ecbe88e	57812718-33b2-4585-ba16-e4a95bec7405	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-25 05:08:30.315+00	2026-05-30 06:26:14.856+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
3df19130-1e1d-4b1c-a476-a67d9bbb63a6	53457790-5c18-4f3a-a2d6-709ded27ed4a	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-25 14:26:24.992+00	2026-05-30 06:26:14.863+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
4f0ada20-ff5d-487d-9296-7f937d178629	b4c7a727-2f6f-4d16-8427-36216992f608	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:14.868+00	2026-05-30 06:26:14.868+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
e8277c37-d4f3-47e6-8c4b-09c04b7a8fbc	e7e3101d-ad0a-457b-8dff-47ff94eb2115	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:14.876+00	2026-05-30 06:26:14.876+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
e27e2763-a10b-43e9-b4be-8016db5f9be1	a451dcc4-9d0a-4c0c-a847-3e5a39e85339	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:14.961+00	2026-05-30 06:26:14.961+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
ffd75ab9-3909-46ec-8be1-2c94b95f0bfd	60642c3d-ad8a-426a-89c0-ad59ef88f62e	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:14.968+00	2026-05-30 06:26:14.968+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
d24508f2-7f71-433f-9d73-927804147f40	add88489-a8a6-4bc6-abc5-0d91fecf1b7b	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:14.976+00	2026-05-30 06:26:14.976+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
748d3299-9024-49db-84f3-da4a1c6274ab	92e4a71c-947a-495f-94d2-3c33c51e5ca4	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.068+00	2026-05-30 06:26:15.068+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
03f28ed7-471a-489e-aa2a-7d6d28b3866f	fe4dbc08-ff7b-4128-a74a-cb6122bc8c45	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.155+00	2026-05-30 06:26:15.155+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
fb02b33c-7d8b-46de-8091-c5c23f1a901f	5bb37879-54d6-414a-9351-7bb0a00af64d	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.176+00	2026-05-30 06:26:15.176+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
fcb7b6dd-ae4a-44c9-97e6-3b946d78be50	56067187-64bf-4352-bac8-60bdd362289c	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.363+00	2026-05-30 06:26:15.363+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
dbf43270-bc45-4695-b2e1-76afe4911fb7	c42488c4-d527-4ece-93a4-4d649a6c9129	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.372+00	2026-05-30 06:26:15.372+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
bb6d74c8-1b55-470f-9c94-d162c04e9f20	ced5f709-365e-4039-965b-583e052cab41	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.38+00	2026-05-30 06:26:15.38+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
90248a3f-4a2d-42c6-92eb-a9e2795cf3b0	947950bc-0c56-426e-b8cc-a5c61d413b8f	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.466+00	2026-05-30 06:26:15.466+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
8151df69-f86a-4552-9ec3-480a34eba03c	7dd6f5ce-d7cb-4383-9fd1-10a8fdb6a5ee	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.474+00	2026-05-30 06:26:15.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
efd9c77d-eae9-4344-9860-4944088ff8ff	709c8e28-4744-41bf-9aba-4e5f53b1432d	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.557+00	2026-05-30 06:26:15.557+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
7f9d19cb-7701-42c9-b659-8546055c3501	ddecac3f-b99f-4028-95d4-48e0268f2153	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.565+00	2026-05-30 06:26:15.565+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
3f9a05c4-8b32-47cb-bdb8-f0aecc850558	89392013-2725-458b-b6ce-5027500fbe8a	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.572+00	2026-05-30 06:26:15.572+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
ee81acb2-1a10-4737-bb4d-daccd0a52b9a	70d1e807-0a90-4643-be02-018fbfdb745d	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.578+00	2026-05-30 06:26:15.578+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
bfc20b57-e82c-4f35-817b-f5e169c2864c	137584c8-4e2e-4728-ab54-c4ce6c3121c5	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.664+00	2026-05-30 06:26:15.664+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
221ec3b6-ce88-45a4-aa3c-9cc57ffa27ae	2a41e7a6-7006-4223-b53d-1a1ce1a74338	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.673+00	2026-05-30 06:26:15.673+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
604b3834-1d6e-4689-84cc-e6259ab129f1	26c9b0d4-e1ab-499a-9bcd-1203fe468e74	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.758+00	2026-05-30 06:26:15.758+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
b3b789d8-9c0e-49ba-9858-e8f66907abac	2865b727-52a0-4e2c-8219-bbf506e719a3	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.771+00	2026-05-30 06:26:15.771+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
335f602d-9e05-493c-bbaf-f149bc1c2282	83147109-d755-4af1-b561-b80e1c2ab864	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.858+00	2026-05-30 06:26:15.858+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
1f3196db-514d-43e6-bf20-94c4e88585cc	0775b9c4-857f-42a9-ba9f-60277c6772ba	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.865+00	2026-05-30 06:26:15.865+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
7761e302-cfbf-4c74-97a2-5b8ed197648a	1332d491-a6ff-4737-b43b-4432cbb7b7ea	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.873+00	2026-05-30 06:26:15.873+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
90dc825b-ac34-434f-a740-19b46a34b682	f579b9a5-f77f-4214-afc4-105a10e27b44	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.88+00	2026-05-30 06:26:15.88+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
4745c9e7-789e-4276-b639-62555e9b266b	3055eb4d-75db-480d-b6dc-b20d25e3576d	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.964+00	2026-05-30 06:26:15.964+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
51608af0-534b-46f4-851b-683b2a508aa8	c5870b7b-8319-431c-81ba-3407e4397ecf	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.97+00	2026-05-30 06:26:15.97+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
69b1baef-8d81-4b64-829b-22a76ec73348	eefc1e76-84a1-4c6d-b11b-86223914651b	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:15.976+00	2026-05-30 06:26:15.976+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
0288487d-abc3-4519-b84a-0bc060375bec	929b6999-db64-4f30-b76e-b5ad0ab5677a	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.06+00	2026-05-30 06:26:16.06+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
bc34db43-9799-4461-ab91-cad77b509c35	94864a35-c94d-42d4-82e0-a6169bcbb6d5	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.068+00	2026-05-30 06:26:16.068+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
6176a182-73f4-4550-8009-79b1576830d8	21da1aac-b7e6-4fbe-8416-0c389669f282	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.074+00	2026-05-30 06:26:16.074+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
c3c38830-58b2-4a57-82ac-e2ad1077be51	6e99de95-02c3-4892-a626-8c76970410c2	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.159+00	2026-05-30 06:26:16.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
e65fa35a-1ba6-40b0-ba00-0867276c2ba4	fbe146a7-6f73-4f67-b6ca-866a381ea033	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.167+00	2026-05-30 06:26:16.167+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
1bbdc1ba-6f20-42d5-a03f-1a180ce36025	f9011ebd-1097-45f8-80bf-12ef2746c1a0	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.173+00	2026-05-30 06:26:16.173+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
32089123-2101-4fdc-a9ef-6e6e8346e4d4	6fc077a8-77b6-4906-a2bf-b794fa9fec9f	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.18+00	2026-05-30 06:26:16.18+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
4a9a3dfe-b3bc-4cd1-a6fb-47efd5e8db1f	0b6246e9-57cf-42fb-a2ba-ac4d1c05c6e1	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.263+00	2026-05-30 06:26:16.263+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
ee243769-cc9e-4f85-a556-c72abba8d7aa	e97a9191-4f78-41fe-a426-96d26c1518b9	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.27+00	2026-05-30 06:26:16.27+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
9a103f71-bf17-45df-ad45-da38c7e5ae37	fb0fe073-f3f9-490b-88ad-a6df8e78a816	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	69dcad3c-97ea-435f-a7b7-a1b59e7ed543	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.359+00	2026-05-30 06:26:16.359+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
5cb4dbb7-9701-4e43-bd19-8e5785c74e71	5c091a8e-b426-4419-b6b4-220a3f5a8b12	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.365+00	2026-05-30 06:26:16.365+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
e98a1db1-c794-4ba2-b202-01e4fbdee719	0459f473-75f9-463a-8237-9ca65fee69f8	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.372+00	2026-05-30 06:26:16.372+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
4a324538-e857-4d48-b207-2f12563249a0	6344a746-687f-48d0-af2e-329cc0932fc7	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.379+00	2026-05-30 06:26:16.379+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
a4c329dc-03e7-48d5-ae20-05f4b3d3e00e	166c4ba0-232b-484f-ad54-fab5379410fa	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ab3136e9-4be0-4ab4-bc36-0674a01fe524	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.465+00	2026-05-30 06:26:16.465+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
dbc9093c-aaf8-4062-9cb4-b8907065cd61	2d8107ad-f2ff-4862-b269-9b274a65b530	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.473+00	2026-05-30 06:26:16.473+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
cccbc295-8fb5-4007-96a3-251c1e39c901	6cf057a6-6a6e-46ac-be49-a0417acd71c3	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.556+00	2026-05-30 06:26:16.556+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
5296e640-df03-4de9-8189-aec2ec6105f6	b196efdd-24e4-4435-a798-aab2e1ec69a0	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.565+00	2026-05-30 06:26:16.565+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
169be7a1-6ddc-4080-b56c-a091356b685e	8c42805b-90f8-4c3d-9784-b6821ad9272a	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.572+00	2026-05-30 06:26:16.572+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
cfd697e7-9a4e-44be-8b38-685218ee9331	7a494ea2-2cf1-419c-ba0a-37da9f178b41	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.656+00	2026-05-30 06:26:16.656+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
5e08a571-2079-4005-830d-bb24caf062d7	f9865733-a9f7-44f6-a031-9c3925042cea	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	100.000	20.000	500.000	50.000	t	2026-05-30 06:26:16.668+00	2026-05-30 06:26:16.668+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
191e64fc-1e79-4ec9-94a6-d997a0bce4c0	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	0.000	0.000	\N	\N	t	2026-06-09 02:06:26.48+00	2026-06-09 02:06:26.48+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
e55a549a-328f-47b8-85af-f26b8dc9771a	7d7b83e4-c8ca-49c8-8de1-f3f83b660c9b	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	0.000	0.000	\N	\N	t	2026-06-12 07:02:46.155+00	2026-06-12 07:02:46.155+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
e56d6479-a0a2-40d3-b298-7f10bd8d315c	bafbf5b3-8550-44fe-956b-9fcc31a13560	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	0.000	5.000	\N	\N	t	2026-06-13 09:35:54.409+00	2026-06-13 09:35:54.409+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
8a9992b6-8042-4090-97f9-d617969030f2	52443e8d-a006-42c7-a450-b9fffd24dd3d	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	0.000	5.000	\N	\N	t	2026-06-13 09:36:40.133+00	2026-06-13 09:36:40.133+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
\.


--
-- Data for Name: product_specifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.product_specifications (id, product_id, label, value, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.products (id, product_code, description, uom, category, hsn_code, material_group, drawing_reference, brand, tax_preference, purchase_price, selling_price, is_active, created_at, updated_at, created_by, updated_by, gst_rate, image_url, thumbnail_url) FROM stdin;
0f509c46-26de-435c-8e5c-6054e05f60a2	PRD002	TV Point	pcs	Electrical	84314900	\N	\N	Sample Brand	TAXABLE	100.00	120.00	t	2026-05-25 16:00:17.464+00	2026-05-25 16:00:17.464+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
be5bee46-21eb-47e0-98a2-8aeecde1e954	PRD003	Data Point	pcs	Electrical	84314901	Consumables	DWG-100	\N	NON_TAXABLE	250.00	299.00	t	2026-05-25 16:00:18.915+00	2026-05-25 16:00:18.915+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
431b4546-2745-432c-8ebe-7c1d298450a0	PRD004	Light Point	Pag	Electrical	84314902	Consumables	\N	BOSCH	TAXABLE	400.00	478.00	t	2026-05-25 16:00:31.133+00	2026-05-25 16:00:31.133+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
b5c9e408-27d3-4dba-b7dd-483825322976	PRD005	AC Point	pcs	Electrical	84314903	Consumables	\N	CHINA	TAXABLE	550.00	657.00	t	2026-05-25 16:00:38.816+00	2026-05-25 16:00:38.816+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
d493fddc-f3b3-4002-ba2a-bb5dc7e7df02	PRD006	Light switch	pcs	Electrical	84314904	Consumables	\N	CHINA	TAXABLE	700.00	836.00	t	2026-05-25 16:00:47.233+00	2026-05-25 16:00:47.233+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
63c5f664-dc5f-4a7f-abdd-b57561288775	PRD007	Fan Point	pcs	Electrical	84314905	Consumables	\N	BOSCH	TAXABLE	850.00	1015.00	t	2026-05-25 16:00:51.875+00	2026-05-25 16:00:51.875+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
97fbabe5-c40e-466d-8a3d-0b1fcc1de16f	PRD008	Door cam	pcs	Electrical	84314906	Consumables	\N	DELL	TAXABLE	1000.00	1194.00	t	2026-05-25 16:00:57.396+00	2026-05-25 16:00:57.396+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
bd4951e4-39b2-4fdc-bc82-d7120963d4cd	PRD009	Light switch dobuleside	pcs	Electrical	84314907	Consumables	\N	DELL	TAXABLE	1150.00	1373.00	t	2026-05-25 16:01:04.971+00	2026-05-25 16:01:04.971+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
c493edaf-78ef-4954-b311-3d45c05cfeaa	PRD010	Additional Point 1	pcs	Electrical	84314908	Consumables	\N	LOCAL	TAXABLE	1300.00	1552.00	t	2026-05-25 16:01:11.62+00	2026-05-25 16:01:11.62+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
30e0ab96-c69d-466c-a806-6f05591d8733	PRD011	Additional Point 2	pag	Electrical	84314909	Consumables	\N	LOCAL	TAXABLE	1450.00	1731.00	t	2026-05-25 16:01:16.16+00	2026-05-25 16:01:16.16+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
ca4e1bca-91a2-4dbb-9886-869563a27c28	PRD012	Brake hold down spring tool	pcs	Auto Tools	84314910	Consumables	\N	LOCAL	TAXABLE	1600.00	1910.00	t	2026-05-25 16:01:21.037+00	2026-05-25 16:01:21.037+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	0.0000	\N	\N
343ccd4b-e7da-4108-a785-3de8313a96e3	PRD013	1/4" Deep and shallow set 5.5-13mm1	pcs	Auto Tools	84314911	Consumables	\N	BOSCH	TAXABLE	1750.00	2089.00	f	2026-05-25 16:01:23.33+00	2026-05-25 16:06:00.432+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587	0.0000	\N	\N
ddecac3f-b99f-4028-95d4-48e0268f2153	ELE017	Industrial Socket 16A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	260.00	340.00	t	2026-05-30 06:26:15.565+00	2026-05-30 06:26:15.565+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
1a84efe0-44bc-4661-ba46-ac6b5a2bcd0f	PRO02	Sample product B	pcs	Grocery	84314900	Consumables	DWG-100	Sample Brand1	NON_TAXABLE	180.00	200.00	t	2026-05-26 16:17:09.292+00	2026-05-29 11:21:09.877+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	0.0000	\N	\N
57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	PRO01	Sample product A	pcs	Grocery	84314900	Consumables	DWG-101	Sample Brand	TAXABLE	90.00	100.00	t	2026-05-26 16:17:09.276+00	2026-05-29 11:21:23.972+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	0.0000	\N	\N
fee8fa94-4b72-4796-943f-ac72ce47cea9	SVC-HQ001	Service line (PO)	EA	Service	995422	\N	\N	\N	TAXABLE	0.00	0.00	f	2026-05-27 11:35:08.384+00	2026-05-29 13:47:41.024+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	0.0000	\N	\N
1f99fcd4-52c2-4c2c-a79d-132838abe2d0	AUT001	Diesel Engine	pcs	Automotive	840790	Automobile	\N	\N	TAXABLE	50000.00	70000.00	t	2026-05-29 13:56:01.989+00	2026-05-30 03:20:29.131+00	6fd97d36-05d1-4617-8c81-0d54da73ace8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	0.0000	\N	\N
57812718-33b2-4585-ba16-e4a95bec7405	ELE001	LED Bulb 9W	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	70.00	90.00	t	2026-05-25 05:08:30.315+00	2026-05-30 06:26:14.777+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	0.0000	\N	\N
53457790-5c18-4f3a-a2d6-709ded27ed4a	ELE002	LED Tube Light 20W	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	180.00	240.00	t	2026-05-25 14:26:24.992+00	2026-05-30 06:26:14.861+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	0.0000	\N	\N
b4c7a727-2f6f-4d16-8427-36216992f608	ELE003	Ceiling Fan 1200mm	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1400.00	1750.00	t	2026-05-30 06:26:14.868+00	2026-05-30 06:26:14.868+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
e7e3101d-ad0a-457b-8dff-47ff94eb2115	ELE004	Modular Switch 6A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	25.00	35.00	t	2026-05-30 06:26:14.876+00	2026-05-30 06:26:14.876+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
a451dcc4-9d0a-4c0c-a847-3e5a39e85339	ELE005	Modular Socket 6A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	40.00	55.00	t	2026-05-30 06:26:14.961+00	2026-05-30 06:26:14.961+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
60642c3d-ad8a-426a-89c0-ad59ef88f62e	ELE006	Copper Wire 1.5 Sq.mm	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1200.00	1450.00	t	2026-05-30 06:26:14.968+00	2026-05-30 06:26:14.968+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
add88489-a8a6-4bc6-abc5-0d91fecf1b7b	ELE007	Copper Wire 2.5 Sq.mm	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	2000.00	2450.00	t	2026-05-30 06:26:14.976+00	2026-05-30 06:26:14.976+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
92e4a71c-947a-495f-94d2-3c33c51e5ca4	ELE008	MCB 32A SP	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	180.00	240.00	t	2026-05-30 06:26:15.068+00	2026-05-30 06:26:15.068+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
fe4dbc08-ff7b-4128-a74a-cb6122bc8c45	ELE009	Distribution Board 8 Way	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	850.00	1100.00	t	2026-05-30 06:26:15.155+00	2026-05-30 06:26:15.155+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
5bb37879-54d6-414a-9351-7bb0a00af64d	ELE010	PVC Conduit Pipe	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	120.00	160.00	t	2026-05-30 06:26:15.176+00	2026-05-30 06:26:15.176+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
56067187-64bf-4352-bac8-60bdd362289c	ELE011	LED Flood Light 50W	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	950.00	1250.00	t	2026-05-30 06:26:15.363+00	2026-05-30 06:26:15.363+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
c42488c4-d527-4ece-93a4-4d649a6c9129	ELE012	LED Street Light 100W	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	2200.00	2800.00	t	2026-05-30 06:26:15.372+00	2026-05-30 06:26:15.372+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
ced5f709-365e-4039-965b-583e052cab41	ELE013	Exhaust Fan 9 Inch	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	850.00	1100.00	t	2026-05-30 06:26:15.38+00	2026-05-30 06:26:15.38+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
947950bc-0c56-426e-b8cc-a5c61d413b8f	ELE014	Fan Regulator	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	140.00	190.00	t	2026-05-30 06:26:15.466+00	2026-05-30 06:26:15.466+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
7dd6f5ce-d7cb-4383-9fd1-10a8fdb6a5ee	ELE015	Door Bell	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	180.00	250.00	t	2026-05-30 06:26:15.474+00	2026-05-30 06:26:15.474+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
709c8e28-4744-41bf-9aba-4e5f53b1432d	ELE016	Industrial Plug 16A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	220.00	290.00	t	2026-05-30 06:26:15.557+00	2026-05-30 06:26:15.557+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
89392013-2725-458b-b6ce-5027500fbe8a	ELE018	Cable Tie Pack	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	45.00	65.00	t	2026-05-30 06:26:15.572+00	2026-05-30 06:26:15.572+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
70d1e807-0a90-4643-be02-018fbfdb745d	ELE019	Insulation Tape	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	12.00	20.00	t	2026-05-30 06:26:15.578+00	2026-05-30 06:26:15.578+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
137584c8-4e2e-4728-ab54-c4ce6c3121c5	ELE020	Junction Box	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	55.00	75.00	t	2026-05-30 06:26:15.664+00	2026-05-30 06:26:15.664+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
2a41e7a6-7006-4223-b53d-1a1ce1a74338	ELE021	LED Panel Light 15W	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	450.00	620.00	t	2026-05-30 06:26:15.673+00	2026-05-30 06:26:15.673+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
26c9b0d4-e1ab-499a-9bcd-1203fe468e74	ELE022	LED Downlight 12W	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	220.00	310.00	t	2026-05-30 06:26:15.758+00	2026-05-30 06:26:15.758+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
2865b727-52a0-4e2c-8219-bbf506e719a3	ELE023	Emergency Light	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	650.00	850.00	t	2026-05-30 06:26:15.771+00	2026-05-30 06:26:15.771+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
83147109-d755-4af1-b561-b80e1c2ab864	ELE024	Rechargeable Torch	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	320.00	450.00	t	2026-05-30 06:26:15.858+00	2026-05-30 06:26:15.858+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
0775b9c4-857f-42a9-ba9f-60277c6772ba	ELE025	Changeover Switch 63A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1800.00	2400.00	t	2026-05-30 06:26:15.865+00	2026-05-30 06:26:15.865+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
1332d491-a6ff-4737-b43b-4432cbb7b7ea	ELE026	ELCB 40A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	950.00	1250.00	t	2026-05-30 06:26:15.873+00	2026-05-30 06:26:15.873+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
f579b9a5-f77f-4214-afc4-105a10e27b44	ELE027	RCCB 63A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1350.00	1700.00	t	2026-05-30 06:26:15.88+00	2026-05-30 06:26:15.88+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
3055eb4d-75db-480d-b6dc-b20d25e3576d	ELE028	Contactor 32A	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1100.00	1450.00	t	2026-05-30 06:26:15.964+00	2026-05-30 06:26:15.964+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
c5870b7b-8319-431c-81ba-3407e4397ecf	ELE029	Overload Relay	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	750.00	980.00	t	2026-05-30 06:26:15.97+00	2026-05-30 06:26:15.97+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
eefc1e76-84a1-4c6d-b11b-86223914651b	ELE030	Push Button Switch	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	65.00	95.00	t	2026-05-30 06:26:15.976+00	2026-05-30 06:26:15.976+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
929b6999-db64-4f30-b76e-b5ad0ab5677a	ELE031	Digital Multimeter	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	450.00	650.00	t	2026-05-30 06:26:16.06+00	2026-05-30 06:26:16.06+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
94864a35-c94d-42d4-82e0-a6169bcbb6d5	ELE032	Clamp Meter	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1200.00	1550.00	t	2026-05-30 06:26:16.068+00	2026-05-30 06:26:16.068+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
21da1aac-b7e6-4fbe-8416-0c389669f282	ELE033	Voltage Tester	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	90.00	140.00	t	2026-05-30 06:26:16.074+00	2026-05-30 06:26:16.074+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
6e99de95-02c3-4892-a626-8c76970410c2	ELE034	Cable Gland	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	18.00	30.00	t	2026-05-30 06:26:16.159+00	2026-05-30 06:26:16.159+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
fbe146a7-6f73-4f67-b6ca-866a381ea033	ELE035	Copper Lug 25mm	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	12.00	20.00	t	2026-05-30 06:26:16.167+00	2026-05-30 06:26:16.167+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
f9011ebd-1097-45f8-80bf-12ef2746c1a0	ELE036	Copper Lug 50mm	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	25.00	40.00	t	2026-05-30 06:26:16.173+00	2026-05-30 06:26:16.173+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
6fc077a8-77b6-4906-a2bf-b794fa9fec9f	ELE037	LED Rope Light	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	550.00	750.00	t	2026-05-30 06:26:16.18+00	2026-05-30 06:26:16.18+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
0b6246e9-57cf-42fb-a2ba-ac4d1c05c6e1	ELE038	LED Strip Light 5m	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	700.00	950.00	t	2026-05-30 06:26:16.263+00	2026-05-30 06:26:16.263+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
e97a9191-4f78-41fe-a426-96d26c1518b9	ELE039	Sensor Light	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	480.00	650.00	t	2026-05-30 06:26:16.27+00	2026-05-30 06:26:16.27+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
fb0fe073-f3f9-490b-88ad-a6df8e78a816	ELE040	Garden Light	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	850.00	1150.00	t	2026-05-30 06:26:16.359+00	2026-05-30 06:26:16.359+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
5c091a8e-b426-4419-b6b4-220a3f5a8b12	ELE041	Motor Starter DOL	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	2200.00	2800.00	t	2026-05-30 06:26:16.365+00	2026-05-30 06:26:16.365+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
0459f473-75f9-463a-8237-9ca65fee69f8	ELE042	Timer Switch	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	450.00	620.00	t	2026-05-30 06:26:16.372+00	2026-05-30 06:26:16.372+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
6344a746-687f-48d0-af2e-329cc0932fc7	ELE043	Selector Switch	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	85.00	120.00	t	2026-05-30 06:26:16.379+00	2026-05-30 06:26:16.379+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
166c4ba0-232b-484f-ad54-fab5379410fa	ELE044	Control Transformer	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	950.00	1250.00	t	2026-05-30 06:26:16.465+00	2026-05-30 06:26:16.465+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
2d8107ad-f2ff-4862-b269-9b274a65b530	ELE045	Flexible Conduit	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	180.00	240.00	t	2026-05-30 06:26:16.473+00	2026-05-30 06:26:16.473+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
6cf057a6-6a6e-46ac-be49-a0417acd71c3	ELE046	Cable Tray	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	650.00	850.00	t	2026-05-30 06:26:16.556+00	2026-05-30 06:26:16.556+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
b196efdd-24e4-4435-a798-aab2e1ec69a0	ELE047	Earth Rod	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	420.00	580.00	t	2026-05-30 06:26:16.565+00	2026-05-30 06:26:16.565+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
8c42805b-90f8-4c3d-9784-b6821ad9272a	ELE048	Lightning Arrester	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	3200.00	4000.00	t	2026-05-30 06:26:16.572+00	2026-05-30 06:26:16.572+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
7a494ea2-2cf1-419c-ba0a-37da9f178b41	ELE049	Busbar Copper	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1800.00	2300.00	t	2026-05-30 06:26:16.656+00	2026-05-30 06:26:16.656+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
f9865733-a9f7-44f6-a031-9c3925042cea	ELE050	Power Capacitor	pcs	Electrical	8536	Electrical Items	\N	Havells	TAXABLE	1450.00	1850.00	t	2026-05-30 06:26:16.668+00	2026-05-30 06:26:16.668+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
96718ee2-4ff3-4de9-bf6f-7bc023e8338f	SVC-PL003	Service line (PO)	EA	Service	\N	\N	\N	\N	TAXABLE	0.00	0.00	t	2026-06-09 02:06:26.48+00	2026-06-09 02:06:26.48+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
7d7b83e4-c8ca-49c8-8de1-f3f83b660c9b	8902979022682	Meera shampoo	UNIT	GENERAL	\N	\N	\N	\N	TAXABLE	1.50	2.00	t	2026-06-12 07:02:46.155+00	2026-06-12 07:02:46.155+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
bafbf5b3-8550-44fe-956b-9fcc31a13560	E2E-SKU-1781343354	E2E Test	PCS	e2e	\N	\N	\N	\N	TAXABLE	100.00	150.00	t	2026-06-13 09:35:54.409+00	2026-06-13 09:35:54.409+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
52443e8d-a006-42c7-a450-b9fffd24dd3d	E2E-SKU-1781343400	E2E Test	PCS	e2e	\N	\N	\N	\N	TAXABLE	100.00	150.00	t	2026-06-13 09:36:40.133+00	2026-06-13 09:36:40.133+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	\N	\N
\.


--
-- Data for Name: purchase_order_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.purchase_order_header (id, po_number, po_date, shop_id, rfq_id, contract_id, supplier, status, remarks, currency, fx_rate_used, discount_amount, tax_amount, total_value, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
d62e1dc9-f157-4ce1-9aad-788ae4e5f9d2	PO-HQ001-202605-00001	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e3ba67e8-f91b-4d30-90d8-1c0b3a338774	e7b2d519-f497-4d56-b8bb-199d5381f5a3	Bharat Electricals Supply	CONFIRMED	Auto-generated from quotation QUO-HQ001-202605-00001	USD	\N	0.00	0.00	99.00	2026-05-25 05:28:26.483+00	2026-05-25 05:28:26.483+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
58c296bd-7d95-40cb-a083-15e50c03b941	PO-HQ001-202605-00002	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	cbba0db5-cda0-4cfc-97df-26985042ff4d	966015a8-2576-4b9a-a415-67aab1ae9c7d	Bharat Electricals Supply	CONFIRMED	Auto-generated from quotation QUO-HQ001-202605-00002	USD	\N	0.00	0.00	2600.00	2026-05-25 06:01:34.406+00	2026-05-25 06:01:34.406+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
d16a81c5-d5e6-4a5e-ae2c-85069bf8cea6	PO-HQ001-202605-00003	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	5daf69be-ed64-4841-931e-0de22ee61183	3187e01c-3304-43f7-8e78-e1e73743879d	Bharat Electricals Supply	CONFIRMED	Auto-generated from quotation QUO-HQ001-202605-00003	USD	\N	0.00	0.00	500.00	2026-05-25 06:10:15.635+00	2026-05-25 06:10:15.635+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
a0305a74-81dc-44c7-b479-93732db5d98e	PO-HQ001-202605-00005	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	8e4dcbdf-a386-42b6-916c-ff4d83490d15	c0f121eb-b090-446c-8322-bfd1d832eee6	Heaven Electrical Supply	CONFIRMED	Auto-generated from quotation QUO-HQ001-202605-00004	USD	\N	0.00	0.00	200.00	2026-05-25 15:48:10.512+00	2026-05-25 15:48:10.512+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
0b050ead-40cc-4b1d-9228-480db2ea54f4	PO-HQ001-202605-00006	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e890e821-c818-46b4-9e4b-bda34532983d	b440d2ed-42d3-45c5-a2c1-90978429a616	Heaven Electrical Supply	CONFIRMED	Auto-generated from quotation QUO-HQ001-202605-00006	USD	\N	0.00	0.00	8000.00	2026-05-25 16:16:13.412+00	2026-05-25 16:16:13.412+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
950a2f19-23be-47c3-8cbd-7db822639954	PO-HQ001-202605-00004	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipVia":"DHL — Domestic & international express","shippingTerms":"Collect — Buyer pays on delivery","lineItemTaxes":[{"productId":"53457790-5c18-4f3a-a2d6-709ded27ed4a","taxPercent":18},{"productId":"57812718-33b2-4585-ba16-e4a95bec7405","taxPercent":18}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	1100.00	2026-05-25 14:52:10.231+00	2026-05-25 16:16:33.964+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1
c0322c43-144e-416e-8ccc-005b82f19897	PO-HQ001-202605-00007	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	c0f121eb-b090-446c-8322-bfd1d832eee6	Bharat Electricals Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipVia":"DHL — Domestic & international express","fob":"FOB Origin, Freight Collect","shippingTerms":"Third Party — Billed to third party","lineItemTaxes":[{"productId":"57812718-33b2-4585-ba16-e4a95bec7405","taxPercent":18}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	500.00	2026-05-25 17:56:43.75+00	2026-05-26 07:26:25.104+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1
c5973c42-3a93-484d-ac68-c64ca799accc	PO-HQ001-202605-00008	2026-05-27	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	10328047-043e-4df1-8fee-a011284c0bed	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"53457790-5c18-4f3a-a2d6-709ded27ed4a","taxPercent":0}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	15000.00	2026-05-26 07:55:03.946+00	2026-05-26 07:55:40.523+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1
7bfd4712-c3e3-4481-b439-cdcc0c189522	PO-REVATH001-202605-00001	2026-05-29	d53ce4ee-7da6-4709-b944-348687fb0843	\N	\N	Nadar depart store	DRAFT	<!--PO_DOCUMENT:{"requisitioner":"Sami","paymentTerms":"Net 30","shipVia":"Buyer's carrier — Buyer arranges","lineItemTaxes":[{"productId":"c493edaf-78ef-4954-b311-3d45c05cfeaa","taxPercent":0},{"productId":"d493fddc-f3b3-4002-ba2a-bb5dc7e7df02","taxPercent":18},{"productId":"d493fddc-f3b3-4002-ba2a-bb5dc7e7df02","taxPercent":10}],"shipToName":"Kumar","shipToCompany":"Head Office","shipToAddress":"Near Police quoters road, Ganapathy","shipToPhone":"9566376859","contactName":"Kumar","contactPhone":"9566376859","contactEmail":"swamiedge@gmail.com"}-->	USD	\N	0.00	0.00	28700.00	2026-05-26 12:59:49.083+00	2026-05-26 12:59:49.083+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	SNAPSHOT	\N	\N	1
84ba57d6-7085-46b5-863e-cf279a415a11	PO-REVATH001-202605-00002	2026-05-27	d53ce4ee-7da6-4709-b944-348687fb0843	\N	\N	Nadar depart store	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Sami","paymentTerms":"Net 30","shipVia":"Hand carry / Pickup — Collected in person","lineItemTaxes":[{"productId":"c493edaf-78ef-4954-b311-3d45c05cfeaa","taxPercent":10}],"shipToName":"Kumar","shipToCompany":"Head Office","shipToAddress":"Near Police quoters road, Ganapathy","shipToPhone":"9566376859","contactName":"Kumar","contactPhone":"9566376859","contactEmail":"swamiedge@gmail.com"}-->	USD	\N	0.00	0.00	13000.00	2026-05-26 13:04:16.527+00	2026-05-26 13:12:13.577+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587	SNAPSHOT	\N	\N	1
98d38f13-ae33-4bea-aa30-f5633f590ae8	PO-REVATH001-202605-00003	2026-05-27	d53ce4ee-7da6-4709-b944-348687fb0843	\N	\N	Nadar depart store	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Sami","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"c493edaf-78ef-4954-b311-3d45c05cfeaa","taxPercent":8}],"shipToName":"Kumar","shipToCompany":"Head Office","shipToAddress":"Near Police quoters road, Ganapathy","shipToPhone":"9566376859","contactName":"Kumar","contactPhone":"9566376859","contactEmail":"swamiedge@gmail.com"}-->	USD	\N	0.00	0.00	32500.00	2026-05-26 15:10:58.608+00	2026-05-26 15:12:47.516+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587	SNAPSHOT	\N	\N	1
4a3f2dfe-53e4-4867-9d43-06172ae206b3	PO-REVATH001-202605-00004	2026-05-27	d53ce4ee-7da6-4709-b944-348687fb0843	\N	\N	Nadar depart store	CANCELLED	<!--PO_DOCUMENT:{"requisitioner":"Sami","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"30e0ab96-c69d-466c-a806-6f05591d8733","taxPercent":10}],"shipToName":"Kumar","shipToCompany":"Head Office","shipToAddress":"Near Police quoters road, Ganapathy","shipToPhone":"9566376859","contactName":"Kumar","contactPhone":"9566376859","contactEmail":"swamiedge@gmail.com"}-->	USD	\N	0.00	0.00	34800.00	2026-05-26 15:12:23.676+00	2026-05-26 15:14:20.243+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	47a8b4e9-c9ee-4239-b6c1-129e71d74587	SNAPSHOT	\N	\N	1
b433c3de-9c5f-4b45-9579-0e90e669981f	PO-0099	2026-05-27	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","department":"IT","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"53457790-5c18-4f3a-a2d6-709ded27ed4a","taxPercent":18}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	15000.00	2026-05-26 15:57:19.422+00	2026-05-26 15:57:19.422+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
24e5f5c4-3725-469e-9c5c-5e1bc438faa0	PO-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"53457790-5c18-4f3a-a2d6-709ded27ed4a","taxPercent":0}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	300.00	2026-05-29 07:50:08.371+00	2026-05-29 07:50:08.371+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
9205e8da-e7d2-41cb-9ccd-98944f0f34e9	PO-HQ001-202605-00009	2026-05-28	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	100.00	2026-05-27 11:35:08.39+00	2026-06-11 08:21:25.144+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-11T08:21:25.143Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
53a1c699-58cd-4d6f-b3b3-071cfd584544	PO-00002	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"53457790-5c18-4f3a-a2d6-709ded27ed4a","taxPercent":0}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	300.00	2026-05-29 07:50:17.812+00	2026-05-29 07:50:17.812+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
17904c2f-5358-489d-8f81-b2945ca9f79a	PO-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	0812e848-3efa-4339-858a-917e342f1d9d	\N	PowerDrive Engines	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"1f99fcd4-52c2-4c2c-a79d-132838abe2d0","taxPercent":17.99}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	300000.00	2026-05-30 04:16:01.268+00	2026-05-30 04:16:01.268+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1
5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	PO-00004	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	\N	Bright Power Distributors	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"f9865733-a9f7-44f6-a031-9c3925042cea","taxPercent":18},{"productId":"7a494ea2-2cf1-419c-ba0a-37da9f178b41","taxPercent":18},{"productId":"8c42805b-90f8-4c3d-9784-b6821ad9272a","taxPercent":18},{"productId":"b196efdd-24e4-4435-a798-aab2e1ec69a0","taxPercent":18},{"productId":"6cf057a6-6a6e-46ac-be49-a0417acd71c3","taxPercent":18}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	37600.00	2026-05-30 10:02:25.978+00	2026-05-30 10:03:59.971+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1
2a5a864c-14e5-4926-bcc8-0eba58535da8	GSTPO-01	2026-05-27	d53ce4ee-7da6-4709-b944-348687fb0843	\N	\N	Nadar depart store	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Sami","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"30e0ab96-c69d-466c-a806-6f05591d8733","taxPercent":4}],"shipToName":"Kumar","shipToCompany":"Head Office","shipToAddress":"Near Police quoters road, Ganapathy","shipToPhone":"9566376859","contactName":"Kumar","contactPhone":"9566376859","contactEmail":"swamiedge@gmail.com"}-->	USD	\N	0.00	0.00	1450.00	2026-05-26 15:20:54.863+00	2026-06-08 10:54:10.44+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	SNAPSHOT	{"shopName": "Head Office", "companyName": "Revathi Hotels", "generatedAt": "2026-06-08T10:54:10.439Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
5deef4ed-cdfb-4baf-966f-dc36ca76b14b	PO-5000000	2026-06-08	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Bharat Electricals Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","department":"Warehouse","paymentTerms":"Net 30","shipVia":"UPS — Ground / 2-Day / Next Day Air","lineItemTaxes":[{"productId":"f9865733-a9f7-44f6-a031-9c3925042cea","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	14500.00	2026-06-08 17:42:07.837+00	2026-06-08 17:42:07.896+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-08T17:42:07.895Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
748dd9cf-1fdd-4f95-840d-22ab88262a03	PO-5000001	2026-06-08	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Bharat Electricals Supply	CONFIRMED	fsddsds\n<!--PO_DOCUMENT:{"requisitioner":"Owner","department":"Operations","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"7a494ea2-2cf1-419c-ba0a-37da9f178b41","taxPercent":9}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	10800.00	2026-06-08 17:46:13.73+00	2026-06-08 17:46:13.823+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-08T17:46:13.822Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
05ae51ad-18be-4ee5-bafe-8c658db0eb89	PO-5000002	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	PowerDrive Engines	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipVia":"USPS — Priority Mail / First Class","fob":"FOB Origin, Freight Collect","shippingTerms":"Prepaid — Seller pays freight","lineItemTaxes":[{"productId":"1f99fcd4-52c2-4c2c-a79d-132838abe2d0","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	600000.00	2026-06-09 01:47:33.96+00	2026-06-09 01:47:34.04+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T01:47:34.039Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
4f91da5c-9b7e-4344-a78b-2dd21950e8a9	PO-5000003	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipVia":"DHL — Domestic & international express","fob":"FOB Origin, Freight Prepaid","shippingTerms":"Prepaid & Add — Seller pays, invoices buyer","shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1200.00	2026-06-09 02:06:26.498+00	2026-06-09 02:06:26.559+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T02:06:26.558Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
245324eb-1995-4571-963a-8c776fcd047e	PO-5000004	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"96718ee2-4ff3-4de9-bf6f-7bc023e8338f","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1000.00	2026-06-09 03:51:57.936+00	2026-06-09 03:51:58.001+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T03:51:58.000Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	PO-5000005	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1200.00	2026-06-09 04:15:47.321+00	2026-06-09 04:15:47.382+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T04:15:47.381Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
2325cf74-910a-4065-9a29-e9c5c9b9bb38	PO-5000006	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	19000.00	2026-06-09 04:50:28.702+00	2026-06-09 04:50:28.756+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T04:50:28.755Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
f1732149-a034-4689-ad21-901760bba457	PO-5000007	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"f9865733-a9f7-44f6-a031-9c3925042cea","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1450.00	2026-06-09 05:02:19.935+00	2026-06-09 05:02:20.013+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:02:20.013Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
e62b76c6-23ef-4d71-ba48-9d10ae494065	PO-5000008	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1800.00	2026-06-09 05:12:37.21+00	2026-06-09 05:12:37.27+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:12:37.269Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
6a65724c-dc91-465a-ba9e-e79e7d88234c	PO-5000009	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"f9865733-a9f7-44f6-a031-9c3925042cea","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1450.00	2026-06-09 05:39:30.337+00	2026-06-09 05:39:30.41+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:39:30.409Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	PO-5000010	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"2d8107ad-f2ff-4862-b269-9b274a65b530","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	180.26	2026-06-09 05:44:33.058+00	2026-06-09 05:44:33.135+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:44:33.134Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	PO-5000011	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"f9865733-a9f7-44f6-a031-9c3925042cea","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	21750.00	2026-06-09 09:59:27.498+00	2026-06-09 09:59:27.558+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T09:59:27.558Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
714d8e69-25db-490c-af43-8c6168c774d4	PO-5000012	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"7a494ea2-2cf1-419c-ba0a-37da9f178b41","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	1800.00	2026-06-09 10:06:59.697+00	2026-06-09 10:06:59.751+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T10:06:59.750Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
eaafa0b8-8e26-4636-9e0b-1039689f82a6	PO-5000013	2026-06-09	5c1f22f6-978a-43fe-ad41-28359edf08d4	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"96718ee2-4ff3-4de9-bf6f-7bc023e8338f","taxPercent":0}],"shipToName":"Kolandasamy","shipToCompany":"Automobile Manafac. plant chennai","shipToAddress":"chennai","shipToPhone":"9677878824","contactName":"Kolandasamy","contactPhone":"9677878824","contactEmail":"kolandasamy.sss@gmail.com"}-->	USD	\N	0.00	0.00	100.00	2026-06-09 10:10:49.361+00	2026-06-09 10:10:49.427+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Automobile Manafac. plant chennai", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T10:10:49.426Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
93ae57bd-78e2-44cc-bfce-eaf421970398	PO-00005	2026-06-09	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	\N	\N	Heaven Electrical Supply	CONFIRMED	<!--PO_DOCUMENT:{"requisitioner":"Owner","paymentTerms":"Net 30","lineItemTaxes":[{"productId":"f9865733-a9f7-44f6-a031-9c3925042cea","taxPercent":0}],"shipToName":"System Admin","shipToCompany":"Headquarters","shipToAddress":"1 Main Street","shipToPhone":"+0000000000","contactName":"System Admin","contactPhone":"+0000000000","contactEmail":"hq@retailims.local"}-->	USD	\N	0.00	0.00	1450.00	2026-06-09 17:16:03.87+00	2026-06-09 17:16:03.947+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T17:16:03.946Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.purchase_order_items (id, po_header_id, product_id, rfq_item_id, current_stock, min_stock, suggested_qty, order_qty, rate, discount_amount, tax_rate, tax_amount, line_value, created_at, updated_at, created_by, updated_by, line_description, line_category) FROM stdin;
986d5071-eef8-4817-ab4b-618f23465941	d62e1dc9-f157-4ce1-9aad-788ae4e5f9d2	57812718-33b2-4585-ba16-e4a95bec7405	b393d774-388b-423f-a107-47a08085e0ea	0.000	0.000	1.000	1.000	99.00	0.00	0.0000	0.00	99.00	2026-05-25 05:28:26.483+00	2026-05-25 05:28:26.483+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
a02833ce-97d2-4503-a165-bc326fbb7b8f	58c296bd-7d95-40cb-a083-15e50c03b941	57812718-33b2-4585-ba16-e4a95bec7405	f0795bf2-6699-48b5-9b7f-eff19fa5f1d5	0.000	0.000	20.000	20.000	130.00	0.00	0.0000	0.00	2600.00	2026-05-25 06:01:34.406+00	2026-05-25 06:01:34.406+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
7d521699-5622-440c-9460-d8e9e9427914	d16a81c5-d5e6-4a5e-ae2c-85069bf8cea6	57812718-33b2-4585-ba16-e4a95bec7405	dfcac917-a831-4881-b82f-3ffbfef9e052	0.000	0.000	1.000	1.000	500.00	0.00	0.0000	0.00	500.00	2026-05-25 06:10:15.635+00	2026-05-25 06:10:15.635+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
448bfc3d-bb3b-4858-9279-3ab56fdea88d	950a2f19-23be-47c3-8cbd-7db822639954	53457790-5c18-4f3a-a2d6-709ded27ed4a	\N	0.000	50.000	100.000	2.000	300.00	0.00	0.0000	0.00	600.00	2026-05-25 14:52:10.231+00	2026-05-25 14:52:10.231+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
7c449183-751e-425f-925c-51c835e49da8	950a2f19-23be-47c3-8cbd-7db822639954	57812718-33b2-4585-ba16-e4a95bec7405	\N	0.000	100.000	200.000	5.000	100.00	0.00	0.0000	0.00	500.00	2026-05-25 14:52:10.231+00	2026-05-25 14:52:10.231+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
f1362c77-40eb-4c69-b1f4-5facfb5e5612	a0305a74-81dc-44c7-b479-93732db5d98e	57812718-33b2-4585-ba16-e4a95bec7405	4b34d676-9587-4185-9009-d47ed80d1fb4	0.000	0.000	4.000	4.000	50.00	0.00	0.0000	0.00	200.00	2026-05-25 15:48:10.512+00	2026-05-25 15:48:10.512+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
ff6b933c-b884-4ccb-aafb-255aafbbde91	0b050ead-40cc-4b1d-9228-480db2ea54f4	57812718-33b2-4585-ba16-e4a95bec7405	b59ce43a-6c3a-4607-a32c-ade6e6aee326	0.000	0.000	20.000	20.000	100.00	0.00	0.0000	0.00	2000.00	2026-05-25 16:16:13.412+00	2026-05-25 16:16:13.412+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
0f571fbf-0ab5-4b73-a0de-4eaf66895cf9	0b050ead-40cc-4b1d-9228-480db2ea54f4	53457790-5c18-4f3a-a2d6-709ded27ed4a	ddb8ba1a-3050-461b-baf7-8605de317f36	0.000	0.000	30.000	30.000	200.00	0.00	0.0000	0.00	6000.00	2026-05-25 16:16:13.412+00	2026-05-25 16:16:13.412+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
268fc177-8415-4cea-9962-ba26023187ec	c0322c43-144e-416e-8ccc-005b82f19897	57812718-33b2-4585-ba16-e4a95bec7405	\N	0.000	100.000	200.000	10.000	50.00	0.00	0.0000	0.00	500.00	2026-05-25 17:56:43.75+00	2026-05-25 17:56:43.75+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
690b60e0-5f1e-4758-a869-69d00e5b8452	c5973c42-3a93-484d-ac68-c64ca799accc	53457790-5c18-4f3a-a2d6-709ded27ed4a	52896ddc-58df-411c-9693-d3eaa195a581	0.000	50.000	100.000	50.000	300.00	0.00	0.0000	0.00	15000.00	2026-05-26 07:55:03.946+00	2026-05-26 07:55:03.946+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	\N
906098c0-b35f-4784-82b5-3b9daf5c6e32	7bfd4712-c3e3-4481-b439-cdcc0c189522	c493edaf-78ef-4954-b311-3d45c05cfeaa	\N	0.000	7.000	14.000	10.000	1300.00	0.00	0.0000	0.00	13000.00	2026-05-26 12:59:49.083+00	2026-05-26 12:59:49.083+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
e748b111-bb94-4186-bd6e-f8ada71f9f43	7bfd4712-c3e3-4481-b439-cdcc0c189522	d493fddc-f3b3-4002-ba2a-bb5dc7e7df02	\N	0.000	0.000	0.000	15.000	860.00	0.00	0.0000	0.00	12900.00	2026-05-26 12:59:49.083+00	2026-05-26 12:59:49.083+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
ad13efd0-63d1-4376-b8d3-712dee75dec6	7bfd4712-c3e3-4481-b439-cdcc0c189522	d493fddc-f3b3-4002-ba2a-bb5dc7e7df02	\N	0.000	0.000	0.000	4.000	700.00	0.00	0.0000	0.00	2800.00	2026-05-26 12:59:49.083+00	2026-05-26 12:59:49.083+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
0d0d0955-7fea-44d2-a79a-41983399975d	84ba57d6-7085-46b5-863e-cf279a415a11	c493edaf-78ef-4954-b311-3d45c05cfeaa	\N	0.000	7.000	14.000	10.000	1300.00	0.00	0.0000	0.00	13000.00	2026-05-26 13:04:16.527+00	2026-05-26 13:04:16.527+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
89c2e5ab-f8fe-429b-86c8-3f92ad5098e4	98d38f13-ae33-4bea-aa30-f5633f590ae8	c493edaf-78ef-4954-b311-3d45c05cfeaa	\N	0.000	7.000	14.000	25.000	1300.00	0.00	0.0000	0.00	32500.00	2026-05-26 15:10:58.608+00	2026-05-26 15:10:58.608+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
6f9150cb-ddeb-45bf-bfd4-7864cccbe773	4a3f2dfe-53e4-4867-9d43-06172ae206b3	30e0ab96-c69d-466c-a806-6f05591d8733	\N	0.000	20.000	40.000	24.000	1450.00	0.00	0.0000	0.00	34800.00	2026-05-26 15:12:23.676+00	2026-05-26 15:12:23.676+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N	\N
9a431ee7-c875-4ca4-963f-217b99bd9f7b	2a5a864c-14e5-4926-bcc8-0eba58535da8	30e0ab96-c69d-466c-a806-6f05591d8733	\N	0.000	20.000	40.000	1.000	1450.00	0.00	0.0000	0.00	1450.00	2026-05-26 15:20:54.863+00	2026-05-26 15:20:54.863+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	Additional Point 2	Electrical
8915590c-a1c9-407c-bd1f-eb309d72bc90	b433c3de-9c5f-4b45-9579-0e90e669981f	53457790-5c18-4f3a-a2d6-709ded27ed4a	\N	0.000	50.000	100.000	50.000	300.00	0.00	0.0000	0.00	15000.00	2026-05-26 15:57:19.422+00	2026-05-26 15:57:19.422+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	MCB (Miniature Circuit Breaker)	Electrical
59f7774e-0c83-4331-8e3e-998e231d5ad8	9205e8da-e7d2-41cb-9ccd-98944f0f34e9	fee8fa94-4b72-4796-943f-ac72ce47cea9	\N	0.000	0.000	0.000	1.000	100.00	0.00	0.0000	0.00	100.00	2026-05-27 11:35:08.39+00	2026-05-27 11:35:08.39+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	MCB (Miniature Circuit Breaker)	Service
a517ee1b-856c-4aa8-966a-fcc8e9965f1e	24e5f5c4-3725-469e-9c5c-5e1bc438faa0	53457790-5c18-4f3a-a2d6-709ded27ed4a	\N	0.000	50.000	100.000	1.000	300.00	0.00	0.0000	0.00	300.00	2026-05-29 07:50:08.371+00	2026-05-29 07:50:08.371+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	MCB (Miniature Circuit Breaker)	Electrical
5533c0c9-9188-4bdb-a7d0-ee9b78d30e7c	53a1c699-58cd-4d6f-b3b3-071cfd584544	53457790-5c18-4f3a-a2d6-709ded27ed4a	\N	0.000	50.000	100.000	1.000	300.00	0.00	0.0000	0.00	300.00	2026-05-29 07:50:17.812+00	2026-05-29 07:50:17.812+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	MCB (Miniature Circuit Breaker)	Electrical
486562ee-ac66-4b71-8404-d0114820ae1d	17904c2f-5358-489d-8f81-b2945ca9f79a	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	eeddcec7-91dc-4579-9fc7-06fdcf75bf6f	0.000	0.000	0.000	3.000	100000.00	0.00	0.0000	0.00	300000.00	2026-05-30 04:16:01.268+00	2026-05-30 04:16:01.268+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Diesel Engine	Automotive
04c2d0d1-03b3-4501-b8d5-5f8705457e9e	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	f9865733-a9f7-44f6-a031-9c3925042cea	651bdd89-8588-434d-a051-c4989a885e1b	0.000	20.000	40.000	5.000	1450.00	0.00	0.0000	0.00	7250.00	2026-05-30 10:02:25.978+00	2026-05-30 10:02:25.978+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Power Capacitor	Electrical
3d43bc57-b104-4e3b-b945-9500f77d85d5	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	7a494ea2-2cf1-419c-ba0a-37da9f178b41	44649baf-0b70-4586-a60d-657df0210898	0.000	20.000	40.000	5.000	1800.00	0.00	0.0000	0.00	9000.00	2026-05-30 10:02:25.978+00	2026-05-30 10:02:25.978+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Busbar Copper	Electrical
0dafc86b-da63-42fe-a2ac-c669eb7406e4	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	8c42805b-90f8-4c3d-9784-b6821ad9272a	6377075d-d840-4993-b59c-812bf407900f	0.000	20.000	40.000	5.000	3200.00	0.00	0.0000	0.00	16000.00	2026-05-30 10:02:25.978+00	2026-05-30 10:02:25.978+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Lightning Arrester	Electrical
c17abbfe-0526-478b-ad51-50ff830bef25	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	b196efdd-24e4-4435-a798-aab2e1ec69a0	4861189f-c67f-470f-8263-9e4cbfb8682b	0.000	20.000	40.000	5.000	420.00	0.00	0.0000	0.00	2100.00	2026-05-30 10:02:25.978+00	2026-05-30 10:02:25.978+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Earth Rod	Electrical
d304cae6-7ea3-4cc3-896c-0f8bebce5ba9	5a5a7cdd-a685-4dfc-91f3-2edae4e0e58b	6cf057a6-6a6e-46ac-be49-a0417acd71c3	17d20d4d-3a2e-454e-aec4-7b739f3eefa1	0.000	20.000	40.000	5.000	650.00	0.00	0.0000	0.00	3250.00	2026-05-30 10:02:25.978+00	2026-05-30 10:02:25.978+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Cable Tray	Electrical
4d10649d-5156-4928-98df-fd702d368e5c	5deef4ed-cdfb-4baf-966f-dc36ca76b14b	f9865733-a9f7-44f6-a031-9c3925042cea	\N	0.000	0.000	0.000	10.000	1450.00	0.00	0.0000	0.00	14500.00	2026-06-08 17:42:07.837+00	2026-06-08 17:42:07.837+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Power Capacitor	Electrical
651c8471-357f-4299-ad80-8712f9b5715b	748dd9cf-1fdd-4f95-840d-22ab88262a03	7a494ea2-2cf1-419c-ba0a-37da9f178b41	\N	0.000	0.000	0.000	6.000	1800.00	0.00	0.0000	0.00	10800.00	2026-06-08 17:46:13.73+00	2026-06-08 17:46:13.73+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Busbar Copper	Electrical
acd64c6a-b6c9-462f-95c0-221a03202486	05ae51ad-18be-4ee5-bafe-8c658db0eb89	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	\N	0.000	10.000	20.000	12.000	50000.00	0.00	0.0000	0.00	600000.00	2026-06-09 01:47:33.96+00	2026-06-09 01:47:33.96+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Diesel Engine	Automotive
eeae3801-ba20-4d2b-8578-17072f58a35b	4f91da5c-9b7e-4344-a78b-2dd21950e8a9	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	\N	0.000	0.000	0.000	1.000	1200.00	0.00	0.0000	0.00	1200.00	2026-06-09 02:06:26.498+00	2026-06-09 02:06:26.498+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Transport charge	Service
1d21f85a-2005-4e34-b406-3b70b03a9eaf	245324eb-1995-4571-963a-8c776fcd047e	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	\N	0.000	0.000	0.000	1.000	1000.00	0.00	0.0000	0.00	1000.00	2026-06-09 03:51:57.936+00	2026-06-09 03:51:57.936+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Service line (PO)	Service
fa93ac0b-2a91-49bb-b2dd-3060efd48bac	ce7b9d07-e04e-4306-9dd8-e3c85a7e7b95	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	\N	0.000	0.000	0.000	1.000	1200.00	0.00	0.0000	0.00	1200.00	2026-06-09 04:15:47.321+00	2026-06-09 04:15:47.321+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Transport charge	Service
4d89e8fb-86d4-49de-9872-f95f49f5c1eb	2325cf74-910a-4065-9a29-e9c5c9b9bb38	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	\N	0.000	0.000	0.000	1.000	19000.00	0.00	0.0000	0.00	19000.00	2026-06-09 04:50:28.702+00	2026-06-09 04:50:28.702+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Service line (PO)	Service
67bbc6bc-4060-431b-a958-4d86d9abe568	f1732149-a034-4689-ad21-901760bba457	f9865733-a9f7-44f6-a031-9c3925042cea	\N	0.000	0.000	0.000	1.000	1450.00	0.00	0.0000	0.00	1450.00	2026-06-09 05:02:19.935+00	2026-06-09 05:02:19.935+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Power Capacitor	Electrical
c3e33d7b-5dbf-4e48-9ca3-f32edcf37d27	e62b76c6-23ef-4d71-ba48-9d10ae494065	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	\N	0.000	0.000	0.000	1.000	1800.00	0.00	0.0000	0.00	1800.00	2026-06-09 05:12:37.21+00	2026-06-09 05:12:37.21+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Transport charge	Service
47d7c204-399d-4698-aa88-2630b4dca711	6a65724c-dc91-465a-ba9e-e79e7d88234c	f9865733-a9f7-44f6-a031-9c3925042cea	\N	0.000	0.000	0.000	1.000	1450.00	0.00	0.0000	0.00	1450.00	2026-06-09 05:39:30.337+00	2026-06-09 05:39:30.337+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Power Capacitor	Electrical
e83657e9-3541-4ae5-a92c-fb72cdda21ba	5e9b2a7a-6ea6-43ba-9eb6-fc40774bb09d	2d8107ad-f2ff-4862-b269-9b274a65b530	\N	0.000	0.000	0.000	1.000	180.26	0.00	0.0000	0.00	180.26	2026-06-09 05:44:33.058+00	2026-06-09 05:44:33.058+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Flexible Conduit	Electrical
90a7fe62-05a1-4120-8cb1-dde3bf4af08e	8ee5a865-3e8a-4e6a-8ebc-cf877d413f01	f9865733-a9f7-44f6-a031-9c3925042cea	\N	0.000	0.000	0.000	15.000	1450.00	0.00	0.0000	0.00	21750.00	2026-06-09 09:59:27.498+00	2026-06-09 09:59:27.498+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Power Capacitor	Electrical
dfc04e77-9e75-4a7b-a701-b9849772c32e	714d8e69-25db-490c-af43-8c6168c774d4	7a494ea2-2cf1-419c-ba0a-37da9f178b41	\N	0.000	0.000	0.000	1.000	1800.00	0.00	0.0000	0.00	1800.00	2026-06-09 10:06:59.697+00	2026-06-09 10:06:59.697+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Busbar Copper	Electrical
e555c973-765c-4c8b-8919-8224999a3a39	eaafa0b8-8e26-4636-9e0b-1039689f82a6	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	\N	0.000	0.000	0.000	1.000	100.00	0.00	0.0000	0.00	100.00	2026-06-09 10:10:49.361+00	2026-06-09 10:10:49.361+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Service line (PO)	Service
08d71b70-8c51-461a-86df-f5b0f8df1736	93ae57bd-78e2-44cc-bfce-eaf421970398	f9865733-a9f7-44f6-a031-9c3925042cea	\N	0.000	20.000	40.000	1.000	1450.00	0.00	0.0000	0.00	1450.00	2026-06-09 17:16:03.87+00	2026-06-09 17:16:03.87+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	Power Capacitor	Electrical
\.


--
-- Data for Name: report_saved_filters; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.report_saved_filters (id, user_id, report_type, name, filter_json, created_at) FROM stdin;
\.


--
-- Data for Name: restore_jobs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.restore_jobs (id, company_id, artifact_id, mode, status, dry_run_report, confirmation_token, error_message, started_at, completed_at, created_by, created_at) FROM stdin;
ddcc634e-20c9-4e75-b540-f0320d2b16c3	582b08bd-2a7a-475b-84c2-e4ef8f834a83	ae13214f-b317-4d76-96c8-eac87530c328	TENANT_REPLACE	FAILED	{"counts": {"shops": 1, "invoices": 0, "products": 2, "goodsIssues": 0, "salesOrders": 1, "goodsReceipts": 11, "purchaseOrders": 8, "paymentReceipts": 0}, "canApply": true, "warnings": [], "exportedAt": "2026-05-26T13:15:05.943Z", "schemaVersion": 1, "sourceCompanyCode": "SDC-001", "targetCompanyCode": "SDC-001"}	1229543d14fb6fb14fb8323f0aa2f672b5f728ecb86b5d50	\nInvalid `tx.customer.deleteMany()` invocation in\n/opt/Inventory-control/apps/api/src/modules/backup/tenant-backup.service.ts:198:25\n\n  195 await tx.purchaseOrderHeader.deleteMany({ where: { shopId: { in: shopIds } } });\n  196 await tx.stockLedger.deleteMany({ where: { shopId: { in: shopIds } } });\n  197 await tx.stockSummary.deleteMany({ where: { shopId: { in: shopIds } } });\n→ 198 await tx.customer.deleteMany(\nForeign key constraint violated on the constraint: `sales_quote_header_customer_id_fkey`	2026-05-26 14:45:39.276+00	2026-05-26 14:45:39.344+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 14:45:21.745+00
fec79b77-4840-4bc3-b4b4-2e3cda36d7e2	582b08bd-2a7a-475b-84c2-e4ef8f834a83	ae13214f-b317-4d76-96c8-eac87530c328	TENANT_REPLACE	DRY_RUN_COMPLETED	{"counts": {"shops": 1, "invoices": 0, "products": 2, "goodsIssues": 0, "salesOrders": 1, "goodsReceipts": 11, "purchaseOrders": 8, "paymentReceipts": 0}, "canApply": true, "warnings": [], "exportedAt": "2026-05-26T13:15:05.943Z", "schemaVersion": 1, "sourceCompanyCode": "SDC-001", "targetCompanyCode": "SDC-001"}	c6ed8d2acf7d58bb482fc9c999d9471f494b90f271070d77	\N	\N	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-26 14:45:49.963+00
b63a75e3-9113-4043-8b83-d08431bb984d	582b08bd-2a7a-475b-84c2-e4ef8f834a83	dcb00710-e88d-4c8e-a0cf-b4c12af181fc	TENANT_REPLACE	DRY_RUN_COMPLETED	{"counts": {"shops": 1, "invoices": 0, "products": 5, "goodsIssues": 3, "salesOrders": 5, "goodsReceipts": 13, "purchaseOrders": 12, "paymentReceipts": 0}, "canApply": true, "warnings": [], "exportedAt": "2026-05-29T11:27:43.574Z", "schemaVersion": 1, "sourceCompanyCode": "SDC-001", "targetCompanyCode": "SDC-001"}	7eb6feaeb65210bdb15a9558d366b739a7a077819dc68ca2	\N	\N	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-29 11:27:53.135+00
\.


--
-- Data for Name: rfq_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.rfq_header (id, rfq_number, rfq_date, deadline, title, notes, shop_id, status, posted_at, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
e3ba67e8-f91b-4d30-90d8-1c0b3a338774	RFQ-HQ001-202605-00001	2026-05-25	2026-05-28	RFQ	Supply\n[Sent 2026-05-25T05:25:15.081Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-25 05:25:15.081+00	2026-05-25 05:25:07.799+00	2026-05-25 05:25:15.083+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
cbba0db5-cda0-4cfc-97df-26985042ff4d	RFQ-HQ001-202605-00002	2026-05-25	2026-05-29	More LED's	More LED\n[Sent 2026-05-25T05:29:04.799Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-25 05:29:04.799+00	2026-05-25 05:29:01.012+00	2026-05-25 05:29:04.801+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
5daf69be-ed64-4841-931e-0de22ee61183	RFQ-HQ001-202605-00003	2026-05-25	2026-05-28	RFQ 2	[Sent 2026-05-25T06:02:51.247Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-25 06:02:51.247+00	2026-05-25 06:02:40.109+00	2026-05-25 06:02:51.249+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
8e4dcbdf-a386-42b6-916c-ff4d83490d15	RFQ-HQ001-202605-00004	2026-05-25	2026-05-30	RFQ	[Sent 2026-05-25T13:56:17.446Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-25 13:56:17.446+00	2026-05-25 13:56:09.077+00	2026-05-25 13:56:17.447+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
e890e821-c818-46b4-9e4b-bda34532983d	RFQ-HQ001-202605-00005	2026-05-25	2026-05-30	MCB	[Sent 2026-05-25T16:08:50.778Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-25 16:08:50.778+00	2026-05-25 16:07:22.899+00	2026-05-25 16:08:50.78+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
10328047-043e-4df1-8fee-a011284c0bed	RFQ-HQ001-202605-00006	2026-05-26	2026-05-30	RFQ test	[Sent 2026-05-26T07:40:52.941Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-26 07:40:52.941+00	2026-05-26 07:40:44.237+00	2026-05-26 07:40:52.942+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
bcdbac0c-1d04-4de1-b2b1-23ec9f2f80eb	RFQ-00001	2026-05-29	2026-05-31	RFQ Testing	[Sent 2026-05-29T09:07:47.553Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-29 09:07:47.553+00	2026-05-29 09:07:27.886+00	2026-05-29 09:07:47.554+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
0812e848-3efa-4339-858a-917e342f1d9d	RFQ-00002	2026-05-30	2026-06-12	Test RFQ's	[Sent 2026-05-30T03:52:29.191Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-30 03:52:29.191+00	2026-05-30 03:49:45.651+00	2026-05-30 03:52:29.193+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
9da63c07-1b8b-4ae6-a239-024fe9cf23c1	RFQ-00003	2026-05-30	2026-06-04	Request rate	Electrical\n[Sent 2026-05-30T08:20:30.788Z]	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	POSTED	2026-05-30 08:20:30.788+00	2026-05-30 08:19:20.369+00	2026-05-30 08:20:30.789+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
\.


--
-- Data for Name: rfq_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.rfq_items (id, rfq_header_id, product_id, description, quantity, uom, specifications, created_at, updated_at, created_by, updated_by) FROM stdin;
b393d774-388b-423f-a107-47a08085e0ea	e3ba67e8-f91b-4d30-90d8-1c0b3a338774	57812718-33b2-4585-ba16-e4a95bec7405	\N	1.000	pcs	\N	2026-05-25 05:25:07.799+00	2026-05-25 05:25:07.799+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
f0795bf2-6699-48b5-9b7f-eff19fa5f1d5	cbba0db5-cda0-4cfc-97df-26985042ff4d	57812718-33b2-4585-ba16-e4a95bec7405	\N	20.000	pcs	\N	2026-05-25 05:29:01.012+00	2026-05-25 05:29:01.012+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
dfcac917-a831-4881-b82f-3ffbfef9e052	5daf69be-ed64-4841-931e-0de22ee61183	57812718-33b2-4585-ba16-e4a95bec7405	\N	1.000	pcs	\N	2026-05-25 06:02:40.109+00	2026-05-25 06:02:40.109+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4b34d676-9587-4185-9009-d47ed80d1fb4	8e4dcbdf-a386-42b6-916c-ff4d83490d15	57812718-33b2-4585-ba16-e4a95bec7405	\N	10.000	pcs	LED	2026-05-25 13:56:09.077+00	2026-05-25 13:56:09.077+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
b59ce43a-6c3a-4607-a32c-ade6e6aee326	e890e821-c818-46b4-9e4b-bda34532983d	57812718-33b2-4585-ba16-e4a95bec7405	\N	20.000	pcs	\N	2026-05-25 16:07:22.899+00	2026-05-25 16:07:22.899+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ddb8ba1a-3050-461b-baf7-8605de317f36	e890e821-c818-46b4-9e4b-bda34532983d	53457790-5c18-4f3a-a2d6-709ded27ed4a	\N	30.000	pcs	\N	2026-05-25 16:07:22.899+00	2026-05-25 16:07:22.899+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
52896ddc-58df-411c-9693-d3eaa195a581	10328047-043e-4df1-8fee-a011284c0bed	53457790-5c18-4f3a-a2d6-709ded27ed4a	\N	50.000	pcs	MCB	2026-05-26 07:40:44.237+00	2026-05-26 07:40:44.237+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
d95dafc1-2b0a-4464-8fc5-a27d4989421a	bcdbac0c-1d04-4de1-b2b1-23ec9f2f80eb	1a84efe0-44bc-4661-ba46-ac6b5a2bcd0f	\N	30.000	pcs	In Philips brand required	2026-05-29 09:07:27.886+00	2026-05-29 09:07:27.886+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
db43aaef-817a-457b-a3df-08189fa189fd	bcdbac0c-1d04-4de1-b2b1-23ec9f2f80eb	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	\N	35.000	pcs	In Crompton brand reauired	2026-05-29 09:07:27.886+00	2026-05-29 09:07:27.886+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
eeddcec7-91dc-4579-9fc7-06fdcf75bf6f	0812e848-3efa-4339-858a-917e342f1d9d	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	\N	7.000	pcs	\N	2026-05-30 03:49:45.651+00	2026-05-30 03:49:45.651+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
651bdd89-8588-434d-a051-c4989a885e1b	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	f9865733-a9f7-44f6-a031-9c3925042cea	\N	5.000	pcs	\N	2026-05-30 08:19:20.369+00	2026-05-30 08:19:20.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
44649baf-0b70-4586-a60d-657df0210898	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	7a494ea2-2cf1-419c-ba0a-37da9f178b41	\N	5.000	pcs	\N	2026-05-30 08:19:20.369+00	2026-05-30 08:19:20.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6377075d-d840-4993-b59c-812bf407900f	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	8c42805b-90f8-4c3d-9784-b6821ad9272a	\N	5.000	pcs	\N	2026-05-30 08:19:20.369+00	2026-05-30 08:19:20.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4861189f-c67f-470f-8263-9e4cbfb8682b	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	b196efdd-24e4-4435-a798-aab2e1ec69a0	\N	5.000	pcs	\N	2026-05-30 08:19:20.369+00	2026-05-30 08:19:20.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
17d20d4d-3a2e-454e-aec4-7b739f3eefa1	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	6cf057a6-6a6e-46ac-be49-a0417acd71c3	\N	5.000	pcs	\N	2026-05-30 08:19:20.369+00	2026-05-30 08:19:20.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: rfq_suppliers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.rfq_suppliers (id, rfq_id, supplier_id, created_at) FROM stdin;
65ae7411-a2fd-4c61-be41-33fcd7ce7424	e3ba67e8-f91b-4d30-90d8-1c0b3a338774	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-25 05:25:07.799+00
29bb3cbe-362c-4a5e-9a04-f1f57d5d11c6	cbba0db5-cda0-4cfc-97df-26985042ff4d	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-25 05:29:01.012+00
9aebc807-7670-4268-bd62-ac9dba24940d	5daf69be-ed64-4841-931e-0de22ee61183	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-25 06:02:40.109+00
d372f7ce-1ade-405a-ade7-1c20349616e8	8e4dcbdf-a386-42b6-916c-ff4d83490d15	a94916e2-72a6-4b9c-985d-01de9bc20a2a	2026-05-25 13:56:09.077+00
fc878f3a-522e-4a20-b2fa-71395349e625	8e4dcbdf-a386-42b6-916c-ff4d83490d15	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-25 13:56:09.077+00
9cb58f17-6b16-40f4-8f2f-e213177b5c4b	e890e821-c818-46b4-9e4b-bda34532983d	a94916e2-72a6-4b9c-985d-01de9bc20a2a	2026-05-25 16:07:22.899+00
f4562167-2e5a-4ccc-b70f-d42c8ef01012	e890e821-c818-46b4-9e4b-bda34532983d	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-25 16:07:22.899+00
815a21ad-c15b-4b7d-aa57-12f025dfc596	10328047-043e-4df1-8fee-a011284c0bed	a94916e2-72a6-4b9c-985d-01de9bc20a2a	2026-05-26 07:40:44.237+00
55c5819e-c81b-4f05-afaf-1ad0bb4e91bb	10328047-043e-4df1-8fee-a011284c0bed	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-26 07:40:44.237+00
772b9b91-7d4c-4a0a-9de6-eeb288ca179b	bcdbac0c-1d04-4de1-b2b1-23ec9f2f80eb	7c961808-5a79-4c95-8c40-a36f4839609c	2026-05-29 09:07:27.886+00
46bcc40b-c274-430a-a39b-af8a8d839642	bcdbac0c-1d04-4de1-b2b1-23ec9f2f80eb	a94916e2-72a6-4b9c-985d-01de9bc20a2a	2026-05-29 09:07:27.886+00
3d6cfd5c-5ea1-49d6-9c07-0f1ff1e3fece	0812e848-3efa-4339-858a-917e342f1d9d	6a9b09b4-5182-49c2-92f4-02870dfac0e5	2026-05-30 03:49:45.651+00
09f1ae89-fc55-46af-a72c-f3dd90a238c1	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	79be7f13-60fd-4d65-a0df-b87335b8c75e	2026-05-30 08:19:20.369+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.roles (id, name, permissions, created_at, updated_at, created_by, updated_by) FROM stdin;
f4e729b2-02ea-4fd7-b315-f52347704c5b	OWNER	["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "product:read", "product:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "billing:manage", "vendor_portal:access"]	2026-05-24 19:03:56.391+00	2026-06-02 15:48:21.584+00	\N	\N
b6ec9a6f-ced1-4e32-8d46-eada8cae9565	ADMIN	["user:manage", "shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "product:read", "product:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "audit_log:read", "api:manage", "vendor_portal:access"]	2026-05-24 19:03:56.397+00	2026-06-02 15:48:21.591+00	\N	\N
36ee7bf2-03b4-496d-a832-910cba96f8a1	INVENTORY_MANAGER	["shop:read", "shop:write", "company:read", "company:write", "contract:read", "contract:write", "product:read", "product:write", "storage_location:read", "storage_location:write", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "quote:read", "quote:write", "purchase_order:read", "purchase_order:create", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view", "report:export", "vendor_portal:access"]	2026-05-24 19:03:56.399+00	2026-06-02 15:48:21.592+00	\N	\N
7bafda55-403e-4143-a952-3bd36a898603	PURCHASE_MANAGER	["shop:read", "company:read", "product:read", "supplier:read", "supplier:write", "rfq:read", "rfq:write", "contract:read", "contract:write", "purchase_order:read", "purchase_order:create", "purchase_order:approve", "goods_receipt:read", "report:view", "report:export"]	2026-06-02 15:44:07.187+00	2026-06-02 15:48:21.593+00	\N	\N
1e1912b8-e3d5-4dd0-a5ec-faeab80a8f27	SALES	["shop:read", "company:read", "product:read", "quote:read", "quote:write", "goods_issue:read", "goods_issue:create", "report:view"]	2026-06-02 15:44:07.188+00	2026-06-02 15:48:21.594+00	\N	\N
48ef5cef-8893-4456-8f65-2e225bed6e1d	EMPLOYEE	["shop:read", "company:read", "product:read"]	2026-06-02 15:44:07.189+00	2026-06-02 15:48:21.596+00	\N	\N
64812ff7-4367-442a-b18a-5df47e3bb4fc	WAREHOUSE_STAFF	["shop:read", "company:read", "contract:read", "product:read", "storage_location:read", "supplier:read", "rfq:read", "quote:read", "purchase_order:read", "goods_receipt:read", "goods_receipt:create", "goods_issue:read", "goods_issue:create", "damage:read", "damage:create", "report:view"]	2026-05-24 19:03:56.4+00	2026-06-02 15:48:21.597+00	\N	\N
9b6c084c-6063-400d-a3e2-be0bcac06ab6	VIEWER	["shop:read", "company:read", "contract:read", "product:read", "storage_location:read", "supplier:read", "rfq:read", "quote:read", "purchase_order:read", "goods_receipt:read", "goods_issue:read", "damage:read", "report:view"]	2026-05-24 19:03:56.401+00	2026-06-02 15:48:21.598+00	\N	\N
4ecbad9f-8440-4df2-8bf9-dc4ed4295223	VENDOR	["vendor_portal:access"]	2026-05-24 19:03:56.402+00	2026-06-02 15:48:21.599+00	\N	\N
\.


--
-- Data for Name: sales_order_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_order_header (id, so_number, order_date, expected_date, customer_id, shop_id, status, fulfillment_status, remarks, currency, fx_rate_used, discount_amount, tax_amount, total_value, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version, gst_supply_type, subtotal_before_tax, total_cgst, total_sgst, total_igst) FROM stdin;
f60f8cee-b969-45fa-b000-ce4880f495c1	SO-HQ001-202605-00001	2026-05-26	2026-05-31	ac6eb189-b321-4104-810c-f90c3db4b0f7	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	FULFILLED	FULL	Payment terms: Net 30\nDelivery: chennai	USD	\N	0.00	0.00	5000.00	2026-05-26 08:25:21.336+00	2026-05-26 08:26:45.23+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
71157456-86b7-491c-890d-1614271ae667	SO-HQ001-202605-00002	2026-05-26	2026-05-28	1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	CONFIRMED	NONE	Payment terms: Due on receipt\nDelivery: Coimbatore	USD	\N	0.00	0.00	500.00	2026-05-26 15:02:54.591+00	2026-05-26 15:03:14.206+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
aad38599-ea83-40b3-a98b-34f8da4358a6	SO-HQ001-202605-00003	2026-05-26	2026-05-30	1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	FULFILLED	FULL	Payment terms: Net 30\nDelivery: Cbe	USD	\N	0.00	0.00	10000.00	2026-05-26 15:24:37.364+00	2026-05-26 15:25:06.237+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
5e625cbc-80a3-4163-9ac0-f66dba7dba6c	SO-HQ001-202605-00004	2026-05-26	\N	1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	CONFIRMED	NONE	From QT-HQ001-202605-00002	USD	\N	0.00	0.00	500.00	2026-05-26 16:03:52.989+00	2026-05-26 16:06:46.041+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
e740e26e-9481-4282-b21e-e899dc6e7771	SO-HQ001-202605-00005	2026-05-26	2026-05-29	ac6eb189-b321-4104-810c-f90c3db4b0f7	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	FULFILLED	FULL	Payment terms: Net 30\nFrom QT-HQ001-202605-00003	USD	\N	0.00	0.00	880.00	2026-05-26 16:26:16.298+00	2026-05-26 16:27:22.6+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	\N	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
69b227da-8e82-4bf9-b4a8-b17c47d559e0	SO-00001	2026-05-30	\N	011faebb-2952-4b7d-affd-a9e450b8cc11	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	CONFIRMED	NONE	Payment terms: Net 30\nDelivery: Chennai SIPCOT Phase 1\nFrom QT-00001	USD	\N	0.00	0.00	120500.00	2026-05-30 07:52:59.363+00	2026-06-08 11:56:55.822+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-08T11:56:55.821Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
e293bebe-4b10-4880-ba04-9e2d01f15679	SO-00002	2026-06-08	2026-06-26	c1663e2a-177a-4bde-90a2-2afb1fc922f4	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	DRAFT	NONE	Payment terms: Net 30\nDelivery: XYZ	USD	\N	0.00	0.00	750.00	2026-06-08 11:59:15.218+00	2026-06-08 11:59:15.218+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	\N	\N	1	INTRA_STATE	0.00	0.00	0.00	0.00
338e7bb0-7631-4a64-802c-7ee734ddb780	SO-00003	2026-06-08	2026-06-18	c1663e2a-177a-4bde-90a2-2afb1fc922f4	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	DRAFT	NONE	Payment terms: Net 30\nDelivery: Chennai, Tamil Nadu, 600020	USD	\N	0.00	207.00	1357.00	2026-06-08 14:20:23.674+00	2026-06-08 14:20:34.976+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-08T14:20:34.975Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1	INTRA_STATE	1150.00	103.50	103.50	0.00
\.


--
-- Data for Name: sales_order_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_order_items (id, so_header_id, product_id, quantity, shipped_qty, uom, unit_price, discount_amount, tax_rate, tax_amount, line_value, created_at, updated_at, created_by, updated_by, cgst_rate, sgst_rate, igst_rate) FROM stdin;
e9aadfae-da93-4c43-8dba-cb4b57a63c95	f60f8cee-b969-45fa-b000-ce4880f495c1	53457790-5c18-4f3a-a2d6-709ded27ed4a	10.000	10.000	UNIT	500.00	0.00	0.0000	0.00	5000.00	2026-05-26 08:25:21.336+00	2026-05-26 08:26:45.224+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
25274e4d-ad6f-413e-8976-5c3646361330	71157456-86b7-491c-890d-1614271ae667	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	0.000	pcs	500.00	0.00	0.0000	0.00	500.00	2026-05-26 15:02:54.591+00	2026-05-26 15:02:54.591+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
0b9c93be-dd15-4db8-bab9-98e2a1970f19	aad38599-ea83-40b3-a98b-34f8da4358a6	53457790-5c18-4f3a-a2d6-709ded27ed4a	20.000	20.000	pcs	500.00	0.00	0.0000	0.00	10000.00	2026-05-26 15:24:37.364+00	2026-05-26 15:25:06.23+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
ee4a6d30-7c02-44fe-b62a-ba32d5b37e2e	5e625cbc-80a3-4163-9ac0-f66dba7dba6c	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	0.000	UNIT	500.00	0.00	0.0000	0.00	500.00	2026-05-26 16:03:52.989+00	2026-05-26 16:03:52.989+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
ed9805c9-6f20-4ec3-bda6-1c55e7e7d9d1	e740e26e-9481-4282-b21e-e899dc6e7771	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	11.000	11.000	UNIT	80.00	0.00	0.0000	0.00	880.00	2026-05-26 16:26:46.64+00	2026-05-26 16:27:22.595+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
abcb4849-cb93-4e41-8029-fa33090c64ed	69b227da-8e82-4bf9-b4a8-b17c47d559e0	f9865733-a9f7-44f6-a031-9c3925042cea	10.000	0.000	pcs	1850.00	0.00	0.0000	0.00	18500.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
c3099a01-401f-4c39-b1f7-4bdee63f969f	69b227da-8e82-4bf9-b4a8-b17c47d559e0	7a494ea2-2cf1-419c-ba0a-37da9f178b41	10.000	0.000	pcs	2300.00	0.00	0.0000	0.00	23000.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
81643e47-a1d6-49cd-a686-0d96e71101de	69b227da-8e82-4bf9-b4a8-b17c47d559e0	8c42805b-90f8-4c3d-9784-b6821ad9272a	10.000	0.000	pcs	4000.00	0.00	0.0000	0.00	40000.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
c1a30294-e7d1-45a8-93e2-feefc94df259	69b227da-8e82-4bf9-b4a8-b17c47d559e0	b196efdd-24e4-4435-a798-aab2e1ec69a0	10.000	0.000	pcs	580.00	0.00	0.0000	0.00	5800.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
664c24c7-d04c-4856-bcd8-32c592cfe3bb	69b227da-8e82-4bf9-b4a8-b17c47d559e0	6cf057a6-6a6e-46ac-be49-a0417acd71c3	10.000	0.000	pcs	850.00	0.00	0.0000	0.00	8500.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
898912b1-0f6c-4ca3-8210-bb83435accbd	69b227da-8e82-4bf9-b4a8-b17c47d559e0	2d8107ad-f2ff-4862-b269-9b274a65b530	10.000	0.000	pcs	240.00	0.00	0.0000	0.00	2400.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
b2b4d4d7-f9c4-40ae-8ed2-8bb134616da9	69b227da-8e82-4bf9-b4a8-b17c47d559e0	2d8107ad-f2ff-4862-b269-9b274a65b530	10.000	0.000	pcs	240.00	0.00	0.0000	0.00	2400.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
273c0e09-1887-4fec-bb45-8a88c71c8482	69b227da-8e82-4bf9-b4a8-b17c47d559e0	166c4ba0-232b-484f-ad54-fab5379410fa	10.000	0.000	pcs	1250.00	0.00	0.0000	0.00	12500.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
3c020507-8f4b-426d-af1d-ce18b2aae394	69b227da-8e82-4bf9-b4a8-b17c47d559e0	6344a746-687f-48d0-af2e-329cc0932fc7	10.000	0.000	pcs	120.00	0.00	0.0000	0.00	1200.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
28b6af2c-0a59-4d51-992b-c1d8bd902ada	69b227da-8e82-4bf9-b4a8-b17c47d559e0	0459f473-75f9-463a-8237-9ca65fee69f8	10.000	0.000	pcs	620.00	0.00	0.0000	0.00	6200.00	2026-05-30 07:53:36.115+00	2026-05-30 07:53:36.115+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
c03ca598-bc69-41c4-8cea-62f00ab51917	e293bebe-4b10-4880-ba04-9e2d01f15679	6fc077a8-77b6-4906-a2bf-b794fa9fec9f	1.000	0.000	pcs	750.00	0.00	0.0000	0.00	750.00	2026-06-08 11:59:15.218+00	2026-06-08 11:59:15.218+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	0.0000	0.0000	0.0000
cbff6266-c4af-4832-9822-c976dcdb9a17	338e7bb0-7631-4a64-802c-7ee734ddb780	fb0fe073-f3f9-490b-88ad-a6df8e78a816	1.000	0.000	pcs	1150.00	0.00	0.1800	207.00	1357.00	2026-06-08 14:20:23.674+00	2026-06-08 14:20:23.674+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	9.0000	9.0000	0.0000
\.


--
-- Data for Name: sales_quote_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_quote_header (id, quote_number, quote_date, valid_until, customer_id, shop_id, status, sales_order_id, portal_token, remarks, total_value, customer_requested_total, customer_request_note, customer_responded_at, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
8a2b2774-cc64-417a-8413-a5f5f41d3a3e	QT-HQ001-202605-00001	2026-05-26	2026-05-30	ac6eb189-b321-4104-810c-f90c3db4b0f7	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	SENT	\N	b5fd089becd743577080dad960d58b8138746ee7128e5debda2f4e0f6097c07e	\N	5000.00	\N	\N	\N	2026-05-26 08:20:02.062+00	2026-05-26 08:20:03.714+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
95610c5b-a600-42de-822a-de207d06a05c	QT-HQ001-202605-00002	2026-05-26	2026-05-31	1e07c4e0-d12a-45f3-b7ae-8f8601fa70ca	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	CONVERTED	5e625cbc-80a3-4163-9ac0-f66dba7dba6c	f8cb56aafb7dc92c27f1c20f54e105e9f10b09e024fee96d5d375304f223a176	\N	500.00	\N	\N	2026-05-26 16:03:33.016+00	2026-05-26 16:03:05.117+00	2026-05-26 16:03:52.994+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
b4b836a0-e28a-437a-bafa-86529b0674cd	QT-HQ001-202605-00003	2026-05-26	2026-05-31	ac6eb189-b321-4104-810c-f90c3db4b0f7	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	CONVERTED	e740e26e-9481-4282-b21e-e899dc6e7771	77e6fcc345e593fbdc2b84a64f082cf5f2427ec57e2ec387dea999115cca7ba7	\N	800.00	\N	\N	2026-05-26 16:23:46.497+00	2026-05-26 16:19:59.605+00	2026-05-26 16:26:16.303+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
3ad198fd-f636-4f80-b9b8-96d64788d70e	QT-00001	2026-05-30	2026-06-02	011faebb-2952-4b7d-affd-a9e450b8cc11	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	CONVERTED	69b227da-8e82-4bf9-b4a8-b17c47d559e0	13fc98188031536a84363a26eb509e16ccaac70304592ae52ba19b9eb3f420be	\N	120500.00	\N	\N	\N	2026-05-30 07:49:29.47+00	2026-05-30 07:52:59.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LIVE	\N	\N	1
\.


--
-- Data for Name: sales_quote_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sales_quote_items (id, quote_header_id, product_id, quantity, uom, unit_price, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
d5e8bff0-e639-4c14-b2f0-c3da55b4511c	8a2b2774-cc64-417a-8413-a5f5f41d3a3e	53457790-5c18-4f3a-a2d6-709ded27ed4a	10.000	UNIT	500.00	5000.00	2026-05-26 08:20:02.062+00	2026-05-26 08:20:02.062+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6bea4177-85aa-416d-8b3d-c318f198bbbf	95610c5b-a600-42de-822a-de207d06a05c	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	UNIT	500.00	500.00	2026-05-26 16:03:05.117+00	2026-05-26 16:03:05.117+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
803c72ed-81d1-442a-a322-157e0742ffbd	b4b836a0-e28a-437a-bafa-86529b0674cd	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	10.000	UNIT	80.00	800.00	2026-05-26 16:23:20.054+00	2026-05-26 16:23:20.054+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3155666f-2f59-47bb-b8aa-eef6302f5acf	3ad198fd-f636-4f80-b9b8-96d64788d70e	f9865733-a9f7-44f6-a031-9c3925042cea	10.000	pcs	1850.00	18500.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3ed37b4a-0806-4973-bb81-d80e633a4125	3ad198fd-f636-4f80-b9b8-96d64788d70e	7a494ea2-2cf1-419c-ba0a-37da9f178b41	10.000	pcs	2300.00	23000.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
598dc01b-d0f8-4ba9-a064-9e43d986cece	3ad198fd-f636-4f80-b9b8-96d64788d70e	8c42805b-90f8-4c3d-9784-b6821ad9272a	10.000	pcs	4000.00	40000.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
5b4918a6-daaf-45b1-891b-c0d23d8ec7ce	3ad198fd-f636-4f80-b9b8-96d64788d70e	b196efdd-24e4-4435-a798-aab2e1ec69a0	10.000	pcs	580.00	5800.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bd22a749-3010-4270-9158-be6de12fb928	3ad198fd-f636-4f80-b9b8-96d64788d70e	6cf057a6-6a6e-46ac-be49-a0417acd71c3	10.000	pcs	850.00	8500.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
d04178e1-dc5f-4ce9-a08b-8da45442310a	3ad198fd-f636-4f80-b9b8-96d64788d70e	2d8107ad-f2ff-4862-b269-9b274a65b530	10.000	pcs	240.00	2400.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
d7021f54-1cc3-4402-9c44-5d4ea9b201f6	3ad198fd-f636-4f80-b9b8-96d64788d70e	2d8107ad-f2ff-4862-b269-9b274a65b530	10.000	pcs	240.00	2400.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ab3da82a-ef8b-46a3-8b6b-93ddbfc8a3b2	3ad198fd-f636-4f80-b9b8-96d64788d70e	166c4ba0-232b-484f-ad54-fab5379410fa	10.000	pcs	1250.00	12500.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
514aa55e-e730-4568-9f73-ee4d5043d82c	3ad198fd-f636-4f80-b9b8-96d64788d70e	6344a746-687f-48d0-af2e-329cc0932fc7	10.000	pcs	120.00	1200.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
eda7b3f9-659d-4b12-83ab-eef23b7880e0	3ad198fd-f636-4f80-b9b8-96d64788d70e	0459f473-75f9-463a-8237-9ca65fee69f8	10.000	pcs	620.00	6200.00	2026-05-30 07:49:29.47+00	2026-05-30 07:49:29.47+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: scan_logs; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.scan_logs (id, company_id, shop_id, barcode, product_id, user_id, action, result, created_at, source, session_id) FROM stdin;
b1aada92-8d7e-4a35-9761-c15af9330609	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	SVC-PL003	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	FOUND	2026-06-12 05:58:31.134+00	CAMERA	\N
5c62fc91-b8c9-4545-a6de-f5b15ba455fc	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	SVC-PL003	96718ee2-4ff3-4de9-bf6f-7bc023e8338f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	FOUND	2026-06-12 05:58:32.711+00	CAMERA	\N
513381a2-3112-4020-8edf-a1ee6c2aae01	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	ELE043	6344a746-687f-48d0-af2e-329cc0932fc7	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	FOUND	2026-06-12 05:58:45.822+00	CAMERA	\N
c7beb5ec-73d7-4c09-b23a-c636d87c73cf	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	8902979022682	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	NOT_FOUND	2026-06-12 06:49:56.349+00	CAMERA	\N
1913152a-f0a6-488b-87fc-48871f60fa25	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	8902979022682	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	NOT_FOUND	2026-06-12 06:52:50.612+00	CAMERA	\N
ee1b216f-b71f-4baa-b757-c7d50737e549	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	8902979022682	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	NOT_FOUND	2026-06-12 06:52:51.448+00	CAMERA	\N
449ad66f-3553-421d-b693-ac0b73fdf111	582b08bd-2a7a-475b-84c2-e4ef8f834a83	5c1f22f6-978a-43fe-ad41-28359edf08d4	8902979022682	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	LOOKUP	NOT_FOUND	2026-06-12 07:02:25.964+00	CAMERA	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.sessions (id, user_id, refresh_hash, ip, user_agent, created_at, last_seen_at, revoked_at, expires_at, device_name) FROM stdin;
b936bede-0232-480f-8ce8-240ab7f5f69f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$fNhQ6e.zmjgn.XfJ3oxgAebmAmSAvi0KEshts5ISeOO6MtT6kz7Jq	220.158.156.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 14:32:02.747+00	2026-05-25 14:52:10.025+00	2026-05-29 05:08:33.985+00	2026-06-01 14:32:02.745+00	\N
6f1f0ba6-e518-4528-9b4a-1f51da389951	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$AULir001GeCGWVPGR/Z3KOjF3EhwiPNpPlH26SruxT.ldt/e3i0mu	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 09:56:25.864+00	2026-05-25 09:56:25.864+00	2026-05-25 09:56:32.519+00	2026-06-01 09:56:25.863+00	\N
fc6aa683-f508-4167-b975-69f5fccaf459	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$BbOLgjzlEQAjhRc52Nflr.ZGHK2Nt4ODLHeWzqsGB.KTPWGDFQKrG	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 04:44:40.496+00	2026-05-25 05:19:16.149+00	2026-05-25 05:19:17.332+00	2026-06-01 04:44:40.495+00	\N
867393bf-501e-47ac-9fcb-d12973474a07	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$mOlZ2hEPt95zWSHT6PxH/ezmweZXYthaeeWLrWZN/3pKfn2Dlu7uq	2405:201:e033:6187:71e1:d4e9:5f6b:ab9b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 12:38:45.898+00	2026-05-25 13:02:23.007+00	2026-05-25 13:02:24.349+00	2026-06-01 12:38:45.897+00	\N
5315e588-f3b4-41c2-862d-0b0672bf77f6	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$bphe54SH6KfYiACPnq0lRe77wApu.7zDDVjF4D8fhky.JxM0D44Vm	2405:201:e033:6187:ede2:221c:be32:3659	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	2026-05-24 19:41:10.514+00	2026-05-25 03:50:44.716+00	2026-05-25 03:50:44.921+00	2026-05-31 19:41:10.513+00	\N
8980d287-7985-49c6-84be-1082ad6b967a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$pc3YWyS1vduybcGE3uDmkeCS2AgjJEPL.E2gFerDR93BhRVqCyUJ.	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 05:19:22.939+00	2026-05-25 05:58:20.281+00	2026-05-25 05:58:20.708+00	2026-06-01 05:19:22.938+00	\N
fe1232b1-9a2a-441d-b0db-61e416aa32ff	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$UeC5l/PSIK18Lo5DfTHuMOGRLi3PI5ujn7LwoqHgXc7Ql/0Y2WUXi	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-24 19:25:58.629+00	2026-05-25 04:08:33.747+00	2026-05-25 04:08:34.073+00	2026-05-31 19:25:58.627+00	\N
07dec3f8-8d97-452f-8a68-6ad5dfe9cc8a	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$Y5Gwx.EDCWosL1eVxr5W4OBX8XBjq3UGdCFDieixH.I16HUPG9DPi	2405:201:e033:6187:25cd:bcb9:2b83:9576	Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36 Edg/148.0.0.0	2026-05-25 12:36:27.145+00	2026-05-25 13:25:28.986+00	2026-05-25 13:25:30.251+00	2026-06-01 12:36:27.144+00	\N
638cdb34-3d7f-44f3-98d8-b7ad1b10e9b4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$qaC5o.30TldRJlf/OaMiZObWtW5Tb7LLlolkW4WT.dp2R6GWNgP32	2405:201:e033:6187:5956:1e94:d1ea:f548	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 03:57:54.553+00	2026-05-25 05:54:38.64+00	2026-05-25 05:54:39.095+00	2026-06-01 03:57:54.551+00	\N
0f959fe9-1cfb-4cdc-9b66-ba68b13f64f9	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$.jBoKiQ83sKusnAgRtXN6elF85bgO3ncR/kUEfGWvbpt9wF4fn0VW	220.158.156.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 12:51:23.914+00	2026-05-25 13:42:01.528+00	2026-05-25 13:42:02.825+00	2026-06-01 12:51:23.913+00	\N
aa4f35eb-69d7-4f4b-af55-29a4b049dc28	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$sbj.DJBYHfq5pb.NdQ0FJuP9nGofaXaoqPr7J3ybzuDYC4CDlXBm2	220.158.156.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 13:52:32.612+00	2026-05-25 14:12:16.899+00	2026-05-25 14:12:17.083+00	2026-06-01 13:52:32.61+00	\N
6a5cb5fb-1cbf-4ede-8889-1eeb76b8178d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$yLGpdRgv6FhBXv3oeP0ilOl92Mv/Pfn7U/Wp0LsKchYMOq7a3c05C	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 05:58:27.053+00	2026-05-25 06:26:58.409+00	2026-05-25 06:26:58.892+00	2026-06-01 05:58:27.052+00	\N
fc132cde-6951-4ae6-9f97-9090828ce029	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$UYFeWSu3wmCsttKVmCn2w.OEsjsqV60zKuBZ4UdiKkEpBTRjDZSN6	220.158.156.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 14:12:20.042+00	2026-05-25 14:13:26.891+00	2026-05-25 14:13:27.909+00	2026-06-01 14:12:20.041+00	\N
74a563e1-285a-426f-bfed-a3baee7f6d0b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$tab4w6c.iI8pToCYZYzRp.UREDudF3Hbp5Ebj7I/2yxOQAT4Rcb4G	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 06:27:24.949+00	2026-05-25 07:04:12.47+00	2026-05-25 07:04:13.208+00	2026-06-01 06:27:24.947+00	\N
5bfdc4d7-7f52-4e9e-beb9-069f8ef9a2a7	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$ZYQVGNnPLLrMMZ9Wk1ncEurasRxTTIQ3QD5IiC7sxStaL9lwnRASG	220.158.156.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 14:13:30.002+00	2026-05-25 14:31:42.906+00	2026-05-25 14:31:43.781+00	2026-06-01 14:13:30.001+00	\N
fc2e81f2-be1f-492e-be9a-182bcdf40825	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$./vpwAtEZ79RklEANw8MTutH5UEEWLP0q8n.d9DuctCqP2HVzlzdC	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 07:05:05.817+00	2026-05-25 08:08:04.375+00	2026-05-25 08:08:06.076+00	2026-06-01 07:05:05.816+00	\N
616fa649-de75-44ce-810a-346f86ed4915	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$gaSArOG.ncNJl5QTIds8SOVn63i1DCy/GnIYtbPtSYsFmKGzHT4gu	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 04:19:32.986+00	2026-05-25 04:41:03.946+00	2026-05-25 10:35:19.115+00	2026-06-01 04:19:32.985+00	\N
f1c283fb-b547-46bd-be2a-507ccb1022b2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$lNbNUU/N2FHpxkr7515VueI5sbU9NuZEs0A.wzHm5toUG2aWcFo7K	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 07:04:17.77+00	2026-05-25 07:05:00.588+00	2026-05-25 10:35:19.115+00	2026-06-01 07:04:17.769+00	\N
21128074-3179-4899-b24d-082b8f20c8b2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$sHLT1ct17VuB9wAH6s6MjuprG5ZezC3BsQsNKZZy7UU1WWowZUJYC	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 08:08:11.632+00	2026-05-25 08:17:52.703+00	2026-05-25 08:21:41.92+00	2026-06-01 08:08:11.631+00	\N
89b7b9f5-ecfd-49c6-a49b-7e219db51741	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$96DRGCAYjD4fZ.nNCt.t1u4MarrOJz1aFdPdHSzNyx9Ijkmy7yvlK	2405:201:e033:6187:b5cb:8da4:302a:f3ed	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	2026-05-25 03:50:48.525+00	2026-05-25 10:35:18.124+00	2026-05-25 10:35:19.115+00	2026-06-01 03:50:48.524+00	\N
20f60de4-94aa-4f14-be7b-a2eb6bcc0f92	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$FxBEzw4ByAYEvjc3dYKxa.51bmOlAzct5miQ.nQyS1XhDFS2QlB5i	2405:201:e033:6187:71e1:d4e9:5f6b:ab9b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 13:02:31.37+00	2026-05-25 15:11:21.99+00	2026-05-25 15:11:22.914+00	2026-06-01 13:02:31.369+00	\N
babcd286-da5f-4d7c-a624-80e3d8633136	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$vKPEVK6AiUNYIc6TMKsYBevKHo7iCDCo07n8RNy9QtPYXEImQZKPe	36.255.17.129	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 04:44:32.861+00	2026-05-25 08:53:01.478+00	2026-05-25 08:53:03.796+00	2026-06-01 04:44:32.86+00	\N
1b9f0aed-558d-4a71-826b-44836ace6880	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$vrCo3VGiAN06h9nX66k.EucccAGcRXBisr//J9kQpQ6aztda3WXfy	2405:201:e033:6187:e0b6:506f:a6f:e174	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 12:10:30.387+00	2026-05-25 12:26:29.813+00	2026-05-25 12:26:31.107+00	2026-06-01 12:10:30.386+00	\N
25fd5b89-dffc-4f8f-8dd6-63ea4df214e8	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$nxDlLMQEjRGBRzqw3qbhi.JA/PDcTSZfvzBz6PjqgPt7IswHnZkXu	2405:201:e033:6187:e0b6:506f:a6f:e174	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 12:27:02.386+00	2026-05-25 12:35:23.018+00	\N	2026-06-01 12:27:02.385+00	\N
64d58ab1-d2db-4462-9937-0bfba1997756	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$2ZpH1X1353OFLwxKeWKwxOc9kwCtwDHT7.7Lzs8ZyV/FJFrZbo1Le	2405:201:e033:6187:c18e:1c1b:8671:f931	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 12:04:21.081+00	2026-05-25 12:38:37.139+00	2026-05-25 12:38:37.802+00	2026-06-01 12:04:21.08+00	\N
037b0d8b-d915-4d0f-b6d8-842a4e33392b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$MGpQgkmd4BXWHLIBftkAQeBTUQnENvdGhbnDW3pGSZbS/i0YEcmCq	36.255.17.197	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 07:36:11.003+00	2026-05-29 08:18:50.091+00	2026-05-29 08:18:50.369+00	2026-06-05 07:36:11.002+00	\N
c97392c1-56d0-40f0-b563-202f6ecf86ec	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$0fswFJe1Zl/IqUyot2/qTuveBh0OT2rWo/v58dZR5qqSuI6U99uaa	2405:201:e033:6187:71e1:d4e9:5f6b:ab9b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 15:35:11.298+00	2026-05-25 15:35:36.002+00	2026-05-29 05:08:33.985+00	2026-06-01 15:35:11.296+00	\N
1fb2844c-a09d-46ae-9b4b-7b55f8407a64	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$5bMjIqg7z1Vl8wVLR2UQouXoRfOy9SVzBV3JOtbVM2I9fOWdztUIW	2405:201:e033:6187:71e1:d4e9:5f6b:ab9b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 15:35:52.854+00	2026-05-25 16:10:13.866+00	2026-05-25 16:10:15.034+00	2026-06-01 15:35:52.853+00	\N
896e4b77-9134-4a87-87b9-a9c3c90219b4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Aj2vVv3L6JueiIn6ziAYm.Sjfi79FYbHgZ/mHiYx1119VqR8rXYLW	220.158.156.250	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 15:44:17.26+00	2026-05-26 16:26:19.033+00	2026-05-26 16:33:34.866+00	2026-06-02 15:44:17.259+00	\N
3a581297-5a94-460b-8bb6-74107cf7e4f4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$FNExMRivbERvQMyTAYAUkeMxxGJHc0K9Azl6y.DS1t8ySbz/O05om	220.158.156.250	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 16:34:08.651+00	2026-05-26 16:34:08.651+00	2026-05-26 16:42:39.163+00	2026-06-02 16:34:08.65+00	\N
52ba44ac-71ac-470a-8693-2fb85e4d1c26	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$EoH2TFKYlWLsLv4tRThwpOhHl1g/v40Tg3xHTMHV73XUk1/vtD1PW	27.4.240.166	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1 Brave	2026-06-09 11:15:57.732+00	2026-06-09 11:15:57.732+00	2026-06-09 17:15:08.387+00	2026-06-16 11:15:57.731+00	\N
5691b750-d023-4e51-8aef-60b5dd2542ce	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$J/n2MLMEWyR3tehqn9/NAO7JCew1WhZFee3wWWKcdyg/5/n0ymivS	2405:201:e033:6187:3c92:3a2f:93b3:75b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 16:02:50.214+00	2026-05-25 16:57:33.933+00	2026-05-25 16:57:35.236+00	2026-06-01 16:02:50.213+00	\N
8786f4d1-4649-47dd-931a-2c1837520afd	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$G6ErYhk/1jVwn3yaNEUTAeHRNysdnyLA.dBADzWcZ4Lj9nW8IV.Ti	2401:4900:4a9b:8ab4:41c6:cb68:6865:46	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 08:59:12.294+00	2026-05-29 09:20:57.295+00	2026-05-29 09:20:59.662+00	2026-06-05 08:59:12.292+00	\N
66f4228c-c5e3-4537-ab19-2514b12e2781	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$Ayh2d441VvpK9YDIkcTOWeDkfPIYVKhF0oVcogt0PYOMlOT1yqK/q	2405:201:e033:6187:3c92:3a2f:93b3:75b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 15:51:56.368+00	2026-05-25 16:02:35.488+00	2026-05-25 16:02:44.447+00	2026-06-01 15:51:56.367+00	\N
d457818f-242b-4f22-95cb-aecc4b554a0d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$PYhFjBgYQX1WZZ65yFxbguveW7HMEN6jfyT.3.Nod3hlhRpD75Uwi	2405:201:e033:6187:71e1:d4e9:5f6b:ab9b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 16:45:26.81+00	2026-05-25 17:03:17.304+00	2026-05-25 17:03:17.72+00	2026-06-01 16:45:26.809+00	\N
7d210946-5dc9-4f80-9755-5b8915459808	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$nWXkDSYC0q47VkM4A4TwnO4tvEjJJgporApoDsJ.t4TklZ9uap/tm	49.47.218.16	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 08:17:50.911+00	2026-05-26 11:03:45.162+00	2026-05-26 11:03:45.359+00	2026-06-02 08:17:50.91+00	\N
34921075-e9e7-40e7-9b6c-587e0bdf736d	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$vBt5T31dqr.XKF8jMJ.W6e4eTyv9KK/6MJ36S6gqxilD/gEgBEVCq	49.47.218.16	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 11:05:07.985+00	2026-05-26 11:05:07.985+00	2026-05-26 11:19:58.866+00	2026-06-02 11:05:07.984+00	\N
9f8e81d0-4e82-4869-a5f6-cbd3caee92c3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$kfyrFUldFTKnnuUDiyjz4ubw7zdDzHqsc30.nmb34x8eZoJ9PCZH.	36.255.17.83	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 13:15:39.47+00	2026-05-30 03:07:24.675+00	2026-05-30 03:07:29.463+00	2026-06-05 13:15:39.469+00	\N
0512c3cd-9585-4d50-b3ac-15d121522f3c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$oWhQkG6hI74Tfj9uT8HYJOhYUpx9fWgn3aOR7.05VLzyQ1pNgcuKS	2405:201:e033:6187:71e1:d4e9:5f6b:ab9b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 16:10:19.829+00	2026-05-25 16:45:22.937+00	2026-05-25 16:45:24.727+00	2026-06-01 16:10:19.828+00	\N
37677b0d-8d9b-41c1-8df8-cd0b31eaf1e5	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$aFmfpk6Z2MR6YoRBVZwtAefAFbBX6SzRovbGpdSSp.XjzNNbfxd7O	2401:4900:232e:9877:99cf:c474:756b:9bc3	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 16:05:10.122+00	2026-05-26 07:47:57.602+00	2026-05-26 07:47:58.178+00	2026-06-01 16:05:10.121+00	\N
9cf17951-867b-4be7-9c60-3c6ec07c1714	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$yDsoOco4RYRXCEZ0rgCWl.lWR0wqQjtN4terJQAebBCjOXoPP8HQC	2405:201:e033:6187:75be:df8b:e10c:9360	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-26 10:24:53.397+00	2026-05-26 12:36:41.223+00	2026-05-26 12:36:41.833+00	2026-06-02 10:24:53.396+00	\N
c4b15596-41f2-4dad-abc2-ba3f8482e9de	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$TGsiGYDw0heysgKT5XtVHeBQgHTvVmt53ak3QLoHm9eZ7vmVTgSzq	2401:4900:4839:2006:f968:b6c7:11a7:acd2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 07:48:02.971+00	2026-05-26 08:59:48.187+00	2026-05-26 08:59:49.025+00	2026-06-02 07:48:02.97+00	\N
7930b1e9-0536-496e-ac98-9ae973e43407	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$KUyfSNnz.10Hvl89ZvfKHupOiIEeHTaPeSdp75dRJqU5elJFiMSou	202.141.98.151	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 03:10:21.672+00	2026-05-30 05:11:25.572+00	2026-05-30 05:11:33.757+00	2026-06-06 03:10:21.671+00	\N
2f85cdef-dd6d-4e82-85bb-d50e91559ff9	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$D6cCLPt9IQrPjizhm8nFruZS25PE0ja9q1MPeGdZwRi6s.4YkTrc.	2405:201:e033:6187:d5ce:d258:a120:dcc8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 16:57:38.957+00	2026-05-26 10:24:47.502+00	\N	2026-06-01 16:57:38.956+00	\N
26db76fe-8440-44b6-a58a-553edfc43f72	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$ikE6s349KDArGD/wmuouPOVFbuRIVpFPvi8Xeebwl26pRZ48roDOO	202.141.98.151	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 03:02:49.768+00	2026-05-30 05:12:49.467+00	2026-05-30 05:13:02.273+00	2026-06-06 03:02:49.767+00	\N
0c271d2a-25a5-4f81-a507-6f456d80c841	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$N8gAAGgLnNCxcnpB/24HKOVtXrLuKdbovkMc/Bz/GhNrwXNwBw7DW	202.141.99.14	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 11:13:45.077+00	2026-05-29 12:21:32.464+00	2026-05-30 05:24:46.579+00	2026-06-05 11:13:45.076+00	\N
386bc746-db6a-4469-a832-40ca83447ec4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Cf.tOw9hHgU2A.jtPNC1e.MdoqOBBN2wxEHogxtMkrSOxh149CwW6	2405:201:e033:6187:4dcc:f133:fe5e:49e6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 11:20:05.068+00	2026-05-26 13:33:17.84+00	2026-05-26 13:33:19.59+00	2026-06-02 11:20:05.067+00	\N
c115ef09-8a8d-4dee-b3b9-f0673445bb76	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$yc4PldZNqzlcbIhZyo0EZets66p9DsLGBJd0qhkNfOIMXNrm3VeeK	2405:201:e033:6187:4dcc:f133:fe5e:49e6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 13:33:23.382+00	2026-05-26 14:32:31.036+00	2026-05-26 14:32:31.151+00	2026-06-02 13:33:23.381+00	\N
b18650b9-1f6c-45e5-b7c4-84d591189122	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$VMXfkJzgLEid/qpAGQ7KV.ohwgBeSrcSNZFbazdz3or8og3piR0Rm	2405:201:e033:6187:3075:ff8a:9ae6:ba45	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-26 12:47:16.807+00	2026-05-26 14:21:13.616+00	2026-05-26 14:21:15.359+00	2026-06-02 12:47:16.806+00	\N
7e36eb60-371f-4f77-a5be-6badea3d4a78	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$P48FCgSP8MREOZEDghdpb.KSFY/YFXrgxIWW8leXbsScMNTADm3Sq	2405:201:e033:6187:792a:326c:7beb:b3c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-26 15:09:31.747+00	2026-05-26 15:14:52.855+00	2026-05-26 15:14:59.925+00	2026-06-02 15:09:31.745+00	\N
dfe44e51-a715-4470-96f6-0d9bece063ee	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$UsqiX5mn2nQB.0IHn3rC2e0twjolhU.ohFobSrYRh9qJrAiLb5CjS	2405:201:e033:6187:f1ad:381e:d1b8:9eab	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-26 15:15:03.587+00	2026-05-26 16:16:49.576+00	2026-05-26 16:16:51.769+00	2026-06-02 15:15:03.586+00	\N
f9aa170a-ff5a-42e2-920d-de80067055df	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$rkidLt7KVxNqYTfNxZvO1.byUdyDILE.Qvz1SCFRuJagjjGS.bu.q	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 05:14:59.593+00	2026-06-10 05:14:59.593+00	2026-06-10 05:15:05.914+00	2026-06-17 05:14:59.592+00	\N
4c8c61bd-cf15-4872-a4b1-f22d597c2331	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$9pAJo.bzAuNoEvt/6qAvyOUYr1YFQgMZDJd/CMd2OEfaD8hDvK7W.	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 07:39:31.374+00	2026-05-30 08:02:24.177+00	2026-05-30 08:02:24.561+00	2026-06-06 07:39:31.373+00	\N
758ff1e7-d3e8-4248-9c71-aa3ad520a367	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$cBGyBfjjpfZL.Ak/L9XwueUmE7PWEWWdY6/b3s4QyI/1aymc.3Dou	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 08:50:00.873+00	2026-05-30 09:15:08.677+00	2026-05-30 10:19:49.074+00	2026-06-06 08:50:00.872+00	\N
2d3c4a75-90e9-4386-8d0d-df133813ca9a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$t8c/R5cqMSm/B9o58TQ.KeUDbe2GoNxRmhsIpzPkw4PV4ZUtYcEVy	2405:201:e033:6187:7489:8164:96b:3256	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 08:29:06.544+00	2026-05-27 08:45:59.19+00	2026-05-27 08:45:59.218+00	2026-06-03 08:29:06.542+00	\N
11aa7cca-bffb-4955-8b82-2d0ee147092c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$6wUBBivur.WdtXaZmusyHe11z1S1BRFdmlD6YiIpSOa2JCoKo74Vu	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 06:51:58.4+00	2026-05-29 07:36:04.091+00	2026-05-29 07:36:06.136+00	2026-06-05 06:51:58.399+00	\N
32b08548-031a-4bfb-bb8a-9d48e4200a9a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$uPKxp7jHwJL9NWnDfYQlxe4udAKic2IgZkbATRxdkunhWNaVhdNl.	2405:201:e033:6187:7489:8164:96b:3256	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 11:31:19.83+00	2026-05-27 15:12:44.964+00	2026-05-27 15:12:47.162+00	2026-06-03 11:31:19.829+00	\N
338bbf65-1f9f-47f2-9635-c681786f8701	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$rMhTtKxA201.nk99DNp2yu7tav/nisMg91OSthCuB8fan09dsW2o6	2405:201:e033:6187:7489:8164:96b:3256	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 08:46:05.63+00	2026-05-27 09:35:48.799+00	2026-05-27 09:35:48.989+00	2026-06-03 08:46:05.629+00	\N
ba0f1be9-929a-4960-b162-9159987f6d11	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$QhwvbT5NGFBBzYfGKPWAWu70Q8s/yBogP1f92FzZyb5uWOUfxLmXi	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 05:03:46.374+00	2026-05-29 05:08:32.561+00	2026-05-29 05:08:34.005+00	2026-06-05 05:03:46.373+00	\N
ace9f985-a0be-4297-8755-03ff2e44676e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$9fpw4TTxDCd7MnrBouwRC.GPyJXb52hl9tPj81x0hetCpoHrdJt5y	36.255.17.11	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 08:28:56.916+00	2026-05-29 08:59:05.706+00	2026-05-29 08:59:07.462+00	2026-06-05 08:28:56.914+00	\N
5c62bc9f-4b08-42aa-ab83-da29e5951a9c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$zKSdCC9Wc2Q4RYcSut.w8OsKFsNQsnucSFCP0aWxXhIDn37fK8tuS	2405:201:e033:6187:7489:8164:96b:3256	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 09:38:03.058+00	2026-05-27 10:09:10.626+00	2026-05-27 10:09:11.981+00	2026-06-03 09:38:03.057+00	\N
030ebb30-5e08-4870-9684-2d7957daf573	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$r020GwtO3vvF2D0Jxw4WquVMKe8mckLgfhstQJuoMRvgtJC7BTlv2	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 04:45:37.758+00	2026-05-29 05:03:41.645+00	2026-05-29 05:03:41.664+00	2026-06-05 04:45:37.756+00	\N
00c67c47-8731-4228-a8ec-74da3c6c6945	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$UNSPAKyvm.dWyOptG/HaquLAY3MG6ja8whL1xPP3luHMl15cGucrm	202.141.99.14	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 12:41:35.767+00	2026-05-29 13:15:29.158+00	2026-05-29 13:15:33.558+00	2026-06-05 12:41:35.766+00	\N
76bffa5a-4440-4c2e-8333-91513b62e6b7	6fd97d36-05d1-4617-8c81-0d54da73ace8	$2b$12$IgP1Oj1O1.IPhbeLtes/DO99qpFu2iWuuQToSvS4DfCRBfSRtC.Le	36.255.17.83	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 06:43:01.176+00	2026-05-30 03:00:14.161+00	\N	2026-06-05 06:43:01.175+00	\N
37fc16e2-1c7a-434d-8838-52d7a4fadfe8	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$AjdKpf3A7PEduFDrsloLuu9m9SYm9RFI5qA1.B0jpsar9uyjKtcfq	2405:201:e033:6187:1885:d591:a2f4:f136	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-26 16:43:25.026+00	2026-05-27 12:38:17.371+00	\N	2026-06-02 16:43:25.025+00	\N
618749b2-b19d-48e0-88c3-59c71be9ecc2	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$kwsTm3FhKBd6stDKkUs7wOM8rxnR/3AFzreQHIyY7PKe8duAmXRGi	2405:201:e033:6187:dc69:2d3b:8d0b:9547	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-27 12:38:46.774+00	2026-05-27 17:16:32.52+00	2026-05-27 17:16:33.358+00	2026-06-03 12:38:46.773+00	\N
e899837b-d878-4ddb-9ee7-9c195fcb409a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$u1qm70GlHDXEb7FduTWzW.oS6IsptRvyqWUYhgH1tkOsMLjzvh3VW	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 04:34:41.303+00	2026-05-29 04:34:41.303+00	2026-05-29 04:37:24.544+00	2026-06-05 04:34:41.302+00	\N
c3e107cb-e8d1-43c4-98ba-d808345df9e3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$ogqbjxUNowFY0kzikLV3QOnegPr4d1cr85e7GTmQuMbs5P0ALt6u6	202.141.98.21	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 16:42:42.37+00	2026-05-27 09:52:12.911+00	2026-05-29 05:08:33.985+00	2026-06-02 16:42:42.369+00	\N
61500c93-46ed-47c5-9a28-57db7bda9e2a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$v3nSUD9cSAaFmg5SlQsh5OoGbMtH/ktvUHQt6LlOV8AHmkcBw8DOC	220.158.156.206	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	2026-05-25 16:29:23.062+00	2026-05-28 13:53:19.897+00	2026-05-29 05:08:33.985+00	2026-06-01 16:29:23.061+00	\N
a1ddeaa4-a047-4386-88e5-91cb6db9e5c5	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$JOLi3qVy/tTrRQwLNdJGbuVF3hB/.9v9VTpXK6hOy//0Iflf7JDL2	2405:201:e033:6187:b387:5bda:4f57:a318	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	2026-05-26 06:45:15.451+00	2026-05-26 06:45:15.451+00	2026-05-29 05:08:33.985+00	2026-06-02 06:45:15.45+00	\N
f7160c9e-e313-4b54-8ce7-662487f7cdff	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$z8qoOK8MRzIi5tpg8xybseSk/3UxiHg32tUWJpr61et1GbqPGynz.	2405:201:e033:6187:14e6:65a4:a5d4:1ea	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-25 17:03:24.27+00	2026-05-26 08:17:43.416+00	2026-05-29 05:08:33.985+00	2026-06-01 17:03:24.269+00	\N
90b90eff-5373-4f7f-ad6b-a0a61b2ff595	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$TB4uVq8csNwmcCB0ey07Lem/bVehwI5p43N5cjEsuZax9Jq6yvin6	2405:201:e033:6187:4dcc:f133:fe5e:49e6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 14:32:36.29+00	2026-05-26 14:32:36.29+00	2026-05-29 05:08:33.985+00	2026-06-02 14:32:36.289+00	\N
f8633980-2d09-412e-9efa-d859da37c076	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$A/sOpWcdyFnSKp98y74Uue.Yvd0Tpz8UT7seuVcQpv34qhZEhO4Mm	2405:201:e033:6187:4dcc:f133:fe5e:49e6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 14:38:21.465+00	2026-05-26 17:11:42.096+00	2026-05-29 05:08:33.985+00	2026-06-02 14:38:21.464+00	\N
e71955e2-7a80-49ac-a025-0dc5fe8c3f55	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$/7RBoW1pk/rW5qwPhljYaujtuJJitfslNL4ZlhNij.ANlf7C/e23y	2405:201:e033:6187:7489:8164:96b:3256	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 10:09:15.656+00	2026-05-27 11:31:17+00	2026-05-29 05:08:33.985+00	2026-06-03 10:09:15.655+00	\N
b5bb4a1e-8156-45c1-bfff-e7f121e3dafb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$gJoS0f2Dv/4HKuDdPdhDHeoOqd3uBqQcCoLKBe791wmD9PB7Y/rx.	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-27 16:31:16.399+00	2026-05-29 04:18:46.506+00	2026-05-29 05:08:33.985+00	2026-06-03 16:31:16.398+00	\N
4738695f-5496-4cd2-8b84-ec671ea26263	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$6EGr58Cc7NInRK5cbN4ZgekRFA9q4RgjqmCUJrQyyayRIV16.asRu	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 05:10:46.189+00	2026-05-29 05:33:15.881+00	2026-05-29 05:33:19.233+00	2026-06-05 05:10:46.188+00	\N
ef780609-a193-487e-9a69-e1e4fba128db	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$4s4j/aLDPHY6PZ19S5Ddv.LqNtKMkkfhgJ8wQknpnwoltHKtXzBOK	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 05:33:22.526+00	2026-05-29 06:51:52.335+00	2026-05-29 06:51:55.601+00	2026-06-05 05:33:22.524+00	\N
07bc3515-35ca-4041-87fe-381e1f9ebe1d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$5qVvEAN/VeYselBONTwgT.OUBbLV7jrUgbeT3m4ZXC4F.1EFhaz/O	202.141.99.14	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 09:54:05.283+00	2026-05-29 11:12:50.575+00	2026-05-30 05:24:46.579+00	2026-06-05 09:54:05.282+00	\N
277a97ce-03e4-4f51-a09e-31e3ad324c57	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$3g3w1EKl0jGPBl7mV0/0I.Xc81MQT2sLW9gcq0UHabUnfo1x6ZVr6	202.141.98.151	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 05:11:37.97+00	2026-05-30 05:11:37.97+00	2026-05-30 05:24:46.579+00	2026-06-06 05:11:37.969+00	\N
88cc14d8-13b9-4ec0-9fdd-7dc2e8e057e0	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$xuYBL4rhgv.Vf30I86F3qul9say/aIFfQvE2vHo2LgsKjojz5n1Zy	36.255.17.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-29 05:29:02.212+00	2026-05-29 06:42:44.43+00	2026-05-30 05:24:46.579+00	2026-06-05 05:29:02.21+00	\N
8ec2924b-7eb4-43b2-914a-af59ccfd5a14	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$luCHMiCV5T/q/NmDdtHfZO7STDfc8OV86umu6V16SURkep455egAe	202.141.98.151	Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36	2026-05-30 05:24:34.858+00	2026-05-30 05:24:41.472+00	2026-05-30 05:24:46.579+00	2026-06-06 05:24:34.857+00	\N
b8ac67a9-9cb4-4140-b5b9-db291f37fbf8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$8lxLCZiIxy.MRw7HeppRN.OFbImI7Ul.2ms3kHwpA6y..RbfkY2yu	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 08:46:22.981+00	2026-06-10 09:05:59.395+00	2026-06-10 09:06:07.558+00	2026-06-17 08:46:22.979+00	\N
92428f28-6878-4c41-ad1a-e5b34f83ec87	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$k.g1VpYvyK15ANwgt47KXutFsuLj17SHt9MSXddxwsltPOjr2O6IG	202.141.98.151	Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Mobile Safari/537.36	2026-05-30 05:26:49.966+00	2026-05-30 05:26:55.462+00	2026-05-30 05:27:02.37+00	2026-06-06 05:26:49.965+00	\N
6ab86b8b-f766-4d01-823e-bf40e57af855	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$vIR0FZEZ8lyTu78VvvZZ5eHRztEcBf0vjfvCU4EyOOHuudKDV5YE.	36.255.17.109	Expo/1017756 CFNetwork/3860.600.12 Darwin/25.5.0	2026-06-10 13:43:17.484+00	2026-06-12 02:33:30.889+00	2026-06-12 02:56:19.763+00	2026-06-17 13:43:17.482+00	\N
7cd2aa52-e1bc-4dda-abca-c77a8c484dcf	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$JiQcRYbC9EMCSU02GjG2JO/aQkyOetJ267gUO2IIa9DFNsZRTc8hS	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 03:17:10.379+00	2026-06-09 03:35:11.938+00	2026-06-09 03:35:12.906+00	2026-06-16 03:17:10.378+00	\N
9efde3b2-888a-4751-ac85-1b4bf5f80e91	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$hqBsyeUD8qe/Q5N.OAMCJODJyPSVwgoFJ2C1w27YsDv1ATpDuOsfe	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 06:22:44.268+00	2026-05-30 06:56:55.579+00	2026-05-30 06:56:56.175+00	2026-06-06 06:22:44.267+00	\N
cfa9071a-d6c6-4502-9fd9-a1bebfc9aa09	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$2XQSsHh9FejjLjGuju8PNOmznZ.ldeL25zQYdZy.nZgLeC5BnvB6O	202.141.98.151	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 06:03:50.267+00	2026-05-30 06:22:34.473+00	2026-05-30 06:22:39.261+00	2026-06-06 06:03:50.266+00	\N
715492e7-487a-473b-a941-3a8b966a0e3c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$ivyaK4pK4yR8ypb5fKJ9zuPUvgXbzBw9DCr12FkkCxrLg2OYVKO16	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 03:35:16.386+00	2026-06-09 05:17:49.729+00	2026-06-09 05:17:50.624+00	2026-06-16 03:35:16.385+00	\N
8874c334-631a-4128-8ee5-af632d265cd4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Zbfu9kun3KRRDb14R8d6veT5lFa0DLmI9lIKUqb1LppNoJBd65fg6	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 05:28:03.664+00	2026-05-30 07:23:02.467+00	2026-05-30 07:23:07.471+00	2026-06-06 05:28:03.663+00	\N
9bdc08fc-977f-4ed0-b2e8-54ea7078e656	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Y3XrRAfsdjPb8jr7p/zT8O7Y3Kb.QLZpIpFp/s5pxIu1kUVDxAPI6	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 08:02:28.561+00	2026-05-30 08:49:50.364+00	2026-05-30 08:50:00.374+00	2026-06-06 08:02:28.56+00	\N
9a6ffebd-d7c0-4281-a111-d8850242549f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$KMcaIHXNOiByeANdSWXO0ecMNDHd1bHxmxs3UhGg8eS9nSlSUdlEa	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:17:54.84+00	2026-06-09 06:26:19.063+00	2026-06-09 06:26:19.522+00	2026-06-16 05:17:54.839+00	\N
c9286db0-0447-48e5-b968-eee036cd1c09	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$AsbxWnFlCyavLwELoNvTzu08F2tVg4NRfPbEx6FbeudSDXZD2/uJ.	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 06:24:07.672+00	2026-06-09 10:07:20.746+00	2026-06-09 17:15:08.387+00	2026-06-16 06:24:07.67+00	\N
f0432c9b-1f04-4c37-987a-a98aafab7a9a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$XOfv8a9rv5hy3iidG0a0iur5LJ8Kqg2shROSLx0fmF/dIeadUuYJi	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:40:48.972+00	2026-05-30 11:12:27.659+00	2026-05-30 11:12:29.159+00	2026-06-06 10:40:48.971+00	\N
91385a43-0406-49bd-9c6a-aa202bc7e50c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$aR8Kd/tc.o8krjBBnCYY/Oeq9zPKWruGjqY9TVPZcbmXwuFxEIrH2	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 07:32:41.275+00	2026-05-30 09:10:23.778+00	2026-05-30 10:19:49.074+00	2026-06-06 07:32:41.274+00	\N
61e5f286-55e2-43ad-b69a-d91e4f15deb3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$gZkz1rV3IYu6akp19cquOu/OfAe4nBJKCWMGp7sF2JQZdy6xp4BNS	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 09:59:02.167+00	2026-05-30 10:19:05.36+00	2026-05-30 10:19:49.074+00	2026-06-06 09:59:02.166+00	\N
0fbf0240-43f2-45c2-b815-a17ca64ecd03	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$uEbXNwsbWUACs7ypZ9xJ9ud5QTDCyW8K7EF2p.KmVmaHvjfjeYTay	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:00:39.774+00	2026-05-30 10:19:45.559+00	2026-05-30 10:19:49.562+00	2026-06-06 10:00:39.773+00	\N
ce346fca-5dec-4898-ba8a-a1c4ae3206fb	d0eda257-86b4-4510-93bc-103cfe0d86e4	$2b$12$XaZye4m94dl1UnhDsvSOTObbIhq4lvUvX0Xh2EOaizPq2j5nNLs9e	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:26:37.178+00	2026-05-30 10:26:37.178+00	2026-05-30 10:29:26.565+00	2026-06-06 10:26:37.177+00	\N
9d707195-438f-421b-8b46-9c87f585770e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$m19WFW2pjh4rIrbD6lyoJONU103E8U3e6nkANeDPyiafby0HKb8OK	202.141.99.248	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-09 12:25:42.119+00	2026-06-09 16:00:18.991+00	2026-06-09 16:00:19.903+00	2026-06-16 12:25:42.118+00	\N
9ee7d213-229c-4378-b7a7-b4f767ae6dce	51e8defb-4c28-490b-beb5-283437c31e20	$2b$12$H4lEWb5cI44LRaSaJPQ9pOurzy41JdE4rVV7bh1IafoPg27TMusOi	202.141.98.193	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	2026-05-31 03:18:02.365+00	2026-05-31 03:19:02.779+00	\N	2026-06-07 03:18:02.364+00	\N
20e62fc2-e304-4a91-bf18-870aedd34839	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$8dEEqnbZkpVboTJ6v2g3fum9212yTvqB4Ku0cpWiCLljch2UDx8CO	2401:4900:230d:7c40:c519:d66e:de25:3ff0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 03:21:19.849+00	2026-06-02 05:54:07.731+00	2026-06-02 05:54:08.744+00	2026-06-09 03:21:19.848+00	\N
fde3f007-ce92-4527-8613-4ef56ece1df1	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$eCqMvfHfGzIpOEKhcXjX7uk03XsJG.oJunL7jhj6SpmZ/Nnk68HOW	202.141.98.219	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-06-02 05:39:11.121+00	2026-06-02 07:54:01.58+00	2026-06-02 07:54:02.806+00	2026-06-09 05:39:11.12+00	\N
a9ef8f63-7349-4c1d-a024-4cfd947a2380	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$J0op4dBwnjj8AEoHjBjzfewGVOYZ1UREe6hTE3tApUyVKPUdcbuRW	36.255.17.156	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 11:42:43.404+00	2026-06-02 11:44:53.644+00	2026-06-02 11:45:00.174+00	2026-06-09 11:42:43.403+00	\N
5555c1ae-fead-402b-919c-34c0cf39c21f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Lmpzb5j8kVyJfovAwz0RaeVHErBFi9sUZPBlFONoSeY.MlpjHD6w.	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 10:19:56.679+00	2026-05-30 10:19:56.679+00	2026-06-02 15:20:03.49+00	2026-06-06 10:19:56.678+00	\N
d3e295e3-c966-4bb6-bd9c-dc8a55f7befe	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$DXTYx81tFzjiAaTB36q1N.FSnc.sqEoIAEMVwYPB5NA10yun.O2IK	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 11:10:12.098+00	2026-05-30 11:40:58.877+00	2026-06-02 15:20:03.49+00	2026-06-06 11:10:12.097+00	\N
3b572c65-a711-4190-beae-d4067968f774	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$OK133PqwVRHZNTuOa.SK4OiMvtk46pAVRI6bK/Zd2CEKwrN8ww5kS	220.158.156.217	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-31 10:56:02.485+00	2026-06-02 02:19:25.963+00	2026-06-02 15:20:03.49+00	2026-06-07 10:56:02.484+00	\N
467823ba-57ce-4bfb-a128-4c2a5c4a92be	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$nIqiBOzrmMYUKoR.1jHf3eTZr1sKtRp8ecHDztoUMBAylUGtCkVMm	36.255.17.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 16:30:13.496+00	2026-05-30 16:30:13.496+00	2026-06-02 15:20:03.49+00	2026-06-06 16:30:13.494+00	\N
6957a14f-b196-4955-b52c-fd2dc40e6722	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$lei50Jtws716pQI6WLPgnOPOeNDawcqcEiCM02EoaVvoY1V2RtCci	220.158.156.169	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	2026-05-31 07:15:40.9+00	2026-06-01 03:05:22.957+00	2026-06-02 15:20:03.49+00	2026-06-07 07:15:40.899+00	\N
b6720306-f4c4-4774-9378-d2b62f5bc890	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$VfrNQdZH2J55UrHGQ/x.YOe2Bg.hiWPxqRfO5MzYJfbufI4Usmo4y	36.255.17.237	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-30 11:12:33.77+00	2026-05-31 10:54:21.372+00	2026-06-02 15:20:03.49+00	2026-06-06 11:12:33.769+00	\N
cb8e0f7c-f467-4ede-9544-f2b259487b68	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Cgv3tdvgXG5N29OPpMI85u3wdmj6HbSoYedf9IGG9c46b6BhTFVvu	2401:4900:2312:f203:f998:da77:8315:8bbd	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 10:26:30.986+00	2026-06-02 11:33:07.119+00	2026-06-02 15:20:03.49+00	2026-06-09 10:26:30.985+00	\N
50bfad78-67fe-49fe-8ec4-cb623f391c5a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$jUHg/PhzyO/2LjmJS9mOFeY/lfwkETJxMaQri1yM9HAuzD8Kbnfhm	202.141.99.152	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 11:45:06.147+00	2026-06-02 14:57:56.114+00	2026-06-02 15:20:03.49+00	2026-06-09 11:45:06.146+00	\N
90bc301b-bbf1-4df0-b67e-82f5773cf818	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$wqxCRsQh3E7CQPPrGY5Sn.0t1hdzoHPrWQUbCD4zaf5f0OLFjz9wa	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 10:37:43.517+00	2026-06-10 10:37:43.517+00	2026-06-10 10:38:41.457+00	2026-06-17 10:37:43.515+00	\N
0308ca1e-77b7-44bb-bbc1-4f3a98bdb9df	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$V1hXUXauP8.q2l78MA9yDuSOq5dcwIKJBQG.hOCPQom.pcKcGHpE2	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 10:53:30.675+00	2026-06-10 10:59:44.422+00	2026-06-10 10:59:48.805+00	2026-06-17 10:53:30.674+00	\N
096383bc-6545-4598-8a82-3c69037230c4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$gTktqmkISikXNjWvB.Y1NOYdI/jj254U/pXAu7aKu9/movxwONjju	202.141.99.152	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 15:21:37.532+00	2026-06-02 15:47:26.934+00	2026-06-02 15:47:31.739+00	2026-06-09 15:21:37.531+00	\N
af1d8fdf-7cd4-40be-90ba-1aee2b2fee4a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$9wv06xgK3TpanjUfkJm2TexbtrerfM2hLUq6.14ebqY1Zrm2pAnYy	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 06:26:23.353+00	2026-06-09 16:25:14.267+00	2026-06-09 17:15:08.387+00	2026-06-16 06:26:23.352+00	\N
db9edfeb-8c6f-4459-b6e5-2540f99fd39b	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$qqN5kF8M6Iq6lYyGwQaRBeDK4neU7ZTMTyWaz19raZlqta3icL3lm	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	2026-06-08 10:51:58.229+00	2026-06-08 10:54:53.553+00	\N	2026-06-15 10:51:58.228+00	\N
81400517-465c-4a87-a414-4af716c7421b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$AGGuAytju4xSLPtlpYH/zuX926sxjj0FF.xkfyKR6Xz8qTYLuANe6	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:55:47.661+00	2026-06-09 04:55:47.661+00	2026-06-09 17:15:08.387+00	2026-06-16 04:55:47.66+00	\N
4d1ae3a9-4f28-4a94-b8d2-c68ea6d97f05	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$burGamUdCALpPWPfVnwO..sCrSjZdqvrvoqbBTlP2gkEdkGeAZVA2	220.158.156.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-09 05:35:44.31+00	2026-06-09 07:40:12.695+00	2026-06-09 17:15:08.387+00	2026-06-16 05:35:44.309+00	\N
964cdf42-b7da-4615-a309-5f405c7aee55	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$MYhUL4WgjQYNabq6fBEVUOW3clzAljQvguJk5e6B79PA4E2H1YEya	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 05:34:12.863+00	2026-06-09 06:24:00.518+00	2026-06-09 06:24:00.697+00	2026-06-16 05:34:12.862+00	\N
d933f8d5-7cbf-4f18-bd64-8894c6a0a424	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Qk6KL0Ft2QPq9p215ksZBu3bD.GFidQrdytt7E6UktVeuZAVo8VPm	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 16:25:23.494+00	2026-06-09 16:59:01.869+00	2026-06-09 17:15:08.387+00	2026-06-16 16:25:23.493+00	\N
bb94eb97-04cf-46a0-86ce-16087c8d3496	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$9u6UiewYghl7bQADJe3ui.gcjGwbhQ/Ijm3hFOCaJSYFXKAbTYeVa	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 16:17:50.76+00	2026-06-09 01:05:59.739+00	2026-06-09 01:06:02.093+00	2026-06-15 16:17:50.759+00	\N
83a5181c-ec45-432c-90f6-ae11538c9c26	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$k9kIrOWtVzxlHL9lFT5eKOxEqmEoi9YG32kgscH/UG.mxzB5k0yE6	2401:4900:265d:dfdc:cc6e:9755:84eb:6ce8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 17:15:20.371+00	2026-06-09 17:30:57.525+00	2026-06-09 17:30:58.503+00	2026-06-16 17:15:20.37+00	\N
a82c9c55-7897-432e-9f1e-b1274d45f55a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$3vERpD7hgd9928kWVqLM/OkP.84fNrXhyr5zJF9Wnhol/XfEN8LMK	202.141.98.25	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 08:31:00.591+00	2026-06-03 09:40:26.216+00	2026-06-03 09:40:26.327+00	2026-06-10 08:31:00.59+00	\N
397e9f29-8cce-4947-8d92-329921f89455	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$P1L5KFvjo32P5saUXn8teu/s1YuubuYkcivnSaFSrEW7MpP7tH4ui	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 11:07:43.445+00	2026-06-10 11:13:50.81+00	2026-06-12 02:56:19.763+00	2026-06-17 11:07:43.444+00	\N
a1516e1e-8ce3-401a-bde0-8f7634bf7dbf	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$tey.uFpe0yf0yYYIWrB0gunAln82A6kpmpMFO2ABoL4k5gVI801im	2401:4900:231a:489:b478:429b:2178:4165	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 11:56:34.49+00	2026-06-08 14:05:27.025+00	2026-06-08 14:05:28.418+00	2026-06-15 11:56:34.489+00	\N
7e5380d5-63df-43c7-be65-9bc639890cad	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$RQvbIdQEQu/p..Y23eicduf5OqyBfOoLl0cMVa32AAMGLMQTRkNMq	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 14:22:29.552+00	2026-06-08 16:02:50.662+00	2026-06-08 16:03:04.14+00	2026-06-15 14:22:29.55+00	\N
9dae0b9a-5ed7-4225-b1a2-8690791b1069	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$3PsMxJoWGLtOsl8UXjVVGenQZipaNboYwLyblnSE9rfVxWG5zM/ZW	2401:4900:4de1:352c:2dfd:e8fa:fb78:e127	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-03 16:08:02.919+00	2026-06-06 05:17:48.39+00	2026-06-09 01:06:01.481+00	2026-06-10 16:08:02.918+00	\N
8cdf2e26-6185-4209-90aa-51bd4313726b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$XwYClSvLVQUSs8uDMWya2OXKt6ict13QXe72j90XXfhgOBRl./Blm	202.141.99.152	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 15:50:06.535+00	2026-06-02 15:50:06.535+00	2026-06-09 01:06:01.481+00	2026-06-09 15:50:06.533+00	\N
a464bd76-aef4-44b1-a5df-4df7d9c7debe	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$FTGQw8z.lQW3YcQlyAImUu4KZ2ZCq9oJQOBsPomg4ihHCc77sohxS	2401:4900:6055:8f8f:f5ca:f5a8:16eb:b858	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 15:47:36.131+00	2026-06-03 08:30:48.33+00	2026-06-09 01:06:01.481+00	2026-06-09 15:47:36.13+00	\N
b7379166-03bb-4637-9242-815d94cd4f7e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$lNGm89MhA5YxjARTabCM2OZczZsCekDrhn74FzgIbuqkASNaKbFsu	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 07:04:35.056+00	2026-06-08 11:56:30.498+00	2026-06-09 01:06:01.481+00	2026-06-15 07:04:35.055+00	\N
9884857e-473d-4c12-a12a-feffb8254683	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$B.3aGKiNcYSixYlo.chgFuo9BYHKG47tDOkjBzOYMmjaZ5DQjW97.	220.158.156.244	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-06 14:25:55.858+00	2026-06-06 14:27:06.892+00	2026-06-09 01:06:01.481+00	2026-06-13 14:25:55.857+00	\N
a9e77ac4-11f3-4518-8d6d-da9e1b05764d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$p0k26EOtY1/j7fHGib/C9uz5N08T3y7xJ4rM61abHIH9XPNjU90yG	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-06 05:17:54.831+00	2026-06-08 05:06:13.274+00	2026-06-09 01:06:01.481+00	2026-06-13 05:17:54.83+00	\N
5e4b06ef-1b40-41e0-8b2e-70038b9ad924	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$t3jTgQ88GFzc1fyS52US0eAKJhM2b79pirJyqPEuID0T/I5hprtu6	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 05:06:18.588+00	2026-06-08 07:04:30.273+00	2026-06-09 01:06:01.481+00	2026-06-15 05:06:18.587+00	\N
21e35f9e-4f93-4bcb-b7e6-08b44b26b63d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$DpznPwnu8QcOa1nNydfq6.wz4jzxp9Bfe2Q05ExFgm1RVPiCgRyWe	2401:4900:231a:489:b478:429b:2178:4165	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 14:05:32.42+00	2026-06-08 14:05:50.577+00	2026-06-09 01:06:01.481+00	2026-06-15 14:05:32.419+00	\N
d08a3226-f8de-4190-a087-afaa06a5a47d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$79SEopvmEoxVgsMMCnIzxu/LbPx8wzQcmizDL2DOdkEiyo/QaMG4.	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 16:03:08.292+00	2026-06-08 16:17:44.527+00	2026-06-09 01:06:01.481+00	2026-06-15 16:03:08.291+00	\N
51b9ed93-8a2b-4108-9c88-3525ee85b7d1	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$Hhcz1IdJSK7FTqUyqemgFuS56H2bw6dDXhomh7EIxyL0vkAs4smuS	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-08 14:05:56.936+00	2026-06-08 14:22:21.966+00	2026-06-09 01:06:01.481+00	2026-06-15 14:05:56.934+00	\N
53300059-02eb-4659-988e-4aaff1398061	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$sYdaGNALJkER9FBoJKhyCe6YtI4eDZw2NrC61uXE4Odnrd3I0UltK	27.4.240.166	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1 Brave	2026-06-08 18:13:45.498+00	2026-06-08 18:14:22.205+00	2026-06-09 01:06:01.481+00	2026-06-15 18:13:45.497+00	\N
4eb9670e-4907-4788-8b8e-3f5c7130c6fb	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$/yDJXkhYvz.9kSTpDqtuC.Jqq5nJO59WVMuCHLaaNThrb9KqnKyee	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 03:39:05.983+00	2026-06-11 07:05:36.782+00	2026-06-11 07:05:36.834+00	2026-06-18 03:39:05.982+00	\N
c8f89353-3101-41d7-ba9e-72c84c16fdd2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$si5KV8z6Vllg2wHqxorJK.vtWNWzh7ifyH1.RUwsfPdzK7yTWnLhK	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 10:50:50.106+00	2026-06-10 12:17:17.102+00	2026-06-10 12:18:51.061+00	2026-06-17 10:50:50.105+00	\N
c941141c-9d46-43f8-ba99-b5bd4decca7d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$H5v3.UPbdhx3wdxL7txym.IZP926zKkexFzespQNi5WtHQWKaeexa	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 07:05:40.819+00	2026-06-11 10:18:18.727+00	2026-06-11 10:18:19.193+00	2026-06-18 07:05:40.818+00	\N
e198e71d-ae36-43be-b09c-1a137b995f02	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$xGGzBnRmyW1Cpt08ZUXd4.jW5XXmPFd/HCS0BhwSGjzWUoRMXAM8K	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 01:06:11.169+00	2026-06-09 03:17:05.714+00	2026-06-09 03:17:06.919+00	2026-06-16 01:06:11.168+00	\N
b244bc35-2405-4e14-bbbd-3f4f2f282eae	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$d7l5HBEV7ZlhvcDGP/IE6O3N4H3sBuRXqTQ2e40zQJi/C064xL1hG	220.158.156.12	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-09 05:07:47.284+00	2026-06-09 05:34:31.384+00	2026-06-09 05:34:33.048+00	2026-06-16 05:07:47.283+00	\N
92a1cce2-af99-4c00-88db-2aa86864b6a2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$dz4rvIDmd9K/xrSsy2yGPOy1DDo3iX7zFPJEL1Ghw8llHdZ9poUFy	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 10:18:28.116+00	2026-06-11 10:18:28.116+00	2026-06-11 10:18:43.732+00	2026-06-18 10:18:28.115+00	\N
d2814551-3073-45bc-97ed-c7edb6fd06fa	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$7VA.sDoYicAnyqwVNwoUtObUrajBSSZ95IsYixeJ17OI52ZJ5cSnK	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 04:56:11.032+00	2026-06-09 05:34:08.116+00	2026-06-09 05:34:08.178+00	2026-06-16 04:56:11.031+00	\N
75f1ccde-e482-4c86-8bf4-95af1d9cb5d5	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$EXrBT2JbhKIiGvY9QVldZ..ljMJq3CfU69Gy3A5.nhP2RAO03wB3e	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 11:00:42.097+00	2026-06-10 11:00:42.097+00	2026-06-12 02:56:19.763+00	2026-06-17 11:00:42.096+00	\N
cb878976-0559-4fc5-bd1d-35ea8405c770	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$IwVNXwNWSV/yhe0OuebV7uxwUmrtYfzwPXaY/GH/2dFflkpORluzm	202.141.99.240	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-09 07:40:16.439+00	2026-06-09 08:11:36.872+00	2026-06-09 08:11:39.02+00	2026-06-16 07:40:16.438+00	\N
2e47c856-e1b0-469d-aa76-e10021fa3d13	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$GQAIEeZwl5B77xhkbu..xu4vC6yAZC4gd7FZ.BfmwIjIzA9DxY34q	2401:4900:265d:dfdc:cc6e:9755:84eb:6ce8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 16:59:06.652+00	2026-06-09 17:15:06.129+00	2026-06-09 17:15:08.387+00	2026-06-16 16:59:06.651+00	\N
2a49fbf7-bc71-4696-9bdd-24b41effbf22	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$tZX4BQrjkETlpiZuYR66e.bTEGB4T0tbLlqJTCrnaXQrbL3jV53UG	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-09 17:31:38.949+00	2026-06-10 04:38:53.65+00	2026-06-10 04:38:54.545+00	2026-06-16 17:31:38.948+00	\N
feae1584-7880-4f28-82cf-f0504450a6f6	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$ixL7f0Sk.QaIxktMCeGwQOs38rbFGFVEuuW1iMGvF/IdfS6fJ8b/i	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 04:55:16.927+00	2026-06-10 05:08:00.05+00	2026-06-10 05:08:21.874+00	2026-06-17 04:55:16.926+00	\N
059a200a-9fe6-4dac-ac65-13a2062afe0d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$UZsRdHoXRIG2O3iG6rjoKuP4mYqnNB6o3j4lp1p9cQ06cvDuVcDxW	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 14:46:01.553+00	2026-06-11 15:29:27.553+00	2026-06-11 15:29:27.773+00	2026-06-18 14:46:01.552+00	\N
4780a195-6685-44c9-af4d-1b56d930fec2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$rklFDw7cAPZQSI8te7JjQ.NPjn0MSd74Zoz46zdMyvr/Q5vPjHKq6	2401:4900:232d:151c:3c0d:509f:456b:c4e8	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1 Brave	2026-06-09 17:50:12.475+00	2026-06-10 17:22:37.908+00	2026-06-12 02:56:19.763+00	2026-06-16 17:50:12.474+00	\N
0f06eb9a-b2f5-45e2-88e9-9e6b3869e95a	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$3oVOkz2RfUiQfJup33KkIepXbFPbmYzlpJ5B6INXWax8wBjRotO96	36.255.17.80	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1 Brave	2026-06-10 17:23:36.756+00	2026-06-11 00:57:25.781+00	2026-06-12 02:56:19.763+00	2026-06-17 17:23:36.755+00	\N
ffb8a3d7-85d3-482e-870a-5509e6038dac	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$qLQf53tIAENyqmHQmXBZAOlybQDSBGKXbJFkDPVkHB2qw6LB076ra	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-10 12:19:11.499+00	2026-06-11 03:36:29.994+00	2026-06-12 02:56:19.763+00	2026-06-17 12:19:11.498+00	\N
6f578f62-7693-420d-b2c3-8483b596c57d	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$L9hKzvts97TQ5AymI88iHuo7y1OMoVR57gkp9NFSm/izCJ2hmEiBu	36.255.17.80	okhttp/4.12.0	2026-06-11 08:10:49.725+00	2026-06-11 08:20:21.21+00	2026-06-12 02:56:19.763+00	2026-06-18 08:10:49.724+00	\N
c1b46530-79db-453f-8ef9-a404e1115fd6	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$r6QuAeaU4vx6gOjQssmKAOWS9SwbtECPk0SgGpoe5L7dKURPUBDra	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 10:24:40.554+00	2026-06-11 13:14:00.018+00	2026-06-12 02:56:19.763+00	2026-06-18 10:24:40.553+00	\N
fe721ba9-a11c-44ac-bf93-e242fdbad673	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$5Hcv1h1y93BnFZ6w6Dqsi.w4mTKIsy0cpOs5L0b27KUb5gJ8M8i62	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 14:25:01.009+00	2026-06-11 14:30:44.22+00	2026-06-12 02:56:19.763+00	2026-06-18 14:25:01.008+00	\N
0f95127c-0d36-4d21-b268-4fedeb0f9771	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$6IVd.a2aEq5fUBo3ZVFpsO0B7NsG0Qomg7tgjp0DGQ/B4T1rK/TxW	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 13:14:10.47+00	2026-06-11 14:24:23.144+00	2026-06-12 02:56:19.763+00	2026-06-18 13:14:10.469+00	\N
8e01f839-f9ec-47a2-9dbe-660088f9f47f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$JfwF5v1yUmdUWxlulVpYsuCPJwNmWXv1zGq9u2SQnybjB2THra9jq	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 14:30:58.772+00	2026-06-11 14:41:53.627+00	2026-06-12 02:56:19.763+00	2026-06-18 14:30:58.771+00	\N
3458141a-1239-4a7d-9485-b32aa5e465ef	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$UsTRA34bQhYrJpT3vujaP.sS8LthpLGcGpvUkrlJxlmG63OZ9hC9e	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 14:42:25.435+00	2026-06-11 14:42:25.435+00	2026-06-12 02:56:19.763+00	2026-06-18 14:42:25.434+00	\N
88a3d2f2-1a26-4d0a-8940-4bdeb01fcf06	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$mXA1JfnpUiqcpIE7EEXYLeU5y.7ZL3g/ONpRm7kKLCKHwAooL6BUC	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 14:42:36.407+00	2026-06-11 14:42:36.407+00	2026-06-12 02:56:19.763+00	2026-06-18 14:42:36.406+00	\N
ebbfed02-e2bb-4df7-87df-e05d57e6a520	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$kfzZ341aWEiaQatJcwW2y.Kg1wuNYpvH/wHWZrHyDU/5wc.MHR71W	36.255.17.80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 15:40:38.681+00	2026-06-11 15:51:54.071+00	2026-06-12 02:56:19.763+00	2026-06-18 15:40:38.68+00	\N
0bdf5f54-984b-45a7-b84a-c2ca4a9a7f47	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$gM7LniLcear7cVZ5Dv6c9ePvZ.THCM0GO2pL07Nn3BSaQRDpaTthG	2401:4900:1739:85d8:2082:728:90be:9d6c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-11 15:52:01.387+00	2026-06-12 02:56:18.684+00	2026-06-12 02:56:19.763+00	2026-06-18 15:52:01.386+00	\N
ab19b8c0-7b8a-4605-ba92-9c7ea10502b2	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$xOZo5W2XsF6H3s.SClc28O3H6ZCo3omsKZPEKmk.fCFUJvbdFBHa2	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-12 07:28:22.915+00	2026-06-12 13:41:22.444+00	\N	2026-06-19 07:28:22.914+00	\N
54ea6d15-6fd6-435b-9ef8-978b180d908f	f20022c7-d1e2-46df-8743-c91fc33601dd	$2b$12$8dBuvCndtXxkrwwIACertO9aWa1EeMvMyom5k/5YbxPwEstaisCv.	127.0.0.1	curl/8.5.0	2026-06-13 08:14:31.391+00	2026-06-13 08:14:31.391+00	\N	2026-06-20 08:14:31.39+00	\N
d569e891-6fde-4b1e-80ac-76eedf006891	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$Y.i.z8WXmGRS78CG/R8uduJUL5rs3RU2HCL6v4L3VmcD48ZTLWMvS	127.0.0.1	curl/8.5.0	2026-06-13 08:16:38.339+00	2026-06-13 08:16:38.339+00	\N	2026-06-20 08:16:38.338+00	\N
9ad27d9d-f656-4b7d-a442-2c815aa3e184	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$ATFO2H.UMT.sqv0gbm2fL.IRqa678RKoRSrWvuDP.v/YZ8Qr4AfVq	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-12 13:41:25.841+00	2026-06-12 15:23:21.998+00	2026-06-12 15:23:23.682+00	2026-06-19 13:41:25.84+00	\N
362b949e-1389-4c6b-a816-11ab8ccb25d3	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$oMfAfrMu0rXG.3zoKmik6uSRG/eib/OJDGHGGLfhzP5STP3oLlrJO	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-12 15:23:33.093+00	2026-06-12 16:29:05.952+00	\N	2026-06-19 15:23:33.092+00	\N
05fd7aec-2408-4367-84fe-700c8a73bfa4	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$xs/7OMd8mXOhD51Nv5lXiO01d25cYoDu2RDAxMBhJJl1yaYEt83fG	36.255.17.13	Expo/1017756 CFNetwork/3860.600.12 Darwin/25.5.0	2026-06-13 04:32:42.795+00	2026-06-13 04:32:42.795+00	\N	2026-06-20 04:32:42.794+00	\N
128c82bc-601f-4b31-80a8-c07c3e744c59	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$mzmEHsSiQVMwgRekg7d0hOHNCjqdzWZocpdFI/RBSNKxZdFasfVVi	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-12 16:29:13.965+00	2026-06-13 04:56:26.803+00	\N	2026-06-19 16:29:13.964+00	\N
aac7eea3-cfcf-43cd-96ed-47ac1235f132	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$IFnRLVTP97ZsAOdWjaSTwOTOGyW4O.CItqeGFy5NpiEBwz4w0XQie	202.141.99.252	okhttp/4.12.0	2026-06-12 03:01:12.945+00	2026-06-12 03:34:20.429+00	2026-06-12 07:28:16.452+00	2026-06-19 03:01:12.944+00	\N
bd875e75-955d-4aea-8f61-5f0bb8b36f21	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$gvrADNo9WECZ8r7a.0KlGOlTdveFUmV4DggC8WWpI/r7johv6dULa	202.141.99.252	Expo/1017756 CFNetwork/3860.600.12 Darwin/25.5.0	2026-06-12 03:38:30.641+00	2026-06-12 04:01:10.919+00	2026-06-12 07:28:16.452+00	2026-06-19 03:38:30.64+00	\N
b0c700b0-ccaf-4e1f-b165-79e7d9c44d90	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$pQQaPUUIxVXENH5McKrCr.JL7FBRlBP6LvX.PQ9xpMDTaid2C06KK	202.141.99.252	Expo/1017756 CFNetwork/3860.600.12 Darwin/25.5.0	2026-06-12 04:08:17.1+00	2026-06-12 07:12:24.772+00	2026-06-12 07:28:16.452+00	2026-06-19 04:08:17.098+00	\N
76ef3589-144a-42ac-91ff-2bbc848ad2ce	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$cIYO5eM17mwIZ0eBnOxt8.LxehI7uYEK6x.9SA8A0fJVAAZDIjAZ.	202.141.99.252	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-12 05:15:10.361+00	2026-06-12 07:28:15.379+00	2026-06-12 07:28:17.227+00	2026-06-19 05:15:10.36+00	\N
733b240d-27b8-4d82-b8bc-92c06f736a11	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$DdsoI1S3N3qan8gi9PXc2OM1x2GmJKG1i7/nsN3nsm.moRDkJ1I4a	36.255.17.13	okhttp/4.12.0	2026-06-13 05:57:11.241+00	2026-06-13 05:58:44.258+00	\N	2026-06-20 05:57:11.24+00	\N
cb49cfd1-cfb0-4ad4-8d78-4545a29eae6e	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$4MQpGnhEqOngmtrOHiwp8u9b9VgLjXoor6DVSWH2BYTU8HlTOuZ2e	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-13 04:56:35.79+00	2026-06-13 07:55:35.158+00	2026-06-13 07:55:39.253+00	2026-06-20 04:56:35.789+00	\N
09fc7e2f-a9bc-4a18-b4a9-ef740fad52b6	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$xQ4qt5AwiZZnEBVBsDYBh.RI/goFTsptqfQYl6zt3/Sj927wk/qPu	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-13 07:55:44.025+00	2026-06-13 09:07:33.955+00	2026-06-13 09:07:34.369+00	2026-06-20 07:55:44.024+00	\N
ecf5e203-a4e2-4d7d-8fbf-1760e46040e7	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$EttOAHHvaNa0pNLbyNLPAO.YGcA6mNBi7KYLdusI3W4reS.WXXOym	36.255.17.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-06-13 09:07:42.335+00	2026-06-13 09:07:42.335+00	2026-06-13 09:07:50.098+00	2026-06-20 09:07:42.334+00	\N
83c7f049-63e4-4527-892b-f70fc184e9ad	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$.cwwXjgRLR2vRTu2PBC97u8GFjsmec6zWpzL/y4uyWEAgHW6HIHyq	127.0.0.1	curl/8.5.0	2026-06-13 09:35:54.286+00	2026-06-13 09:35:54.286+00	\N	2026-06-20 09:35:54.285+00	\N
905486d2-5602-47e9-b30f-895335e9fefa	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$cowCnKy4bG.Pl5YAjpKklOumk7O3NvOOvsizujyaCjVSFggL/Bgiy	127.0.0.1	curl/8.5.0	2026-06-13 09:36:40.033+00	2026-06-13 09:36:40.033+00	\N	2026-06-20 09:36:40.032+00	\N
ff384e94-7a5b-4389-9bc9-1a5d55065eec	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$jjHubm7PZHCYCBS2ZpeBPOCFvw6fpTJ6yGdz3TjTw9zJ8Kly4mgF.	127.0.0.1	curl/8.5.0	2026-06-13 09:37:13.551+00	2026-06-13 09:37:13.551+00	\N	2026-06-20 09:37:13.55+00	\N
7bb7565a-5700-4b26-a2b0-4ec7e2f8673b	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	$2b$12$OXqrU4nTK1RGQaYDC3I6FOwQ1EN/vF0eKTa5d/QkcSepH6hL8Tjiq	127.0.0.1	curl/8.5.0	2026-06-13 09:37:29.592+00	2026-06-13 09:37:29.592+00	\N	2026-06-20 09:37:29.591+00	\N
\.


--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.shops (id, shop_number, shop_name, tax_id, address, contact_person, mobile, email, company_id, is_active, costing_method, functional_currency, created_at, updated_at, created_by, updated_by, branding_profile_id) FROM stdin;
0f2ae8d3-b590-4b93-9c27-198ef987b2ad	HQ-001	Headquarters	\N	1 Main Street	System Admin	+0000000000	hq@retailims.local	582b08bd-2a7a-475b-84c2-e4ef8f834a83	t	AVERAGE	USD	2026-05-24 19:03:56.404+00	2026-05-24 19:03:56.404+00	\N	\N	\N
a193b5a3-f970-46cb-97df-5fd787496f8e	SAMITE-001	Head Office	\N	77/44,2nd main road,gandhi nagar,Adyar	Tharun Adhithya	+919566376859	gstharunadhithya08@gmail.com	41168db8-acc2-46f2-87e0-d07b6b813bc8	t	AVERAGE	USD	2026-05-25 09:59:42.511+00	2026-05-25 09:59:42.511+00	\N	\N	\N
c52ae944-6e14-4517-962f-8a8de35d7b30	THARUN-001	Head Office	\N	77/44,2nd main road,gandhi nagar,Adyar	Tharun Adhithya	+919566376859	gstharunadhithya@gmail.com	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	t	AVERAGE	USD	2026-05-25 10:08:06.434+00	2026-05-25 10:08:06.434+00	\N	\N	\N
2b4ea860-95fe-4047-a7a5-6c3ee795c461	SOFTDI-001	Head Office	\N	77/44,2nd main road,gandhi nagar,Adyar	Tharun Adhithya	+919566376859	tharunbackup08@gmail.com	ff82dfb2-daf8-4f8f-a813-19033c69ea47	t	AVERAGE	USD	2026-05-25 12:04:20.862+00	2026-05-25 12:04:20.862+00	\N	\N	\N
d53ce4ee-7da6-4709-b944-348687fb0843	REVATH-001	Head Office	\N	Near Police quoters road, Ganapathy	Kumar	9566376859	swamiedge@gmail.com	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	t	AVERAGE	USD	2026-05-25 12:10:30.168+00	2026-05-25 12:17:11.605+00	\N	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
5c1f22f6-978a-43fe-ad41-28359edf08d4	PL-003	Automobile Manafac. plant chennai	\N	chennai	Kolandasamy	9677878824	kolandasamy.sss@gmail.com	582b08bd-2a7a-475b-84c2-e4ef8f834a83	t	AVERAGE	USD	2026-05-29 13:52:49.956+00	2026-05-29 13:52:49.956+00	6fd97d36-05d1-4617-8c81-0d54da73ace8	\N	\N
e7b380ad-9b2d-4cef-afd6-5a620973c9c8	SAMAND-001	Head Office	\N	12 Industrial area Hosur	Samritha	9976774044	samrithags12@gmail.com	5c4b301a-5ddc-4777-acbd-adddeee7ef37	t	AVERAGE	USD	2026-05-31 03:18:01.915+00	2026-05-31 03:18:01.915+00	\N	\N	\N
\.


--
-- Data for Name: signup_verifications; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.signup_verifications (id, email, payload, otp_hash, attempt_count, expires_at, consumed_at, created_at, session_token_hash, totp_secret_encrypted) FROM stdin;
fd271046-3153-4e89-9b6b-1ddfc8f449dc	gstharunadhithya08@gmail.com	{"plan": "plus", "mobile": "+919566376859", "billing": "monthly", "adminName": "Tharun Adhithya", "plantName": "Head Office", "companyName": "Sami tech", "passwordHash": "$2b$12$6EU1PsEuQB0z5WV4Z1LfE.uiJURvoRyzLJUl294C55XypCh3c/3B2", "plantAddress": "77/44,2nd main road,gandhi nagar,Adyar", "contactPerson": "Tharun Adhithya", "otpVerifiedAt": "2026-05-25T09:58:51.796Z", "companyAddress": "77/44,2nd main road,gandhi nagar,Adyar"}	$2b$12$vVOngpIWz9x7kT2hds3AEeN7.KfdmEmBaatw2E9sh0WU6zvgSXvl.	0	2026-05-25 10:13:23.211+00	2026-05-25 09:59:42.515+00	2026-05-25 09:58:23.215+00	\N	\N
d26b4c4d-37d7-4b30-a0c3-53fc21e5ffed	gstharunadhithya@gmail.com	{"plan": "plus", "mobile": "+919566376859", "billing": "monthly", "adminName": "Tharun Adhithya", "plantName": "Head Office", "companyName": "Tharun Pvt Ltd", "passwordHash": "$2b$12$LWuP0UjuHvdyfM/m2oy75.squuQkiKInJIsHAEnQkHhthrIvuE1Zu", "plantAddress": "77/44,2nd main road,gandhi nagar,Adyar", "contactPerson": "Tharun Adhithya", "otpVerifiedAt": "2026-05-25T10:07:22.907Z", "companyAddress": "77/44,2nd main road,gandhi nagar,Adyar"}	$2b$12$sp.MKrqE.Uwg71iHylrYLuhcb3982bod/wDlsZxYQ.80P6LQp6vzy	0	2026-05-25 10:21:47.686+00	2026-05-25 10:08:06.439+00	2026-05-25 10:06:47.69+00	\N	\N
4205b32d-d490-4bf3-bcba-982d050b880b	tharunbackup08@gmail.com	{"plan": "trial", "mobile": "+919566376859", "billing": "monthly", "adminName": "Tharun Adhithya", "mfaMethod": "totp", "plantName": "Head Office", "companyName": "SoftDigits", "passwordHash": "$2b$12$HvjQYAGj4A/1l/v/RJrLIuJKed98das1UBxv5894.ONyT7lIW3cnq", "plantAddress": "77/44,2nd main road,gandhi nagar,Adyar", "contactPerson": "Tharun Adhithya", "mfaVerifiedAt": "2026-05-25T12:04:12.760Z", "otpVerifiedAt": "2026-05-25T12:01:45.466Z", "companyAddress": "77/44,2nd main road,gandhi nagar,Adyar", "backupCodeHashes": ["$2b$12$xMwvoTA7XKvlHJSqk9dWKOxFmdfCmnc9aDKSclAvCNZ6DDcGF2ycm", "$2b$12$eXEnFLsngYCu9w24RcTMCOsVfzwyMIX6C4hrW8wR9g85X7tOTAJJi", "$2b$12$JoFLhK4AROxrQLIZb9fyfeiG/tcY9qEuCa1bxatwT7ktMPO116iHG", "$2b$12$AzNNL3M8BG5XXz2Ppju.jemuojCp4BmFDblSMSjyoEtZg3QXP5sqa", "$2b$12$8sgDTVMNF6IKCTJ81NayHeNymTo/1avB9wLm0ikYhWpYOux2A1vqy", "$2b$12$bHbzvlzQfJOhYuctSjokKOIDwTeZIAjTiMlnRTYKs3T4ucAJJTsku", "$2b$12$mUA1zg9LjTpflU2titZ.H.e98wmribS1Z9kdHWp/iqLPDlU3sm4De", "$2b$12$V1PMpKAaGMufPISS3E1J2e8zTbudb1N5qeDVdkdoLCbNB/fxKGBD."]}	$2b$12$fWf0fUOoAQID/wb01.x90uV0JCOF02SZbrR3IFJEY/lI4/FcryDB2	0	2026-05-25 13:01:45.466+00	2026-05-25 12:04:20.869+00	2026-05-25 12:01:14.423+00	\N	pyXzsX9wzOofVjiv.RXTyve5b02nk_pvAXs4HUw.NOnWdEHaloM5DvqCNMSWTsB6AntadhhFb6otUsbkdOs
3203bea5-ed4d-49ca-a2a7-937bbb15a5fe	swamiedge@gmail.com	{"plan": "plus", "mobile": "9566376859", "billing": "monthly", "adminName": "Sami", "mfaMethod": "totp", "plantName": "Head Office", "companyName": "Revathi Hotels", "passwordHash": "$2b$12$Rt.O5kls9nCKWQ9U8tSU4u0IzBwBpyszja34jll6Xn.8I9cpjb2Zq", "plantAddress": "Near Police quoters road, Ganapathy", "contactPerson": "Kumar", "mfaVerifiedAt": "2026-05-25T12:09:54.029Z", "otpVerifiedAt": "2026-05-25T12:07:52.712Z", "companyAddress": "2/235,Udaya Nagar, Sivaram nagar", "paymentOrderId": "order_StajBMdghC68mg", "backupCodeHashes": ["$2b$12$1pTCoW3excpEJX0Q2KxqbumFOI4ESi8wgyAo2mnBGLQ78II37wuUy", "$2b$12$M1IIxkHPBtSrsuX144yujOowf61JInt9fwcSL0njHdizm5GPnPJ2G", "$2b$12$7uI48t65MLM1y0EssBQ8Xelz0H0/FLy2Yxo8hEex/olvYlJmn3R4G", "$2b$12$jdbYKP6G1aTRkqy81Fm2IOH6XV0B.RDg5fgaFzFTCrO9iQtl9poH6", "$2b$12$H2HdccvKFIspCfMkbzwHI.dnsI2ZUvwRT0QV9iHK2R7A/4hoMK2ki", "$2b$12$DQoyymgb6j3sRyiBMZp3muiYVW02ecOCZU/8uaEK.eHhJTLBI2Dy2", "$2b$12$eeckjlWXorWGNEHydgGmWeqGlCNlGcZJJaBWME4ie3ErxwIt9PWAG", "$2b$12$t9NkQmmS4/Bv73mOHNdfgu8H2dziRBXZO1yrexgOl0uRTDwRAYFHG"], "paymentPaymentId": "pay_StajcUG2XnRQDb", "paymentVerifiedAt": "2026-05-25T12:08:36.171Z"}	$2b$12$ARSmOsLfGeG3Are3g40SH.jUhrTwXZBSqRSgLQQT7ilHfxvR9isbC	0	2026-05-25 13:08:36.172+00	2026-05-25 12:10:30.174+00	2026-05-25 12:07:23.733+00	\N	L-DZietOk0eap1tK.zZCfqK24rmQrINPTQUA8dw.GB1VauohLxVzADQzpotbYsXJ0-u-SZ-KaO9y1XnPwcM
18a68494-ce18-451d-9569-f0c99479608e	samrithags12@gmail.com	{"plan": "trial", "mobile": "9976774044", "billing": "monthly", "adminName": "Samritha", "plantName": "Head Office", "companyName": "Sam and co", "passwordHash": "$2b$12$vO59zPw3fXa0FEzvJWuxoeHLAa1/gc9efe4C4UTnimwwR63WiwccK", "plantAddress": "12 Industrial area Hosur", "contactPerson": "Samritha", "otpVerifiedAt": "2026-05-31T03:17:58.979Z", "companyAddress": "12 Industrial area Hosur"}	$2b$12$s2xawAVrclqzqpepc2rPbuDQXY3AA1uDPf1B4mIyEbo1Snaq8KWgO	0	2026-05-31 04:17:58.979+00	2026-05-31 03:18:01.92+00	2026-05-31 03:17:31.789+00	\N	\N
\.


--
-- Data for Name: stock_count_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_count_items (id, session_id, product_id, counted_qty, expected_qty, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_count_sessions; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_count_sessions (id, session_number, company_id, shop_id, status, remarks, started_by, approved_by, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_ledger; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_ledger (id, transaction_type, transaction_ref, transaction_date, shop_id, product_id, in_qty, out_qty, balance_qty, unit_rate, value, remarks, idempotency_key, created_at, updated_at, created_by, updated_by) FROM stdin;
9adf40ea-a63d-4283-9461-37f901d556d9	GOODS_RECEIPT	GR-HQ001-202605-00003	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	1.000	0.000	0.000	500.00	500.00	{"sourceType":"GOODS_RECEIPT","sourceId":"8f914892-94f8-44a0-888c-c6d2867c8805","sourceLineId":"712b800e-a15b-40af-a194-a251015627e8"}	gr:8f914892-94f8-44a0-888c-c6d2867c8805:712b800e-a15b-40af-a194-a251015627e8	2026-05-25 08:10:02.062+00	2026-05-25 08:10:02.062+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
1b30c385-fcdc-4f9a-acec-d1f4af05cb7d	GOODS_ISSUE	RMO-202605-00001	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	0.000	1.000	0.000	500.00	500.00	Supplier return acknowledged | {"sourceType":"SUPPLIER_RETURN","sourceId":"943c0a1f-0367-4504-81fc-c7c934db14a7","sourceLineId":"09d0526b-4020-454b-8306-293edd2e76e2"}	sup-ret:943c0a1f-0367-4504-81fc-c7c934db14a7:09d0526b-4020-454b-8306-293edd2e76e2	2026-05-25 08:13:48.778+00	2026-05-25 08:13:48.778+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
c64004a7-c47e-44a9-bd67-49b7b49bca36	OPENING	OPENING-PRD002-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	0f509c46-26de-435c-8e5c-6054e05f60a2	10.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD002-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:17.469+00	2026-05-25 16:00:17.469+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
980d78a2-d431-47c3-8edf-ecce04b37b87	OPENING	OPENING-PRD003-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	be5bee46-21eb-47e0-98a2-8aeecde1e954	2.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD003-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:18.922+00	2026-05-25 16:00:18.922+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
fc1c7211-e4d0-433c-aed3-e89cf2dd2c93	OPENING	OPENING-PRD004-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	431b4546-2745-432c-8ebe-7c1d298450a0	23.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD004-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:31.137+00	2026-05-25 16:00:31.137+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
df73868f-6c2b-44c7-a6b6-d8d4f7cbe353	OPENING	OPENING-PRD005-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	b5c9e408-27d3-4dba-b7dd-483825322976	54.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD005-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:38.819+00	2026-05-25 16:00:38.819+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
03b7fc67-5641-4fa7-b154-5d099b5c106b	OPENING	OPENING-PRD006-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	d493fddc-f3b3-4002-ba2a-bb5dc7e7df02	12.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD006-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:47.236+00	2026-05-25 16:00:47.236+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
ff38c960-a992-4613-82b7-58d9436a9405	OPENING	OPENING-PRD007-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	63c5f664-dc5f-4a7f-abdd-b57561288775	22.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD007-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:51.878+00	2026-05-25 16:00:51.878+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
5c10d5e4-c316-4fa5-8512-2174e1c2a7df	OPENING	OPENING-PRD008-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	97fbabe5-c40e-466d-8a3d-0b1fcc1de16f	9.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD008-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:00:57.4+00	2026-05-25 16:00:57.4+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
9865513b-eb83-4b8e-92a2-2e3c21d90bff	OPENING	OPENING-PRD009-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	bd4951e4-39b2-4fdc-bc82-d7120963d4cd	13.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD009-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:01:04.974+00	2026-05-25 16:01:04.974+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
7b0cc4f2-4ca2-45b3-a237-4756ed678757	OPENING	OPENING-PRD010-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	c493edaf-78ef-4954-b311-3d45c05cfeaa	7.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD010-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:01:11.623+00	2026-05-25 16:01:11.623+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
00d10c22-25d1-4035-a796-1fe9d117ed5d	OPENING	OPENING-PRD011-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	30e0ab96-c69d-466c-a806-6f05591d8733	43.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD011-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:01:16.167+00	2026-05-25 16:01:16.167+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
dfc630d9-af0f-4b24-a043-1cbe660235d8	OPENING	OPENING-PRD012-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	ca4e1bca-91a2-4dbb-9886-869563a27c28	2.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD012-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:01:21.04+00	2026-05-25 16:01:21.04+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
d617d564-4f80-4b79-8980-6487776fd60b	OPENING	OPENING-PRD013-d53ce4ee	2026-05-25	d53ce4ee-7da6-4709-b944-348687fb0843	343ccd4b-e7da-4108-a785-3de8313a96e3	3.000	0.000	0.000	\N	\N	Opening stock | {"sourceType":"OPENING","sourceId":"OPENING-PRD013-d53ce4ee","sourceLineId":null}	\N	2026-05-25 16:01:23.334+00	2026-05-25 16:01:23.334+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
4ad3e10c-99f4-4e0f-8335-37bbbe4bd552	GOODS_RECEIPT	GR-HQ001-202605-00006	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	2.000	0.000	0.000	300.00	600.00	{"sourceType":"GOODS_RECEIPT","sourceId":"45646ecc-b754-4e18-8325-9ced2130180f","sourceLineId":"5161a057-b0fe-40c0-a2a3-4b6a7cf05709"}	gr:45646ecc-b754-4e18-8325-9ced2130180f:5161a057-b0fe-40c0-a2a3-4b6a7cf05709	2026-05-25 16:19:32.334+00	2026-05-25 16:19:32.334+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
f95334db-b4b1-435f-9edd-b1b41d9f1a76	GOODS_RECEIPT	GR-HQ001-202605-00006	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	5.000	0.000	0.000	100.00	500.00	{"sourceType":"GOODS_RECEIPT","sourceId":"45646ecc-b754-4e18-8325-9ced2130180f","sourceLineId":"a44d547d-2d99-4a43-8308-2a6a6605b24b"}	gr:45646ecc-b754-4e18-8325-9ced2130180f:a44d547d-2d99-4a43-8308-2a6a6605b24b	2026-05-25 16:19:32.338+00	2026-05-25 16:19:32.338+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7faf7a0c-97c5-4a52-8ea5-8235f4eaa012	GOODS_RECEIPT	GR-HQ001-202605-00007	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	20.000	0.000	0.000	100.00	2000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"7aa747e6-053b-4195-a602-336b745fa59d","sourceLineId":"03e76f66-9390-4725-bd49-44953ca15cc8"}	gr:7aa747e6-053b-4195-a602-336b745fa59d:03e76f66-9390-4725-bd49-44953ca15cc8	2026-05-25 17:04:52.557+00	2026-05-25 17:04:52.557+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6e6ea201-07ad-48fc-a075-8d11b889f2da	GOODS_RECEIPT	GR-HQ001-202605-00007	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	30.000	0.000	0.000	300.00	9000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"7aa747e6-053b-4195-a602-336b745fa59d","sourceLineId":"f3ea3c13-b9ff-4394-983c-ad06416cabe1"}	gr:7aa747e6-053b-4195-a602-336b745fa59d:f3ea3c13-b9ff-4394-983c-ad06416cabe1	2026-05-25 17:04:52.56+00	2026-05-25 17:04:52.56+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4c492080-0975-4f43-81fd-56dc17d74df5	GOODS_RECEIPT	GR-HQ001-202605-00008	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	1.000	0.000	0.000	100.00	100.00	{"sourceType":"GOODS_RECEIPT","sourceId":"1106b90e-4c5b-4583-b8cf-90a80d92ef99","sourceLineId":"65a6f65b-0ead-4b46-ac62-88f963e35c60"}	gr:1106b90e-4c5b-4583-b8cf-90a80d92ef99:65a6f65b-0ead-4b46-ac62-88f963e35c60	2026-05-25 17:06:46.699+00	2026-05-25 17:06:46.699+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
68785116-cf07-43e1-a62f-fbf1ae7a94c9	GOODS_RECEIPT	GR-HQ001-202605-00009	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	20.000	0.000	0.000	100.00	2000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"7265e3e8-c9d0-4c1e-9deb-c84c79b747e2","sourceLineId":"017bbec9-1bf9-45b0-bfe1-64f9dd9d7aa3"}	gr:7265e3e8-c9d0-4c1e-9deb-c84c79b747e2:017bbec9-1bf9-45b0-bfe1-64f9dd9d7aa3	2026-05-25 17:11:09.975+00	2026-05-25 17:11:09.975+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
a473d118-0243-444d-b5bb-f1c94c3c81db	GOODS_RECEIPT	GR-HQ001-202605-00010	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	10.000	0.000	0.000	100.00	1000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"c940051f-3ff8-4982-a627-ac3f1dd24018","sourceLineId":"cb1e7995-b594-468e-aa75-e6c6b7a5d5e5"}	gr:c940051f-3ff8-4982-a627-ac3f1dd24018:cb1e7995-b594-468e-aa75-e6c6b7a5d5e5	2026-05-26 07:27:34.647+00	2026-05-26 07:27:34.647+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
5894cbc4-a986-42c0-a9ac-1e3ea9483237	GOODS_RECEIPT	GR-HQ001-202605-00011	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	25.000	0.000	0.000	300.00	7500.00	{"sourceType":"GOODS_RECEIPT","sourceId":"dbe84bee-6afc-411a-943c-32c4467b05d6","sourceLineId":"7b68abf4-513a-458d-ba15-2554cbb7caa0"}	gr:dbe84bee-6afc-411a-943c-32c4467b05d6:7b68abf4-513a-458d-ba15-2554cbb7caa0	2026-05-26 07:57:58.271+00	2026-05-26 07:57:58.271+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
097f1d1d-962f-4ef6-9b5c-74fdae1656c6	GOODS_ISSUE	SO-HQ001-202605-00001	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	0.000	10.000	0.000	500.00	5000.00	Sales order fulfillment | {"sourceType":"SALES_ORDER","sourceId":"f60f8cee-b969-45fa-b000-ce4880f495c1","sourceLineId":"e9aadfae-da93-4c43-8dba-cb4b57a63c95"}	so-fulfill:f60f8cee-b969-45fa-b000-ce4880f495c1:e9aadfae-da93-4c43-8dba-cb4b57a63c95:0	2026-05-26 08:26:45.227+00	2026-05-26 08:26:45.227+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4c815f15-8903-4b32-882e-4b924a68f9b8	GOODS_ISSUE	RMO-202605-00002	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	0.000	5.000	0.000	300.00	1500.00	Supplier return acknowledged | {"sourceType":"SUPPLIER_RETURN","sourceId":"d2031d2e-f4f8-40d5-ba30-d2e7870037ac","sourceLineId":"0895de8c-01ae-451e-bf63-120c401a02b6"}	sup-ret:d2031d2e-f4f8-40d5-ba30-d2e7870037ac:0895de8c-01ae-451e-bf63-120c401a02b6	2026-05-26 08:30:31.544+00	2026-05-26 08:30:31.544+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
fb4a97fb-938c-413b-b6fe-6924afc091df	GOODS_RECEIPT	GR-REVATH001-202605-00001	2026-05-26	d53ce4ee-7da6-4709-b944-348687fb0843	c493edaf-78ef-4954-b311-3d45c05cfeaa	10.000	0.000	0.000	1300.00	13000.00	batch:Bar04348 | {"sourceType":"GOODS_RECEIPT","sourceId":"4c30dcfe-1b7f-453f-928f-35fe9d255115","sourceLineId":"7abfa4ee-23da-4fcf-8d46-0a73ff15b4d0"}	gr:4c30dcfe-1b7f-453f-928f-35fe9d255115:7abfa4ee-23da-4fcf-8d46-0a73ff15b4d0	2026-05-26 13:13:23.09+00	2026-05-26 13:13:23.09+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
44827fdf-3243-4a9d-9d4e-7c12b2facfbf	GOODS_ISSUE	GI-HQ001-202605-00001	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	0.000	1.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"6045be97-ea41-4a8c-ba88-ae1ca2882767","sourceLineId":"3152f35b-6047-43cd-963b-c8b0ef7a6a7c"}	gi:6045be97-ea41-4a8c-ba88-ae1ca2882767:3152f35b-6047-43cd-963b-c8b0ef7a6a7c	2026-05-26 15:23:12.68+00	2026-05-26 15:23:12.68+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
62535e37-7761-4592-b966-3fb6b936c904	GOODS_ISSUE	SO-HQ001-202605-00003	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	0.000	20.000	0.000	500.00	10000.00	Sales order fulfillment | {"sourceType":"SALES_ORDER","sourceId":"aad38599-ea83-40b3-a98b-34f8da4358a6","sourceLineId":"0b9c93be-dd15-4db8-bab9-98e2a1970f19"}	so-fulfill:aad38599-ea83-40b3-a98b-34f8da4358a6:0b9c93be-dd15-4db8-bab9-98e2a1970f19:0	2026-05-26 15:25:06.233+00	2026-05-26 15:25:06.233+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
cb178bc9-ae00-4ba9-a39c-6aadd88945c3	GOODS_RECEIPT	GR-HQ001-202605-00012	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	25.000	0.000	0.000	300.00	7500.00	{"sourceType":"GOODS_RECEIPT","sourceId":"70daea11-f9f3-40c2-aab2-5a33b3840e43","sourceLineId":"1726baa5-8c18-4827-8302-60beb2b612f9"}	gr:70daea11-f9f3-40c2-aab2-5a33b3840e43:1726baa5-8c18-4827-8302-60beb2b612f9	2026-05-26 15:59:30.238+00	2026-05-26 15:59:30.238+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
76db09d0-7c81-4d63-a035-b5ada2b2997d	GOODS_RECEIPT	GR-HQ001-202605-00013	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	25.000	0.000	0.000	300.00	7500.00	{"sourceType":"GOODS_RECEIPT","sourceId":"805be505-2858-4642-abf1-8d09549077d6","sourceLineId":"43166535-c7da-43b6-9402-42d8131c5183"}	gr:805be505-2858-4642-abf1-8d09549077d6:43166535-c7da-43b6-9402-42d8131c5183	2026-05-26 16:01:55.62+00	2026-05-26 16:01:55.62+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
f9a722c3-9fbd-402d-97b9-c3c197ed97e4	GOODS_ISSUE	GI-HQ001-202605-00002	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	0.000	1.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"19ef01b3-9b42-4d70-89af-7e0bd8cad27d","sourceLineId":"6cb6191b-6db8-47c8-9334-e91eb5ac7b1d"}	gi:19ef01b3-9b42-4d70-89af-7e0bd8cad27d:6cb6191b-6db8-47c8-9334-e91eb5ac7b1d	2026-05-26 16:11:35.847+00	2026-05-26 16:11:35.847+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
d22230da-02d5-4ff0-b2de-c2bb992aa96c	OPENING	BULK-IMPORT-PRO01-0f2ae8d3	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	50.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-PRO01-0f2ae8d3","sourceLineId":null}	\N	2026-05-26 16:17:09.284+00	2026-05-26 16:17:09.284+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
202d925b-1763-47d5-a489-952909c0a293	OPENING	BULK-IMPORT-PRO02-0f2ae8d3	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	1a84efe0-44bc-4661-ba46-ac6b5a2bcd0f	50.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-PRO02-0f2ae8d3","sourceLineId":null}	\N	2026-05-26 16:17:09.295+00	2026-05-26 16:17:09.295+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bfd6accf-ec6b-445b-ba51-80acb9d562f4	GOODS_ISSUE	SO-HQ001-202605-00005	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	0.000	11.000	0.000	80.00	880.00	Sales order fulfillment | {"sourceType":"SALES_ORDER","sourceId":"e740e26e-9481-4282-b21e-e899dc6e7771","sourceLineId":"ed9805c9-6f20-4ec3-bda6-1c55e7e7d9d1"}	so-fulfill:e740e26e-9481-4282-b21e-e899dc6e7771:ed9805c9-6f20-4ec3-bda6-1c55e7e7d9d1:0	2026-05-26 16:27:22.597+00	2026-05-26 16:27:22.597+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
637b2343-c360-4bc8-a508-6d5392eaf531	GOODS_ISSUE	GI-HQ001-202605-00003	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57fce59e-4ee2-4bff-8b07-b6cb5a8ebed1	0.000	11.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"b3e554ba-0efa-49cd-9e9b-ef1558d44982","sourceLineId":"3deecc26-d7b3-4342-ad14-f14029fa3fbc"}	gi:b3e554ba-0efa-49cd-9e9b-ef1558d44982:3deecc26-d7b3-4342-ad14-f14029fa3fbc	2026-05-26 16:28:52.412+00	2026-05-26 16:28:52.412+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
9e347ef3-fef9-4443-9f8a-458429007300	GOODS_RECEIPT	GR-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	3.000	0.000	0.000	50000.00	150000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"bd3940c3-fefd-4511-bd92-552eeff4740f","sourceLineId":"9ac72c0b-2a94-4197-9b6f-38465812db97"}	gr:bd3940c3-fefd-4511-bd92-552eeff4740f:9ac72c0b-2a94-4197-9b6f-38465812db97	2026-05-30 04:26:39.968+00	2026-05-30 04:26:39.968+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
edb282bc-ed54-4eef-8bf2-867d4debd704	GOODS_RECEIPT	GR-00002	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	1.000	0.000	0.000	450.00	450.00	{"sourceType":"GOODS_RECEIPT","sourceId":"345870ff-1253-4b69-9a2a-9a9648742362","sourceLineId":"83cfd615-46ce-484b-bcb9-bfa211994a21"}	gr:345870ff-1253-4b69-9a2a-9a9648742362:83cfd615-46ce-484b-bcb9-bfa211994a21	2026-05-30 05:30:08.365+00	2026-05-30 05:30:08.365+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6f73196a-a7cc-4a17-8452-16070e17f0a7	OPENING	BULK-SYNC-ELE001-0f2ae8d3-1780122374858	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	57812718-33b2-4585-ba16-e4a95bec7405	44.000	0.000	0.000	\N	\N	Bulk import stock sync | {"sourceType":"OPENING","sourceId":"BULK-SYNC-ELE001-0f2ae8d3-1780122374858","sourceLineId":null}	\N	2026-05-30 06:26:14.859+00	2026-05-30 06:26:14.859+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
aeb661c8-8054-4b32-ace9-8c213a6b4769	OPENING	BULK-SYNC-ELE002-0f2ae8d3-1780122374863	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	53457790-5c18-4f3a-a2d6-709ded27ed4a	29.000	0.000	0.000	\N	\N	Bulk import stock sync | {"sourceType":"OPENING","sourceId":"BULK-SYNC-ELE002-0f2ae8d3-1780122374863","sourceLineId":null}	\N	2026-05-30 06:26:14.864+00	2026-05-30 06:26:14.864+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
a0f0922e-3f40-46bc-a946-41f2ccd6c80b	OPENING	BULK-IMPORT-ELE003-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	b4c7a727-2f6f-4d16-8427-36216992f608	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE003-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:14.873+00	2026-05-30 06:26:14.873+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6cf0b776-c7d8-4a6c-9e55-04ceba0c8566	OPENING	BULK-IMPORT-ELE004-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e7e3101d-ad0a-457b-8dff-47ff94eb2115	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE004-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:14.879+00	2026-05-30 06:26:14.879+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
909e5f61-5ada-45c6-a7c4-fcb813f0c6b2	OPENING	BULK-IMPORT-ELE005-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	a451dcc4-9d0a-4c0c-a847-3e5a39e85339	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE005-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:14.964+00	2026-05-30 06:26:14.964+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
081cf89f-aae7-4e44-bbc5-b27a5fa00bc5	OPENING	BULK-IMPORT-ELE006-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	60642c3d-ad8a-426a-89c0-ad59ef88f62e	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE006-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:14.971+00	2026-05-30 06:26:14.971+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
26a15478-049c-4c63-bc67-b56dd6609f5f	OPENING	BULK-IMPORT-ELE007-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	add88489-a8a6-4bc6-abc5-0d91fecf1b7b	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE007-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.058+00	2026-05-30 06:26:15.058+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
f07c7905-5c55-4d3e-b129-c891ec779664	OPENING	BULK-IMPORT-ELE008-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	92e4a71c-947a-495f-94d2-3c33c51e5ca4	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE008-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.074+00	2026-05-30 06:26:15.074+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
01804c22-a4e7-41e8-99f4-4d355e66f57a	OPENING	BULK-IMPORT-ELE009-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	fe4dbc08-ff7b-4128-a74a-cb6122bc8c45	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE009-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.166+00	2026-05-30 06:26:15.166+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bc68f647-5c95-4044-bd95-55b787109ffd	OPENING	BULK-IMPORT-ELE010-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	5bb37879-54d6-414a-9351-7bb0a00af64d	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE010-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.357+00	2026-05-30 06:26:15.357+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
2b2837ef-2c24-4969-8354-8ab08d24269b	OPENING	BULK-IMPORT-ELE011-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	56067187-64bf-4352-bac8-60bdd362289c	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE011-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.368+00	2026-05-30 06:26:15.368+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
cb618465-b6d1-415c-85d6-9c3bc200afec	OPENING	BULK-IMPORT-ELE012-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c42488c4-d527-4ece-93a4-4d649a6c9129	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE012-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.374+00	2026-05-30 06:26:15.374+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
9fe4865e-c314-40c3-b69e-77b43e0341b0	OPENING	BULK-IMPORT-ELE013-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ced5f709-365e-4039-965b-583e052cab41	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE013-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.462+00	2026-05-30 06:26:15.462+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
68aad89a-d15b-4393-9210-d8f8a042551b	OPENING	BULK-IMPORT-ELE014-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	947950bc-0c56-426e-b8cc-a5c61d413b8f	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE014-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.469+00	2026-05-30 06:26:15.469+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
55674570-888c-4ed9-8561-161635698693	OPENING	BULK-IMPORT-ELE015-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7dd6f5ce-d7cb-4383-9fd1-10a8fdb6a5ee	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE015-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.476+00	2026-05-30 06:26:15.476+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ee48b55e-79f1-436e-9085-a07fe0ccfcc4	OPENING	BULK-IMPORT-ELE016-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	709c8e28-4744-41bf-9aba-4e5f53b1432d	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE016-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.56+00	2026-05-30 06:26:15.56+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3cae5985-087b-40b8-9f15-a2aa1dfc1b0b	OPENING	BULK-IMPORT-ELE017-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	ddecac3f-b99f-4028-95d4-48e0268f2153	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE017-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.568+00	2026-05-30 06:26:15.568+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
9c48b4c4-5f4d-4d0e-b9e1-798c209c635d	OPENING	BULK-IMPORT-ELE018-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	89392013-2725-458b-b6ce-5027500fbe8a	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE018-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.575+00	2026-05-30 06:26:15.575+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
244dd74e-48ce-4dba-8762-8d62b3d04345	OPENING	BULK-IMPORT-ELE019-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	70d1e807-0a90-4643-be02-018fbfdb745d	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE019-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.658+00	2026-05-30 06:26:15.658+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ef60a916-c86b-4e42-a767-6d27f2186268	OPENING	BULK-IMPORT-ELE020-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	137584c8-4e2e-4728-ab54-c4ce6c3121c5	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE020-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.668+00	2026-05-30 06:26:15.668+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
2fe70959-a072-4252-99c0-546d4259b0c8	OPENING	BULK-IMPORT-ELE021-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	2a41e7a6-7006-4223-b53d-1a1ce1a74338	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE021-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.677+00	2026-05-30 06:26:15.677+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bcf5da3c-bba5-4c19-9777-a95b70fb8258	OPENING	BULK-IMPORT-ELE022-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	26c9b0d4-e1ab-499a-9bcd-1203fe468e74	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE022-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.763+00	2026-05-30 06:26:15.763+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
5fa0e8db-1f08-414c-aa25-3bf544814a79	OPENING	BULK-IMPORT-ELE023-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	2865b727-52a0-4e2c-8219-bbf506e719a3	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE023-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.776+00	2026-05-30 06:26:15.776+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
94937db0-b7e4-43e2-912f-a7b095eabf78	OPENING	BULK-IMPORT-ELE024-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	83147109-d755-4af1-b561-b80e1c2ab864	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE024-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.861+00	2026-05-30 06:26:15.861+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
c98ecaea-8270-4b4a-8814-4530f2ce995a	OPENING	BULK-IMPORT-ELE025-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	0775b9c4-857f-42a9-ba9f-60277c6772ba	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE025-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.868+00	2026-05-30 06:26:15.868+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7ed05f8f-58d5-48fe-a714-a80685057ff6	OPENING	BULK-IMPORT-ELE026-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	1332d491-a6ff-4737-b43b-4432cbb7b7ea	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE026-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.876+00	2026-05-30 06:26:15.876+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
2ce17113-7e41-4575-9aab-458fd0b8b3c5	OPENING	BULK-IMPORT-ELE027-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	f579b9a5-f77f-4214-afc4-105a10e27b44	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE027-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.96+00	2026-05-30 06:26:15.96+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
e9db2b0f-b30f-4728-b178-807411c4ecc0	OPENING	BULK-IMPORT-ELE028-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	3055eb4d-75db-480d-b6dc-b20d25e3576d	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE028-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.966+00	2026-05-30 06:26:15.966+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
8327f737-794a-4b06-b7ae-a214a9e98459	OPENING	BULK-IMPORT-ELE029-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	c5870b7b-8319-431c-81ba-3407e4397ecf	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE029-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:15.973+00	2026-05-30 06:26:15.973+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
b01b6981-6a8d-4651-8155-da5d315bcb24	OPENING	BULK-IMPORT-ELE030-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	eefc1e76-84a1-4c6d-b11b-86223914651b	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE030-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.055+00	2026-05-30 06:26:16.055+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4c4acc98-8e4d-4f4a-833d-c37ed67a9530	OPENING	BULK-IMPORT-ELE031-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	929b6999-db64-4f30-b76e-b5ad0ab5677a	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE031-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.064+00	2026-05-30 06:26:16.064+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3d3eddec-3f81-4e98-9632-e2f39b755268	OPENING	BULK-IMPORT-ELE032-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	94864a35-c94d-42d4-82e0-a6169bcbb6d5	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE032-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.071+00	2026-05-30 06:26:16.071+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
9d9d080a-ea41-4cc0-b849-103729964054	OPENING	BULK-IMPORT-ELE033-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	21da1aac-b7e6-4fbe-8416-0c389669f282	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE033-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.077+00	2026-05-30 06:26:16.077+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
64d91c54-d5a2-4aa6-90b4-8ec2266302d7	OPENING	BULK-IMPORT-ELE034-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6e99de95-02c3-4892-a626-8c76970410c2	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE034-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.164+00	2026-05-30 06:26:16.164+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
c7bbb3f5-f444-4509-9cb9-8d8bfb216098	OPENING	BULK-IMPORT-ELE035-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	fbe146a7-6f73-4f67-b6ca-866a381ea033	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE035-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.17+00	2026-05-30 06:26:16.17+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
be4c0817-fe40-4365-858b-57763ec26755	OPENING	BULK-IMPORT-ELE036-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	f9011ebd-1097-45f8-80bf-12ef2746c1a0	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE036-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.176+00	2026-05-30 06:26:16.176+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
b62f5412-691d-4977-8c77-f9e53599b803	OPENING	BULK-IMPORT-ELE037-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6fc077a8-77b6-4906-a2bf-b794fa9fec9f	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE037-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.259+00	2026-05-30 06:26:16.259+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
36f7ed71-ae1f-4d39-8173-ec7f543ee4b8	OPENING	BULK-IMPORT-ELE038-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	0b6246e9-57cf-42fb-a2ba-ac4d1c05c6e1	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE038-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.266+00	2026-05-30 06:26:16.266+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
0d2671e4-31e2-4f2f-86e7-57c758e9b7f8	OPENING	BULK-IMPORT-ELE039-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e97a9191-4f78-41fe-a426-96d26c1518b9	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE039-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.273+00	2026-05-30 06:26:16.273+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
3c848bf8-fb44-44be-9776-99824e9a8fa7	OPENING	BULK-IMPORT-ELE040-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	fb0fe073-f3f9-490b-88ad-a6df8e78a816	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE040-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.362+00	2026-05-30 06:26:16.362+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7bf16a36-8239-4ac3-9fe7-48c672ed78e2	OPENING	BULK-IMPORT-ELE041-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	5c091a8e-b426-4419-b6b4-220a3f5a8b12	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE041-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.368+00	2026-05-30 06:26:16.368+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7cb5c703-d7c7-4744-883e-24ed7faaa85c	OPENING	BULK-IMPORT-ELE042-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	0459f473-75f9-463a-8237-9ca65fee69f8	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE042-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.375+00	2026-05-30 06:26:16.375+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
a9f2e13e-c7fa-49d7-a522-873eb4b062c7	OPENING	BULK-IMPORT-ELE043-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6344a746-687f-48d0-af2e-329cc0932fc7	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE043-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.461+00	2026-05-30 06:26:16.461+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
d3d13ba6-367f-4c67-97e0-30969065fc0d	OPENING	BULK-IMPORT-ELE044-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	166c4ba0-232b-484f-ad54-fab5379410fa	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE044-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.469+00	2026-05-30 06:26:16.469+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7a3b8f17-e757-4bc3-9dff-d343f86b029d	OPENING	BULK-IMPORT-ELE045-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	2d8107ad-f2ff-4862-b269-9b274a65b530	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE045-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.477+00	2026-05-30 06:26:16.477+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
0c5a39d9-0c25-4078-8197-ed0ed21261d2	OPENING	BULK-IMPORT-ELE046-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6cf057a6-6a6e-46ac-be49-a0417acd71c3	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE046-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.56+00	2026-05-30 06:26:16.56+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
d171a7a6-7a86-42c9-9a7e-da6e78250097	OPENING	BULK-IMPORT-ELE047-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	b196efdd-24e4-4435-a798-aab2e1ec69a0	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE047-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.568+00	2026-05-30 06:26:16.568+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
5cf212fe-c0ed-4109-97ba-cf6897939954	OPENING	BULK-IMPORT-ELE048-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	8c42805b-90f8-4c3d-9784-b6821ad9272a	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE048-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.575+00	2026-05-30 06:26:16.575+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6493f320-e3fd-42ad-9190-778c8ba24a8f	OPENING	BULK-IMPORT-ELE049-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7a494ea2-2cf1-419c-ba0a-37da9f178b41	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE049-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.659+00	2026-05-30 06:26:16.659+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
74ff8f4d-175a-4f60-a363-9e0afbf68e54	OPENING	BULK-IMPORT-ELE050-0f2ae8d3	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	f9865733-a9f7-44f6-a031-9c3925042cea	100.000	0.000	0.000	\N	\N	Bulk import opening stock | {"sourceType":"OPENING","sourceId":"BULK-IMPORT-ELE050-0f2ae8d3","sourceLineId":null}	\N	2026-05-30 06:26:16.671+00	2026-05-30 06:26:16.671+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
1c268cef-7902-4e81-bb6e-45d436fd874e	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	f9865733-a9f7-44f6-a031-9c3925042cea	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"4235b367-11c0-4e43-873e-344f0ab272b6"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:4235b367-11c0-4e43-873e-344f0ab272b6	2026-05-30 07:55:42.356+00	2026-05-30 07:55:42.356+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
4cb501d1-0eba-448b-9944-e256fc8bab4f	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7a494ea2-2cf1-419c-ba0a-37da9f178b41	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"8019a04c-f38c-4c64-a921-4787e5661d7c"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:8019a04c-f38c-4c64-a921-4787e5661d7c	2026-05-30 07:55:42.36+00	2026-05-30 07:55:42.36+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
039538e8-fa0f-436a-969c-8ded1cde6268	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	8c42805b-90f8-4c3d-9784-b6821ad9272a	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"e813a95f-0858-440d-9b7f-790200ba41c8"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:e813a95f-0858-440d-9b7f-790200ba41c8	2026-05-30 07:55:42.362+00	2026-05-30 07:55:42.362+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
539b4533-3edf-4663-9de3-3c80c02f5f04	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	b196efdd-24e4-4435-a798-aab2e1ec69a0	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"676f070b-ec2f-430e-95f2-d06729d2312a"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:676f070b-ec2f-430e-95f2-d06729d2312a	2026-05-30 07:55:42.363+00	2026-05-30 07:55:42.363+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
8b4c344f-f5a9-457d-87d0-7e330bc75068	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6cf057a6-6a6e-46ac-be49-a0417acd71c3	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"f7bfa51a-73eb-4a68-bccf-e6722a3007bd"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:f7bfa51a-73eb-4a68-bccf-e6722a3007bd	2026-05-30 07:55:42.364+00	2026-05-30 07:55:42.364+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bd5a5498-c4bc-4fa0-a48f-f5822926f16a	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	2d8107ad-f2ff-4862-b269-9b274a65b530	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"046ae86d-baf2-4945-b9c7-bf8b4c2c1eb0"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:046ae86d-baf2-4945-b9c7-bf8b4c2c1eb0	2026-05-30 07:55:42.365+00	2026-05-30 07:55:42.365+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
32bec168-2554-494a-85a4-85aea8aa0080	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	2d8107ad-f2ff-4862-b269-9b274a65b530	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"c6c7f113-aeff-44fc-adcb-27ab9a12e035"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:c6c7f113-aeff-44fc-adcb-27ab9a12e035	2026-05-30 07:55:42.366+00	2026-05-30 07:55:42.366+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
e0899152-16e2-43c5-bff9-251e651333b1	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	166c4ba0-232b-484f-ad54-fab5379410fa	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"657064aa-34a9-4b53-9158-2cd9371e3aa9"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:657064aa-34a9-4b53-9158-2cd9371e3aa9	2026-05-30 07:55:42.367+00	2026-05-30 07:55:42.367+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
2ac7c520-91af-4cb8-9765-6f716bf9615b	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6344a746-687f-48d0-af2e-329cc0932fc7	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"355e9419-8b3b-43f4-9d3e-bd5e3441f78b"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:355e9419-8b3b-43f4-9d3e-bd5e3441f78b	2026-05-30 07:55:42.368+00	2026-05-30 07:55:42.368+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
8ab1836d-27e5-4ac7-850e-5bbd02a12caf	GOODS_ISSUE	GI-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	0459f473-75f9-463a-8237-9ca65fee69f8	0.000	10.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"11970999-986b-42db-bf4b-90d0d04642a6","sourceLineId":"55a4357f-e113-4f65-af34-cd5dcd755385"}	gi:11970999-986b-42db-bf4b-90d0d04642a6:55a4357f-e113-4f65-af34-cd5dcd755385	2026-05-30 07:55:42.369+00	2026-05-30 07:55:42.369+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ffc53a1c-1626-46ba-8cf2-3bed5c1fec72	GOODS_RECEIPT	GR-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	f9865733-a9f7-44f6-a031-9c3925042cea	5.000	0.000	0.000	1450.00	7250.00	{"sourceType":"GOODS_RECEIPT","sourceId":"9dbceae8-fc02-403b-8b8c-3cd7c6513498","sourceLineId":"9cbfffc8-53a0-4190-88de-e945eb0262ba"}	gr:9dbceae8-fc02-403b-8b8c-3cd7c6513498:9cbfffc8-53a0-4190-88de-e945eb0262ba	2026-05-30 10:05:40.861+00	2026-05-30 10:05:40.861+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
478ffb5c-d9bc-457f-8a1f-452838638881	GOODS_RECEIPT	GR-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7a494ea2-2cf1-419c-ba0a-37da9f178b41	5.000	0.000	0.000	1800.00	9000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"9dbceae8-fc02-403b-8b8c-3cd7c6513498","sourceLineId":"4b2d6a69-af52-455f-8c53-0324679a4075"}	gr:9dbceae8-fc02-403b-8b8c-3cd7c6513498:4b2d6a69-af52-455f-8c53-0324679a4075	2026-05-30 10:05:40.869+00	2026-05-30 10:05:40.869+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
cb0c0717-4363-4cfc-9f5c-52ae203f7757	GOODS_RECEIPT	GR-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	8c42805b-90f8-4c3d-9784-b6821ad9272a	5.000	0.000	0.000	3200.00	16000.00	{"sourceType":"GOODS_RECEIPT","sourceId":"9dbceae8-fc02-403b-8b8c-3cd7c6513498","sourceLineId":"860d8347-96fd-48c0-8af0-069eb327d680"}	gr:9dbceae8-fc02-403b-8b8c-3cd7c6513498:860d8347-96fd-48c0-8af0-069eb327d680	2026-05-30 10:05:40.873+00	2026-05-30 10:05:40.873+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ad37f966-4454-4fdf-848c-ce75064ea427	GOODS_RECEIPT	GR-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	b196efdd-24e4-4435-a798-aab2e1ec69a0	5.000	0.000	0.000	420.00	2100.00	{"sourceType":"GOODS_RECEIPT","sourceId":"9dbceae8-fc02-403b-8b8c-3cd7c6513498","sourceLineId":"ff36bfe7-753b-45cb-a338-c4ab749ce514"}	gr:9dbceae8-fc02-403b-8b8c-3cd7c6513498:ff36bfe7-753b-45cb-a338-c4ab749ce514	2026-05-30 10:05:40.877+00	2026-05-30 10:05:40.877+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7af0765f-c185-4ed5-beb5-f42dea10382a	GOODS_RECEIPT	GR-00003	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	6cf057a6-6a6e-46ac-be49-a0417acd71c3	5.000	0.000	0.000	650.00	3250.00	{"sourceType":"GOODS_RECEIPT","sourceId":"9dbceae8-fc02-403b-8b8c-3cd7c6513498","sourceLineId":"e7939424-5c56-4104-b28b-6613f0bc54e4"}	gr:9dbceae8-fc02-403b-8b8c-3cd7c6513498:e7939424-5c56-4104-b28b-6613f0bc54e4	2026-05-30 10:05:40.88+00	2026-05-30 10:05:40.88+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
364ce1bc-1683-4753-a90e-5abbd273397c	GOODS_RECEIPT	GR-00004	2026-06-09	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	166c4ba0-232b-484f-ad54-fab5379410fa	18.000	0.000	0.000	950.00	17100.00	batch:B290 serial:S.NO 9022 | {"sourceType":"GOODS_RECEIPT","sourceId":"265ba202-982a-4bfa-bbd6-51ea0bff27e8","sourceLineId":"7a5e0905-f8a9-46fa-8bd4-f9d0ffde4452"}	gr:265ba202-982a-4bfa-bbd6-51ea0bff27e8:7a5e0905-f8a9-46fa-8bd4-f9d0ffde4452	2026-06-09 05:19:50.649+00	2026-06-09 05:19:50.649+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
bb571f57-8c69-45f3-9aea-90326674a9f0	GOODS_RECEIPT	GR-00005	2026-06-09	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	166c4ba0-232b-484f-ad54-fab5379410fa	10.000	0.000	0.000	950.00	9500.00	batch:B290 | {"sourceType":"GOODS_RECEIPT","sourceId":"408aea7a-6b67-4fab-af46-3321ed698642","sourceLineId":"ca23639e-85aa-406f-b802-5387df7ebe1d"}	gr:408aea7a-6b67-4fab-af46-3321ed698642:ca23639e-85aa-406f-b802-5387df7ebe1d	2026-06-09 05:23:01.756+00	2026-06-09 05:23:01.756+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
cef53de2-8ef2-4f8e-85a8-90ef47638352	GOODS_ISSUE	GI-00002	2026-06-11	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	0.000	1.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"508241a7-af1a-4fca-8454-20511c911948","sourceLineId":"a2c8ea4a-22e7-4473-af2c-462fc32d862f"}	gi:508241a7-af1a-4fca-8454-20511c911948:a2c8ea4a-22e7-4473-af2c-462fc32d862f	2026-06-11 07:05:10.212+00	2026-06-11 07:05:10.212+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
962609e5-aa8b-483e-a885-b0734f7d8c1b	GOODS_ISSUE	GI-00002	2026-06-11	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	b196efdd-24e4-4435-a798-aab2e1ec69a0	0.000	1.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"508241a7-af1a-4fca-8454-20511c911948","sourceLineId":"34af0e21-a2bb-4c00-adbd-dea07894bcf5"}	gi:508241a7-af1a-4fca-8454-20511c911948:34af0e21-a2bb-4c00-adbd-dea07894bcf5	2026-06-11 07:05:10.214+00	2026-06-11 07:05:10.214+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
7c6440df-0112-4610-a784-8847619c476f	GOODS_ISSUE	GI-00002	2026-06-11	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7a494ea2-2cf1-419c-ba0a-37da9f178b41	0.000	1.000	0.000	\N	\N	{"sourceType":"GOODS_ISSUE","sourceId":"508241a7-af1a-4fca-8454-20511c911948","sourceLineId":"38956dd1-500d-4ea1-b0a2-953c98ff9be9"}	gi:508241a7-af1a-4fca-8454-20511c911948:38956dd1-500d-4ea1-b0a2-953c98ff9be9	2026-06-11 07:05:10.215+00	2026-06-11 07:05:10.215+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: stock_summary; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_summary (id, shop_id, product_id, current_stock, avg_cost, last_movement_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: stock_transfer_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_transfer_header (id, transfer_number, transfer_date, from_shop_id, to_shop_id, from_storage_location_id, to_storage_location_id, status, notes, posted_at, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.stock_transfer_items (id, transfer_id, product_id, quantity, uom) FROM stdin;
\.


--
-- Data for Name: storage_locations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.storage_locations (id, shop_id, code, name, description, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
69dcad3c-97ea-435f-a7b7-a1b59e7ed543	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	SL-01	Raw material store	Raw material store	t	2026-05-25 05:07:41.07+00	2026-05-25 05:07:41.07+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ba130361-208a-420e-a1a8-0d04b8028734	d53ce4ee-7da6-4709-b944-348687fb0843	Sloc-01	Storage 01	Rack 01 - inside the Room.	t	2026-05-25 12:18:17.249+00	2026-05-25 12:18:17.249+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
6fc11bf0-7d35-445e-8077-0725a0285028	d53ce4ee-7da6-4709-b944-348687fb0843	SLOC-02	Rack-2 Storage location 02	Right side rack inside the room	t	2026-05-25 12:18:55.918+00	2026-05-25 12:18:55.918+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
8df413cb-56c5-44e8-9377-7925430aecaa	d53ce4ee-7da6-4709-b944-348687fb0843	SLoc-03	Outside room	Outside room - work location	t	2026-05-25 12:19:42.684+00	2026-05-25 12:19:42.684+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N
ab3136e9-4be0-4ab4-bc36-0674a01fe524	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	SL-02	semi-finished product	Electrical items	t	2026-05-30 06:25:04.156+00	2026-05-30 06:25:04.156+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
c2623d01-fb3d-4e14-9c8b-1a5a14d8f093	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	SL-03	Finished product	Electrical Finished prduct	t	2026-05-30 06:25:45.758+00	2026-05-30 06:25:45.758+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
f3bd7054-d585-468c-9c6f-6bb5e42b6a51	5c1f22f6-978a-43fe-ad41-28359edf08d4	SL-01	Raw material	Raw material storage	t	2026-05-29 13:52:50.463+00	2026-05-30 12:10:23.424+00	6fd97d36-05d1-4617-8c81-0d54da73ace8	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
\.


--
-- Data for Name: subscription_invoices; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.subscription_invoices (id, invoice_number, company_id, plan, billing_cycle, amount_paise, tax_paise, total_paise, currency, gst_number, billing_address_snapshot, issued_at, pdf_storage_key, created_at) FROM stdin;
22077146-462e-4577-bdb0-caadec31b66c	SINV-202605-00001	582b08bd-2a7a-475b-84c2-e4ef8f834a83	PLUS	MONTHLY	500	0	500	INR	29XXXXX0000X1Z5	{"address": "1 Main Street", "companyName": "Softdigit Consulting"}	2026-05-25 04:42:43.787+00	\N	2026-05-29 11:09:37.518+00
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.subscription_payments (id, company_id, plan, billing_cycle, amount_paise, currency, razorpay_order_id, razorpay_payment_id, status, verified_at, consumed_at, created_at, invoice_id, failure_reason, renewal_attempt) FROM stdin;
11752c3f-bcd5-4ae7-8623-d2a1b7b49c2a	\N	PRO	MONTHLY	39900	INR	order_StSJUkaoWboU14	\N	created	\N	\N	2026-05-25 03:54:01.702+00	\N	\N	0
5772d8dc-7086-4088-95b4-adc487afa31b	41168db8-acc2-46f2-87e0-d07b6b813bc8	PLUS	MONTHLY	500	INR	order_StYWtT3tQfALZ5	pay_StYXSIlaWdyyEF	paid	2026-05-25 09:59:41.793+00	2026-05-25 09:59:42.503+00	2026-05-25 09:58:52.441+00	\N	\N	0
6dd5f20a-11a3-480a-8254-c2c2fb6508ae	c910bf96-4c0e-4b5c-bc76-e2134cce1d4d	PLUS	MONTHLY	500	INR	order_StYft7698mmxvc	pay_StYgMi9lpquCCA	paid	2026-05-25 10:08:06.16+00	2026-05-25 10:08:06.423+00	2026-05-25 10:07:23.314+00	\N	\N	0
ddac2429-79af-432d-8d18-e2973393d122	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	PLUS	MONTHLY	500	INR	order_StajBMdghC68mg	pay_StajcUG2XnRQDb	paid	2026-05-25 12:08:36.171+00	2026-05-25 12:10:30.176+00	2026-05-25 12:07:53.666+00	\N	\N	0
c07a378d-fadc-4356-a150-0508ed053b05	ff82dfb2-daf8-4f8f-a813-19033c69ea47	PLUS	MONTHLY	500	INR	order_StyCWsqAbt0s2R	pay_StyDFqqipig91k	paid	2026-05-26 11:06:36.382+00	2026-05-26 11:06:36.382+00	2026-05-26 11:05:37.722+00	\N	\N	0
8983998c-2cf5-42ab-a22b-30602de6b20f	582b08bd-2a7a-475b-84c2-e4ef8f834a83	PLUS	MONTHLY	500	INR	order_StT7F8Xh739Wo9	pay_StT8eKez4UMlWn	paid	2026-05-25 04:42:43.787+00	2026-05-25 04:42:43.787+00	2026-05-25 04:41:07.407+00	22077146-462e-4577-bdb0-caadec31b66c	\N	0
928a722e-ccb8-44a9-844a-ea629fc24fc0	\N	PLUS	MONTHLY	59900	INR	order_SvovMjcxORnYOK	\N	created	\N	\N	2026-05-31 03:19:08.503+00	\N	\N	0
\.


--
-- Data for Name: supplier_bill_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_bill_header (id, bill_number, bill_date, due_date, shop_id, supplier_id, purchase_order_id, goods_receipt_id, status, total_value, paid_value, remarks, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
\.


--
-- Data for Name: supplier_bill_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_bill_items (id, bill_header_id, product_id, quantity, uom, unit_cost, line_value) FROM stdin;
\.


--
-- Data for Name: supplier_payments; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_payments (id, payment_number, payment_date, supplier_bill_id, shop_id, amount, method, reference, remarks, created_at, updated_at, created_by, updated_by, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
\.


--
-- Data for Name: supplier_quote_header; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_quote_header (id, quote_number, quote_date, shop_id, rfq_id, supplier_id, notes, status, posted_at, total_value, created_at, updated_at, created_by, updated_by) FROM stdin;
3169c1cc-0e34-4f9a-a766-6d7e1f1c18e5	QUO-HQ001-202605-00001	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e3ba67e8-f91b-4d30-90d8-1c0b3a338774	7c961808-5a79-4c95-8c40-a36f4839609c	Submitted via supplier portal	POSTED	2026-05-25 05:28:26.493+00	\N	2026-05-25 05:28:12.384+00	2026-05-25 05:28:26.494+00	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
0410cc07-87eb-41fc-8813-a297207a902e	QUO-HQ001-202605-00002	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	cbba0db5-cda0-4cfc-97df-26985042ff4d	7c961808-5a79-4c95-8c40-a36f4839609c	Lead time: 12 days\nSubmitted via supplier portal	POSTED	2026-05-25 06:01:34.417+00	\N	2026-05-25 05:30:49.959+00	2026-05-25 06:01:34.418+00	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
d4165258-cb44-41c0-b7ef-72a5019aa73c	QUO-HQ001-202605-00003	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	5daf69be-ed64-4841-931e-0de22ee61183	7c961808-5a79-4c95-8c40-a36f4839609c	Lead time: 3 days\nSubmitted via supplier portal	POSTED	2026-05-25 06:10:15.648+00	\N	2026-05-25 06:03:51.051+00	2026-05-25 06:10:15.648+00	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
41095b55-bef2-44b9-bccd-d0adcdff720e	QUO-HQ001-202605-00005	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	8e4dcbdf-a386-42b6-916c-ff4d83490d15	7c961808-5a79-4c95-8c40-a36f4839609c	Lead time: 30 days\nSubmitted via supplier portal	POSTED	2026-05-25 14:31:57.804+00	\N	2026-05-25 14:31:57.805+00	2026-05-25 14:31:57.805+00	\N	\N
0839653d-55ac-4e4a-b4c5-03dd3166edcd	QUO-HQ001-202605-00004	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	8e4dcbdf-a386-42b6-916c-ff4d83490d15	a94916e2-72a6-4b9c-985d-01de9bc20a2a	LED\nLead time: 1 days\nSubmitted via supplier portal	POSTED	2026-05-25 15:48:10.521+00	\N	2026-05-25 14:14:25.287+00	2026-05-25 15:48:10.522+00	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
b4d5b54d-e4a2-46d8-aba3-283dca75f3d6	QUO-HQ001-202605-00006	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e890e821-c818-46b4-9e4b-bda34532983d	a94916e2-72a6-4b9c-985d-01de9bc20a2a	Lead time: 10 days\nSubmitted via supplier portal	POSTED	2026-05-25 16:16:13.422+00	\N	2026-05-25 16:11:13.676+00	2026-05-25 16:16:13.423+00	\N	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
48be167e-71e0-4ee7-ab9d-8f39668ad5bf	QUO-HQ001-202605-00007	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	e890e821-c818-46b4-9e4b-bda34532983d	7c961808-5a79-4c95-8c40-a36f4839609c	Lead time: 12 days\nSubmitted via supplier portal	POSTED	2026-05-25 16:16:16.822+00	\N	2026-05-25 16:16:16.823+00	2026-05-25 16:16:16.823+00	\N	\N
997ff610-0247-4e1c-937f-718f2bfb7a8a	QUO-HQ001-202605-00008	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	10328047-043e-4df1-8fee-a011284c0bed	a94916e2-72a6-4b9c-985d-01de9bc20a2a	Lead time: 10 days\nSubmitted via supplier portal	POSTED	2026-05-26 07:43:16.737+00	\N	2026-05-26 07:43:16.738+00	2026-05-26 07:43:16.738+00	\N	\N
868824d2-aa4d-4e7f-ba41-7b290af66120	QUO-HQ001-202605-00009	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	10328047-043e-4df1-8fee-a011284c0bed	7c961808-5a79-4c95-8c40-a36f4839609c	Lead time: 30 days\nSubmitted via supplier portal	POSTED	2026-05-26 07:45:07.339+00	\N	2026-05-26 07:45:07.339+00	2026-05-26 07:45:07.339+00	\N	\N
1602ff84-1d70-4243-9e73-9a86c7036ef2	QUO-00001	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	0812e848-3efa-4339-858a-917e342f1d9d	6a9b09b4-5182-49c2-92f4-02870dfac0e5	Lead time: 13 days	POSTED	2026-05-30 04:04:22.62+00	\N	2026-05-30 04:04:22.26+00	2026-05-30 04:04:22.621+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
918f85ed-06e2-413f-9c17-7b8c9dce44d0	QUO-00002	2026-05-30	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	9da63c07-1b8b-4ae6-a239-024fe9cf23c1	79be7f13-60fd-4d65-a0df-b87335b8c75e	Lead time: 3 days	POSTED	2026-05-30 08:25:14.945+00	\N	2026-05-30 08:24:50.464+00	2026-05-30 08:25:14.947+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
\.


--
-- Data for Name: supplier_quote_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_quote_items (id, quote_header_id, rfq_item_id, product_id, description, quantity, uom, specifications, unit_price, line_value, created_at, updated_at, created_by, updated_by) FROM stdin;
31d5f9d1-7168-496b-959c-aba5a5e6af26	3169c1cc-0e34-4f9a-a766-6d7e1f1c18e5	b393d774-388b-423f-a107-47a08085e0ea	57812718-33b2-4585-ba16-e4a95bec7405	LED	1.000	pcs	\N	99.00	99.00	2026-05-25 05:28:12.384+00	2026-05-25 05:28:12.384+00	\N	\N
bc1b0d04-3d89-4c72-95cf-310658004e2f	0410cc07-87eb-41fc-8813-a297207a902e	f0795bf2-6699-48b5-9b7f-eff19fa5f1d5	57812718-33b2-4585-ba16-e4a95bec7405	LED	20.000	pcs	\N	130.00	2600.00	2026-05-25 05:30:49.959+00	2026-05-25 05:30:49.959+00	\N	\N
a092d96e-8d28-4a91-8ee1-c84811f2035d	d4165258-cb44-41c0-b7ef-72a5019aa73c	dfcac917-a831-4881-b82f-3ffbfef9e052	57812718-33b2-4585-ba16-e4a95bec7405	LED	1.000	pcs	\N	500.00	500.00	2026-05-25 06:03:51.051+00	2026-05-25 06:03:51.051+00	\N	\N
3a6bd740-cc90-40e6-a42c-8838fa7280cb	0839653d-55ac-4e4a-b4c5-03dd3166edcd	4b34d676-9587-4185-9009-d47ed80d1fb4	57812718-33b2-4585-ba16-e4a95bec7405	LED	10.000	pcs	LED	50.00	500.00	2026-05-25 14:14:25.287+00	2026-05-25 14:14:25.287+00	\N	\N
857b6977-ebc5-46d6-b4fb-1584ad7f1f4a	41095b55-bef2-44b9-bccd-d0adcdff720e	4b34d676-9587-4185-9009-d47ed80d1fb4	57812718-33b2-4585-ba16-e4a95bec7405	LED	10.000	pcs	LED	500.00	5000.00	2026-05-25 14:31:57.805+00	2026-05-25 14:31:57.805+00	\N	\N
646cec57-1e6c-4768-b05d-7cf858258893	b4d5b54d-e4a2-46d8-aba3-283dca75f3d6	b59ce43a-6c3a-4607-a32c-ade6e6aee326	57812718-33b2-4585-ba16-e4a95bec7405	LED	20.000	pcs	\N	100.00	2000.00	2026-05-25 16:11:13.676+00	2026-05-25 16:11:13.676+00	\N	\N
e2ec0800-7898-4aac-83b3-74426e1c52c5	b4d5b54d-e4a2-46d8-aba3-283dca75f3d6	ddb8ba1a-3050-461b-baf7-8605de317f36	53457790-5c18-4f3a-a2d6-709ded27ed4a	MCB (Miniature Circuit Breaker)	30.000	pcs	\N	200.00	6000.00	2026-05-25 16:11:13.676+00	2026-05-25 16:11:13.676+00	\N	\N
1d45ca9a-23c3-4001-8aeb-8459c1f2ef6e	48be167e-71e0-4ee7-ab9d-8f39668ad5bf	b59ce43a-6c3a-4607-a32c-ade6e6aee326	57812718-33b2-4585-ba16-e4a95bec7405	LED	20.000	pcs	\N	10.00	200.00	2026-05-25 16:16:16.823+00	2026-05-25 16:16:16.823+00	\N	\N
4023c242-ccea-4d68-a768-7cb37960975c	48be167e-71e0-4ee7-ab9d-8f39668ad5bf	ddb8ba1a-3050-461b-baf7-8605de317f36	53457790-5c18-4f3a-a2d6-709ded27ed4a	MCB (Miniature Circuit Breaker)	30.000	pcs	\N	30.00	900.00	2026-05-25 16:16:16.823+00	2026-05-25 16:16:16.823+00	\N	\N
6d11f126-76a0-4640-a179-7483491a7526	997ff610-0247-4e1c-937f-718f2bfb7a8a	52896ddc-58df-411c-9693-d3eaa195a581	53457790-5c18-4f3a-a2d6-709ded27ed4a	MCB (Miniature Circuit Breaker)	50.000	pcs	MCB	100.00	5000.00	2026-05-26 07:43:16.738+00	2026-05-26 07:43:16.738+00	\N	\N
60819674-5774-4887-8185-1946b9131fe5	868824d2-aa4d-4e7f-ba41-7b290af66120	52896ddc-58df-411c-9693-d3eaa195a581	53457790-5c18-4f3a-a2d6-709ded27ed4a	MCB (Miniature Circuit Breaker)	50.000	pcs	MCB	1250.00	62500.00	2026-05-26 07:45:07.339+00	2026-05-26 07:45:07.339+00	\N	\N
d7c756eb-c1e1-4234-88cf-848311c20d6e	1602ff84-1d70-4243-9e73-9a86c7036ef2	eeddcec7-91dc-4579-9fc7-06fdcf75bf6f	1f99fcd4-52c2-4c2c-a79d-132838abe2d0	Diesel Engine	7.000	pcs	\N	100000.00	700000.00	2026-05-30 04:04:22.26+00	2026-05-30 04:04:22.26+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
6a97c689-3f74-4b47-8958-7803a8c07762	918f85ed-06e2-413f-9c17-7b8c9dce44d0	651bdd89-8588-434d-a051-c4989a885e1b	f9865733-a9f7-44f6-a031-9c3925042cea	Power Capacitor	5.000	pcs	\N	70.00	350.00	2026-05-30 08:24:50.464+00	2026-05-30 08:24:50.464+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
fe1231bb-6fc8-469e-8b85-6e8e1d30224a	918f85ed-06e2-413f-9c17-7b8c9dce44d0	44649baf-0b70-4586-a60d-657df0210898	7a494ea2-2cf1-419c-ba0a-37da9f178b41	Busbar Copper	5.000	pcs	\N	50.00	250.00	2026-05-30 08:24:50.464+00	2026-05-30 08:24:50.464+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
9c7e81dc-58ca-490a-98fd-538668af5f0c	918f85ed-06e2-413f-9c17-7b8c9dce44d0	6377075d-d840-4993-b59c-812bf407900f	8c42805b-90f8-4c3d-9784-b6821ad9272a	Lightning Arrester	5.000	pcs	\N	2000.00	10000.00	2026-05-30 08:24:50.464+00	2026-05-30 08:24:50.464+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
8f1e0dac-aa9a-41c0-b217-101178fc6a24	918f85ed-06e2-413f-9c17-7b8c9dce44d0	4861189f-c67f-470f-8263-9e4cbfb8682b	b196efdd-24e4-4435-a798-aab2e1ec69a0	Earth Rod	5.000	pcs	\N	3000.00	15000.00	2026-05-30 08:24:50.464+00	2026-05-30 08:24:50.464+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
69b2b82f-e7aa-4da8-9169-cd5e447eb794	918f85ed-06e2-413f-9c17-7b8c9dce44d0	17d20d4d-3a2e-454e-aec4-7b739f3eefa1	6cf057a6-6a6e-46ac-be49-a0417acd71c3	Cable Tray	5.000	pcs	\N	7000.00	35000.00	2026-05-30 08:24:50.464+00	2026-05-30 08:24:50.464+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
\.


--
-- Data for Name: supplier_return_images; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_return_images (id, return_id, return_item_id, file_path, public_url, original_filename, mime_type, created_at, updated_at, created_by) FROM stdin;
5dfdc4b6-fb8d-468d-99e8-b2f2470cb17a	943c0a1f-0367-4504-81fc-c7c934db14a7	09d0526b-4020-454b-8306-293edd2e76e2	returns/943c0a1f-0367-4504-81fc-c7c934db14a7/1779696744471-f4820dfc-5d9f-4144-84b2-862af6223b62.jpg	/uploads/returns/943c0a1f-0367-4504-81fc-c7c934db14a7/1779696744471-f4820dfc-5d9f-4144-84b2-862af6223b62.jpg	Chick.jpg	image/jpeg	2026-05-25 08:12:24.473+00	2026-05-25 08:12:24.473+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
2d521e76-f204-4b41-bf7f-c026d8788581	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	cb118e59-c5a9-4eed-87b1-6d8ce598e62d	returns/4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac/1780982734469-bd3e5580-f70a-4152-bd6a-1beec5a45999.png	/uploads/returns/4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac/1780982734469-bd3e5580-f70a-4152-bd6a-1beec5a45999.png	Screenshot 2026-04-25 163807.png	image/png	2026-06-09 05:25:34.471+00	2026-06-09 05:25:34.471+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c
\.


--
-- Data for Name: supplier_return_items; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_return_items (id, return_id, product_id, quantity, uom, unit_cost, line_value, goods_receipt_item_id, grn_quantity, reason_code) FROM stdin;
09d0526b-4020-454b-8306-293edd2e76e2	943c0a1f-0367-4504-81fc-c7c934db14a7	57812718-33b2-4585-ba16-e4a95bec7405	1.000	pcs	500.00	500.00	712b800e-a15b-40af-a194-a251015627e8	1.000	DAMAGED
0895de8c-01ae-451e-bf63-120c401a02b6	d2031d2e-f4f8-40d5-ba30-d2e7870037ac	53457790-5c18-4f3a-a2d6-709ded27ed4a	5.000	pcs	300.00	1500.00	7b68abf4-513a-458d-ba15-2554cbb7caa0	25.000	DAMAGED
cb118e59-c5a9-4eed-87b1-6d8ce598e62d	4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	166c4ba0-232b-484f-ad54-fab5379410fa	5.000	pcs	950.00	4750.00	ca23639e-85aa-406f-b802-5387df7ebe1d	10.000	EXCESS
\.


--
-- Data for Name: supplier_returns; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.supplier_returns (id, return_number, return_date, shop_id, supplier_name, purchase_order_id, reason, remarks, status, total_value, posted_at, created_at, updated_at, created_by, updated_by, supplier_id, goods_receipt_id, supplier_ref, internal_cc_email, submitted_at, acknowledged_at, email_sent_at, ack_token_hash, email_message_id, branding_mode, branding_snapshot, branding_version, template_version) FROM stdin;
943c0a1f-0367-4504-81fc-c7c934db14a7	RMO-202605-00001	2026-05-25	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Bharat Electricals Supply	d16a81c5-d5e6-4a5e-ae2c-85069bf8cea6	\N	\N	DONE	500.00	2026-05-25 08:13:48.779+00	2026-05-25 08:11:53.11+00	2026-05-25 08:13:48.78+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	7c961808-5a79-4c95-8c40-a36f4839609c	8f914892-94f8-44a0-888c-c6d2867c8805	\N	gstharunadhithya08@gmail.com	2026-05-25 08:12:33.408+00	2026-05-25 08:13:48.769+00	2026-05-25 08:12:33.408+00	aeeb042eb4174cac76d4cadb35775d5527e1658c92e8ffa7a0802a30835fd26a	<337de320-c081-f443-aab2-289a0936c415@softdigitconsulting.com>	SNAPSHOT	\N	\N	1
d2031d2e-f4f8-40d5-ba30-d2e7870037ac	RMO-202605-00002	2026-05-26	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	c5973c42-3a93-484d-ac68-c64ca799accc	\N	\N	DONE	1500.00	2026-05-26 08:30:31.545+00	2026-05-26 08:29:59.413+00	2026-05-26 08:30:31.546+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	a94916e2-72a6-4b9c-985d-01de9bc20a2a	dbe84bee-6afc-411a-943c-32c4467b05d6	\N	\N	2026-05-26 08:30:05.476+00	2026-05-26 08:30:31.537+00	2026-05-26 08:30:05.476+00	08f0fa5eae8baa562c86657ab22d6283a7b294929e4f8f7bd1e356b856d55c7a	<0c57a224-2d36-a66f-c113-e60ac660882e@softdigitconsulting.com>	SNAPSHOT	\N	\N	1
4d3fb1d5-e9ba-4a34-83c2-66ad9a9b2eac	RMO-00001	2026-06-09	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	Heaven Electrical Supply	\N	\N	\N	SUBMITTED	4750.00	\N	2026-06-09 05:24:46.882+00	2026-06-09 05:25:44.077+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	a94916e2-72a6-4b9c-985d-01de9bc20a2a	408aea7a-6b67-4fab-af46-3321ed698642	\N	\N	2026-06-09 05:25:44.076+00	\N	2026-06-09 05:25:44.076+00	64ef947439edd82080b4a3816357ec09469eecfd99e0c1d9885084fcbbcf116a	\N	SNAPSHOT	{"shopName": "Headquarters", "companyName": "Softdigit Consulting", "generatedAt": "2026-06-09T05:25:38.583Z", "logoVersion": null, "brandingVersion": null, "templateVersion": 1}	\N	1
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.suppliers (id, supplier_code, supplier_name, company_id, tax_id, vat_number, rating, categories, contact_person, email, phone, street, city, state, postal_code, country, payment_terms, bank_name, account_number, routing_number, iban, is_active, created_at, updated_at, created_by, updated_by, deleted_at) FROM stdin;
a94916e2-72a6-4b9c-985d-01de9bc20a2a	SUP-0001	Heaven Electrical Supply	582b08bd-2a7a-475b-84c2-e4ef8f834a83	33AAECH4587K1Z2	\N	4	{}	samy	kolandasamy.sss@gmail.com	09677878824	Pallavaram	Oggiyamduraipakkam	Tamil Nadu	600004	India	Net 30	SBI	\N	\N	\N	t	2026-05-25 05:12:27.518+00	2026-05-25 05:12:27.518+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
7c961808-5a79-4c95-8c40-a36f4839609c	SUP-0002	Bharat Electricals Supply	582b08bd-2a7a-475b-84c2-e4ef8f834a83	33ABCDE1234F1Z5	\N	5	{}	Tharun	gstharunadhithya08@gmail.com	9488329318	coimbatore	coimbatore	Tamil Nadu	600097	India	Net 30	SBI	31520896574	\N	\N	t	2026-05-25 05:14:16.56+00	2026-05-26 08:02:16.051+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N
ca807d32-c879-460d-896d-df5193dcb198	SUP-001	Nadar depart store	97321e34-ea5a-49ed-8dc8-f6b6af4e91ec	33AASANED32340J1ZA	\N	3	{Supermarker}	Murugan	office@supermarket.com	9007435322	TATA Nagar	Chennai	Tamilnadu	600034	India	Net 30	\N	\N	\N	\N	t	2026-05-26 12:50:25.347+00	2026-05-26 12:50:25.347+00	47a8b4e9-c9ee-4239-b6c1-129e71d74587	\N	\N
6a9b09b4-5182-49c2-92f4-02870dfac0e5	SUP-0003	PowerDrive Engines	582b08bd-2a7a-475b-84c2-e4ef8f834a83	\N	\N	4	{Automotive}	Bala	kolandasamy.sss@gmail.com	9677878824	Erode	Bhavani	Tamil Nadu	638314	India	Net 30	SBI	31520897654	\N	\N	t	2026-05-29 14:02:08.726+00	2026-05-29 14:02:08.726+00	6fd97d36-05d1-4617-8c81-0d54da73ace8	\N	\N
79be7f13-60fd-4d65-a0df-b87335b8c75e	SUP-0004	Bright Power Distributors	582b08bd-2a7a-475b-84c2-e4ef8f834a83	TY67UHTRE3CKL	COYPK2567ER	4	{Electrical}	Tharun	kolandasamy.sss@gmail.com	09677878824	Tambaram	chennai	Tamil Nadu	600097	India	Net 30	SBI	31528087769790	\N	\N	t	2026-05-30 08:17:47.666+00	2026-05-30 08:17:47.666+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.system_settings (id, key, value, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: trusted_mfa_devices; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.trusted_mfa_devices (id, user_id, token_hash, ip, user_agent, last_used_at, expires_at, revoked_at, created_at) FROM stdin;
f9df60f8-4e62-4a84-b45f-60cc4c928b6b	47a8b4e9-c9ee-4239-b6c1-129e71d74587	ff58bd7945b07f4994d6c04fb11ea1d6c1ff885021c211eea5a0de26377d4e71	2405:201:e033:6187:e0b6:506f:a6f:e174	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-25 12:27:02.39+00	2026-06-01 12:27:02.39+00	\N	2026-05-25 12:27:02.391+00
f0b03cd8-0c3f-4d4b-b97f-4b2e7889f49a	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	43ecbaa19d0a83acff33ec66abf56488241d379dc54714e5cfa42e3cea0d96e3	49.47.218.16	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 11:05:07.99+00	2026-06-02 11:05:07.99+00	\N	2026-05-26 11:05:07.991+00
a4914aa3-7a0d-4302-a2b6-8c8eb1e9922f	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	a502bd67597e30254ed9450cf27d6c14718d113c180ead5377200d3a16d90761	220.158.156.250	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-26 16:34:08.655+00	2026-06-02 16:34:08.655+00	2026-05-26 16:42:32.151+00	2026-05-26 16:34:08.656+00
1ed935fc-0791-46d7-a84f-0c617e0df873	47a8b4e9-c9ee-4239-b6c1-129e71d74587	744c9b4bdaf63b471bed2b9f08209cc31d8339daefef220903ac66ca6eeac5f0	2405:201:e033:6187:1885:d591:a2f4:f136	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0	2026-05-27 12:38:46.564+00	2026-06-01 15:51:56.373+00	\N	2026-05-25 15:51:56.374+00
0db39f48-bae4-490b-9339-7192c6053d50	47a8b4e9-c9ee-4239-b6c1-129e71d74587	4cf282c9abd94aa16c4345b7a7f6269a24a97a81e7d73747953961502d1ca8cb	27.4.240.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0	2026-06-08 10:51:58.235+00	2026-06-15 10:51:58.235+00	\N	2026-06-08 10:51:58.236+00
\.


--
-- Data for Name: user_backup_codes; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.user_backup_codes (id, user_id, code_hash, consumed_at, created_at) FROM stdin;
61db5498-e48f-4fc9-9b47-1bd596f94003	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$xMwvoTA7XKvlHJSqk9dWKOxFmdfCmnc9aDKSclAvCNZ6DDcGF2ycm	\N	2026-05-25 12:04:20.867+00
1f547fdb-dcf5-43ef-841a-83db7356783e	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$eXEnFLsngYCu9w24RcTMCOsVfzwyMIX6C4hrW8wR9g85X7tOTAJJi	\N	2026-05-25 12:04:20.867+00
153fce24-1a8b-41a7-b0c9-edeaf6cd3f56	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$JoFLhK4AROxrQLIZb9fyfeiG/tcY9qEuCa1bxatwT7ktMPO116iHG	\N	2026-05-25 12:04:20.867+00
e9eb4cba-2c02-4512-a2d0-a421fe7f68be	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$AzNNL3M8BG5XXz2Ppju.jemuojCp4BmFDblSMSjyoEtZg3QXP5sqa	\N	2026-05-25 12:04:20.867+00
0329e0fd-ed4e-484a-b674-cba0e3b535e1	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$8sgDTVMNF6IKCTJ81NayHeNymTo/1avB9wLm0ikYhWpYOux2A1vqy	\N	2026-05-25 12:04:20.867+00
705dce74-9451-46a8-9dd2-a82966980b80	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$bHbzvlzQfJOhYuctSjokKOIDwTeZIAjTiMlnRTYKs3T4ucAJJTsku	\N	2026-05-25 12:04:20.867+00
6f54b11f-7943-4176-9fc6-40e17130679e	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$mUA1zg9LjTpflU2titZ.H.e98wmribS1Z9kdHWp/iqLPDlU3sm4De	\N	2026-05-25 12:04:20.867+00
b4dd576b-b912-4426-9d07-91a371a55c62	ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	$2b$12$V1PMpKAaGMufPISS3E1J2e8zTbudb1N5qeDVdkdoLCbNB/fxKGBD.	\N	2026-05-25 12:04:20.867+00
55b85284-9ee1-4851-aec8-4ef868ffad27	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$1pTCoW3excpEJX0Q2KxqbumFOI4ESi8wgyAo2mnBGLQ78II37wuUy	\N	2026-05-25 12:10:30.173+00
7fa18644-92bc-4e5b-a173-4c21a6d89bd2	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$M1IIxkHPBtSrsuX144yujOowf61JInt9fwcSL0njHdizm5GPnPJ2G	\N	2026-05-25 12:10:30.173+00
9159829d-06fa-4520-a2cb-e781ac1a2344	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$7uI48t65MLM1y0EssBQ8Xelz0H0/FLy2Yxo8hEex/olvYlJmn3R4G	\N	2026-05-25 12:10:30.173+00
6c87fe58-6993-4241-8944-c29e6e00d20c	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$jdbYKP6G1aTRkqy81Fm2IOH6XV0B.RDg5fgaFzFTCrO9iQtl9poH6	\N	2026-05-25 12:10:30.173+00
8ab67c4d-fb43-41ca-b925-37ed59b90445	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$H2HdccvKFIspCfMkbzwHI.dnsI2ZUvwRT0QV9iHK2R7A/4hoMK2ki	\N	2026-05-25 12:10:30.173+00
e48ae01c-ecc6-42e3-944e-03b44a903996	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$DQoyymgb6j3sRyiBMZp3muiYVW02ecOCZU/8uaEK.eHhJTLBI2Dy2	\N	2026-05-25 12:10:30.173+00
5a5ead89-0d2e-4293-8b05-b98396b77ced	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$eeckjlWXorWGNEHydgGmWeqGlCNlGcZJJaBWME4ie3ErxwIt9PWAG	\N	2026-05-25 12:10:30.173+00
642fe021-921c-494f-b7b3-dc23917d23a3	47a8b4e9-c9ee-4239-b6c1-129e71d74587	$2b$12$t9NkQmmS4/Bv73mOHNdfgu8H2dziRBXZO1yrexgOl0uRTDwRAYFHG	\N	2026-05-25 12:10:30.173+00
\.


--
-- Data for Name: user_invitations; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.user_invitations (id, email, name, role_id, shop_id, token_hash, invited_by, expires_at, consumed_at, created_at) FROM stdin;
4976c4d6-175a-4dce-b20c-e10368af4f93	gstharunadhithya08@gmail.com	Manager	b6ec9a6f-ced1-4e32-8d46-eada8cae9565	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	7c72d5d2cba1a30e0f59efa143cf635d09e2a0cdf28312c429d3f766d41fd02c	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-05-27 19:28:14.416+00	\N	2026-05-24 19:28:14.419+00
09488a2f-633b-44f9-8534-df6b148d0a5e	kolandasamy.sss@gmail.com	Inventory Manager	36ee7bf2-03b4-496d-a832-910cba96f8a1	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	89a805f060882dae63c12c391670300dd46b3f327d33acf05075dffe2ec4af34	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	2026-06-01 06:42:15.687+00	2026-05-29 06:43:00.495+00	2026-05-29 06:42:15.697+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: retail
--

COPY public.users (id, name, email, password_hash, avatar_url, role_id, shop_id, is_active, deleted_at, last_login_at, refresh_token_hash, failed_login_count, locked_until, created_at, updated_at, created_by, updated_by, password_changed_at, mfa_enabled, mfa_method, mfa_enrolled_at, mfa_secret_encrypted) FROM stdin;
51e8defb-4c28-490b-beb5-283437c31e20	Samritha	samrithags12@gmail.com	$2b$12$vO59zPw3fXa0FEzvJWuxoeHLAa1/gc9efe4C4UTnimwwR63WiwccK	\N	f4e729b2-02ea-4fd7-b315-f52347704c5b	e7b380ad-9b2d-4cef-afd6-5a620973c9c8	t	\N	2026-05-31 03:18:02.368+00	\N	0	\N	2026-05-31 03:18:01.917+00	2026-05-31 03:18:02.369+00	\N	\N	\N	f	\N	\N	\N
47a8b4e9-c9ee-4239-b6c1-129e71d74587	Sami	swamiedge@gmail.com	$2b$12$Rt.O5kls9nCKWQ9U8tSU4u0IzBwBpyszja34jll6Xn.8I9cpjb2Zq	\N	f4e729b2-02ea-4fd7-b315-f52347704c5b	d53ce4ee-7da6-4709-b944-348687fb0843	t	\N	2026-06-08 10:51:58.233+00	\N	0	\N	2026-05-25 12:10:30.17+00	2026-06-08 10:51:58.233+00	\N	\N	\N	t	TOTP	2026-05-25 12:09:54.029+00	L-DZietOk0eap1tK.zZCfqK24rmQrINPTQUA8dw.GB1VauohLxVzADQzpotbYsXJ0-u-SZ-KaO9y1XnPwcM
984b0cee-92c8-43d1-8108-2d33a1f5fd7c	Owner	admin@retailims.com	$2b$12$605heYR6bwQdPU4t7z4ypOtz1I9WH4XerFN0nBGohSZoiuJOkpfk6	/uploads/avatars/984b0cee-92c8-43d1-8108-2d33a1f5fd7c-1780942457202.png	f4e729b2-02ea-4fd7-b315-f52347704c5b	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	\N	2026-06-13 09:37:29.594+00	\N	0	\N	2026-05-24 19:03:56.615+00	2026-06-13 09:37:29.595+00	\N	\N	\N	f	\N	\N	\N
6fd97d36-05d1-4617-8c81-0d54da73ace8	Inventory Manager	kolandasamy.sss@gmail.com	$2b$12$f0VUKi6tlpPasa/UXPAgnOJlQzpZuyrGFCzSqcKWOu3YaZ14aXrRG	\N	36ee7bf2-03b4-496d-a832-910cba96f8a1	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	\N	2026-05-29 06:43:01.183+00	\N	2	\N	2026-05-29 06:43:00.488+00	2026-06-11 08:10:15.781+00	984b0cee-92c8-43d1-8108-2d33a1f5fd7c	\N	\N	f	\N	\N	\N
73670f0a-df99-4e54-88fc-9b64dee80a28	Tharun Adhithya	gstharunadhithya@gmail.com	$2b$12$LWuP0UjuHvdyfM/m2oy75.squuQkiKInJIsHAEnQkHhthrIvuE1Zu	\N	f4e729b2-02ea-4fd7-b315-f52347704c5b	c52ae944-6e14-4517-962f-8a8de35d7b30	t	\N	\N	\N	1	\N	2026-05-25 10:08:06.435+00	2026-06-13 08:11:00.631+00	\N	\N	\N	f	\N	\N	\N
d0eda257-86b4-4510-93bc-103cfe0d86e4	Tharun Adhithya	gstharunadhithya08@gmail.com	$2b$12$6EU1PsEuQB0z5WV4Z1LfE.uiJURvoRyzLJUl294C55XypCh3c/3B2	\N	f4e729b2-02ea-4fd7-b315-f52347704c5b	a193b5a3-f970-46cb-97df-5fd787496f8e	t	\N	2026-05-30 10:26:37.182+00	\N	0	\N	2026-05-25 09:59:42.513+00	2026-05-30 10:26:37.183+00	\N	\N	\N	f	\N	\N	\N
f20022c7-d1e2-46df-8743-c91fc33601dd	Day 3 Test User	audit-test@retailims.com	$2b$10$U0BhLLO5LJ48ePLJPghEVOGQWdkRKqANq/f8/Z2Fexw6RtJM/3Wn6	\N	b6ec9a6f-ced1-4e32-8d46-eada8cae9565	0f2ae8d3-b590-4b93-9c27-198ef987b2ad	t	\N	2026-06-13 08:14:31.405+00	\N	0	\N	2026-06-13 08:14:25.49174+00	2026-06-13 08:14:31.406+00	\N	\N	\N	f	\N	\N	\N
ea80761f-b62a-45fe-b2d9-2a4ae6dfd082	Tharun Adhithya	tharunbackup08@gmail.com	$2b$10$U0BhLLO5LJ48ePLJPghEVOGQWdkRKqANq/f8/Z2Fexw6RtJM/3Wn6	\N	f4e729b2-02ea-4fd7-b315-f52347704c5b	2b4ea860-95fe-4047-a7a5-6c3ee795c461	t	\N	2026-06-13 08:16:38.355+00	\N	0	\N	2026-05-25 12:04:20.864+00	2026-06-13 08:16:38.356+00	\N	\N	\N	f	TOTP	2026-05-25 12:04:12.76+00	pyXzsX9wzOofVjiv.RXTyve5b02nk_pvAXs4HUw.NOnWdEHaloM5DvqCNMSWTsB6AntadhhFb6otUsbkdOs
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: alert_events alert_events_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_pkey PRIMARY KEY (id);


--
-- Name: approval_comments approval_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_pkey PRIMARY KEY (id);


--
-- Name: approval_escalations approval_escalations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_escalations
    ADD CONSTRAINT approval_escalations_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: backup_artifacts backup_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_artifacts
    ADD CONSTRAINT backup_artifacts_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: backup_provider_credentials backup_provider_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_provider_credentials
    ADD CONSTRAINT backup_provider_credentials_pkey PRIMARY KEY (id);


--
-- Name: barcode_audit_logs barcode_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_audit_logs
    ADD CONSTRAINT barcode_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: barcode_history barcode_history_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_history
    ADD CONSTRAINT barcode_history_pkey PRIMARY KEY (id);


--
-- Name: barcode_print_jobs barcode_print_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_print_jobs
    ADD CONSTRAINT barcode_print_jobs_pkey PRIMARY KEY (id);


--
-- Name: barcode_template_versions barcode_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_template_versions
    ADD CONSTRAINT barcode_template_versions_pkey PRIMARY KEY (id);


--
-- Name: branding_profiles branding_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_engagement_snapshots company_engagement_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_engagement_snapshots
    ADD CONSTRAINT company_engagement_snapshots_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: contract_header contract_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_pkey PRIMARY KEY (id);


--
-- Name: contract_items contract_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_items
    ADD CONSTRAINT contract_items_pkey PRIMARY KEY (id);


--
-- Name: cost_layers cost_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.cost_layers
    ADD CONSTRAINT cost_layers_pkey PRIMARY KEY (id);


--
-- Name: credit_notes credit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (code);


--
-- Name: customer_return_items customer_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_pkey PRIMARY KEY (id);


--
-- Name: customer_returns customer_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: damaged_stock damaged_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.damaged_stock
    ADD CONSTRAINT damaged_stock_pkey PRIMARY KEY (id);


--
-- Name: data_retention_config data_retention_config_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.data_retention_config
    ADD CONSTRAINT data_retention_config_pkey PRIMARY KEY (id);


--
-- Name: device_registrations device_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_pkey PRIMARY KEY (id);


--
-- Name: document_email_outbox document_email_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_email_outbox
    ADD CONSTRAINT document_email_outbox_pkey PRIMARY KEY (id);


--
-- Name: document_sequences document_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_pkey PRIMARY KEY (id);


--
-- Name: document_series_config document_series_config_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_series_config
    ADD CONSTRAINT document_series_config_pkey PRIMARY KEY (id);


--
-- Name: email_delivery_log email_delivery_log_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_delivery_log
    ADD CONSTRAINT email_delivery_log_pkey PRIMARY KEY (id);


--
-- Name: email_sender_domains email_sender_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_domains
    ADD CONSTRAINT email_sender_domains_pkey PRIMARY KEY (id);


--
-- Name: email_sender_identities email_sender_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_identities
    ADD CONSTRAINT email_sender_identities_pkey PRIMARY KEY (id);


--
-- Name: email_sender_verifications email_sender_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_verifications
    ADD CONSTRAINT email_sender_verifications_pkey PRIMARY KEY (id);


--
-- Name: fx_rates fx_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.fx_rates
    ADD CONSTRAINT fx_rates_pkey PRIMARY KEY (id);


--
-- Name: goods_issue_header goods_issue_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_header
    ADD CONSTRAINT goods_issue_header_pkey PRIMARY KEY (id);


--
-- Name: goods_issue_items goods_issue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_header goods_receipt_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_header
    ADD CONSTRAINT goods_receipt_header_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: invoice_header invoice_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_pkey PRIMARY KEY (id);


--
-- Name: job_failures job_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.job_failures
    ADD CONSTRAINT job_failures_pkey PRIMARY KEY (id);


--
-- Name: lifecycle_campaign_enrollments lifecycle_campaign_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.lifecycle_campaign_enrollments
    ADD CONSTRAINT lifecycle_campaign_enrollments_pkey PRIMARY KEY (id);


--
-- Name: media_assets media_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_pkey PRIMARY KEY (id);


--
-- Name: notification_audit_logs notification_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_audit_logs
    ADD CONSTRAINT notification_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_requests password_reset_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.password_reset_requests
    ADD CONSTRAINT password_reset_requests_pkey PRIMARY KEY (id);


--
-- Name: payment_receipts payment_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_pkey PRIMARY KEY (id);


--
-- Name: platform_audit_log platform_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_audit_log
    ADD CONSTRAINT platform_audit_log_pkey PRIMARY KEY (id);


--
-- Name: platform_notification_reads platform_notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_notification_reads
    ADD CONSTRAINT platform_notification_reads_pkey PRIMARY KEY (id);


--
-- Name: platform_notifications platform_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_notifications
    ADD CONSTRAINT platform_notifications_pkey PRIMARY KEY (id);


--
-- Name: po_cancel_verifications po_cancel_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.po_cancel_verifications
    ADD CONSTRAINT po_cancel_verifications_pkey PRIMARY KEY (id);


--
-- Name: product_barcodes product_barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_pkey PRIMARY KEY (id);


--
-- Name: product_plants product_plants_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_pkey PRIMARY KEY (id);


--
-- Name: product_specifications product_specifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_specifications
    ADD CONSTRAINT product_specifications_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_header purchase_order_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: report_saved_filters report_saved_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.report_saved_filters
    ADD CONSTRAINT report_saved_filters_pkey PRIMARY KEY (id);


--
-- Name: restore_jobs restore_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_pkey PRIMARY KEY (id);


--
-- Name: rfq_header rfq_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_header
    ADD CONSTRAINT rfq_header_pkey PRIMARY KEY (id);


--
-- Name: rfq_items rfq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_pkey PRIMARY KEY (id);


--
-- Name: rfq_suppliers rfq_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_suppliers
    ADD CONSTRAINT rfq_suppliers_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_order_header sales_order_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_header
    ADD CONSTRAINT sales_order_header_pkey PRIMARY KEY (id);


--
-- Name: sales_order_items sales_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_pkey PRIMARY KEY (id);


--
-- Name: sales_quote_header sales_quote_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_pkey PRIMARY KEY (id);


--
-- Name: sales_quote_items sales_quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_pkey PRIMARY KEY (id);


--
-- Name: scan_logs scan_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.scan_logs
    ADD CONSTRAINT scan_logs_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (id);


--
-- Name: signup_verifications signup_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.signup_verifications
    ADD CONSTRAINT signup_verifications_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_pkey PRIMARY KEY (id);


--
-- Name: stock_count_sessions stock_count_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_sessions
    ADD CONSTRAINT stock_count_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_ledger stock_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_pkey PRIMARY KEY (id);


--
-- Name: stock_summary stock_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_summary
    ADD CONSTRAINT stock_summary_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_header stock_transfer_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: storage_locations storage_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_pkey PRIMARY KEY (id);


--
-- Name: subscription_invoices subscription_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: supplier_bill_header supplier_bill_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_pkey PRIMARY KEY (id);


--
-- Name: supplier_bill_items supplier_bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_items
    ADD CONSTRAINT supplier_bill_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_payments supplier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_pkey PRIMARY KEY (id);


--
-- Name: supplier_quote_header supplier_quote_header_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_pkey PRIMARY KEY (id);


--
-- Name: supplier_quote_items supplier_quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_return_images supplier_return_images_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_images
    ADD CONSTRAINT supplier_return_images_pkey PRIMARY KEY (id);


--
-- Name: supplier_return_items supplier_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_returns supplier_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: trusted_mfa_devices trusted_mfa_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.trusted_mfa_devices
    ADD CONSTRAINT trusted_mfa_devices_pkey PRIMARY KEY (id);


--
-- Name: user_backup_codes user_backup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_backup_codes
    ADD CONSTRAINT user_backup_codes_pkey PRIMARY KEY (id);


--
-- Name: user_invitations user_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: alert_events_alert_type_triggered_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX alert_events_alert_type_triggered_at_idx ON public.alert_events USING btree (alert_type, triggered_at);


--
-- Name: alert_events_shop_id_is_read_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX alert_events_shop_id_is_read_idx ON public.alert_events USING btree (shop_id, is_read);


--
-- Name: approval_comments_approval_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_comments_approval_id_idx ON public.approval_comments USING btree (approval_id);


--
-- Name: approval_escalations_approval_id_escalated_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_escalations_approval_id_escalated_at_idx ON public.approval_escalations USING btree (approval_id, escalated_at);


--
-- Name: approval_requests_approval_type_reference_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_requests_approval_type_reference_id_idx ON public.approval_requests USING btree (approval_type, reference_id);


--
-- Name: approval_requests_assigned_to_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_requests_assigned_to_status_idx ON public.approval_requests USING btree (assigned_to, status);


--
-- Name: approval_requests_company_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX approval_requests_company_id_status_created_at_idx ON public.approval_requests USING btree (company_id, status, created_at);


--
-- Name: audit_log_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_log_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_log_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_log_entity_type_entity_id_idx ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: audit_log_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX audit_log_user_id_created_at_idx ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: auth_challenges_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX auth_challenges_expires_at_idx ON public.auth_challenges USING btree (expires_at);


--
-- Name: auth_challenges_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX auth_challenges_token_hash_idx ON public.auth_challenges USING btree (token_hash);


--
-- Name: auth_challenges_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX auth_challenges_user_id_idx ON public.auth_challenges USING btree (user_id);


--
-- Name: backup_artifacts_backup_job_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX backup_artifacts_backup_job_id_key ON public.backup_artifacts USING btree (backup_job_id);


--
-- Name: backup_artifacts_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX backup_artifacts_company_id_created_at_idx ON public.backup_artifacts USING btree (company_id, created_at);


--
-- Name: backup_jobs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX backup_jobs_company_id_created_at_idx ON public.backup_jobs USING btree (company_id, created_at);


--
-- Name: backup_provider_credentials_company_id_provider_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX backup_provider_credentials_company_id_provider_key ON public.backup_provider_credentials USING btree (company_id, provider);


--
-- Name: barcode_audit_logs_barcode_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_audit_logs_barcode_id_idx ON public.barcode_audit_logs USING btree (barcode_id);


--
-- Name: barcode_audit_logs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_audit_logs_company_id_created_at_idx ON public.barcode_audit_logs USING btree (company_id, created_at);


--
-- Name: barcode_audit_logs_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_audit_logs_product_id_idx ON public.barcode_audit_logs USING btree (product_id);


--
-- Name: barcode_history_barcode_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_history_barcode_idx ON public.barcode_history USING btree (barcode);


--
-- Name: barcode_history_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX barcode_history_company_id_created_at_idx ON public.barcode_history USING btree (company_id, created_at);


--
-- Name: barcode_template_versions_template_name_version_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX barcode_template_versions_template_name_version_key ON public.barcode_template_versions USING btree (template_name, version);


--
-- Name: companies_company_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX companies_company_code_key ON public.companies USING btree (company_code);


--
-- Name: company_engagement_snapshots_company_id_snapshot_date_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX company_engagement_snapshots_company_id_snapshot_date_key ON public.company_engagement_snapshots USING btree (company_id, snapshot_date);


--
-- Name: company_engagement_snapshots_lifecycle_stage_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX company_engagement_snapshots_lifecycle_stage_idx ON public.company_engagement_snapshots USING btree (lifecycle_stage);


--
-- Name: company_engagement_snapshots_snapshot_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX company_engagement_snapshots_snapshot_date_idx ON public.company_engagement_snapshots USING btree (snapshot_date);


--
-- Name: company_settings_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX company_settings_company_id_idx ON public.company_settings USING btree (company_id);


--
-- Name: company_settings_company_id_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX company_settings_company_id_key_key ON public.company_settings USING btree (company_id, key);


--
-- Name: contract_header_contract_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX contract_header_contract_number_key ON public.contract_header USING btree (contract_number);


--
-- Name: contract_header_shop_id_start_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX contract_header_shop_id_start_date_idx ON public.contract_header USING btree (shop_id, start_date);


--
-- Name: contract_header_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX contract_header_supplier_id_idx ON public.contract_header USING btree (supplier_id);


--
-- Name: contract_items_contract_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX contract_items_contract_id_idx ON public.contract_items USING btree (contract_id);


--
-- Name: cost_layers_qty_remaining_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX cost_layers_qty_remaining_idx ON public.cost_layers USING btree (qty_remaining);


--
-- Name: cost_layers_shop_id_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX cost_layers_shop_id_product_id_created_at_idx ON public.cost_layers USING btree (shop_id, product_id, created_at);


--
-- Name: credit_notes_credit_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX credit_notes_credit_number_key ON public.credit_notes USING btree (credit_number);


--
-- Name: credit_notes_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX credit_notes_customer_id_idx ON public.credit_notes USING btree (customer_id);


--
-- Name: credit_notes_return_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX credit_notes_return_id_key ON public.credit_notes USING btree (return_id);


--
-- Name: credit_notes_shop_id_credit_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX credit_notes_shop_id_credit_date_idx ON public.credit_notes USING btree (shop_id, credit_date);


--
-- Name: customer_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_return_items_return_id_idx ON public.customer_return_items USING btree (return_id);


--
-- Name: customer_returns_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_returns_customer_id_idx ON public.customer_returns USING btree (customer_id);


--
-- Name: customer_returns_invoice_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_returns_invoice_id_idx ON public.customer_returns USING btree (invoice_id);


--
-- Name: customer_returns_return_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX customer_returns_return_number_key ON public.customer_returns USING btree (return_number);


--
-- Name: customer_returns_shop_id_return_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customer_returns_shop_id_return_date_idx ON public.customer_returns USING btree (shop_id, return_date);


--
-- Name: customers_shop_id_customer_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX customers_shop_id_customer_code_key ON public.customers USING btree (shop_id, customer_code);


--
-- Name: customers_shop_id_customer_name_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX customers_shop_id_customer_name_idx ON public.customers USING btree (shop_id, customer_name);


--
-- Name: damaged_stock_damage_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX damaged_stock_damage_number_key ON public.damaged_stock USING btree (damage_number);


--
-- Name: damaged_stock_shop_id_damage_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX damaged_stock_shop_id_damage_date_idx ON public.damaged_stock USING btree (shop_id, damage_date);


--
-- Name: damaged_stock_shop_id_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX damaged_stock_shop_id_product_id_idx ON public.damaged_stock USING btree (shop_id, product_id);


--
-- Name: damaged_stock_status_damage_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX damaged_stock_status_damage_date_idx ON public.damaged_stock USING btree (status, damage_date);


--
-- Name: data_retention_config_entity_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX data_retention_config_entity_key ON public.data_retention_config USING btree (entity);


--
-- Name: device_registrations_company_id_platform_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX device_registrations_company_id_platform_idx ON public.device_registrations USING btree (company_id, platform);


--
-- Name: device_registrations_is_active_last_active_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX device_registrations_is_active_last_active_at_idx ON public.device_registrations USING btree (is_active, last_active_at);


--
-- Name: device_registrations_user_id_device_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX device_registrations_user_id_device_id_key ON public.device_registrations USING btree (user_id, device_id);


--
-- Name: document_email_outbox_entity_type_entity_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_email_outbox_entity_type_entity_id_created_at_idx ON public.document_email_outbox USING btree (entity_type, entity_id, created_at DESC);


--
-- Name: document_email_outbox_status_next_retry_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_email_outbox_status_next_retry_at_idx ON public.document_email_outbox USING btree (status, next_retry_at);


--
-- Name: document_sequences_doc_type_shop_id_year_month_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX document_sequences_doc_type_shop_id_year_month_key ON public.document_sequences USING btree (doc_type, shop_id, year_month);


--
-- Name: document_series_config_company_default_unique; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX document_series_config_company_default_unique ON public.document_series_config USING btree (company_id, doc_type) WHERE (shop_id IS NULL);


--
-- Name: document_series_config_company_id_doc_type_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_series_config_company_id_doc_type_idx ON public.document_series_config USING btree (company_id, doc_type);


--
-- Name: document_series_config_company_id_shop_id_doc_type_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX document_series_config_company_id_shop_id_doc_type_idx ON public.document_series_config USING btree (company_id, shop_id, doc_type);


--
-- Name: document_series_config_shop_override_unique; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX document_series_config_shop_override_unique ON public.document_series_config USING btree (company_id, shop_id, doc_type) WHERE (shop_id IS NOT NULL);


--
-- Name: email_delivery_log_template_entity_recipient_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX email_delivery_log_template_entity_recipient_key ON public.email_delivery_log USING btree (template_id, entity_type, entity_id, recipient);


--
-- Name: email_sender_domains_company_id_domain_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX email_sender_domains_company_id_domain_key ON public.email_sender_domains USING btree (company_id, domain);


--
-- Name: email_sender_identities_company_id_email_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX email_sender_identities_company_id_email_key ON public.email_sender_identities USING btree (company_id, email);


--
-- Name: email_sender_identities_company_id_is_primary_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX email_sender_identities_company_id_is_primary_idx ON public.email_sender_identities USING btree (company_id, is_primary);


--
-- Name: email_sender_verifications_sender_id_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX email_sender_verifications_sender_id_expires_at_idx ON public.email_sender_verifications USING btree (sender_id, expires_at);


--
-- Name: fx_rates_base_quote_as_of_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX fx_rates_base_quote_as_of_idx ON public.fx_rates USING btree (base, quote, as_of);


--
-- Name: fx_rates_base_quote_as_of_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX fx_rates_base_quote_as_of_key ON public.fx_rates USING btree (base, quote, as_of);


--
-- Name: goods_issue_header_gi_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX goods_issue_header_gi_number_key ON public.goods_issue_header USING btree (gi_number);


--
-- Name: goods_issue_header_shop_id_gi_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_header_shop_id_gi_date_idx ON public.goods_issue_header USING btree (shop_id, gi_date);


--
-- Name: goods_issue_header_shop_id_status_gi_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_header_shop_id_status_gi_date_idx ON public.goods_issue_header USING btree (shop_id, status, gi_date);


--
-- Name: goods_issue_items_gi_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_items_gi_header_id_idx ON public.goods_issue_items USING btree (gi_header_id);


--
-- Name: goods_issue_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_issue_items_product_id_idx ON public.goods_issue_items USING btree (product_id);


--
-- Name: goods_receipt_header_gr_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX goods_receipt_header_gr_number_key ON public.goods_receipt_header USING btree (gr_number);


--
-- Name: goods_receipt_header_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_header_purchase_order_id_idx ON public.goods_receipt_header USING btree (purchase_order_id);


--
-- Name: goods_receipt_header_shop_id_gr_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_header_shop_id_gr_date_idx ON public.goods_receipt_header USING btree (shop_id, gr_date);


--
-- Name: goods_receipt_header_shop_id_status_gr_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_header_shop_id_status_gr_date_idx ON public.goods_receipt_header USING btree (shop_id, status, gr_date);


--
-- Name: goods_receipt_items_gr_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_items_gr_header_id_idx ON public.goods_receipt_items USING btree (gr_header_id);


--
-- Name: goods_receipt_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_items_product_id_idx ON public.goods_receipt_items USING btree (product_id);


--
-- Name: goods_receipt_items_storage_location_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX goods_receipt_items_storage_location_id_idx ON public.goods_receipt_items USING btree (storage_location_id);


--
-- Name: idempotency_keys_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX idempotency_keys_expires_at_idx ON public.idempotency_keys USING btree (expires_at);


--
-- Name: idempotency_keys_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX idempotency_keys_key_key ON public.idempotency_keys USING btree (key);


--
-- Name: idempotency_keys_scope_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX idempotency_keys_scope_idx ON public.idempotency_keys USING btree (scope);


--
-- Name: invoice_header_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_customer_id_idx ON public.invoice_header USING btree (customer_id);


--
-- Name: invoice_header_invoice_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX invoice_header_invoice_number_key ON public.invoice_header USING btree (invoice_number);


--
-- Name: invoice_header_sales_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_sales_order_id_idx ON public.invoice_header USING btree (sales_order_id);


--
-- Name: invoice_header_shop_id_invoice_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_shop_id_invoice_date_idx ON public.invoice_header USING btree (shop_id, invoice_date);


--
-- Name: invoice_header_shop_id_status_invoice_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX invoice_header_shop_id_status_invoice_date_idx ON public.invoice_header USING btree (shop_id, status, invoice_date);


--
-- Name: job_failures_job_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX job_failures_job_id_idx ON public.job_failures USING btree (job_id);


--
-- Name: job_failures_queue_failed_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX job_failures_queue_failed_at_idx ON public.job_failures USING btree (queue, failed_at);


--
-- Name: lifecycle_campaign_enrollments_campaign_key_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX lifecycle_campaign_enrollments_campaign_key_idx ON public.lifecycle_campaign_enrollments USING btree (campaign_key);


--
-- Name: lifecycle_campaign_enrollments_company_id_campaign_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX lifecycle_campaign_enrollments_company_id_campaign_key_key ON public.lifecycle_campaign_enrollments USING btree (company_id, campaign_key);


--
-- Name: lifecycle_campaign_enrollments_scheduled_for_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX lifecycle_campaign_enrollments_scheduled_for_idx ON public.lifecycle_campaign_enrollments USING btree (scheduled_for);


--
-- Name: lifecycle_campaign_enrollments_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX lifecycle_campaign_enrollments_status_idx ON public.lifecycle_campaign_enrollments USING btree (status);


--
-- Name: media_assets_branding_profile_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_branding_profile_id_idx ON public.media_assets USING btree (branding_profile_id);


--
-- Name: media_assets_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_company_id_idx ON public.media_assets USING btree (company_id);


--
-- Name: media_assets_shop_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_shop_id_idx ON public.media_assets USING btree (shop_id);


--
-- Name: media_assets_type_active_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX media_assets_type_active_idx ON public.media_assets USING btree (type, active);


--
-- Name: notification_audit_logs_company_id_action_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_audit_logs_company_id_action_created_at_idx ON public.notification_audit_logs USING btree (company_id, action, created_at);


--
-- Name: notification_audit_logs_user_id_action_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_audit_logs_user_id_action_idx ON public.notification_audit_logs USING btree (user_id, action);


--
-- Name: notification_preferences_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notification_preferences_company_id_idx ON public.notification_preferences USING btree (company_id);


--
-- Name: notification_preferences_user_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX notification_preferences_user_id_key ON public.notification_preferences USING btree (user_id);


--
-- Name: notifications_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_company_id_created_at_idx ON public.notifications USING btree (company_id, created_at);


--
-- Name: notifications_is_read_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_is_read_expires_at_idx ON public.notifications USING btree (is_read, expires_at);


--
-- Name: notifications_type_priority_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_type_priority_idx ON public.notifications USING btree (type, priority);


--
-- Name: notifications_user_id_status_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX notifications_user_id_status_created_at_idx ON public.notifications USING btree (user_id, status, created_at);


--
-- Name: password_reset_requests_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_email_idx ON public.password_reset_requests USING btree (email);


--
-- Name: password_reset_requests_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_expires_at_idx ON public.password_reset_requests USING btree (expires_at);


--
-- Name: password_reset_requests_link_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_link_token_hash_idx ON public.password_reset_requests USING btree (link_token_hash);


--
-- Name: password_reset_requests_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX password_reset_requests_user_id_idx ON public.password_reset_requests USING btree (user_id);


--
-- Name: payment_receipts_invoice_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX payment_receipts_invoice_id_idx ON public.payment_receipts USING btree (invoice_id);


--
-- Name: payment_receipts_receipt_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX payment_receipts_receipt_number_key ON public.payment_receipts USING btree (receipt_number);


--
-- Name: payment_receipts_shop_id_receipt_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX payment_receipts_shop_id_receipt_date_idx ON public.payment_receipts USING btree (shop_id, receipt_date);


--
-- Name: platform_audit_log_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_audit_log_created_at_idx ON public.platform_audit_log USING btree (created_at);


--
-- Name: platform_audit_log_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_audit_log_entity_type_entity_id_idx ON public.platform_audit_log USING btree (entity_type, entity_id);


--
-- Name: platform_audit_log_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_audit_log_user_id_created_at_idx ON public.platform_audit_log USING btree (user_id, created_at);


--
-- Name: platform_notification_reads_admin_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notification_reads_admin_email_idx ON public.platform_notification_reads USING btree (admin_email);


--
-- Name: platform_notification_reads_notification_id_admin_email_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX platform_notification_reads_notification_id_admin_email_key ON public.platform_notification_reads USING btree (notification_id, admin_email);


--
-- Name: platform_notifications_category_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notifications_category_created_at_idx ON public.platform_notifications USING btree (category, created_at);


--
-- Name: platform_notifications_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notifications_created_at_idx ON public.platform_notifications USING btree (created_at);


--
-- Name: platform_notifications_notification_key_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX platform_notifications_notification_key_idx ON public.platform_notifications USING btree (notification_key);


--
-- Name: po_cancel_verifications_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX po_cancel_verifications_expires_at_idx ON public.po_cancel_verifications USING btree (expires_at);


--
-- Name: po_cancel_verifications_po_id_user_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX po_cancel_verifications_po_id_user_id_idx ON public.po_cancel_verifications USING btree (po_id, user_id);


--
-- Name: product_barcodes_company_id_barcode_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX product_barcodes_company_id_barcode_key ON public.product_barcodes USING btree (company_id, barcode);


--
-- Name: product_barcodes_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_barcodes_supplier_id_idx ON public.product_barcodes USING btree (supplier_id);


--
-- Name: product_plants_product_id_shop_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX product_plants_product_id_shop_id_key ON public.product_plants USING btree (product_id, shop_id);


--
-- Name: product_plants_shop_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_plants_shop_id_idx ON public.product_plants USING btree (shop_id);


--
-- Name: product_plants_storage_location_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_plants_storage_location_id_idx ON public.product_plants USING btree (storage_location_id);


--
-- Name: product_specifications_product_id_sort_order_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX product_specifications_product_id_sort_order_idx ON public.product_specifications USING btree (product_id, sort_order);


--
-- Name: products_product_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX products_product_code_key ON public.products USING btree (product_code);


--
-- Name: purchase_order_header_contract_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_contract_id_idx ON public.purchase_order_header USING btree (contract_id);


--
-- Name: purchase_order_header_po_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX purchase_order_header_po_number_key ON public.purchase_order_header USING btree (po_number);


--
-- Name: purchase_order_header_rfq_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_rfq_id_idx ON public.purchase_order_header USING btree (rfq_id);


--
-- Name: purchase_order_header_shop_id_po_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_shop_id_po_date_idx ON public.purchase_order_header USING btree (shop_id, po_date);


--
-- Name: purchase_order_header_shop_id_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_header_shop_id_status_idx ON public.purchase_order_header USING btree (shop_id, status);


--
-- Name: purchase_order_items_po_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_items_po_header_id_idx ON public.purchase_order_items USING btree (po_header_id);


--
-- Name: purchase_order_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_items_product_id_idx ON public.purchase_order_items USING btree (product_id);


--
-- Name: purchase_order_items_rfq_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX purchase_order_items_rfq_item_id_idx ON public.purchase_order_items USING btree (rfq_item_id);


--
-- Name: report_saved_filters_user_id_report_type_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX report_saved_filters_user_id_report_type_idx ON public.report_saved_filters USING btree (user_id, report_type);


--
-- Name: restore_jobs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX restore_jobs_company_id_created_at_idx ON public.restore_jobs USING btree (company_id, created_at);


--
-- Name: rfq_header_rfq_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX rfq_header_rfq_number_key ON public.rfq_header USING btree (rfq_number);


--
-- Name: rfq_header_shop_id_rfq_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX rfq_header_shop_id_rfq_date_idx ON public.rfq_header USING btree (shop_id, rfq_date);


--
-- Name: rfq_items_rfq_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX rfq_items_rfq_header_id_idx ON public.rfq_items USING btree (rfq_header_id);


--
-- Name: rfq_suppliers_rfq_id_supplier_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX rfq_suppliers_rfq_id_supplier_id_key ON public.rfq_suppliers USING btree (rfq_id, supplier_id);


--
-- Name: rfq_suppliers_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX rfq_suppliers_supplier_id_idx ON public.rfq_suppliers USING btree (supplier_id);


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: sales_order_header_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_header_customer_id_idx ON public.sales_order_header USING btree (customer_id);


--
-- Name: sales_order_header_shop_id_fulfillment_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_header_shop_id_fulfillment_status_idx ON public.sales_order_header USING btree (shop_id, fulfillment_status);


--
-- Name: sales_order_header_shop_id_order_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_header_shop_id_order_date_idx ON public.sales_order_header USING btree (shop_id, order_date);


--
-- Name: sales_order_header_so_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_order_header_so_number_key ON public.sales_order_header USING btree (so_number);


--
-- Name: sales_order_items_so_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_order_items_so_header_id_idx ON public.sales_order_items USING btree (so_header_id);


--
-- Name: sales_quote_header_customer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_header_customer_id_idx ON public.sales_quote_header USING btree (customer_id);


--
-- Name: sales_quote_header_portal_token_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_quote_header_portal_token_key ON public.sales_quote_header USING btree (portal_token);


--
-- Name: sales_quote_header_quote_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_quote_header_quote_number_key ON public.sales_quote_header USING btree (quote_number);


--
-- Name: sales_quote_header_sales_order_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX sales_quote_header_sales_order_id_key ON public.sales_quote_header USING btree (sales_order_id);


--
-- Name: sales_quote_header_shop_id_quote_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_header_shop_id_quote_date_idx ON public.sales_quote_header USING btree (shop_id, quote_date);


--
-- Name: sales_quote_header_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_header_status_idx ON public.sales_quote_header USING btree (status);


--
-- Name: sales_quote_items_quote_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sales_quote_items_quote_header_id_idx ON public.sales_quote_items USING btree (quote_header_id);


--
-- Name: scan_logs_barcode_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_barcode_idx ON public.scan_logs USING btree (barcode);


--
-- Name: scan_logs_company_id_created_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_company_id_created_at_idx ON public.scan_logs USING btree (company_id, created_at);


--
-- Name: scan_logs_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_product_id_idx ON public.scan_logs USING btree (product_id);


--
-- Name: scan_logs_session_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX scan_logs_session_id_idx ON public.scan_logs USING btree (session_id);


--
-- Name: sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sessions_expires_at_idx ON public.sessions USING btree (expires_at);


--
-- Name: sessions_user_id_revoked_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX sessions_user_id_revoked_at_idx ON public.sessions USING btree (user_id, revoked_at);


--
-- Name: shops_shop_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX shops_shop_number_key ON public.shops USING btree (shop_number);


--
-- Name: signup_verifications_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX signup_verifications_email_idx ON public.signup_verifications USING btree (email);


--
-- Name: signup_verifications_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX signup_verifications_expires_at_idx ON public.signup_verifications USING btree (expires_at);


--
-- Name: signup_verifications_session_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX signup_verifications_session_token_hash_idx ON public.signup_verifications USING btree (session_token_hash);


--
-- Name: stock_count_items_product_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_count_items_product_id_idx ON public.stock_count_items USING btree (product_id);


--
-- Name: stock_count_items_session_id_product_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_count_items_session_id_product_id_key ON public.stock_count_items USING btree (session_id, product_id);


--
-- Name: stock_count_sessions_company_id_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_count_sessions_company_id_status_idx ON public.stock_count_sessions USING btree (company_id, status);


--
-- Name: stock_count_sessions_session_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_count_sessions_session_number_key ON public.stock_count_sessions USING btree (session_number);


--
-- Name: stock_count_sessions_shop_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_count_sessions_shop_id_idx ON public.stock_count_sessions USING btree (shop_id);


--
-- Name: stock_ledger_idempotency_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_ledger_idempotency_key_key ON public.stock_ledger USING btree (idempotency_key);


--
-- Name: stock_ledger_shop_id_product_id_transaction_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_ledger_shop_id_product_id_transaction_date_idx ON public.stock_ledger USING btree (shop_id, product_id, transaction_date);


--
-- Name: stock_summary_shop_id_product_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_summary_shop_id_product_id_key ON public.stock_summary USING btree (shop_id, product_id);


--
-- Name: stock_transfer_header_from_shop_id_transfer_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_header_from_shop_id_transfer_date_idx ON public.stock_transfer_header USING btree (from_shop_id, transfer_date);


--
-- Name: stock_transfer_header_status_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_header_status_idx ON public.stock_transfer_header USING btree (status);


--
-- Name: stock_transfer_header_to_shop_id_transfer_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_header_to_shop_id_transfer_date_idx ON public.stock_transfer_header USING btree (to_shop_id, transfer_date);


--
-- Name: stock_transfer_header_transfer_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX stock_transfer_header_transfer_number_key ON public.stock_transfer_header USING btree (transfer_number);


--
-- Name: stock_transfer_items_transfer_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX stock_transfer_items_transfer_id_idx ON public.stock_transfer_items USING btree (transfer_id);


--
-- Name: storage_locations_shop_id_code_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX storage_locations_shop_id_code_idx ON public.storage_locations USING btree (shop_id, code);


--
-- Name: storage_locations_shop_id_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX storage_locations_shop_id_code_key ON public.storage_locations USING btree (shop_id, code);


--
-- Name: subscription_invoices_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_invoices_company_id_idx ON public.subscription_invoices USING btree (company_id);


--
-- Name: subscription_invoices_invoice_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX subscription_invoices_invoice_number_key ON public.subscription_invoices USING btree (invoice_number);


--
-- Name: subscription_invoices_issued_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_invoices_issued_at_idx ON public.subscription_invoices USING btree (issued_at);


--
-- Name: subscription_payments_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_payments_company_id_idx ON public.subscription_payments USING btree (company_id);


--
-- Name: subscription_payments_invoice_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX subscription_payments_invoice_id_idx ON public.subscription_payments USING btree (invoice_id);


--
-- Name: subscription_payments_razorpay_order_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX subscription_payments_razorpay_order_id_key ON public.subscription_payments USING btree (razorpay_order_id);


--
-- Name: subscription_payments_razorpay_payment_id_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX subscription_payments_razorpay_payment_id_key ON public.subscription_payments USING btree (razorpay_payment_id);


--
-- Name: supplier_bill_header_bill_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_bill_header_bill_number_key ON public.supplier_bill_header USING btree (bill_number);


--
-- Name: supplier_bill_header_goods_receipt_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_goods_receipt_id_idx ON public.supplier_bill_header USING btree (goods_receipt_id);


--
-- Name: supplier_bill_header_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_purchase_order_id_idx ON public.supplier_bill_header USING btree (purchase_order_id);


--
-- Name: supplier_bill_header_shop_id_bill_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_shop_id_bill_date_idx ON public.supplier_bill_header USING btree (shop_id, bill_date);


--
-- Name: supplier_bill_header_shop_id_status_bill_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_shop_id_status_bill_date_idx ON public.supplier_bill_header USING btree (shop_id, status, bill_date);


--
-- Name: supplier_bill_header_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_header_supplier_id_idx ON public.supplier_bill_header USING btree (supplier_id);


--
-- Name: supplier_bill_items_bill_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_bill_items_bill_header_id_idx ON public.supplier_bill_items USING btree (bill_header_id);


--
-- Name: supplier_payments_payment_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_payments_payment_number_key ON public.supplier_payments USING btree (payment_number);


--
-- Name: supplier_payments_shop_id_payment_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_payments_shop_id_payment_date_idx ON public.supplier_payments USING btree (shop_id, payment_date);


--
-- Name: supplier_payments_supplier_bill_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_payments_supplier_bill_id_idx ON public.supplier_payments USING btree (supplier_bill_id);


--
-- Name: supplier_quote_header_quote_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_quote_header_quote_number_key ON public.supplier_quote_header USING btree (quote_number);


--
-- Name: supplier_quote_header_rfq_id_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_header_rfq_id_supplier_id_idx ON public.supplier_quote_header USING btree (rfq_id, supplier_id);


--
-- Name: supplier_quote_header_shop_id_quote_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_header_shop_id_quote_date_idx ON public.supplier_quote_header USING btree (shop_id, quote_date);


--
-- Name: supplier_quote_items_quote_header_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_items_quote_header_id_idx ON public.supplier_quote_items USING btree (quote_header_id);


--
-- Name: supplier_quote_items_rfq_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_quote_items_rfq_item_id_idx ON public.supplier_quote_items USING btree (rfq_item_id);


--
-- Name: supplier_return_images_return_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_images_return_id_idx ON public.supplier_return_images USING btree (return_id);


--
-- Name: supplier_return_images_return_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_images_return_item_id_idx ON public.supplier_return_images USING btree (return_item_id);


--
-- Name: supplier_return_items_goods_receipt_item_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_items_goods_receipt_item_id_idx ON public.supplier_return_items USING btree (goods_receipt_item_id);


--
-- Name: supplier_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_return_items_return_id_idx ON public.supplier_return_items USING btree (return_id);


--
-- Name: supplier_returns_goods_receipt_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_goods_receipt_id_idx ON public.supplier_returns USING btree (goods_receipt_id);


--
-- Name: supplier_returns_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_purchase_order_id_idx ON public.supplier_returns USING btree (purchase_order_id);


--
-- Name: supplier_returns_return_number_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX supplier_returns_return_number_key ON public.supplier_returns USING btree (return_number);


--
-- Name: supplier_returns_shop_id_return_date_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_shop_id_return_date_idx ON public.supplier_returns USING btree (shop_id, return_date);


--
-- Name: supplier_returns_supplier_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX supplier_returns_supplier_id_idx ON public.supplier_returns USING btree (supplier_id);


--
-- Name: suppliers_company_id_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX suppliers_company_id_idx ON public.suppliers USING btree (company_id);


--
-- Name: suppliers_deleted_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX suppliers_deleted_at_idx ON public.suppliers USING btree (deleted_at);


--
-- Name: suppliers_supplier_code_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX suppliers_supplier_code_key ON public.suppliers USING btree (supplier_code);


--
-- Name: suppliers_supplier_name_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX suppliers_supplier_name_idx ON public.suppliers USING btree (supplier_name);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: trusted_mfa_devices_token_hash_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX trusted_mfa_devices_token_hash_key ON public.trusted_mfa_devices USING btree (token_hash);


--
-- Name: trusted_mfa_devices_user_id_expires_at_revoked_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX trusted_mfa_devices_user_id_expires_at_revoked_at_idx ON public.trusted_mfa_devices USING btree (user_id, expires_at, revoked_at);


--
-- Name: user_backup_codes_user_id_consumed_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_backup_codes_user_id_consumed_at_idx ON public.user_backup_codes USING btree (user_id, consumed_at);


--
-- Name: user_invitations_email_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_invitations_email_idx ON public.user_invitations USING btree (email);


--
-- Name: user_invitations_expires_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_invitations_expires_at_idx ON public.user_invitations USING btree (expires_at);


--
-- Name: user_invitations_token_hash_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX user_invitations_token_hash_idx ON public.user_invitations USING btree (token_hash);


--
-- Name: users_deleted_at_idx; Type: INDEX; Schema: public; Owner: retail
--

CREATE INDEX users_deleted_at_idx ON public.users USING btree (deleted_at);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: retail
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: alert_events alert_events_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: approval_comments approval_comments_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.approval_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_comments approval_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_comments
    ADD CONSTRAINT approval_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_escalations approval_escalations_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_escalations
    ADD CONSTRAINT approval_escalations_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.approval_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_escalations approval_escalations_escalated_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_escalations
    ADD CONSTRAINT approval_escalations_escalated_to_fkey FOREIGN KEY (escalated_to) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_requests approval_requests_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_requests approval_requests_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: approval_requests approval_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_logs audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: auth_challenges auth_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_artifacts backup_artifacts_backup_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_artifacts
    ADD CONSTRAINT backup_artifacts_backup_job_id_fkey FOREIGN KEY (backup_job_id) REFERENCES public.backup_jobs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: backup_artifacts backup_artifacts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_artifacts
    ADD CONSTRAINT backup_artifacts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_jobs backup_jobs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_provider_credentials backup_provider_credentials_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.backup_provider_credentials
    ADD CONSTRAINT backup_provider_credentials_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: barcode_audit_logs barcode_audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_audit_logs
    ADD CONSTRAINT barcode_audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: barcode_history barcode_history_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.barcode_history
    ADD CONSTRAINT barcode_history_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: branding_profiles branding_profiles_letterhead_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_letterhead_asset_id_fkey FOREIGN KEY (letterhead_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_logo_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_logo_asset_id_fkey FOREIGN KEY (logo_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_seal_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_seal_asset_id_fkey FOREIGN KEY (seal_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_signature_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_signature_asset_id_fkey FOREIGN KEY (signature_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: branding_profiles branding_profiles_watermark_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.branding_profiles
    ADD CONSTRAINT branding_profiles_watermark_asset_id_fkey FOREIGN KEY (watermark_asset_id) REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: companies companies_branding_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_branding_profile_id_fkey FOREIGN KEY (branding_profile_id) REFERENCES public.branding_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: company_engagement_snapshots company_engagement_snapshots_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_engagement_snapshots
    ADD CONSTRAINT company_engagement_snapshots_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_settings company_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contract_header contract_header_quotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_quotation_id_fkey FOREIGN KEY (quotation_id) REFERENCES public.supplier_quote_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contract_header contract_header_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contract_header contract_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contract_header contract_header_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_header
    ADD CONSTRAINT contract_header_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contract_items contract_items_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_items
    ADD CONSTRAINT contract_items_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contract_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contract_items contract_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.contract_items
    ADD CONSTRAINT contract_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cost_layers cost_layers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.cost_layers
    ADD CONSTRAINT cost_layers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cost_layers cost_layers_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.cost_layers
    ADD CONSTRAINT cost_layers_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: credit_notes credit_notes_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: credit_notes credit_notes_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: credit_notes credit_notes_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.customer_returns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: credit_notes credit_notes_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_return_items customer_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_return_items customer_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.customer_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_returns customer_returns_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_returns customer_returns_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_returns customer_returns_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_returns customer_returns_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customers customers_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: damaged_stock damaged_stock_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.damaged_stock
    ADD CONSTRAINT damaged_stock_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: damaged_stock damaged_stock_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.damaged_stock
    ADD CONSTRAINT damaged_stock_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: device_registrations device_registrations_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: device_registrations device_registrations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.device_registrations
    ADD CONSTRAINT device_registrations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_sequences document_sequences_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: document_series_config document_series_config_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_series_config
    ADD CONSTRAINT document_series_config_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_series_config document_series_config_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.document_series_config
    ADD CONSTRAINT document_series_config_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sender_domains email_sender_domains_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_domains
    ADD CONSTRAINT email_sender_domains_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sender_identities email_sender_identities_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_identities
    ADD CONSTRAINT email_sender_identities_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_sender_identities email_sender_identities_domain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_identities
    ADD CONSTRAINT email_sender_identities_domain_id_fkey FOREIGN KEY (domain_id) REFERENCES public.email_sender_domains(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: email_sender_verifications email_sender_verifications_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.email_sender_verifications
    ADD CONSTRAINT email_sender_verifications_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.email_sender_identities(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_issue_header goods_issue_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_header
    ADD CONSTRAINT goods_issue_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_issue_items goods_issue_items_gi_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_gi_header_id_fkey FOREIGN KEY (gi_header_id) REFERENCES public.goods_issue_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_issue_items goods_issue_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_issue_items
    ADD CONSTRAINT goods_issue_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_header goods_receipt_header_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_header
    ADD CONSTRAINT goods_receipt_header_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: goods_receipt_header goods_receipt_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_header
    ADD CONSTRAINT goods_receipt_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_items goods_receipt_items_gr_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_gr_header_id_fkey FOREIGN KEY (gr_header_id) REFERENCES public.goods_receipt_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_receipt_items goods_receipt_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_items goods_receipt_items_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoice_header invoice_header_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoice_header invoice_header_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoice_header invoice_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.invoice_header
    ADD CONSTRAINT invoice_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lifecycle_campaign_enrollments lifecycle_campaign_enrollments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.lifecycle_campaign_enrollments
    ADD CONSTRAINT lifecycle_campaign_enrollments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_assets media_assets_branding_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_branding_profile_id_fkey FOREIGN KEY (branding_profile_id) REFERENCES public.branding_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notification_audit_logs notification_audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_audit_logs
    ADD CONSTRAINT notification_audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_audit_logs notification_audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_audit_logs
    ADD CONSTRAINT notification_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notification_preferences notification_preferences_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_reset_requests password_reset_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.password_reset_requests
    ADD CONSTRAINT password_reset_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_receipts payment_receipts_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_receipts payment_receipts_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_audit_log platform_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_audit_log
    ADD CONSTRAINT platform_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_notification_reads platform_notification_reads_notification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.platform_notification_reads
    ADD CONSTRAINT platform_notification_reads_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES public.platform_notifications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: po_cancel_verifications po_cancel_verifications_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.po_cancel_verifications
    ADD CONSTRAINT po_cancel_verifications_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_barcodes product_barcodes_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_barcodes product_barcodes_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_plants product_plants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_plants product_plants_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_plants product_plants_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_plants
    ADD CONSTRAINT product_plants_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_specifications product_specifications_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.product_specifications
    ADD CONSTRAINT product_specifications_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_header purchase_order_header_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contract_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_header purchase_order_header_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_header purchase_order_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_header
    ADD CONSTRAINT purchase_order_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_po_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_po_header_id_fkey FOREIGN KEY (po_header_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_rfq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_rfq_item_id_fkey FOREIGN KEY (rfq_item_id) REFERENCES public.rfq_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: report_saved_filters report_saved_filters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.report_saved_filters
    ADD CONSTRAINT report_saved_filters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_artifact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_artifact_id_fkey FOREIGN KEY (artifact_id) REFERENCES public.backup_artifacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: restore_jobs restore_jobs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_header rfq_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_header
    ADD CONSTRAINT rfq_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: rfq_items rfq_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rfq_items rfq_items_rfq_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_rfq_header_id_fkey FOREIGN KEY (rfq_header_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_suppliers rfq_suppliers_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_suppliers
    ADD CONSTRAINT rfq_suppliers_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rfq_suppliers rfq_suppliers_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.rfq_suppliers
    ADD CONSTRAINT rfq_suppliers_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_header sales_order_header_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_header
    ADD CONSTRAINT sales_order_header_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_header sales_order_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_header
    ADD CONSTRAINT sales_order_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_items sales_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_order_items sales_order_items_so_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_so_header_id_fkey FOREIGN KEY (so_header_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_quote_header sales_quote_header_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_quote_header sales_quote_header_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sales_quote_header sales_quote_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_header
    ADD CONSTRAINT sales_quote_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_quote_items sales_quote_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_quote_items sales_quote_items_quote_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sales_quote_items
    ADD CONSTRAINT sales_quote_items_quote_header_id_fkey FOREIGN KEY (quote_header_id) REFERENCES public.sales_quote_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scan_logs scan_logs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.scan_logs
    ADD CONSTRAINT scan_logs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shops shops_branding_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_branding_profile_id_fkey FOREIGN KEY (branding_profile_id) REFERENCES public.branding_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shops shops_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_count_items stock_count_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_count_items stock_count_items_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.stock_count_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_ledger stock_ledger_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_ledger stock_ledger_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_ledger
    ADD CONSTRAINT stock_ledger_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_summary stock_summary_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_summary
    ADD CONSTRAINT stock_summary_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_summary stock_summary_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_summary
    ADD CONSTRAINT stock_summary_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_header stock_transfer_header_from_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_from_shop_id_fkey FOREIGN KEY (from_shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_header stock_transfer_header_from_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_from_storage_location_id_fkey FOREIGN KEY (from_storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_transfer_header stock_transfer_header_to_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_to_shop_id_fkey FOREIGN KEY (to_shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_header stock_transfer_header_to_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_header
    ADD CONSTRAINT stock_transfer_header_to_storage_location_id_fkey FOREIGN KEY (to_storage_location_id) REFERENCES public.storage_locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_transfer_items stock_transfer_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_transfer_items stock_transfer_items_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES public.stock_transfer_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: storage_locations storage_locations_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.storage_locations
    ADD CONSTRAINT storage_locations_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_invoices subscription_invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_invoices
    ADD CONSTRAINT subscription_invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_payments subscription_payments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscription_payments subscription_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.subscription_invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_bill_header supplier_bill_header_goods_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_goods_receipt_id_fkey FOREIGN KEY (goods_receipt_id) REFERENCES public.goods_receipt_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_bill_header supplier_bill_header_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_bill_header supplier_bill_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_bill_header supplier_bill_header_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_header
    ADD CONSTRAINT supplier_bill_header_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_bill_items supplier_bill_items_bill_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_items
    ADD CONSTRAINT supplier_bill_items_bill_header_id_fkey FOREIGN KEY (bill_header_id) REFERENCES public.supplier_bill_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_bill_items supplier_bill_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_bill_items
    ADD CONSTRAINT supplier_bill_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_payments supplier_payments_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_payments supplier_payments_supplier_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_supplier_bill_id_fkey FOREIGN KEY (supplier_bill_id) REFERENCES public.supplier_bill_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_quote_header supplier_quote_header_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq_header(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_quote_header supplier_quote_header_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_quote_header supplier_quote_header_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_header
    ADD CONSTRAINT supplier_quote_header_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_quote_items supplier_quote_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_quote_items supplier_quote_items_quote_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_quote_header_id_fkey FOREIGN KEY (quote_header_id) REFERENCES public.supplier_quote_header(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_quote_items supplier_quote_items_rfq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_quote_items
    ADD CONSTRAINT supplier_quote_items_rfq_item_id_fkey FOREIGN KEY (rfq_item_id) REFERENCES public.rfq_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_return_images supplier_return_images_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_images
    ADD CONSTRAINT supplier_return_images_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.supplier_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_return_images supplier_return_images_return_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_images
    ADD CONSTRAINT supplier_return_images_return_item_id_fkey FOREIGN KEY (return_item_id) REFERENCES public.supplier_return_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_return_items supplier_return_items_goods_receipt_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_goods_receipt_item_id_fkey FOREIGN KEY (goods_receipt_item_id) REFERENCES public.goods_receipt_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_return_items supplier_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_return_items supplier_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.supplier_returns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_returns supplier_returns_goods_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_goods_receipt_id_fkey FOREIGN KEY (goods_receipt_id) REFERENCES public.goods_receipt_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_returns supplier_returns_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_order_header(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_returns supplier_returns_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_returns supplier_returns_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: suppliers suppliers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trusted_mfa_devices trusted_mfa_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.trusted_mfa_devices
    ADD CONSTRAINT trusted_mfa_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_backup_codes user_backup_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_backup_codes
    ADD CONSTRAINT user_backup_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_invitations user_invitations_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_invitations user_invitations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_invitations user_invitations_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_shop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: retail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_shop_id_fkey FOREIGN KEY (shop_id) REFERENCES public.shops(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: retail
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: customers rls_customers_company; Type: POLICY; Schema: public; Owner: retail
--

CREATE POLICY rls_customers_company ON public.customers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (EXISTS ( SELECT 1
   FROM public.shops s
  WHERE ((s.id = customers.shop_id) AND (s.company_id = (current_setting('app.current_company_id'::text, true))::uuid)))))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (EXISTS ( SELECT 1
   FROM public.shops s
  WHERE ((s.id = customers.shop_id) AND (s.company_id = (current_setting('app.current_company_id'::text, true))::uuid))))));


--
-- Name: shops rls_shops_company; Type: POLICY; Schema: public; Owner: retail
--

CREATE POLICY rls_shops_company ON public.shops USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (company_id = (current_setting('app.current_company_id'::text, true))::uuid)));


--
-- Name: sales_order_header rls_so_company; Type: POLICY; Schema: public; Owner: retail
--

CREATE POLICY rls_so_company ON public.sales_order_header USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (EXISTS ( SELECT 1
   FROM public.shops s
  WHERE ((s.id = sales_order_header.shop_id) AND (s.company_id = (current_setting('app.current_company_id'::text, true))::uuid)))))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (EXISTS ( SELECT 1
   FROM public.shops s
  WHERE ((s.id = sales_order_header.shop_id) AND (s.company_id = (current_setting('app.current_company_id'::text, true))::uuid))))));


--
-- Name: storage_locations rls_storage_locations_company; Type: POLICY; Schema: public; Owner: retail
--

CREATE POLICY rls_storage_locations_company ON public.storage_locations USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (EXISTS ( SELECT 1
   FROM public.shops s
  WHERE ((s.id = storage_locations.shop_id) AND (s.company_id = (current_setting('app.current_company_id'::text, true))::uuid)))))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (EXISTS ( SELECT 1
   FROM public.shops s
  WHERE ((s.id = storage_locations.shop_id) AND (s.company_id = (current_setting('app.current_company_id'::text, true))::uuid))))));


--
-- Name: suppliers rls_suppliers_company; Type: POLICY; Schema: public; Owner: retail
--

CREATE POLICY rls_suppliers_company ON public.suppliers USING (((company_id IS NULL) OR (company_id = (current_setting('app.current_company_id'::text, true))::uuid)));


--
-- Name: sales_order_header; Type: ROW SECURITY; Schema: public; Owner: retail
--

ALTER TABLE public.sales_order_header ENABLE ROW LEVEL SECURITY;

--
-- Name: shops; Type: ROW SECURITY; Schema: public; Owner: retail
--

ALTER TABLE public.shops ENABLE ROW LEVEL SECURITY;

--
-- Name: storage_locations; Type: ROW SECURITY; Schema: public; Owner: retail
--

ALTER TABLE public.storage_locations ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: retail
--

ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict HuMp4xhl18BrgnJQfTJyKOgddz2miYnssWamQzGgs6PHmH4lYLOJ4kLJjtD1udA

